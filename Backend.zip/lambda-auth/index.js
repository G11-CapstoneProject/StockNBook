const mysql = require("mysql2/promise");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const crypto = require("crypto");
// ===== BEGIN StockNBook identification numbers (identical in lambda-auth, lambda-pos, lambda-products, lambda-rental-inventory) =====
const identifiers = (() => {
    /*
     * StockNBook standardized identification numbers.
     *
     *   Order      STORE-BRANCH-MMDDYY-XXXX   e.g. SPS-B4-110326-0001
     *   Product    STORE-BRANCH-PRD-XXXX      e.g. SPS-B4-PRD-0001  (one per product type)
     *   Equipment  STORE-BRANCH-EQP-XXXX      e.g. SPS-B4-EQP-0001  (one per physical rental unit)
     *   Employee   STORE_ID-BRANCH_ID-MN/SF-XXXX  e.g. 6-12-MN-0001 / 6-12-SF-0001
     *
     * Other Lambdas retain the existing order/product/equipment numbering.
     * Employee IDs are issued only by lambda-auth and have separate MN/SF sequences.
     *
     * Existing records are never modified: old Order IDs, Product Nos., equipment
     * numbers, store codes and branch codes stay exactly as they are. Only records
     * created from now on receive these formats.
     *
     * Sequences are at least four digits. They are never truncated: after 9999 the
     * next number is 10000, so an identifier can never repeat.
     */

    const CODE_PATTERN = /^[A-Z0-9]{2,8}$/;
    const SEQUENCE_DIGITS = 4;

    const PATTERNS = Object.freeze({
        order: /^([A-Z0-9]{2,8})-([A-Z0-9]{2,8})-(\d{6})-(\d{4,})$/,
        product: /^([A-Z0-9]{2,8})-([A-Z0-9]{2,8})-PRD-(\d{4,})$/,
        equipment: /^([A-Z0-9]{2,8})-([A-Z0-9]{2,8})-EQP-(\d{4,})$/,
        employee: /^(\d+)-(\d+)-(MN|SF)-(\d{4,})$/,
        // Product Nos. created before standardization, e.g. SPS-IMS-001.
        legacyProduct: /^([A-Za-z0-9]{2,8})-([A-Za-z0-9]{2,8})-(\d{3,})$/,
    });

    /* ------------------------------------------------------------------ */
    /* Store initials (unchanged StockNBook rule, e.g. Sparkling Party     */
    /* Supplies - Antipolo City = SPS). Existing store codes are kept.    */
    /* ------------------------------------------------------------------ */

    const STORE_CODE_STOP_WORDS = new Set([
        "THE", "AND", "OF", "STORE", "SHOP", "ENTERPRISE", "ENTERPRISES",
        "TRADING", "COMPANY", "CO", "INC", "CORP", "CORPORATION", "CITY",
    ]);

    function normalizeCodeWords(value) {
        return String(value || "")
            .normalize("NFKD")
            .replace(/[\u0300-\u036f]/g, "")
            .toUpperCase()
            .replace(/[^A-Z0-9]+/g, " ")
            .trim()
            .split(/\s+/)
            .filter(Boolean);
    }

    function compactAlpha(value) {
        return normalizeCodeWords(value).join("").replace(/[^A-Z]/g, "");
    }

    function codeFromSingleWord(word) {
        const clean = String(word || "").replace(/[^A-Z]/g, "");
        if (!clean) return "XXX";
        const first = clean.charAt(0);
        const consonants = clean.slice(1).replace(/[AEIOU]/g, "");
        let code = `${first}${consonants}`.slice(0, 3);
        if (code.length < 3) code = `${code}${clean.slice(1)}`.slice(0, 3);
        return code.padEnd(3, "X");
    }

    function buildReadableCode(value, stopWords, fallback = "XXX") {
        const words = normalizeCodeWords(value).filter((word) => !stopWords.has(word));
        if (words.length >= 3) return words.slice(0, 3).map((word) => word.charAt(0)).join("");
        if (words.length === 2) return `${words[0].charAt(0)}${codeFromSingleWord(words[1]).slice(0, 2)}`;
        if (words.length === 1) return codeFromSingleWord(words[0]);
        return codeFromSingleWord(normalizeCodeWords(fallback)[0] || "XXX");
    }

    function storeCodeCandidates(storeName, slug, storeId) {
        const source = storeName || slug || `Store ${storeId}`;
        const base = buildReadableCode(source, STORE_CODE_STOP_WORDS, "STR");
        const compact = compactAlpha(source);
        const candidates = [base];
        for (let length = 4; length <= 7; length += 1) {
            const candidate = `${base}${compact.slice(0, Math.max(0, length - 3))}`.slice(0, length);
            if (candidate && !candidates.includes(candidate)) candidates.push(candidate);
        }
        for (let suffix = 0; suffix < 26; suffix += 1) candidates.push(`${base}${String.fromCharCode(65 + suffix)}`);
        return candidates;
    }

    /* ------------------------------------------------------------------ */
    /* Branch initials, taken from the branch name:                       */
    /*   Moon Walk Branch       -> MW   (initials of the words)           */
    /*   Moonwalk Branch        -> MW   (first letter + next syllable)    */
    /*   Branch 4 Retail Branch -> B4   (numbered branch)                 */
    /*   Main Retail Branch     -> MAIN (one-syllable word kept whole)    */
    /* Generic words such as Branch/Retail/Store are ignored. Initials are */
    /* saved in branches.branch_code when the branch is created and      */
    /* never change afterwards, even if the branch is renamed.            */
    /* ------------------------------------------------------------------ */

    const BRANCH_INITIAL_STOP_WORDS = new Set([
        "THE", "AND", "OF", "BRANCH", "BRANCHES", "BR", "RETAIL", "OUTLET",
        "LOCATION", "STORE", "SHOP",
    ]);
    const VOWELS = new Set(["A", "E", "I", "O", "U"]);
    const CONSONANT_DIGRAPHS = new Set(["CH", "SH", "TH", "PH", "WH", "CK", "GH"]);

    function isVowelAt(word, index) {
        const letter = word.charAt(index);
        if (VOWELS.has(letter)) return true;
        // Y acts as a vowel after a consonant (e.g. "Lyceum").
        return letter === "Y" && index > 0 && !VOWELS.has(word.charAt(index - 1));
    }

    // First letter of the word's second syllable, or "" for one-syllable words.
    function secondSyllableInitial(rawWord) {
        const word = String(rawWord || "").replace(/[^A-Z]/g, "");
        let index = 0;
        while (index < word.length && !isVowelAt(word, index)) index += 1;
        if (index >= word.length) return "";
        while (index < word.length && isVowelAt(word, index)) index += 1;
        const clusterStart = index;
        while (index < word.length && !isVowelAt(word, index)) index += 1;
        if (index >= word.length) return "";
        const cluster = word.slice(clusterStart, index);
        if (cluster.length <= 1) return cluster;
        // Two or more consonants split after the first consonant (moon|walk),
        // keeping common digraphs together (south|west).
        const firstUnit = CONSONANT_DIGRAPHS.has(cluster.slice(0, 2)) ? 2 : 1;
        return cluster.length > firstUnit ? cluster.charAt(firstUnit) : cluster.charAt(0);
    }

    function branchInitials(branchName) {
        const words = normalizeCodeWords(branchName).filter((word) => !BRANCH_INITIAL_STOP_WORDS.has(word));
        const numbers = words.filter((word) => /^\d+$/.test(word)).join("");
        const named = words.filter((word) => !/^\d+$/.test(word));
        let base;
        if (named.length === 0) {
            base = numbers ? `B${numbers}` : "BR";
        } else if (named.length >= 2) {
            base = `${named.map((word) => word.charAt(0)).join("")}${numbers}`;
        } else {
            const word = named[0];
            const next = secondSyllableInitial(word);
            base = `${next ? `${word.charAt(0)}${next}` : word}${numbers}`;
        }
        base = base.replace(/[^A-Z0-9]/g, "").slice(0, 8);
        return base.length >= 2 ? base : `${base}BR`.slice(0, 2);
    }

    // Deterministic fallbacks when two branches of the same store share initials:
    // MW, MW2, MW3 ... or, for codes ending in a digit, B4A, B4B ...
    function branchCodeCandidates(branchName) {
        const base = branchInitials(branchName);
        const candidates = [base];
        const suffixes = /\d$/.test(base)
            ? Array.from({ length: 26 }, (_, i) => String.fromCharCode(65 + i))
            : Array.from({ length: 98 }, (_, i) => String(i + 2));
        for (const suffix of suffixes) {
            const candidate = `${base.slice(0, 8 - suffix.length)}${suffix}`;
            if (!candidates.includes(candidate)) candidates.push(candidate);
        }
        return candidates;
    }

    /* ------------------------------------------------------------------ */
    /* Formatting                                                          */
    /* ------------------------------------------------------------------ */

    function formatSequence(sequence) {
        const value = Number(sequence);
        if (!Number.isSafeInteger(value) || value < 1) throw new Error("Invalid identification sequence.");
        return String(value).padStart(SEQUENCE_DIGITS, "0"); // never truncates (10000 stays 10000)
    }

    function orderDatePart(orderDate) {
        const match = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(orderDate || ""));
        if (!match) throw new Error("A valid order date (YYYY-MM-DD) is required for the Order ID.");
        return `${match[2]}${match[3]}${match[1].slice(2)}`; // MMDDYY
    }

    function assertCodes(storeCode, branchCode) {
        if (!CODE_PATTERN.test(String(storeCode || "")) || !CODE_PATTERN.test(String(branchCode || ""))) {
            throw new Error("Store/branch initials are missing or invalid for identification numbers.");
        }
    }

    function buildOrderId(storeCode, branchCode, orderDate, sequence) {
        assertCodes(storeCode, branchCode);
        return `${storeCode}-${branchCode}-${orderDatePart(orderDate)}-${formatSequence(sequence)}`;
    }
    function buildProductNumber(storeCode, branchCode, sequence) {
        assertCodes(storeCode, branchCode);
        return `${storeCode}-${branchCode}-PRD-${formatSequence(sequence)}`;
    }
    function buildEquipmentNumber(storeCode, branchCode, sequence) {
        assertCodes(storeCode, branchCode);
        return `${storeCode}-${branchCode}-EQP-${formatSequence(sequence)}`;
    }
    function buildEmployeeCode(storeId, branchId, roleCode, sequence) {
        if (![storeId, branchId].every((value) => Number.isSafeInteger(Number(value)) && Number(value) > 0)) {
            throw new Error("A valid store number and branch number are required for Employee IDs.");
        }
        if (roleCode !== "MN" && roleCode !== "SF") {
            throw new Error("Employee ID role must be MN (manager) or SF (staff).");
        }
        return `${Number(storeId)}-${Number(branchId)}-${roleCode}-${formatSequence(sequence)}`;
    }

    function trailingSequence(value) {
        const match = /-(\d+)$/.exec(String(value || ""));
        return match ? Number(match[1]) : 0;
    }

    /* ------------------------------------------------------------------ */
    /* Codes and sequences (stocknbook_v2)                                 */
    /* Store and branch initials are stored in stores.store_code and       */
    /* branches.branch_code. Sequences are derived from the identifiers    */
    /* already saved; a row lock on the branch serializes allocation and   */
    /* the unique keys on each identifier column reject any duplicate.     */
    /* ------------------------------------------------------------------ */

    // stocknbook_v2 already contains every column these identifiers use.
    async function ensureIdentifierSchema() {
        return true;
    }

    async function lockBranch(connection, storeId, branchId) {
        const [rows] = await connection.execute(
            "SELECT id FROM branches WHERE id = ? AND store_id = ? FOR UPDATE",
            [branchId, storeId]
        );
        if (!rows.length) throw new Error("The branch does not belong to this store.");
    }

    async function getIdentifierCodes(connection, storeId, branchId) {
        const [rows] = await connection.execute(
            `SELECT s.store_code AS storeCode, b.branch_code AS branchCode
             FROM branches b
                      JOIN stores s ON s.id = b.store_id
             WHERE b.id = ? AND b.store_id = ?
                 LIMIT 1`,
            [branchId, storeId]
        );
        if (!rows.length) throw new Error("The branch does not belong to this store.");
        const storeCode = String(rows[0].storeCode || "").trim().toUpperCase();
        const branchCode = String(rows[0].branchCode || "").trim().toUpperCase();
        assertCodes(storeCode, branchCode);
        return { storeCode, branchCode };
    }

    // stores.store_code for a newly registered store (unique across StockNBook).
    async function allocateStoreCode(connection, storeName, slug) {
        const [rows] = await connection.execute("SELECT store_code AS code FROM stores");
        const used = new Set(rows.map((row) => String(row.code || "").toUpperCase()));
        const code = storeCodeCandidates(storeName, slug, "").find(
            (candidate) => CODE_PATTERN.test(candidate) && !used.has(candidate)
        );
        if (!code) throw new Error("Unable to allocate a unique store code.");
        return code;
    }

    // branches.branch_code for a new branch (unique within its store).
    async function allocateBranchCode(connection, storeId, branchName) {
        const [rows] = await connection.execute(
            "SELECT branch_code AS code FROM branches WHERE store_id = ?",
            [storeId]
        );
        const used = new Set(rows.map((row) => String(row.code || "").toUpperCase()));
        const code = branchCodeCandidates(branchName).find(
            (candidate) => CODE_PATTERN.test(candidate) && !used.has(candidate)
        );
        if (!code) throw new Error("Unable to allocate unique branch initials.");
        return code;
    }

    async function maxSequenceFrom(connection, sql, params, pattern) {
        const [rows] = await connection.execute(sql, params);
        return rows.reduce((max, row) => {
            const value = String(row.value || "");
            return pattern && !pattern.test(value) ? max : Math.max(max, trailingSequence(value));
        }, 0);
    }

    /*
     * Reserves `count` consecutive numbers after `floor` (the highest number already
     * stored). Callers lock the branch row first so concurrent requests inside a
     * transaction are serialized; the unique keys still reject any duplicate.
     */
    async function reserveSequenceBlock(connection, { storeId, branchId, count = 1, floor = 0 }) {
        const size = Number(count);
        if (!Number.isSafeInteger(size) || size < 1) throw new Error("Invalid identification sequence request.");
        await lockBranch(connection, storeId, branchId);
        const first = (Number(floor) || 0) + 1;
        return { first, last: first + size - 1 };
    }

    async function generateOrderId(connection, { storeId, branchId, orderDate }) {
        await lockBranch(connection, storeId, branchId);
        const { storeCode, branchCode } = await getIdentifierCodes(connection, storeId, branchId);
        const datePart = orderDatePart(orderDate);
        const prefix = `${storeCode}-${branchCode}-${datePart}-`;
        const floor = await maxSequenceFrom(connection,
            "SELECT order_number AS value FROM orders WHERE store_id = ? AND order_number LIKE ?",
            [storeId, `${prefix}%`], PATTERNS.order);
        const { last } = await reserveSequenceBlock(connection, { storeId, branchId, floor });
        return buildOrderId(storeCode, branchCode, orderDate, last);
    }

    // Manager and staff Employee IDs are permanent and independently sequential per branch.
    // The store/branch numbers are the existing immutable database primary keys.
    async function generateEmployeeCode(connection, { storeId, branchId, roleCode }) {
        if (roleCode !== "MN" && roleCode !== "SF") {
            throw new Error("Employee ID role must be MN (manager) or SF (staff).");
        }
        await lockBranch(connection, storeId, branchId);
        const prefix = `${Number(storeId)}-${Number(branchId)}-${roleCode}-`;
        const floor = await maxSequenceFrom(connection,
            `SELECT employee_code AS value FROM users
             WHERE store_id = ? AND branch_id = ? AND employee_code LIKE ?`,
            [storeId, branchId, `${prefix}%`], PATTERNS.employee);
        const { last } = await reserveSequenceBlock(connection, { storeId, branchId, floor });
        return buildEmployeeCode(storeId, branchId, roleCode, last);
    }

    // Highest Product No. already issued with this exact prefix (products or rental equipment).
    async function maxProductPrefixSequence(connection, storeCode, branchCode) {
        const prefix = `${storeCode}-${branchCode}-PRD-%`;
        const fromProducts = await maxSequenceFrom(connection,
            "SELECT product_number AS value FROM products WHERE product_number LIKE ?", [prefix], PATTERNS.product);
        const fromRental = await maxSequenceFrom(connection,
            "SELECT equipment_number AS value FROM equipment WHERE equipment_number LIKE ?", [prefix], PATTERNS.product);
        return Math.max(fromProducts, fromRental);
    }

    /*
     * Product Nos. for sales products (products.product_number) and rental
     * equipment (equipment.equipment_number) share one sequence per branch, so a
     * rental item can never reuse a sales product's number. Caller must be inside
     * a transaction; the branch row lock serializes allocation.
     */
    async function allocateProductNumber(connection, { storeId, branchId }) {
        await lockBranch(connection, storeId, branchId);
        const { storeCode, branchCode } = await getIdentifierCodes(connection, storeId, branchId);
        const branchPrefix = `${storeCode}-${branchCode}-%`;
        const fromProducts = await maxSequenceFrom(connection,
            "SELECT product_number AS value FROM products WHERE store_id = ? AND product_number LIKE ?",
            [storeId, branchPrefix]);
        const fromRental = await maxSequenceFrom(connection,
            "SELECT equipment_number AS value FROM equipment WHERE store_id = ? AND equipment_number LIKE ?",
            [storeId, branchPrefix], PATTERNS.product);
        const fromPrefix = await maxProductPrefixSequence(connection, storeCode, branchCode);
        const next = Math.max(fromProducts, fromRental, fromPrefix) + 1;
        return buildProductNumber(storeCode, branchCode, next);
    }

    /*
     * stocknbook_v2 tracks rental equipment by quantity per branch
     * (branch_inventory); individual physical units are not numbered.
     * These helpers are kept so existing callers keep working.
     */
    async function adjustEquipmentUnits() {
        return { issued: [], retired: 0 };
    }

    async function listEquipmentUnitNumbers() {
        return new Map();
    }

    return {
        PATTERNS,
        CODE_PATTERN,
        branchInitials,
        branchCodeCandidates,
        secondSyllableInitial,
        storeCodeCandidates,
        formatSequence,
        orderDatePart,
        buildOrderId,
        buildProductNumber,
        buildEquipmentNumber,
        buildEmployeeCode,
        trailingSequence,
        ensureIdentifierSchema,
        getIdentifierCodes,
        reserveSequenceBlock,
        generateOrderId,
        generateEmployeeCode,
        allocateProductNumber,
        allocateStoreCode,
        allocateBranchCode,
        lockBranch,
        adjustEquipmentUnits,
        maxProductPrefixSequence,
        listEquipmentUnitNumbers,
    };
})();
// ===== END StockNBook identification numbers =====
const tls = require("tls");
const fs = require("fs");

/*
 * Shared subscription entitlement checks.
 *
 * Subscription management belongs to the store owner, but plan limits are
 * enforced at the API boundary so managers/staff (and public booking pages)
 * cannot bypass the active store plan.
 */

function normalizeLimit(value) {
    if (value === null || value === undefined || Number(value) === 0) {
        return null;
    }

    const parsed = Number(value);
    return Number.isFinite(parsed) ? parsed : null;
}
// Paid subscriptions remain usable through their displayed expiration date.
// A single eligible payment submitted before expiry can retain paid access for
// up to 48 hours while the administrator reviews it. No records are deleted.
async function getActivePlan(connection, storeId) {
    await processDueSubscriptionPlanChange(connection, Number(storeId));
    const [rows] = await connection.execute(
        `SELECT p.id, p.plan_name AS name, p.price, p.max_inventory, p.max_bookings,
                p.max_staff, p.max_branches, p.has_low_stock_alerts,
                p.has_analytics, p.has_forecasting, p.has_multi_store,
                s.expires_at, s.status,
                CASE WHEN s.expires_at IS NOT NULL AND DATE(s.expires_at) < CURDATE()
             THEN 1 ELSE 0 END AS is_past_expiry
         FROM subscriptions s INNER JOIN plans p ON p.id = s.plan_id
         WHERE s.store_id = ? AND LOWER(s.status) IN ('active','expiring')
         ORDER BY s.id DESC LIMIT 1`, [Number(storeId)]
    );
    const paid = rows[0] || null;
    const normalized = (plan, accessStatus) => ({
        id: Number(plan.id), name: String(plan.name || 'Starter'),
        price: Number(plan.price || 0),
        max_inventory: normalizeLimit(plan.max_inventory),
        max_bookings: normalizeLimit(plan.max_bookings),
        max_staff: normalizeLimit(plan.max_staff),
        max_branches: normalizeLimit(plan.max_branches),
        has_low_stock_alerts: Boolean(plan.has_low_stock_alerts),
        has_analytics: Boolean(plan.has_analytics),
        has_forecasting: Boolean(plan.has_forecasting),
        has_multi_store: Boolean(plan.has_multi_store),
        access_status: accessStatus,
    });
    if (paid && !Number(paid.is_past_expiry)) {
        return normalized(paid, 'PAID');
    }
    if (paid && Number(paid.price) > 0) {
        // Two calendar days after the expiration day, pending review only.
        // A submission made after expiration cannot create a new grace period.
        const paymentColumns = await getPlanColumnsForOwner(connection);
        // Older payment schemas may call this column submitted_at or payment_date.
        // Never grant grace without verifiable pre-expiry submission time.
        if (paymentColumns.createdAt) {
            const [eligible] = await connection.execute(
                `SELECT p.id FROM subscription_payments p
                 WHERE p.store_id = ? AND UPPER(p.status) = 'PENDING'
                   AND DATE(p.${paymentColumns.createdAt}) <= DATE(?)
                   AND CURDATE() <= DATE_ADD(DATE(?), INTERVAL 2 DAY)
                 ORDER BY p.id ASC LIMIT 1`,
                [Number(storeId), paid.expires_at, paid.expires_at]
            );
            if (eligible.length > 0) {
                return normalized(paid, 'GRACE');
            }
        }
    }
    const [starterRows] = await connection.execute(
        `SELECT id, plan_name AS name, price, max_inventory, max_bookings, max_staff,
                max_branches, has_low_stock_alerts, has_analytics,
                has_forecasting, has_multi_store
         FROM plans WHERE is_archived = 0 AND (LOWER(plan_code) = 'starter' OR LOWER(plan_name) = 'starter' OR price = 0)
         ORDER BY price ASC, id ASC LIMIT 1`
    );
    if (!starterRows.length) return null;
    return normalized(starterRows[0], 'STARTER_FALLBACK');
}

async function getStoreUsage(connection, storeId) {
    const [inventoryRows] = await connection.execute(
        `SELECT COUNT(*) AS total
         FROM products
         WHERE store_id = ?
           AND deleted_at IS NULL`,
        [Number(storeId)]
    );

    const [bookingRows] = await connection.execute(
        `SELECT COUNT(*) AS total FROM bookings
         WHERE store_id = ? AND created_at >= DATE_FORMAT(CURDATE(), '%Y-%m-01')
           AND created_at < DATE_FORMAT(DATE_ADD(CURDATE(), INTERVAL 1 MONTH), '%Y-%m-01')`,
        [Number(storeId)]
    );

    const [staffRows] = await connection.execute(
        `SELECT COUNT(*) AS total
         FROM users
         WHERE store_id = ?
           AND role = 'staff'
           AND status IN ('active', 'pending')`,
        [Number(storeId)]
    );

    const [branchRows] = await connection.execute(
        `SELECT COUNT(*) AS total
         FROM branches
         WHERE store_id = ?
           AND COALESCE(status, 'active') <> 'deleted'`,
        [Number(storeId)]
    );

    return {
        inventory: Number(inventoryRows[0]?.total || 0),
        bookings: Number(bookingRows[0]?.total || 0),
        staff: Number(staffRows[0]?.total || 0),
        branches: Number(branchRows[0]?.total || 0),
    };
}

function makeLimitError(resource, plan, current, limit, increment = 1, role = "") {
    const labels = {
        inventory: "inventory items",
        bookings: "bookings",
        staff: "staff accounts",
        branches: "branches",
    };

    const label = labels[resource] || resource;
    const isOwner = role === "owner";
    const ownerAction = isOwner
        ? "Upgrade your plan to add more."
        : "Contact your account owner to upgrade.";

    const error = new Error(
        `Plan limit reached: your ${plan?.name || "current"} plan allows up to ${limit} ${label}. ${ownerAction}`
    );
    error.statusCode = 409;
    error.code = `${String(resource).toUpperCase()}_LIMIT_REACHED`;
    error.plan_name = plan?.name || "Current plan";
    error.resource = resource;
    error.current = current;
    error.limit = limit;
    error.requested = current + increment;
    return error;
}

async function assertPlanLimit(
    connection,
    storeId,
    resource,
    increment = 1,
    role = ""
) {
    const plan = await getActivePlan(connection, storeId);

    if (!plan) {
        const error = new Error("No active subscription plan is configured for this store.");
        error.statusCode = 500;
        error.code = "PLAN_NOT_CONFIGURED";
        throw error;
    }

    const usage = await getStoreUsage(connection, storeId);
    const current = Number(usage[resource] || 0);
    const limit = plan[`max_${resource}`];

    if (limit !== null && current + Number(increment) > limit) {
        throw makeLimitError(resource, plan, current, limit, Number(increment), role);
    }

    return { plan, usage, current, limit };
}

module.exports = {
    getActivePlan,
    getStoreUsage,
    assertPlanLimit,
};


const JWT_SECRET = process.env.JWT_SECRET || "stocknbook-secret-key";

const OTP_EXPIRY_SECONDS = 90;
const MANAGER_INVITE_OTP_EXPIRY_SECONDS = OTP_EXPIRY_SECONDS;
const STAFF_INVITE_OTP_EXPIRY_SECONDS = OTP_EXPIRY_SECONDS;
const PAYMENT_OTP_EXPIRY_SECONDS = 300;
// Separate limits for accepted OTP emails and failed email-delivery attempts.
const PAYMENT_OTP_MAX_SENT_PER_WINDOW = 5;
const PAYMENT_OTP_MAX_FAILED_PER_WINDOW = 3;
const PAYMENT_OTP_RATE_WINDOW_MINUTES = 10;

// Local subscription-payment OTP terminal fallback is explicit opt-in only.
// A normal `npm run dev` must not silently treat failed Gmail delivery as success.
// For isolated local debugging, explicitly set PAYMENT_OTP_TERMINAL_DEBUG=true.
// Never enable this flag in production: it prints private OTP codes to logs.
const PAYMENT_OTP_TERMINAL_DEBUG =
    String(process.env.PAYMENT_OTP_TERMINAL_DEBUG || "").toLowerCase() === "true" &&
    String(process.env.NODE_ENV || "").toLowerCase() !== "production";

// Local invitation testing / recovery.
// Invitation links remain usable even when SMTP cannot deliver a demo email.
// In development, failed Manager/Staff invitations are also printed to the
// server terminal so activation can still be tested safely.
const INVITATION_TERMINAL_DEBUG =
    String(process.env.INVITATION_TERMINAL_DEBUG || "").toLowerCase() === "true" ||
    String(process.env.NODE_ENV || "").toLowerCase() === "development";

const SMTP_NETWORK_ERROR_CODES = new Set([
    "ENOTFOUND",
    "EAI_AGAIN",
    "ETIMEDOUT",
    "ECONNRESET",
    "ECONNREFUSED",
    "EHOSTUNREACH",
    "ENETUNREACH",
]);

function isSmtpNetworkError(error) {
    return SMTP_NETWORK_ERROR_CODES.has(String(error?.code || "").toUpperCase());
}

function logDevelopmentInvitationFallback({
                                              role,
                                              email,
                                              name,
                                              storeName,
                                              branchName,
                                              inviteLink,
                                              errorMessage,
                                          }) {
    if (!INVITATION_TERMINAL_DEBUG) return;

    console.warn(
        `[StockNBook DEV INVITE] ${role} invitation email was not delivered. ` +
        `Use the backup invitation link for local testing.`,
        {
            role,
            name: name || "",
            email: email || "",
            store: storeName || "",
            branch: branchName || "",
            invite_link: inviteLink || "",
            email_error: errorMessage || "",
        }
    );
}

const SMTP_USER = "stocknbook@gmail.com";

// Replace this value with a CURRENT 16-character Google App Password
// generated for the same Gmail account used in SMTP_USER.
// Do not use the normal Gmail account password.
const SMTP_PASS = "rrmk ivgo ojgg nkqw"
    .replace(/\s/g, "");

const EMAIL_FROM =
    `"StockNBook" <${SMTP_USER}>`;

const EMAIL_REPLY_TO = SMTP_USER;

const SMTP_HOST = "smtp.gmail.com";
const SMTP_PORT = 465;
const SMTP_TIMEOUT_MS = 20000;

const APP_BASE_URL =
    String(
        process.env.APP_BASE_URL ||
        process.env.APP_URL ||
        "http://localhost:3000"
    ).replace(/\/+$/, "");
function generateOtp() {
    return String(crypto.randomInt(0, 1000000)).padStart(6, "0");
}

function hashOtp(otp) {
    return crypto
        .createHash("sha256")
        .update(String(otp))
        .digest("hex");
}
function paymentOtpRetrySeconds(value) {
    const seconds = Number(value);
    return Number.isFinite(seconds) && seconds > 0 ? Math.ceil(seconds) : 60;
}

// Display the remaining wait in readable units instead of only minutes.
function formatPaymentOtpWaitTime(seconds) {
    const totalMinutes = Math.max(1, Math.ceil(Number(seconds) / 60));
    const hours = Math.floor(totalMinutes / 60);
    const minutes = totalMinutes % 60;
    if (hours === 0) return `${minutes} ${minutes === 1 ? "minute" : "minutes"}`;
    const hourText = `${hours} ${hours === 1 ? "hour" : "hours"}`;
    if (minutes === 0) return hourText;
    return `${hourText} and ${minutes} ${minutes === 1 ? "minute" : "minutes"}`;
}

function paymentOtpCooldownResponse(headers, message, retryAfterSeconds, code) {
    return {
        statusCode: 429,
        headers: { ...headers, "Retry-After": String(retryAfterSeconds) },
        body: JSON.stringify({
            error: message,
            code,
            retry_after_seconds: retryAfterSeconds,
        }),
    };
}


function hashInviteToken(inviteToken) {
    return crypto
        .createHash("sha256")
        .update(String(inviteToken))
        .digest("hex");
}

async function getManagerInviteRecord(connection, inviteToken) {
    if (!inviteToken) {
        const error = new Error("Missing invitation token.");
        error.statusCode = 400;
        throw error;
    }

    let decoded;

    try {
        decoded = jwt.verify(inviteToken, JWT_SECRET);
    } catch {
        const error = new Error("Invalid or expired invitation.");
        error.statusCode = 401;
        throw error;
    }

    if (decoded.type !== "manager_invite") {
        const error = new Error("Invalid invitation type.");
        error.statusCode = 400;
        throw error;
    }

    const [rows] = await connection.execute(
        `SELECT
             users.id AS manager_id,
             users.full_name AS manager_name,
             users.email AS manager_email,
             users.permissions,
             users.status,
             users.store_id,
             users.branch_id,
             branches.branch_name,
             stores.store_name
         FROM users
                  JOIN branches ON users.branch_id = branches.id
                  JOIN stores ON users.store_id = stores.id
         WHERE users.role = 'manager'
           AND users.invite_token_hash = SHA2(?, 256)
           AND users.email = ?
           AND users.store_id = ?
           AND users.branch_id = ?
           AND users.status = 'pending'
             LIMIT 1`,
        [
            inviteToken,
            String(decoded.email || "").toLowerCase(),
            decoded.store_id,
            decoded.branch_id,
        ]
    );

    if (rows.length === 0) {
        const error = new Error("Invitation not found or already used.");
        error.statusCode = 404;
        throw error;
    }

    const manager = rows[0];

    return {
        decoded,
        manager: {
            manager_id: manager.manager_id,
            manager_name: manager.manager_name || "",
            manager_email: manager.manager_email || "",
            store_id: manager.store_id,
            store_name: manager.store_name || "",
            branch_id: manager.branch_id,
            branch_name: manager.branch_name || "",
            role: "manager",
            status: manager.status || "pending",
            permissions:
                typeof manager.permissions === "string"
                    ? JSON.parse(manager.permissions || "{}")
                    : manager.permissions || {},
        },
    };
}

async function requireVerifiedManagerInvite(connection, inviteToken, email) {

    const inviteTokenHash = hashInviteToken(inviteToken);
    const [rows] = await connection.execute(
        `SELECT id
         FROM otp_codes
         WHERE purpose = 'manager_invite'
           AND invite_token_hash = ?
           AND email = ?
           AND verified_at IS NOT NULL
           AND verified_at > DATE_SUB(UTC_TIMESTAMP(), INTERVAL 30 MINUTE)
         ORDER BY id DESC
             LIMIT 1`,
        [inviteTokenHash, String(email || "").toLowerCase()]
    );

    if (rows.length === 0) {
        const error = new Error(
            "Verify the invited email before continuing."
        );
        error.statusCode = 403;
        throw error;
    }
}


async function getStaffInviteRecord(connection, inviteToken) {
    if (!inviteToken) {
        const error = new Error("Missing invitation token.");
        error.statusCode = 400;
        throw error;
    }

    let decoded;

    try {
        decoded = jwt.verify(inviteToken, JWT_SECRET);
    } catch {
        const error = new Error("Invalid or expired invitation.");
        error.statusCode = 401;
        throw error;
    }

    if (decoded.type !== "staff_invite") {
        const error = new Error("Invalid invitation type.");
        error.statusCode = 400;
        throw error;
    }

    const [rows] = await connection.execute(
        `SELECT
             staff.id AS staff_id,
             staff.full_name AS staff_name,
             staff.email AS staff_email,
             staff.permissions,
             staff.status,
             staff.store_id,
             staff.branch_id,
             staff.manager_id,
             branches.branch_name,
             stores.store_name,
             COALESCE(managers.full_name, '') AS manager_name
         FROM users staff
                  JOIN branches ON staff.branch_id = branches.id
                  JOIN stores ON staff.store_id = stores.id
                  LEFT JOIN users managers ON staff.manager_id = managers.id AND managers.role = 'manager'
         WHERE staff.role = 'staff'
           AND staff.invite_token_hash = SHA2(?, 256)
           AND staff.email = ?
           AND staff.store_id = ?
           AND staff.branch_id = ?
           AND staff.manager_id = ?
           AND staff.status = 'pending'
             LIMIT 1`,
        [
            inviteToken,
            String(decoded.email || "").toLowerCase(),
            decoded.store_id,
            decoded.branch_id,
            decoded.manager_id,
        ]
    );

    if (rows.length === 0) {
        const error = new Error("Invitation not found or already used.");
        error.statusCode = 404;
        throw error;
    }

    const staffMember = rows[0];

    return {
        decoded,
        staff: {
            staff_id: staffMember.staff_id,
            staff_name: staffMember.staff_name || "",
            staff_email: staffMember.staff_email || "",
            manager_id: staffMember.manager_id,
            manager_name: staffMember.manager_name || "",
            store_id: staffMember.store_id,
            store_name: staffMember.store_name || "",
            branch_id: staffMember.branch_id,
            branch_name: staffMember.branch_name || "",
            role: "staff",
            status: staffMember.status || "pending",
            permissions:
                typeof staffMember.permissions === "string"
                    ? JSON.parse(staffMember.permissions || "{}")
                    : staffMember.permissions || {},
        },
    };
}

async function requireVerifiedStaffInvite(connection, inviteToken, email) {

    const inviteTokenHash = hashInviteToken(inviteToken);
    const [rows] = await connection.execute(
        `SELECT id
         FROM otp_codes
         WHERE purpose = 'staff_invite'
           AND invite_token_hash = ?
           AND email = ?
           AND verified_at IS NOT NULL
           AND verified_at > DATE_SUB(UTC_TIMESTAMP(), INTERVAL 30 MINUTE)
         ORDER BY id DESC
             LIMIT 1`,
        [inviteTokenHash, String(email || "").toLowerCase()]
    );

    if (rows.length === 0) {
        const error = new Error(
            "Verify the invited email before continuing."
        );
        error.statusCode = 403;
        throw error;
    }
}

function createSmtpResponseReader(socket) {
    let buffer = "";
    const waiting = [];

    const flush = () => {
        while (waiting.length > 0) {
            const lines = buffer.split(/\r?\n/);
            let responseEnd = -1;

            for (let index = 0; index < lines.length; index += 1) {
                if (/^\d{3} /.test(lines[index])) {
                    responseEnd = index;
                    break;
                }
            }

            if (responseEnd === -1) {
                return;
            }

            const responseLines = lines.slice(0, responseEnd + 1);
            buffer = lines.slice(responseEnd + 1).join("\r\n");

            const finalLine = responseLines[responseLines.length - 1];
            const code = Number(finalLine.slice(0, 3));
            const waiter = waiting.shift();

            waiter.resolve({
                code,
                message: responseLines.join("\n"),
            });
        }
    };

    socket.on("data", (chunk) => {
        buffer += chunk.toString("utf8");
        flush();
    });

    socket.on("error", (error) => {
        while (waiting.length > 0) {
            waiting.shift().reject(error);
        }
    });

    socket.on("close", () => {
        while (waiting.length > 0) {
            waiting.shift().reject(
                new Error("SMTP connection closed unexpectedly.")
            );
        }
    });

    return () =>
        new Promise((resolve, reject) => {
            waiting.push({ resolve, reject });
            flush();
        });
}

async function expectSmtpResponse(readResponse, expectedCodes) {
    const response = await readResponse();

    if (!expectedCodes.includes(response.code)) {
        const error = new Error(
            `Gmail SMTP error ${response.code}: ${response.message}`
        );

        error.code =
            response.code === 535
                ? "GMAIL_AUTH_FAILED"
                : "GMAIL_SMTP_ERROR";

        throw error;
    }

    return response;
}

async function sendSmtpCommand(
    socket,
    readResponse,
    command,
    expectedCodes
) {
    socket.write(`${command}\r\n`);
    return expectSmtpResponse(readResponse, expectedCodes);
}

function buildOtpEmail(toEmail, otp) {
    const html = `
        <div style="font-family: Arial, sans-serif; background:#FDFAF4; padding:24px;">
            <div style="max-width:520px; margin:auto; background:#ffffff; border:1px solid #EBE4F0; border-radius:16px; padding:28px;">
                <h2 style="margin:0; color:#2D1B4E;">StockNBook</h2>

                <p style="margin-top:18px; color:#3F354C;">Hello,</p>

                <p style="color:#3F354C;">
                    Use the verification code below to continue creating your
                    StockNBook account.
                </p>

                <div style="margin:24px 0; padding:18px; text-align:center; background:#F8F5FF; border-radius:12px;">
                    <div style="font-size:32px; font-weight:bold; letter-spacing:6px; color:#2D1B4E;">
                        ${otp}
                    </div>
                </div>

                <p style="color:#7A6E88;">
                    This OTP will expire in <strong>1 minute and 30 seconds</strong>.
                </p>

                <p style="margin-top:24px; color:#7A6E88; font-size:13px;">
                    If you did not request this code, you can safely ignore this
                    email.
                </p>

                <p style="margin-top:24px; color:#2D1B4E; font-weight:bold;">
                    — StockNBook Team
                </p>
            </div>
        </div>
    `;

    const message = [
        `From: ${EMAIL_FROM}`,
        `To: ${toEmail}`,
        "Subject: StockNBook Email Verification Code",
        `Date: ${new Date().toUTCString()}`,
        "MIME-Version: 1.0",
        'Content-Type: text/html; charset="UTF-8"',
        "Content-Transfer-Encoding: 8bit",
        "",
        html,
    ].join("\r\n");

    return message.replace(/^\./gm, "..");
}


function buildPaymentOtpEmail(toEmail, otp, planName) {
    const planLabel = planName ? escapeHtml(planName) : "your selected";

    const html = `
        <div style="font-family: Arial, sans-serif; background:#FDFAF4; padding:24px;">
            <div style="max-width:520px; margin:auto; background:#ffffff; border:1px solid #EBE4F0; border-radius:16px; padding:28px;">
                <h2 style="margin:0; color:#2D1B4E;">StockNBook</h2>

                <p style="margin-top:18px; color:#3F354C;">Hello,</p>

                <p style="color:#3F354C;">
                    Use the verification code below to confirm your subscription
                    payment submission for the <strong>${planLabel}</strong> plan.
                </p>

                <div style="margin:24px 0; padding:18px; text-align:center; background:#F8F5FF; border-radius:12px;">
                    <div style="font-size:32px; font-weight:bold; letter-spacing:6px; color:#2D1B4E;">
                        ${otp}
                    </div>
                </div>

                <p style="color:#7A6E88;">
                    This code will expire in <strong>5 minutes</strong>.
                </p>

                <p style="margin-top:24px; color:#7A6E88; font-size:13px;">
                    If you did not request this, you can safely ignore this email
                    — no changes will be made to your account or subscription.
                </p>

                <p style="margin-top:24px; color:#2D1B4E; font-weight:bold;">
                    — StockNBook Team
                </p>
            </div>
        </div>
    `;

    const message = [
        `From: ${EMAIL_FROM}`,
        `To: ${toEmail}`,
        "Subject: StockNBook Payment Verification Code",
        `Date: ${new Date().toUTCString()}`,
        "MIME-Version: 1.0",
        'Content-Type: text/html; charset="UTF-8"',
        "Content-Transfer-Encoding: 8bit",
        "",
        html,
    ].join("\r\n");

    return message.replace(/^\./gm, "..");
}


function escapeHtml(value) {
    return String(value ?? "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

function sanitizeEmailHeader(value) {
    return String(value ?? "")
        .replace(/[\r\n]+/g, " ")
        .trim();
}

function permissionLabel(permission) {
    const labels = {
        dashboard: "Dashboard",
        bookings: "Bookings",
        packages: "Packages",
        packages_manage: "Manage Packages",
        inventory: "Inventory",
        pos: "Sales / POS",
        reports: "Reports",
        analytics: "Analytics",
        forecasting: "Forecasting",
        staff_management: "Staff Management",
        branch_settings: "Branch Settings",
    };

    return labels[permission] || permission;
}

// Normalizes a raw permission value (which may be a boolean flag like
// `staff_management: true`, or a granular access-mode string like
// `"full" | "view" | "none"`) into a display-ready access level.
// Returns null when the module is set to no access at all, so callers
// can filter those out instead of showing them as granted.
function permissionAccessLevel(value) {
    if (value === true || value === "full" || value === "true") {
        return "Full Access";
    }

    if (value === "view" || value === "view_only" || value === "viewOnly") {
        return "View Only";
    }

    // Explicitly covers false, "none", undefined, null, "", 0, etc.
    return null;
}


function buildManagerInviteOtpEmail(toEmail, otp, managerName) {
    const safeName = escapeHtml(managerName || "Manager");
    const safeOtp = escapeHtml(otp);

    const html = `
        <div style="font-family:Arial,Helvetica,sans-serif;background:#F7F4FB;padding:28px 14px;color:#21172C;">
            <div style="max-width:560px;margin:auto;overflow:hidden;border:1px solid #E7DFEA;border-radius:20px;background:#FFFFFF;box-shadow:0 18px 50px rgba(45,27,78,.12);">
                <div style="background:linear-gradient(135deg,#2D1B4E,#4B2B75);padding:26px 30px;color:#FFFFFF;">
                    <div style="font-size:22px;font-weight:800;">Stock<span style="color:#D4A126;">N</span>Book</div>
                    <div style="margin-top:7px;font-size:13px;color:rgba(255,255,255,.72);">Manager invitation verification</div>
                </div>
                <div style="padding:30px;">
                    <h1 style="margin:0;font-size:25px;color:#21172C;">Verify your invited email</h1>
                    <p style="margin:16px 0 0;font-size:15px;line-height:1.7;color:#6F6577;">
                        Hello <strong style="color:#2D1B4E;">${safeName}</strong>, use the code below to continue accepting your StockNBook manager invitation.
                    </p>
                    <div style="margin:24px 0;padding:20px;text-align:center;border-radius:14px;background:#F3ECFF;">
                        <div style="font-size:34px;font-weight:800;letter-spacing:8px;color:#4B2380;">${safeOtp}</div>
                    </div>
                    <p style="margin:0;font-size:13px;line-height:1.6;color:#7A6E88;">
                        This code expires in 1 minute and 30 seconds. Do not share it with anyone.
                    </p>
                </div>
            </div>
        </div>
    `;

    const message = [
        `From: ${EMAIL_FROM}`,
        `Reply-To: ${EMAIL_REPLY_TO}`,
        `To: ${sanitizeEmailHeader(toEmail)}`,
        "Subject: StockNBook Manager Invitation Verification Code",
        `Date: ${new Date().toUTCString()}`,
        "MIME-Version: 1.0",
        'Content-Type: text/html; charset="UTF-8"',
        "Content-Transfer-Encoding: 8bit",
        "",
        html,
    ].join("\r\n");

    return message.replace(/^\./gm, "..");
}


function buildStaffInviteOtpEmail(toEmail, otp, staffName) {
    const safeName = escapeHtml(staffName || "Staff member");
    const safeOtp = escapeHtml(otp);

    const html = `
        <div style="font-family:Arial,Helvetica,sans-serif;background:#F7F4FB;padding:28px 14px;color:#21172C;">
            <div style="max-width:560px;margin:auto;overflow:hidden;border:1px solid #E7DFEA;border-radius:20px;background:#FFFFFF;box-shadow:0 18px 50px rgba(45,27,78,.12);">
                <div style="background:linear-gradient(135deg,#2D1B4E,#4B2B75);padding:26px 30px;color:#FFFFFF;">
                    <div style="font-size:22px;font-weight:800;">Stock<span style="color:#D4A126;">N</span>Book</div>
                    <div style="margin-top:7px;font-size:13px;color:rgba(255,255,255,.72);">Staff invitation verification</div>
                </div>
                <div style="padding:30px;">
                    <h1 style="margin:0;font-size:25px;color:#21172C;">Verify your invited email</h1>
                    <p style="margin:16px 0 0;font-size:15px;line-height:1.7;color:#6F6577;">
                        Hello <strong style="color:#2D1B4E;">${safeName}</strong>, use the code below to continue accepting your StockNBook staff invitation.
                    </p>
                    <div style="margin:24px 0;padding:20px;text-align:center;border-radius:14px;background:#F3ECFF;">
                        <div style="font-size:34px;font-weight:800;letter-spacing:8px;color:#4B2380;">${safeOtp}</div>
                    </div>
                    <p style="margin:0;font-size:13px;line-height:1.6;color:#7A6E88;">
                        This code expires in 1 minute and 30 seconds. Do not share it with anyone.
                    </p>
                </div>
            </div>
        </div>
    `;

    const message = [
        `From: ${EMAIL_FROM}`,
        `Reply-To: ${EMAIL_REPLY_TO}`,
        `To: ${sanitizeEmailHeader(toEmail)}`,
        "Subject: StockNBook Staff Invitation Verification Code",
        `Date: ${new Date().toUTCString()}`,
        "MIME-Version: 1.0",
        'Content-Type: text/html; charset="UTF-8"',
        "Content-Transfer-Encoding: 8bit",
        "",
        html,
    ].join("\r\n");

    return message.replace(/^\./gm, "..");
}

function buildManagerInvitationEmail({
                                         toEmail,
                                         managerName,
                                         storeName,
                                         branchName,
                                         inviteLink,
                                         permissions,
                                     }) {
    const safeManagerName = escapeHtml(managerName || "Manager");
    const safeStoreName = escapeHtml(storeName || "StockNBook Store");
    const safeBranchName = escapeHtml(branchName || "Assigned Branch");
    const safeInviteLink = escapeHtml(inviteLink);
    const safeRecipient = escapeHtml(toEmail);

    const subject = "StockNBook Manager Invitation";

    const html = `
        <div style="margin:0;background:#F7F4FB;padding:30px 14px;font-family:Arial,Helvetica,sans-serif;color:#21172C;">
            <div style="max-width:620px;margin:0 auto;overflow:hidden;border:1px solid #E7DFEA;border-radius:22px;background:#FFFFFF;box-shadow:0 18px 50px rgba(45,27,78,.12);">
                <div style="background:linear-gradient(135deg,#2D1B4E,#4B2B75);padding:28px 30px;color:#FFFFFF;">
                    <div style="font-size:23px;font-weight:800;letter-spacing:-.6px;">
                        Stock<span style="color:#D4A126;">N</span>Book
                    </div>
                    <div style="margin-top:7px;font-size:13px;color:rgba(255,255,255,.72);">
                        Secure branch manager invitation
                    </div>
                </div>

                <div style="padding:30px;">
                    <h1 style="margin:0;font-size:27px;line-height:1.25;color:#21172C;">
                        You have been invited
                    </h1>

                    <p style="margin:16px 0 0;font-size:15px;line-height:1.75;color:#6F6577;">
                        Hello <strong style="color:#2D1B4E;">${safeManagerName}</strong>,
                        the owner of <strong style="color:#2D1B4E;">${safeStoreName}</strong>
                        invited you to manage the
                        <strong style="color:#2D1B4E;">${safeBranchName}</strong> branch.
                    </p>

                    <div style="margin:24px 0;padding:18px;border:1px solid #E8DFF0;border-radius:16px;background:#FCFAFD;">
                        <table role="presentation" style="width:100%;border-collapse:collapse;">
                            <tr>
                                <td style="padding:4px 10px 10px 0;color:#8A7896;font-size:12px;text-transform:uppercase;letter-spacing:.1em;">Store</td>
                                <td style="padding:4px 0 10px;color:#2D1B4E;font-size:14px;font-weight:700;">${safeStoreName}</td>
                            </tr>
                            <tr>
                                <td style="padding:4px 10px 10px 0;color:#8A7896;font-size:12px;text-transform:uppercase;letter-spacing:.1em;">Branch</td>
                                <td style="padding:4px 0 10px;color:#2D1B4E;font-size:14px;font-weight:700;">${safeBranchName}</td>
                            </tr>
                            <tr>
                                <td style="padding:4px 10px 0 0;color:#8A7896;font-size:12px;text-transform:uppercase;letter-spacing:.1em;">Role</td>
                                <td style="padding:4px 0 0;color:#2D1B4E;font-size:14px;font-weight:700;">Branch Manager</td>
                            </tr>
                        </table>
                    </div>

                    <a href="${safeInviteLink}"
                       style="display:block;border-radius:12px;background:#2D1B4E;padding:15px 20px;text-align:center;font-size:15px;font-weight:800;color:#FFFFFF;text-decoration:none;">
                        Review and accept invitation
                    </a>

                    <p style="margin:20px 0 0;font-size:12px;line-height:1.65;color:#8A8091;">
                        This invitation is intended only for <strong>${safeRecipient}</strong>.
                        Do not forward this email or share the invitation link.
                    </p>

                    <p style="margin:14px 0 0;font-size:12px;line-height:1.65;color:#8A8091;">
                        The invitation expires after 7 days. If you were not expecting this invitation,
                        you may safely ignore this email.
                    </p>
                </div>
            </div>
        </div>
    `;

    const message = [
        `From: ${EMAIL_FROM}`,
        `Reply-To: ${EMAIL_REPLY_TO}`,
        `To: ${sanitizeEmailHeader(toEmail)}`,
        `Subject: ${subject}`,
        `Date: ${new Date().toUTCString()}`,
        "MIME-Version: 1.0",
        'Content-Type: text/html; charset="UTF-8"',
        "Content-Transfer-Encoding: 8bit",
        "",
        html,
    ].join("\r\n");

    return message.replace(/^\./gm, "..");
}


function buildStaffInvitationEmail({
                                       toEmail,
                                       staffName,
                                       managerName,
                                       storeName,
                                       branchName,
                                       inviteLink,
                                       permissions,
                                   }) {
    const safeStaffName = escapeHtml(staffName || "Staff member");
    const safeManagerName = escapeHtml(managerName || "Branch Manager");
    const safeStoreName = escapeHtml(storeName || "StockNBook Store");
    const safeBranchName = escapeHtml(branchName || "Assigned Branch");
    const safeInviteLink = escapeHtml(inviteLink);
    const safeRecipient = escapeHtml(toEmail);

    // A staff permission may be represented twice (e.g. pos + pos_access).
    // Show each granted module once, without exposing internal field names.
    const invitationModules = [
        { label: "Dashboard", flag: "dashboard" },
        { label: "Sales / POS", flag: "pos", access: "pos_access" },
        { label: "Bookings", flag: "bookings", access: "bookings_access" },
        { label: "Inventory", flag: "inventory", access: "inventory_access" },
        { label: "Packages", flag: "packages", access: "package_access" },
        { label: "Reports", flag: "reports", access: "reports_access" },
        { label: "Analytics", flag: "analytics", access: "analytics_access" },
        { label: "Forecasting", flag: "forecasting", access: "forecasting_access" },
        { label: "Staff Management", flag: "staff_management" },
        { label: "Branch Settings", flag: "branch_settings" },
    ];
    const enabledPermissions = invitationModules.flatMap(({ label, flag, access }) => {
        const granular = access ? permissions?.[access] : undefined;
        const value = granular !== undefined ? granular : permissions?.[flag];
        const level = permissionAccessLevel(value);
        return level ? [{ label, level }] : [];
    });

    const permissionItems = enabledPermissions.length > 0
        ? enabledPermissions.map(({ label, level }) =>
            `<span style="display:inline-block;margin:4px 18px 4px 0;color:#5B32C5;font-size:13px;font-weight:700;">${escapeHtml(label)}${level === "View Only" ? ' <span style="color:#8A7896;font-weight:400;">(View only)</span>' : ""}</span>`
        ).join("")
        : `<span style="color:#7A6E88;font-size:13px;">Your access will be configured by your branch manager.</span>`;

    const subject = "StockNBook Staff Invitation";

    const html = `
        <div style="margin:0;background:#F7F4FB;padding:30px 14px;font-family:Arial,Helvetica,sans-serif;color:#21172C;">
            <div style="max-width:620px;margin:0 auto;overflow:hidden;border:1px solid #E7DFEA;border-radius:22px;background:#FFFFFF;box-shadow:0 18px 50px rgba(45,27,78,.12);">
                <div style="background:linear-gradient(135deg,#2D1B4E,#4B2B75);padding:28px 30px;color:#FFFFFF;">
                    <div style="font-size:23px;font-weight:800;letter-spacing:-.6px;">
                        Stock<span style="color:#D4A126;">N</span>Book
                    </div>
                    <div style="margin-top:7px;font-size:13px;color:rgba(255,255,255,.72);">
                        Secure staff invitation
                    </div>
                </div>

                <div style="padding:30px;">
                    <h1 style="margin:0;font-size:27px;line-height:1.25;color:#21172C;">
                        You have been invited
                    </h1>

                    <p style="margin:16px 0 0;font-size:15px;line-height:1.75;color:#6F6577;">
                        Hello <strong style="color:#2D1B4E;">${safeStaffName}</strong>,
                        <strong style="color:#2D1B4E;">${safeManagerName}</strong>
                        invited you to join
                        <strong style="color:#2D1B4E;">${safeStoreName}</strong>
                        at the <strong style="color:#2D1B4E;">${safeBranchName}</strong> branch.
                    </p>

                    <div style="margin:24px 0;padding:18px;border:1px solid #E8DFF0;border-radius:16px;background:#FCFAFD;">
                        <table role="presentation" style="width:100%;border-collapse:collapse;">
                            <tr>
                                <td style="padding:4px 10px 10px 0;color:#8A7896;font-size:12px;text-transform:uppercase;letter-spacing:.1em;">Store</td>
                                <td style="padding:4px 0 10px;color:#2D1B4E;font-size:14px;font-weight:700;">${safeStoreName}</td>
                            </tr>
                            <tr>
                                <td style="padding:4px 10px 10px 0;color:#8A7896;font-size:12px;text-transform:uppercase;letter-spacing:.1em;">Branch</td>
                                <td style="padding:4px 0 10px;color:#2D1B4E;font-size:14px;font-weight:700;">${safeBranchName}</td>
                            </tr>
                            <tr>
                                <td style="padding:4px 10px 0 0;color:#8A7896;font-size:12px;text-transform:uppercase;letter-spacing:.1em;">Role</td>
                                <td style="padding:4px 0 0;color:#2D1B4E;font-size:14px;font-weight:700;">Staff Member</td>
                            </tr>
                        </table>
                    </div>

                    <div style="margin:0 0 22px;">
                        <div style="margin-bottom:9px;color:#2D1B4E;font-size:13px;font-weight:800;">Access assigned to you</div>
                        <div>${permissionItems}</div>
                    </div>

                    <a href="${safeInviteLink}"
                       style="display:block;border-radius:12px;background:#2D1B4E;padding:15px 20px;text-align:center;font-size:15px;font-weight:800;color:#FFFFFF;text-decoration:none;">
                        Review and accept invitation
                    </a>

                    <p style="margin:20px 0 0;font-size:12px;line-height:1.65;color:#8A8091;">
                        This invitation is intended only for <strong>${safeRecipient}</strong>.
                        Do not forward this email or share the invitation link.
                    </p>

                    <p style="margin:14px 0 0;font-size:12px;line-height:1.65;color:#8A8091;">
                        The invitation expires after 7 days. If you were not expecting this invitation,
                        you may safely ignore this email.
                    </p>
                </div>
            </div>
        </div>
    `;

    const message = [
        `From: ${EMAIL_FROM}`,
        `Reply-To: ${EMAIL_REPLY_TO}`,
        `To: ${sanitizeEmailHeader(toEmail)}`,
        `Subject: ${subject}`,
        `Date: ${new Date().toUTCString()}`,
        "MIME-Version: 1.0",
        'Content-Type: text/html; charset="UTF-8"',
        "Content-Transfer-Encoding: 8bit",
        "",
        html,
    ].join("\r\n");

    return message.replace(/^\./gm, "..");
}

async function sendGmailHtmlEmail(toEmail, rawMessage, logLabel) {
    if (
        !SMTP_USER ||
        !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(SMTP_USER)
    ) {
        const configError = new Error(
            "Email sending is not configured. Set a valid SMTP_USER directly in index.js."
        );
        configError.code = "SMTP_NOT_CONFIGURED";
        throw configError;
    }

    if (
        !SMTP_PASS ||
        SMTP_PASS === "rrmk ivgo ojgg nkqw"
    ) {
        const configError = new Error(
            "Email sending is not configured. Replace PASTE_NEW_GOOGLE_APP_PASSWORD_HERE in index.js with a valid Google App Password."
        );
        configError.code = "SMTP_NOT_CONFIGURED";
        throw configError;
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(toEmail)) {
        const emailError = new Error("Invalid email recipient.");
        emailError.code = "INVALID_RECIPIENT";
        throw emailError;
    }

    const socket = tls.connect({
        host: SMTP_HOST,
        port: SMTP_PORT,
        servername: SMTP_HOST,
        rejectUnauthorized: true,
    });

    socket.setTimeout(SMTP_TIMEOUT_MS);

    const readResponse = createSmtpResponseReader(socket);

    try {
        await new Promise((resolve, reject) => {
            socket.once("secureConnect", resolve);
            socket.once("error", reject);
            socket.once("timeout", () => {
                const timeoutError = new Error(
                    "Lambda could not connect to Gmail SMTP."
                );
                timeoutError.code = "GMAIL_NETWORK_FAILED";
                reject(timeoutError);
            });
        });

        await expectSmtpResponse(readResponse, [220]);

        await sendSmtpCommand(
            socket,
            readResponse,
            "EHLO stocknbook.local",
            [250]
        );

        await sendSmtpCommand(
            socket,
            readResponse,
            "AUTH LOGIN",
            [334]
        );

        await sendSmtpCommand(
            socket,
            readResponse,
            Buffer.from(SMTP_USER).toString("base64"),
            [334]
        );

        await sendSmtpCommand(
            socket,
            readResponse,
            Buffer.from(SMTP_PASS).toString("base64"),
            [235]
        );

        await sendSmtpCommand(
            socket,
            readResponse,
            `MAIL FROM:<${SMTP_USER}>`,
            [250]
        );

        await sendSmtpCommand(
            socket,
            readResponse,
            `RCPT TO:<${toEmail}>`,
            [250, 251]
        );

        await sendSmtpCommand(
            socket,
            readResponse,
            "DATA",
            [354]
        );

        socket.write(`${rawMessage}\r\n.\r\n`);

        const dataResponse = await expectSmtpResponse(
            readResponse,
            [250]
        );

        socket.write("QUIT\r\n");

        console.log(`[stocknbook-auth] ${logLabel} email accepted:`, {
            to: toEmail,
            smtpResponse: dataResponse.message,
        });

        return {
            accepted: [toEmail],
            response: dataResponse.message,
        };
    } catch (error) {
        console.error(`[stocknbook-auth] ${logLabel} Gmail SMTP error:`, {
            code: error?.code,
            message: error?.message,
        });

        if (error?.code === "GMAIL_AUTH_FAILED") {
            const authError = new Error(
                "Gmail rejected the sender credentials. Replace SMTP_PASS in index.js with a current Google App Password generated for the same Gmail account used in SMTP_USER."
            );
            authError.code = "GMAIL_AUTH_FAILED";
            throw authError;
        }

        if (isSmtpNetworkError(error)) {
            const networkError = new Error(
                "The invitation email service is temporarily unreachable. The invitation itself is still valid; use the backup invite link or try Resend later."
            );
            networkError.code = "GMAIL_NETWORK_FAILED";
            networkError.cause = error;
            throw networkError;
        }

        throw error;
    } finally {
        if (!socket.destroyed) {
            socket.end();
        }
    }
}

async function sendSignupOtpEmail(toEmail, otp) {
    return sendGmailHtmlEmail(
        toEmail,
        buildOtpEmail(toEmail, otp),
        "OTP"
    );
}

async function sendManagerInvitationEmail(invite) {
    return sendGmailHtmlEmail(
        invite.manager_email,
        buildManagerInvitationEmail({
            toEmail: invite.manager_email,
            managerName: invite.manager_name,
            storeName: invite.store_name,
            branchName: invite.branch_name,
            inviteLink: invite.invite_link,
            permissions: invite.permissions,
        }),
        "manager invitation"
    );
}


async function sendStaffInvitationEmail(invite) {
    return sendGmailHtmlEmail(
        invite.staff_email,
        buildStaffInvitationEmail({
            toEmail: invite.staff_email,
            staffName: invite.staff_name,
            managerName: invite.manager_name,
            storeName: invite.store_name,
            branchName: invite.branch_name,
            inviteLink: invite.invite_link,
            permissions: invite.permissions,
        }),
        "staff invitation"
    );
}


function getInvitationEmailFailureMessage(error) {
    const code = String(error?.code || "").toUpperCase();

    if (code === "GMAIL_NETWORK_FAILED" || isSmtpNetworkError(error)) {
        return "The email service is temporarily unreachable. The invitation is still valid; use the backup invite link or try Resend later.";
    }

    if (code === "GMAIL_AUTH_FAILED") {
        return "The email service could not authenticate. The invitation is still valid; use the backup invite link while the SMTP account is being fixed.";
    }

    if (code === "SMTP_NOT_CONFIGURED") {
        return "Email delivery is not configured yet. The invitation is still valid; use the backup invite link.";
    }

    if (code === "INVALID_RECIPIENT") {
        return "The invitation email address is invalid. Check the address or use the backup invite link.";
    }

    if (code === "GMAIL_SMTP_ERROR") {
        return "Gmail did not accept the invitation email. The invitation is still valid; use the backup invite link or try Resend later.";
    }

    return "The invitation email could not be delivered. The invitation is still valid; use the backup invite link or try Resend later.";
}

async function deliverInvitationEmail({
                                          role,
                                          email,
                                          name,
                                          storeName,
                                          branchName,
                                          inviteLink,
                                          send,
                                      }) {
    try {
        await send();

        return {
            email_sent: true,
            email_status: "sent",
            email_error: "",
        };
    } catch (sendError) {
        const emailError = getInvitationEmailFailureMessage(sendError);

        console.error(
            `[stocknbook-auth] ${role} invitation was created, but email delivery failed:`,
            {
                email,
                branch: branchName || "",
                code: sendError?.code || "EMAIL_SEND_FAILED",
                error: emailError,
            }
        );

        logDevelopmentInvitationFallback({
            role,
            email,
            name,
            storeName,
            branchName,
            inviteLink,
            errorMessage: emailError,
        });

        return {
            email_sent: false,
            email_status: "failed",
            email_error: emailError,
        };
    }
}


async function sendManagerInviteOtpEmail(toEmail, otp, managerName) {
    return sendGmailHtmlEmail(
        toEmail,
        buildManagerInviteOtpEmail(toEmail, otp, managerName),
        "manager invitation OTP"
    );
}


async function sendStaffInviteOtpEmail(toEmail, otp, staffName) {
    return sendGmailHtmlEmail(
        toEmail,
        buildStaffInviteOtpEmail(toEmail, otp, staffName),
        "staff invitation OTP"
    );
}

async function sendPaymentOtpEmail(toEmail, otp, planName) {
    return sendGmailHtmlEmail(
        toEmail,
        buildPaymentOtpEmail(toEmail, otp, planName),
        "payment verification OTP"
    );
}


// Sent only after the payment submission has been saved successfully.
// Acknowledgment does NOT mean that GCash funds have been verified.
function buildPaymentSubmissionAcknowledgmentEmail(toEmail, details) {
    const storeName = escapeHtml(details.store_name || "your store");
    const planName = escapeHtml(details.plan_name || "selected");
    const amount = Number(details.amount || 0).toLocaleString("en-PH", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
    });
    const paymentId = escapeHtml(details.payment_submission_id);

    const html = `
        <div style="font-family:Arial,sans-serif;background:#FDFAF4;padding:24px;color:#3F354C;">
          <div style="max-width:560px;margin:auto;background:#fff;border:1px solid #E7DCEB;border-radius:16px;padding:28px;">
            <h2 style="color:#2D1B4E;margin:0;">StockNBook</h2>
            <p>Thank you for choosing StockNBook, <strong>${storeName}</strong>!</p>
            <p>We have <strong>received your GCash payment details and proof</strong> for the
              <strong>${planName}</strong> plan. Your submission is now <strong>Pending Review</strong>.</p>
            <div style="background:#F6F1FB;border-radius:12px;padding:16px;margin:20px 0;">
              <p style="margin:6px 0;">Plan: <strong>${planName}</strong></p>
              <p style="margin:6px 0;">Submitted amount: <strong>PHP ${amount}</strong></p>
              <p style="margin:6px 0;">Submission ID: <strong>#${paymentId}</strong></p>
              <p style="margin:6px 0;">Status: <strong>Pending Review</strong></p>
            </div>
            <p>Please allow <strong>up to 24 hours</strong> for the Platform Admin to review your payment.
              Reviews may take longer if extra verification is necessary.</p>
            <p><strong>Your plan is not yet activated by this email.</strong> We'll email you again if
              the payment is approved and your subscription is activated.</p>
            <p>If you did not submit this payment, contact StockNBook support.</p>
            <p style="margin-top:24px;color:#2D1B4E;font-weight:bold;">— StockNBook Team</p>
          </div>
        </div>`;
    return [
        `From: ${EMAIL_FROM}`,
        `To: ${sanitizeEmailHeader(toEmail)}`,
        "Subject: StockNBook - We received your subscription payment proof",
        `Date: ${new Date().toUTCString()}`,
        "MIME-Version: 1.0",
        'Content-Type: text/html; charset="UTF-8"',
        "Content-Transfer-Encoding: 8bit",
        "",
        html,
    ].join("\r\n").replace(/^\./gm, "..");
}

async function sendPaymentSubmissionAcknowledgmentEmail(toEmail, details) {
    return sendGmailHtmlEmail(
        toEmail,
        buildPaymentSubmissionAcknowledgmentEmail(toEmail, details),
        "subscription payment submission acknowledgment"
    );
}

function generateSlug(storeName) {
    return storeName
        .toLowerCase()
        .trim()
        .replace(/[^a-z0-9\s-]/g, "")
        .replace(/\s+/g, "-")
        .replace(/-+/g, "-");
}

/*
 * MySQL connection stored directly in this Lambda code.
 *
 * The previous error said "using password: NO" because
 * password: process.env.DB_PASSWORD was undefined.
 */

const dbConfig = {
    host: "127.0.0.1",
    user: "root",
    password: "BTA5EYVWLfWcebF",
    database: "stocknbook_v2",
    ssl: { rejectUnauthorized: false },
};

// Reuse database connections across warm requests. This avoids paying the
// TCP/TLS/database handshake cost for every dashboard API call.
const dbPool = mysql.createPool({
    ...dbConfig,
    waitForConnections: true,
    connectionLimit: 5,
    queueLimit: 0,
});



function getBearerTokenFromEvent(event) {
    const authHeader =
        event.headers?.Authorization || event.headers?.authorization || "";
    return String(authHeader).replace(/^Bearer\s+/i, "").trim();
}

// Subscription payment submissions are stored in subscription_payments.
async function getPlanColumnsForOwner() {
    return {
        id: "id",
        storeId: "store_id",
        planId: "plan_id",
        amount: "amount",
        reference: "reference_number",
        receipt: "receipt_storage_key",
        status: "status",
        createdAt: "submitted_at",
    };
}

function normalizePlanLimit(value) {
    if (value === null || value === undefined || Number(value) === 0) return null;
    return Number(value);
}

// These defaults mirror the Platform Admin dashboard. Database values always
// win, so an admin edit is reflected in the owner's checkout immediately.
const DEFAULT_PLATFORM_GCASH_SETTINGS = {
    account_name: "StockNBook Admin",
    gcash_number: "0917 123 4567",
    instruction: "Include your store name",
    qr_image: "",
};

async function getPlatformGcashPaymentSettings(connection) {
    const [rows] = await connection.execute(
        `SELECT \`key\`, value
         FROM platform_settings
         WHERE \`key\` IN ('gcash_account_name', 'gcash_number', 'gcash_instruction', 'gcash_qr_image')`
    );

    const values = {};
    for (const row of rows) {
        values[String(row.key)] = String(row.value ?? "");
    }

    const paymentSettings = {
        account_name:
            values.gcash_account_name?.trim() ||
            DEFAULT_PLATFORM_GCASH_SETTINGS.account_name,
        gcash_number:
            values.gcash_number?.trim() ||
            DEFAULT_PLATFORM_GCASH_SETTINGS.gcash_number,
        instruction:
            values.gcash_instruction?.trim() ||
            DEFAULT_PLATFORM_GCASH_SETTINGS.instruction,
        qr_image:
            values.gcash_qr_image?.trim() ||
            DEFAULT_PLATFORM_GCASH_SETTINGS.qr_image,
    };

    return {
        ...paymentSettings,
        configured: Boolean(paymentSettings.account_name && paymentSettings.gcash_number),
    };
}

const BUILT_IN_SUBSCRIPTION_PLAN_TIER = {
    starter: 1,
    growth: 2,
    scale: 3,
};

function getSubscriptionPlanTier(plan) {
    if (!plan) return null;

    const explicitTier = Number(plan.tier_order);
    if (Number.isInteger(explicitTier) && explicitTier > 0) {
        return explicitTier;
    }

    return (
        BUILT_IN_SUBSCRIPTION_PLAN_TIER[
            String(plan.name || "").trim().toLowerCase()
            ] ?? null
    );
}

function getSubscriptionPlanDirection(currentPlan, targetPlan) {
    if (!currentPlan || !targetPlan) return null;
    if (Number(currentPlan.id) === Number(targetPlan.id)) return "current";

    const currentTier = getSubscriptionPlanTier(currentPlan);
    const targetTier = getSubscriptionPlanTier(targetPlan);

    if (currentTier !== null && targetTier !== null) {
        return targetTier > currentTier ? "upgrade" : "downgrade";
    }

    // Compatibility fallback for any custom plan that has no explicit/built-in tier.
    const currentPrice = Number(currentPlan.price || 0);
    const targetPrice = Number(targetPlan.price || 0);
    return targetPrice > currentPrice ? "upgrade" : "downgrade";
}

function dateOnlyUtc(value = new Date()) {
    return new Date(value).toISOString().slice(0, 10);
}

function addUtcDays(dateOnly, days) {
    const date = new Date(`${dateOnly}T00:00:00.000Z`);
    date.setUTCDate(date.getUTCDate() + Number(days));
    return date.toISOString().slice(0, 10);
}

async function getPendingSubscriptionPlanChange(connection, storeId) {

    const [rows] = await connection.execute(
        `SELECT
             s.id,
             s.id AS subscription_id,
             s.store_id,
             s.plan_id AS current_plan_id,
             s.scheduled_plan_id AS target_plan_id,
             'DOWNGRADE' AS change_type,
             CASE
                 WHEN DATE(s.scheduled_change_at) <= UTC_DATE() AND COALESCE(target_plan.price, 0) > 0
             THEN 'AWAITING_PAYMENT'
             ELSE 'SCHEDULED'
        END AS status,
             'owner' AS requested_by_role,
             NULL AS requested_by_email,
             s.updated_at AS requested_at,
             s.scheduled_change_at AS effective_at,
             NULL AS cancelled_at,
             NULL AS applied_at,
             NULL AS notes,
             current_plan.plan_name AS current_plan_name,
             target_plan.plan_name AS target_plan_name,
             target_plan.price AS target_plan_price,
             target_plan.max_inventory AS target_max_inventory,
             target_plan.max_bookings AS target_max_bookings,
             target_plan.max_staff AS target_max_staff,
             target_plan.max_branches AS target_max_branches
         FROM subscriptions s
                  LEFT JOIN plans current_plan ON current_plan.id = s.plan_id
                  LEFT JOIN plans target_plan ON target_plan.id = s.scheduled_plan_id
         WHERE s.store_id = ?
           AND s.scheduled_plan_id IS NOT NULL
         ORDER BY s.id DESC
             LIMIT 1`,
        [storeId]
    );

    return rows[0] || null;
}

function serializeSubscriptionPlanChange(row) {
    if (!row) return null;

    return {
        id: Number(row.id),
        subscription_id:
            row.subscription_id == null ? null : Number(row.subscription_id),
        current_plan_id: Number(row.current_plan_id),
        current_plan_name: row.current_plan_name || null,
        target_plan_id: Number(row.target_plan_id),
        target_plan_name: row.target_plan_name || null,
        target_plan_price: Number(row.target_plan_price || 0),
        change_type: String(row.change_type || "DOWNGRADE").toUpperCase(),
        status: String(row.status || "SCHEDULED").toUpperCase(),
        requested_at: row.requested_at || null,
        effective_at: row.effective_at
            ? dateOnlyUtc(row.effective_at)
            : null,
    };
}

async function processDueSubscriptionPlanChange(connection, storeId) {
    const change = await getPendingSubscriptionPlanChange(connection, storeId);
    if (!change) return null;

    const status = String(change.status || "").toUpperCase();
    if (status !== "SCHEDULED") return change;

    const effectiveAt = change.effective_at
        ? dateOnlyUtc(change.effective_at)
        : null;

    if (!effectiveAt || effectiveAt > dateOnlyUtc()) {
        return change;
    }

    const [targetRows] = await connection.execute(
        `SELECT *, plan_name AS name FROM plans WHERE id = ? LIMIT 1`,
        [change.target_plan_id]
    );
    const targetPlan = targetRows[0] || null;

    if (!targetPlan || Number(targetPlan.is_archived) === 1) {
        await connection.execute(
            `UPDATE subscriptions
             SET scheduled_plan_id = NULL,
                 scheduled_change_at = NULL
             WHERE id = ? AND scheduled_plan_id IS NOT NULL`,
            [change.id]
        );
        return null;
    }

    // Paid lower-tier plans still require the owner's normal GCash payment and
    // platform-admin verification. The scheduled record simply makes that lower
    // plan eligible for payment after the current paid period ends.
    // The awaiting-payment state is derived from subscriptions.scheduled_change_at.
    if (Number(targetPlan.price || 0) > 0) {
        return getPendingSubscriptionPlanChange(connection, storeId);
    }

    // A free target plan (Starter) needs no GCash payment. Apply it automatically
    // when the current paid period has fully ended.
    await connection.beginTransaction();
    try {
        const [subscriptionRows] = await connection.execute(
            `SELECT * FROM subscriptions
             WHERE store_id = ?
             ORDER BY id DESC
                 LIMIT 1
             FOR UPDATE`,
            [storeId]
        );
        const subscription = subscriptionRows[0] || null;

        if (!subscription) {
            throw Object.assign(
                new Error("The current subscription record could not be found."),
                { statusCode: 409 }
            );
        }

        await connection.execute(
            `UPDATE subscriptions
             SET plan_id = ?,
                 status = 'active',
                 started_at = ?,
                 expires_at = NULL,
                 scheduled_plan_id = NULL,
                 scheduled_change_at = NULL
             WHERE id = ?`,
            [targetPlan.id, effectiveAt, subscription.id]
        );

        // The UPDATE above applied the plan and cleared the scheduled change.
        await connection.commit();
        return null;
    } catch (error) {
        await connection.rollback();
        throw error;
    }
}

function getDowngradeUsageIssues(snapshot, targetPlan) {
    const checks = [
        {
            key: "inventory",
            label: "Inventory",
            current: Number(snapshot.usage.inventory || 0),
            limit: normalizePlanLimit(targetPlan.max_inventory),
        },
        {
            key: "bookings",
            label: "Bookings",
            current: Number(snapshot.usage.bookings || 0),
            limit: normalizePlanLimit(targetPlan.max_bookings),
        },
        {
            key: "staff",
            label: "Staff",
            current: Number(snapshot.usage.staff || 0),
            limit: normalizePlanLimit(targetPlan.max_staff),
        },
        {
            key: "branches",
            label: "Branches",
            current: Number(snapshot.usage.branches || 0),
            limit: normalizePlanLimit(targetPlan.max_branches),
        },
    ];

    return checks.filter(
        (item) => item.limit !== null && item.current > Number(item.limit)
    );
}

async function getStoreSubscriptionSnapshot(connection, storeId) {
    const [subscriptionRows] = await connection.execute(
        `SELECT
             s.id AS subscription_id,
             s.plan_id,
             s.status,
             s.started_at,
             s.expires_at,
             p.id AS plan_id_joined,
             p.plan_name AS name,
             p.price,
             p.max_inventory,
             p.max_bookings,
             p.max_staff,
             p.max_branches,
             p.has_low_stock_alerts,
             p.has_analytics,
             p.has_forecasting,
             p.has_multi_store,
             p.is_archived
         FROM subscriptions s
                  INNER JOIN plans p ON p.id = s.plan_id
         WHERE s.store_id = ?
         ORDER BY s.id DESC
             LIMIT 1`,
        [storeId]
    );

    let subscription = subscriptionRows[0] || null;

    if (!subscription) {
        const [starterRows] = await connection.execute(
            `SELECT
                 id AS plan_id,
                 plan_name AS name,
                 price,
                 max_inventory,
                 max_bookings,
                 max_staff,
                 max_branches,
                 has_low_stock_alerts,
                 has_analytics,
                 has_forecasting,
                 has_multi_store,
                 is_archived
             FROM plans
             WHERE is_archived = 0
               AND (LOWER(plan_code) = 'starter' OR LOWER(plan_name) = 'starter' OR price = 0)
             ORDER BY price ASC, id ASC
                 LIMIT 1`
        );

        subscription = starterRows[0]
            ? {
                ...starterRows[0],
                subscription_id: null,
                status: "active",
                started_at: null,
                expires_at: null,
            }
            : null;
    }

    if (!subscription) {
        const error = new Error("No active plan is configured for this platform.");
        error.statusCode = 500;
        throw error;
    }

    // Use the same usage calculation as the plan-enforcement layer so a
    // downgrade cannot be approved by the Subscription page while another
    // module would still consider the store above the target plan limit.
    const usage = await getStoreUsage(connection, storeId);

    const [pendingPaymentRows] = await connection.execute(
        `SELECT COUNT(*) AS total
         FROM subscription_payments
         WHERE store_id = ?
           AND UPPER(status) = 'PENDING'`,
        [storeId]
    );

    const expiresAt = subscription.expires_at
        ? dateOnlyUtc(subscription.expires_at)
        : null;

    let displayStatus = String(subscription.status || "active").toUpperCase();
    if (
        displayStatus !== "CANCELLED" &&
        expiresAt &&
        expiresAt < dateOnlyUtc()
    ) {
        displayStatus = "EXPIRED";
    }

    return {
        subscription_id:
            subscription.subscription_id == null
                ? null
                : Number(subscription.subscription_id),
        status: displayStatus,
        started_at: subscription.started_at || null,
        expires_at: expiresAt,
        plan: {
            id: Number(subscription.plan_id || subscription.plan_id_joined),
            name: subscription.name,
            price: Number(subscription.price || 0),
            max_inventory: normalizePlanLimit(subscription.max_inventory),
            max_bookings: normalizePlanLimit(subscription.max_bookings),
            max_staff: normalizePlanLimit(subscription.max_staff),
            max_branches: normalizePlanLimit(subscription.max_branches),
            has_low_stock_alerts: Boolean(subscription.has_low_stock_alerts),
            has_analytics: Boolean(subscription.has_analytics),
            has_forecasting: Boolean(subscription.has_forecasting),
            has_multi_store: Boolean(subscription.has_multi_store),
        },
        usage: {
            inventory: Number(usage.inventory || 0),
            bookings: Number(usage.bookings || 0),
            staff: Number(usage.staff || 0),
            branches: Number(usage.branches || 0),
        },
        pending_payment: Number(pendingPaymentRows[0]?.total || 0) > 0,
    };
}

async function getOwnerSubscription(connection, storeId) {
    await processDueSubscriptionPlanChange(connection, storeId);

    const snapshot = await getStoreSubscriptionSnapshot(connection, storeId);
    const pendingChange = await getPendingSubscriptionPlanChange(connection, storeId);

    const [planRows] = await connection.execute(
        `SELECT
             id,
             plan_name AS name,
             price,
             max_inventory,
             max_bookings,
             max_staff,
             max_branches,
             has_low_stock_alerts,
             has_analytics,
             has_forecasting,
             has_multi_store
         FROM plans
         WHERE is_archived = 0
         ORDER BY
             CASE LOWER(plan_name)
                 WHEN 'starter' THEN 1
                 WHEN 'growth' THEN 2
                 WHEN 'scale' THEN 3
                 ELSE 100
                 END ASC,
             price ASC,
             id ASC`
    );

    const effectivePlan = await getActivePlan(connection, storeId);
    const expiryDay = snapshot.expires_at;
    const dateToday = dateOnlyUtc();
    const daysUntilExpiration = expiryDay
        ? Math.round((Date.parse(`${expiryDay}T00:00:00Z`) - Date.parse(`${dateToday}T00:00:00Z`)) / 86400000)
        : null;
    const status = String(snapshot.status || '').toUpperCase();
    const displayStatus = status === 'ACTIVE' && daysUntilExpiration !== null &&
    daysUntilExpiration >= 0 && daysUntilExpiration <= 7 && Number(snapshot.plan.price) > 0
        ? 'EXPIRING' : status;
    return {
        ...snapshot,
        status: displayStatus,
        effective_plan: effectivePlan,
        access_status: effectivePlan?.access_status || 'STARTER_FALLBACK',
        days_until_expiration: daysUntilExpiration,
        scheduled_change: serializeSubscriptionPlanChange(pendingChange),
        available_plans: planRows.map((row) => ({
            id: Number(row.id),
            name: row.name,
            price: Number(row.price || 0),
            max_inventory: normalizePlanLimit(row.max_inventory),
            max_bookings: normalizePlanLimit(row.max_bookings),
            max_staff: normalizePlanLimit(row.max_staff),
            max_branches: normalizePlanLimit(row.max_branches),
            has_low_stock_alerts: Boolean(row.has_low_stock_alerts),
            has_analytics: Boolean(row.has_analytics),
            has_forecasting: Boolean(row.has_forecasting),
            has_multi_store: Boolean(row.has_multi_store),
        })),
    };
}

async function requestOwnerSubscriptionDowngrade(connection, decoded, body) {
    if (decoded.role !== "owner" || !decoded.store_id) {
        const error = new Error("Only the store owner can request a downgrade.");
        error.statusCode = 403;
        throw error;
    }

    const storeId = Number(decoded.store_id);
    const targetPlanId = Number(body.plan_id);

    if (!Number.isInteger(targetPlanId) || targetPlanId <= 0) {
        const error = new Error("Select a valid downgrade plan.");
        error.statusCode = 400;
        throw error;
    }

    await processDueSubscriptionPlanChange(connection, storeId);

    const snapshot = await getStoreSubscriptionSnapshot(connection, storeId);
    if (!snapshot.subscription_id) {
        const error = new Error("The current plan does not have a lower subscription tier to schedule.");
        error.statusCode = 409;
        throw error;
    }

    if (snapshot.pending_payment) {
        const error = new Error("Finish the payment request that is already awaiting review before scheduling another plan change.");
        error.statusCode = 409;
        throw error;
    }

    const [targetRows] = await connection.execute(
        `SELECT *, plan_name AS name FROM plans WHERE id = ? AND is_archived = 0 LIMIT 1`,
        [targetPlanId]
    );
    const targetPlan = targetRows[0] || null;

    if (!targetPlan) {
        const error = new Error("The selected downgrade plan is no longer available.");
        error.statusCode = 404;
        throw error;
    }

    const direction = getSubscriptionPlanDirection(snapshot.plan, {
        id: Number(targetPlan.id),
        name: targetPlan.name,
        price: Number(targetPlan.price || 0),
    });

    if (direction !== "downgrade") {
        const error = new Error("The selected plan is not a lower subscription tier.");
        error.statusCode = 409;
        throw error;
    }

    const issues = getDowngradeUsageIssues(snapshot, targetPlan);
    if (issues.length) {
        const details = issues
            .map(
                (item) =>
                    `${item.label}: ${item.current} / ${item.limit}`
            )
            .join("; ");
        const error = new Error(
            `Your current usage exceeds the ${targetPlan.name} plan limits. ${details}`
        );
        error.statusCode = 409;
        error.usage_issues = issues;
        throw error;
    }

    const existingChange = await getPendingSubscriptionPlanChange(connection, storeId);
    if (existingChange) {
        const error = new Error(
            `A ${String(existingChange.target_plan_name || "lower-tier")} downgrade is already ${String(existingChange.status || "scheduled").toLowerCase().replace(/_/g, " ")}. Cancel it before requesting another downgrade.`
        );
        error.statusCode = 409;
        throw error;
    }

    const currentExpiry = snapshot.expires_at;
    const effectiveAt = currentExpiry
        ? addUtcDays(currentExpiry, 1)
        : dateOnlyUtc();

    const [result] = await connection.execute(
        `UPDATE subscriptions
         SET scheduled_plan_id = ?,
             scheduled_change_at = ?
         WHERE id = ?
           AND store_id = ?`,
        [
            targetPlan.id,
            effectiveAt,
            snapshot.subscription_id,
            storeId,
        ]
    );

    // If the current period is already over, immediately advance the scheduled
    // record to the correct next state (automatic Starter or awaiting paid plan).
    await processDueSubscriptionPlanChange(connection, storeId);
    const scheduled = await getPendingSubscriptionPlanChange(connection, storeId);

    return {
        message:
            Number(targetPlan.price || 0) > 0
                ? `Downgrade to ${targetPlan.name} scheduled. Your current plan remains active through its paid period; payment for ${targetPlan.name} will be requested when the downgrade becomes effective.`
                : `Downgrade to ${targetPlan.name} scheduled. It will apply automatically after the current paid period ends.`,
        change_id: Number(result.affectedRows ? snapshot.subscription_id : 0),
        scheduled_change: serializeSubscriptionPlanChange(scheduled),
    };
}

async function cancelOwnerSubscriptionDowngrade(connection, decoded) {
    if (decoded.role !== "owner" || !decoded.store_id) {
        const error = new Error("Only the store owner can cancel a scheduled downgrade.");
        error.statusCode = 403;
        throw error;
    }

    const storeId = Number(decoded.store_id);
    await processDueSubscriptionPlanChange(connection, storeId);

    const change = await getPendingSubscriptionPlanChange(connection, storeId);
    if (!change) {
        const error = new Error("There is no scheduled downgrade to cancel.");
        error.statusCode = 404;
        throw error;
    }

    const changeStatus = String(change.status || "").toUpperCase();
    const effectiveAt = change.effective_at ? dateOnlyUtc(change.effective_at) : null;

    if (changeStatus !== "SCHEDULED" || (effectiveAt && effectiveAt <= dateOnlyUtc())) {
        const error = new Error(
            "This downgrade has already reached its effective date and can no longer be cancelled from the owner screen."
        );
        error.statusCode = 409;
        throw error;
    }

    const [pendingPaymentRows] = await connection.execute(
        `SELECT COUNT(*) AS total
         FROM subscription_payments
         WHERE store_id = ?
           AND UPPER(status) = 'PENDING'`,
        [storeId]
    );

    if (Number(pendingPaymentRows[0]?.total || 0) > 0) {
        const error = new Error("A subscription payment is already awaiting review. Resolve that payment before cancelling the downgrade.");
        error.statusCode = 409;
        throw error;
    }

    await connection.execute(
        `UPDATE subscriptions
         SET scheduled_plan_id = NULL,
             scheduled_change_at = NULL
         WHERE id = ?
           AND scheduled_plan_id IS NOT NULL`,
        [change.id]
    );

    return {
        message: "Scheduled downgrade cancelled.",
        cancelled_change_id: Number(change.id),
    };
}

async function submitOwnerPlanPayment(connection, decoded, body) {
    if (decoded.role !== "owner" || !decoded.store_id) {
        const error = new Error("Only the store owner can change the subscription.");
        error.statusCode = 403;
        throw error;
    }

    const storeId = Number(decoded.store_id);
    const planId = Number(body.plan_id);
    const referenceNumber = String(body.reference_number || "").trim();
    const receiptMimeType = String(body.receipt_mime_type || "").trim().toLowerCase();
    const receiptBase64 = body.receipt_base64;
    const maxReceiptBytes = 5 * 1024 * 1024;
    const maxBase64Length = Math.ceil(maxReceiptBytes / 3) * 4;
    const receiptTypes = ["image/png", "image/jpeg", "image/webp"];

    if (!receiptTypes.includes(receiptMimeType) || typeof receiptBase64 !== "string" ||
        !receiptBase64 || receiptBase64.length > maxBase64Length ||
        receiptBase64.length % 4 !== 0) {
        const error = new Error("Upload a valid PNG, JPG, JPEG, or WEBP receipt (maximum 5 MB).");
        error.statusCode = 400;
        throw error;
    }

    const receiptData = Buffer.from(receiptBase64, "base64");
    // Round-trip validation rejects malformed / noncanonical base64 without a
    // large, backtracking regular expression for multi-megabyte uploads.
    if (receiptData.toString("base64") !== receiptBase64) {
        const error = new Error("The receipt image data is invalid.");
        error.statusCode = 400;
        throw error;
    }
    if (!receiptData.length || receiptData.length > maxReceiptBytes) {
        const error = new Error("The receipt image must be 5 MB or smaller.");
        error.statusCode = 400;
        throw error;
    }

    // Content signature check: do not trust the browser's declared MIME type.
    const validImage = receiptMimeType === "image/png"
        ? receiptData.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]))
        : receiptMimeType === "image/jpeg"
            ? receiptData.length >= 3 && receiptData[0] === 255 && receiptData[1] === 216 && receiptData[2] === 255
            : receiptData.length >= 12 && receiptData.toString("ascii", 0, 4) === "RIFF" &&
            receiptData.toString("ascii", 8, 12) === "WEBP";
    if (!validImage) {
        const error = new Error("The selected file is not a valid receipt image.");
        error.statusCode = 400;
        throw error;
    }

    if (!Number.isInteger(planId) || planId <= 0) {
        const error = new Error("Select a valid plan.");
        error.statusCode = 400;
        throw error;
    }

    if (!referenceNumber || referenceNumber.length < 4 || referenceNumber.length > 120) {
        const error = new Error("Enter a valid GCash reference number.");
        error.statusCode = 400;
        throw error;
    }

    await processDueSubscriptionPlanChange(connection, storeId);

    const [planRows] = await connection.execute(
        `SELECT *, plan_name AS name FROM plans WHERE id = ? AND is_archived = 0 LIMIT 1`,
        [planId]
    );
    const targetPlan = planRows[0];

    if (!targetPlan) {
        const error = new Error("The selected plan is no longer available.");
        error.statusCode = 404;
        throw error;
    }

    if (Number(targetPlan.price || 0) <= 0) {
        const error = new Error("Starter does not require a payment submission.");
        error.statusCode = 400;
        throw error;
    }

    const snapshot = await getStoreSubscriptionSnapshot(connection, storeId);
    const direction = getSubscriptionPlanDirection(snapshot.plan, {
        id: Number(targetPlan.id),
        name: targetPlan.name,
        price: Number(targetPlan.price || 0),
    });

    // Once the previous paid term has expired, a new paid plan may be chosen
    // freely; there is no remaining paid period to schedule a downgrade for.
    if (direction === "downgrade" && snapshot.status !== "EXPIRED") {
        const scheduled = await getPendingSubscriptionPlanChange(connection, storeId);
        const validScheduledDowngrade =
            scheduled &&
            String(scheduled.status || "").toUpperCase() === "AWAITING_PAYMENT" &&
            Number(scheduled.target_plan_id) === Number(targetPlan.id);

        if (!validScheduledDowngrade) {
            const error = new Error(
                "Lower-tier paid plans must first be requested as a downgrade and become due at the end of the current paid period."
            );
            error.statusCode = 409;
            throw error;
        }
    }

    const columns = await getPlanColumnsForOwner(connection);

    const [pendingRows] = await connection.execute(
        `SELECT ${columns.id} AS payment_id
         FROM subscription_payments
         WHERE ${columns.storeId} = ?
           AND UPPER(${columns.status}) = 'PENDING'
             LIMIT 1`,
        [storeId]
    );

    if (pendingRows.length) {
        const error = new Error("You already have a payment awaiting platform admin review.");
        error.statusCode = 409;
        throw error;
    }

    const [duplicateRows] = await connection.execute(
        `SELECT ${columns.id} AS payment_id
         FROM subscription_payments
         WHERE ${columns.reference} = ?
           AND UPPER(${columns.status}) IN ('PENDING', 'APPROVED')
             LIMIT 1`,
        [referenceNumber]
    );

    if (duplicateRows.length) {
        const error = new Error("That GCash reference number has already been submitted.");
        error.statusCode = 409;
        throw error;
    }


    const otp = String(body.otp || "").trim();

    if (!/^\d{6}$/.test(otp)) {
        const error = new Error("Enter the 6-digit verification code sent to your email.");
        error.statusCode = 400;
        throw error;
    }

    const otpHash = hashOtp(otp);

    await connection.execute(
        `UPDATE otp_codes
         SET used_at = UTC_TIMESTAMP()
         WHERE purpose = 'subscription_payment'
           AND store_id = ?
           AND used_at IS NULL
           AND expires_at <= UTC_TIMESTAMP()`,
        [storeId]
    );

    const [otpRows] = await connection.execute(
        `SELECT id
         FROM otp_codes
         WHERE purpose = 'subscription_payment'
           AND store_id = ?
           AND otp_hash = ?
           AND used_at IS NULL
           AND expires_at > UTC_TIMESTAMP()
         ORDER BY id DESC
             LIMIT 1`,
        [storeId, otpHash]
    );

    if (!otpRows.length) {
        const error = new Error("That verification code is invalid or has expired. Request a new one.");
        error.statusCode = 400;
        throw error;
    }

    await connection.execute(`UPDATE otp_codes SET used_at = UTC_TIMESTAMP() WHERE id = ?`, [otpRows[0].id]);

    const insertColumns = [
        columns.storeId,
        columns.planId,
        "subscription_id",
        columns.amount,
        "payment_method",
        columns.reference,
        columns.status,
    ];
    const insertValues = [
        storeId,
        planId,
        snapshot.subscription_id || null,
        Number(targetPlan.price),
        "GCash",
        referenceNumber,
        "pending",
    ];

    // Store the image with the payment record, not in a publicly accessible path.
    insertColumns.push("receipt_data", "receipt_mime_type");
    insertValues.push(receiptData, receiptMimeType);

    if (columns.createdAt) {
        insertColumns.push(columns.createdAt);
        insertValues.push(new Date());
    }

    const placeholders = insertColumns.map(() => "?").join(", ");
    const [result] = await connection.execute(
        `INSERT INTO subscription_payments (${insertColumns.join(", ")}) VALUES (${placeholders})`,
        insertValues
    );

    return {
        message: "Payment submitted for platform admin review.",
        payment_submission_id: Number(result.insertId),
        plan_name: targetPlan.name,
        amount: Number(targetPlan.price),
    };
}

module.exports.handler = async (event) => {
    const headers = {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type, Authorization",
        "Access-Control-Allow-Methods": "POST, OPTIONS",
        "Content-Type": "application/json",
    };

    const method =
        event?.requestContext?.http?.method ||
        event?.httpMethod;

    if (method === "OPTIONS") {
        return { statusCode: 200, headers, body: "" };
    }

    let body = {};

    try {
        body = JSON.parse(event.body || "{}");
    } catch (err) {
        return {
            statusCode: 400,
            headers,
            body: JSON.stringify({ error: "Invalid JSON body" }),
        };
    }

    const { action, store_name, email, password } = body;

    let connection;

    try {
        connection = await dbPool.getConnection();

        if (action === "get_subscription") {
            const token = getBearerTokenFromEvent(event);
            if (!token) {
                return { statusCode: 401, headers, body: JSON.stringify({ error: "Missing token" }) };
            }

            let decoded;
            try {
                decoded = jwt.verify(token, JWT_SECRET);
            } catch {
                return { statusCode: 401, headers, body: JSON.stringify({ error: "Invalid token" }) };
            }

            const subscriptionRole = String(decoded.role || "").toLowerCase();
            const allowedSubscriptionRoles = ["owner", "manager", "staff"];

            if (!allowedSubscriptionRoles.includes(subscriptionRole) || !decoded.store_id) {
                return {
                    statusCode: 403,
                    headers,
                    body: JSON.stringify({
                        error: "You do not have access to this store's plan and usage details.",
                        code: "SUBSCRIPTION_VIEW_FORBIDDEN",
                    }),
                };
            }

            // Managers and staff receive the same store-level plan snapshot for
            // visibility, but only the owner receives management permission.
            const subscription = await getOwnerSubscription(connection, Number(decoded.store_id));
            return {
                statusCode: 200,
                headers,
                body: JSON.stringify({
                    role: subscriptionRole,
                    can_manage_subscription: subscriptionRole === "owner",
                    subscription,
                }),
            };
        }

        if (action === "get_payment_settings") {
            const token = getBearerTokenFromEvent(event);
            if (!token) {
                return { statusCode: 401, headers, body: JSON.stringify({ error: "Missing token" }) };
            }

            let decoded;
            try {
                decoded = jwt.verify(token, JWT_SECRET);
            } catch {
                return { statusCode: 401, headers, body: JSON.stringify({ error: "Invalid token" }) };
            }

            if (String(decoded.role || "").toLowerCase() !== "owner" || !decoded.store_id) {
                return {
                    statusCode: 403,
                    headers,
                    body: JSON.stringify({
                        error: "Only the store owner can access subscription payment details.",
                    }),
                };
            }

            const paymentSettings = await getPlatformGcashPaymentSettings(connection);
            return {
                statusCode: 200,
                headers,
                body: JSON.stringify({ payment_settings: paymentSettings }),
            };
        }

        // SEND PAYMENT VERIFICATION OTP
        // Triggered when the owner opens the "Upgrade" payment-proof modal, before
        // they can submit a GCash reference number. Confirms it is really the
        // account owner (not just whoever is holding an open session) submitting
        // the proof of payment.
        if (action === "send_payment_otp") {
            const token = getBearerTokenFromEvent(event);
            if (!token) {
                return { statusCode: 401, headers, body: JSON.stringify({ error: "Missing token" }) };
            }

            let decoded;
            try {
                decoded = jwt.verify(token, JWT_SECRET);
            } catch {
                return { statusCode: 401, headers, body: JSON.stringify({ error: "Invalid token" }) };
            }

            if (decoded.role !== "owner" || !decoded.store_id) {
                return {
                    statusCode: 403,
                    headers,
                    body: JSON.stringify({
                        error: "Only the store owner can submit a subscription payment.",
                    }),
                };
            }

            const storeId = Number(decoded.store_id);

            let ownerEmail = String(decoded.email || "").trim().toLowerCase();
            if (!ownerEmail) {
                const [storeRows] = await connection.execute(
                    `SELECT email FROM users WHERE store_id = ? AND role = 'owner' LIMIT 1`,
                    [storeId]
                );
                ownerEmail = String(storeRows[0]?.email || "").trim().toLowerCase();
            }

            if (!ownerEmail) {
                return {
                    statusCode: 500,
                    headers,
                    body: JSON.stringify({ error: "No email is on file for this account." }),
                };
            }


            // Count accepted or still-in-progress OTP requests. A failed SMTP
            // request deletes its pending OTP and is counted separately below.
            const [recentRows] = await connection.execute(
                `SELECT COUNT(*) AS total,
                        TIMESTAMPDIFF(SECOND, NOW(),
                                              DATE_ADD(MIN(created_at), INTERVAL ? MINUTE)) AS retry_after_seconds
                 FROM otp_codes
                 WHERE purpose = 'subscription_payment'
                   AND store_id = ?
                   AND created_at > DATE_SUB(NOW(), INTERVAL ? MINUTE)`,
                [PAYMENT_OTP_RATE_WINDOW_MINUTES, storeId, PAYMENT_OTP_RATE_WINDOW_MINUTES]
            );

            if (Number(recentRows[0]?.total || 0) >= PAYMENT_OTP_MAX_SENT_PER_WINDOW) {
                const retrySeconds = paymentOtpRetrySeconds(recentRows[0]?.retry_after_seconds);
                return paymentOtpCooldownResponse(
                    headers,
                    `Too many verification emails requested. Please try again in ${formatPaymentOtpWaitTime(retrySeconds)}.`,
                    retrySeconds,
                    "PAYMENT_OTP_RATE_LIMIT"
                );
            }

            // A broken Gmail connection must not permit unlimited retries.
            // Failed attempts have their own independent 10-minute allowance.
            const [failureRows] = await connection.execute(
                `SELECT COUNT(*) AS total,
                        TIMESTAMPDIFF(SECOND, NOW(),
                                              DATE_ADD(MIN(created_at), INTERVAL ? MINUTE)) AS retry_after_seconds
                 FROM otp_codes
                 WHERE purpose = 'subscription_payment_email_failure'
                   AND store_id = ?
                   AND created_at > DATE_SUB(NOW(), INTERVAL ? MINUTE)`,
                [PAYMENT_OTP_RATE_WINDOW_MINUTES, storeId, PAYMENT_OTP_RATE_WINDOW_MINUTES]
            );

            if (Number(failureRows[0]?.total || 0) >= PAYMENT_OTP_MAX_FAILED_PER_WINDOW) {
                const retrySeconds = paymentOtpRetrySeconds(failureRows[0]?.retry_after_seconds);
                return paymentOtpCooldownResponse(
                    headers,
                    `Email delivery has failed repeatedly. Please wait ${formatPaymentOtpWaitTime(retrySeconds)} before trying again. If the issue persists, check the Auth Lambda Gmail SMTP connection.`,
                    retrySeconds,
                    "PAYMENT_OTP_EMAIL_COOLDOWN"
                );
            }

            let planName = null;
            if (body.plan_id) {
                const [planRows] = await connection.execute(
                    `SELECT plan_name AS name FROM plans WHERE id = ? LIMIT 1`,
                    [Number(body.plan_id)]
                );
                planName = planRows[0]?.name || null;
            }

            const otp = generateOtp();
            const otpHash = hashOtp(otp);

            // Keep this OTP unusable until the SMTP server accepts the email.
            // In particular, do not invalidate the owner's previous active code
            // when delivery of this replacement code fails.
            const [insertResult] = await connection.execute(
                `INSERT INTO otp_codes (purpose, store_id, email, otp_hash, expires_at, used_at)
                 VALUES ('subscription_payment', ?, ?, ?, DATE_ADD(UTC_TIMESTAMP(), INTERVAL ? SECOND), UTC_TIMESTAMP())`,
                [storeId, ownerEmail, otpHash, PAYMENT_OTP_EXPIRY_SECONDS]
            );
            const newOtpId = Number(insertResult.insertId);

            try {
                await sendPaymentOtpEmail(ownerEmail, otp, planName);
            } catch (emailError) {
                // Remove the code that was never delivered. It will not count
                // toward the five accepted-email OTP requests.
                try {
                    await connection.execute(
                        `DELETE FROM otp_codes WHERE id = ? AND store_id = ? AND purpose = 'subscription_payment' AND used_at IS NOT NULL`,
                        [newOtpId, storeId]
                    );
                } catch (cleanupError) {
                    console.error("[stocknbook-auth] Unable to clean up undelivered OTP:", {
                        store_id: storeId,
                        message: cleanupError?.message,
                    });
                }

                const smtpErrorCode = String(emailError?.code || "SMTP_DELIVERY_FAILED")
                    .replace(/[^A-Za-z0-9_]/g, "_").slice(0, 50);
                try {
                    await connection.execute(
                        `INSERT INTO otp_codes
                             (purpose, store_id, email, otp_hash, expires_at, used_at)
                         VALUES ('subscription_payment_email_failure', ?, ?, ?, UTC_TIMESTAMP(), UTC_TIMESTAMP())`,
                        [storeId, ownerEmail, smtpErrorCode]
                    );
                } catch (trackingError) {
                    console.error("[stocknbook-auth] Unable to track OTP email failure:", {
                        store_id: storeId,
                        message: trackingError?.message,
                    });
                }

                console.error("[stocknbook-auth] Subscription OTP was not delivered:", {
                    store_id: storeId,
                    code: smtpErrorCode,
                    message: emailError?.message || "Unknown SMTP failure",
                });

                const deliveryError = new Error(
                    smtpErrorCode === "GMAIL_AUTH_FAILED" || smtpErrorCode === "SMTP_NOT_CONFIGURED"
                        ? "StockNBook could not authenticate its email sender. Ask the administrator to check the Auth Lambda Gmail App Password before retrying."
                        : "StockNBook could not send the verification email. No new code was activated. Please try again shortly or check the Auth Lambda email-service logs."
                );
                deliveryError.statusCode = 503;
                deliveryError.code = "PAYMENT_OTP_EMAIL_FAILED";
                throw deliveryError;
            }

            // Gmail accepted the message: now activate the new code atomically
            // and invalidate only the previously active code(s).
            await connection.beginTransaction();
            try {
                await connection.execute(
                    `UPDATE otp_codes SET used_at = UTC_TIMESTAMP() WHERE purpose = 'subscription_payment' AND store_id = ? AND used_at IS NULL`,
                    [storeId]
                );
                const [activation] = await connection.execute(
                    `UPDATE otp_codes
                     SET used_at = NULL, expires_at = DATE_ADD(UTC_TIMESTAMP(), INTERVAL ? SECOND)
                     WHERE id = ? AND store_id = ? AND purpose = 'subscription_payment' AND used_at IS NOT NULL`,
                    [PAYMENT_OTP_EXPIRY_SECONDS, newOtpId, storeId]
                );
                if (Number(activation.affectedRows || 0) !== 1) {
                    throw new Error("The emailed OTP could not be activated in the database.");
                }
                await connection.commit();
            } catch (activationError) {
                await connection.rollback();
                throw activationError;
            }

            // Explicit local debug remains optional, but a failed email never
            // silently turns into a successful terminal-only OTP.
            if (PAYMENT_OTP_TERMINAL_DEBUG) {
                console.log(
                    `[StockNBook DEV OTP] Subscription payment verification | ` +
                    `Store ID: ${storeId} | ` +
                    `Plan: ${planName || "Selected plan"} | ` +
                    `Email: ${ownerEmail} | ` +
                    `OTP: ${otp} | ` +
                    `Expires in: ${PAYMENT_OTP_EXPIRY_SECONDS}s`
                );
            }

            return {
                statusCode: 200,
                headers,
                body: JSON.stringify({
                    message: "Verification code sent to your email.",
                    delivery: "email",
                    expires_in: PAYMENT_OTP_EXPIRY_SECONDS,
                    email_hint: ownerEmail.replace(/^(.{2}).+(@.+)$/, "$1***$2"),
                }),
            };
        }

        if (action === "submit_subscription_payment") {
            const token = getBearerTokenFromEvent(event);
            if (!token) {
                return { statusCode: 401, headers, body: JSON.stringify({ error: "Missing token" }) };
            }

            let decoded;
            try {
                decoded = jwt.verify(token, JWT_SECRET);
            } catch {
                return { statusCode: 401, headers, body: JSON.stringify({ error: "Invalid token" }) };
            }

            const result = await submitOwnerPlanPayment(connection, decoded, body);

            // The payment INSERT succeeded. Email delivery is best-effort so an
            // SMTP outage never causes the owner to re-submit an existing payment.
            let confirmationEmailStatus = "failed";
            try {
                const [storeRows] = await connection.execute(
                    `SELECT s.store_name, u.email
                     FROM stores s
                              LEFT JOIN users u ON u.store_id = s.id AND u.role = 'owner'
                     WHERE s.id = ?
                         LIMIT 1`,
                    [Number(decoded.store_id)]
                );
                const store = storeRows[0];
                const ownerEmail = String(store?.email || "").trim().toLowerCase();
                if (ownerEmail) {
                    await sendPaymentSubmissionAcknowledgmentEmail(ownerEmail, {
                        ...result,
                        store_name: store.store_name,
                    });
                    confirmationEmailStatus = "sent";
                } else {
                    confirmationEmailStatus = "no_email_on_file";
                }
            } catch (notificationError) {
                console.error("[stocknbook-auth] Payment saved, but acknowledgment email failed:", {
                    payment_submission_id: result.payment_submission_id,
                    message: notificationError?.message || "Unknown email error",
                });
            }
            return {
                statusCode: 201,
                headers,
                body: JSON.stringify({
                    ...result,
                    confirmation_email_status: confirmationEmailStatus,
                }),
            };
        }

        if (action === "request_subscription_downgrade") {
            const token = getBearerTokenFromEvent(event);
            if (!token) {
                return { statusCode: 401, headers, body: JSON.stringify({ error: "Missing token" }) };
            }

            let decoded;
            try {
                decoded = jwt.verify(token, JWT_SECRET);
            } catch {
                return { statusCode: 401, headers, body: JSON.stringify({ error: "Invalid token" }) };
            }

            const result = await requestOwnerSubscriptionDowngrade(
                connection,
                decoded,
                body
            );
            return { statusCode: 201, headers, body: JSON.stringify(result) };
        }

        if (action === "cancel_subscription_downgrade") {
            const token = getBearerTokenFromEvent(event);
            if (!token) {
                return { statusCode: 401, headers, body: JSON.stringify({ error: "Missing token" }) };
            }

            let decoded;
            try {
                decoded = jwt.verify(token, JWT_SECRET);
            } catch {
                return { statusCode: 401, headers, body: JSON.stringify({ error: "Invalid token" }) };
            }

            const result = await cancelOwnerSubscriptionDowngrade(
                connection,
                decoded
            );
            return { statusCode: 200, headers, body: JSON.stringify(result) };
        }

        // SEND SIGNUP OTP
        if (action === "send_signup_otp") {

            const ownerName = String(
                body.owner_name ?? body.ownerName ?? ""
            ).trim();

            const storeName = String(
                body.store_name ?? body.storeName ?? ""
            ).trim();

            const phoneNumber = String(
                body.phone_number ?? body.phoneNumber ?? body.phone ?? ""
            ).trim();

            const emailAddress = String(body.email ?? "").trim().toLowerCase();
            const accountPassword = String(body.password ?? "");

            if (!ownerName || !storeName || !phoneNumber || !emailAddress || !accountPassword) {
                return {
                    statusCode: 400,
                    headers,
                    body: JSON.stringify({
                        error: "Owner name, business name, phone number, email, and password are required.",
                    }),
                };
            }

            const phoneDigits = phoneNumber.replace(/\D/g, "");

            if (phoneDigits.length < 10 || phoneDigits.length > 15) {
                return {
                    statusCode: 400,
                    headers,
                    body: JSON.stringify({ error: "Enter a valid phone number." }),
                };
            }

            if (!/^\S+@\S+\.\S+$/.test(emailAddress)) {
                return {
                    statusCode: 400,
                    headers,
                    body: JSON.stringify({ error: "Enter a valid email address." }),
                };
            }

            if (accountPassword.length < 8) {
                return {
                    statusCode: 400,
                    headers,
                    body: JSON.stringify({ error: "Password must contain at least 8 characters." }),
                };
            }

            const slug = generateSlug(storeName);

            if (!slug) {
                return {
                    statusCode: 400,
                    headers,
                    body: JSON.stringify({ error: "Business name must contain letters or numbers." }),
                };
            }

            const [existing] = await connection.execute(
                `SELECT id FROM users WHERE email = ? LIMIT 1`,
                [emailAddress]
            );

            if (existing.length > 0) {
                return {
                    statusCode: 400,
                    headers,
                    body: JSON.stringify({ error: "Email already exists" }),
                };
            }

            const otp = generateOtp();
            const otpHash = hashOtp(otp);

            await connection.execute(
                `UPDATE otp_codes
                 SET used_at = UTC_TIMESTAMP()
                 WHERE purpose = 'signup'
                   AND email = ?
                   AND used_at IS NULL`,
                [emailAddress]
            );

            await connection.execute(
                `INSERT INTO otp_codes
                     (purpose, email, otp_hash, expires_at)
                 VALUES
                     ('signup', ?, ?, DATE_ADD(UTC_TIMESTAMP(), INTERVAL ? SECOND))`,
                [emailAddress, otpHash, OTP_EXPIRY_SECONDS]
            );

            try {
                await sendSignupOtpEmail(emailAddress, otp);
            } catch (emailError) {
                await connection.execute(
                    `UPDATE otp_codes
                     SET used_at = UTC_TIMESTAMP()
                     WHERE purpose = 'signup'
                       AND email = ?
                       AND otp_hash = ?
                       AND used_at IS NULL`,
                    [emailAddress, otpHash]
                );

                throw emailError;
            }

            return {
                statusCode: 200,
                headers,
                body: JSON.stringify({
                    message: "OTP sent successfully",
                    expires_in: OTP_EXPIRY_SECONDS,
                }),
            };
        }

        // VERIFY SIGNUP OTP AND CREATE OWNER ACCOUNT
        if (action === "verify_signup_otp") {

            const otp = String(body.otp ?? "").trim();
            const otpEmail = String(body.email ?? "").trim().toLowerCase();

            if (!otp || !otpEmail) {
                return {
                    statusCode: 400,
                    headers,
                    body: JSON.stringify({ error: "OTP and email are required." }),
                };
            }

            if (!/^\d{6}$/.test(otp)) {
                return {
                    statusCode: 400,
                    headers,
                    body: JSON.stringify({ error: "OTP must be exactly 6 digits." }),
                };
            }

            const otpHash = hashOtp(otp);

            // Explicitly invalidate every expired OTP for this email.
            await connection.execute(
                `UPDATE otp_codes
                 SET used_at = UTC_TIMESTAMP()
                 WHERE purpose = 'signup'
                   AND email = ?
                   AND used_at IS NULL
                   AND expires_at <= UTC_TIMESTAMP()`,
                [otpEmail]
            );

            // Accept only an unused OTP that has not expired.
            const [otpRows] = await connection.execute(
                `SELECT id
                 FROM otp_codes
                 WHERE purpose = 'signup'
                   AND email = ?
                   AND otp_hash = ?
                   AND used_at IS NULL
                   AND expires_at > UTC_TIMESTAMP()
                 ORDER BY id DESC
                     LIMIT 1`,
                [otpEmail, otpHash]
            );

            if (otpRows.length === 0) {
                return {
                    statusCode: 400,
                    headers,
                    body: JSON.stringify({ error: "Invalid or expired OTP." }),
                };
            }

            // Accept both snake_case and camelCase because the Create Account modal
            // may submit either naming style. The current modal submits owner_name
            // and phone, which are both supported here.
            const ownerName = String(
                body.owner_name ?? body.ownerName ?? ""
            ).trim();
            const storeName = String(
                body.store_name ?? body.storeName ?? ""
            ).trim();
            const phoneNumber = String(
                body.phone_number ?? body.phoneNumber ?? body.phone ?? ""
            ).trim();
            const emailAddress = String(body.email ?? "").trim().toLowerCase();
            const accountPassword = String(body.password ?? "");

            if (!ownerName || !storeName || !phoneNumber || !emailAddress || !accountPassword) {
                return {
                    statusCode: 400,
                    headers,
                    body: JSON.stringify({
                        error: "Owner name, business name, phone number, email, and password are required.",
                    }),
                };
            }

            const phoneDigits = phoneNumber.replace(/\D/g, "");
            if (phoneDigits.length < 10 || phoneDigits.length > 15) {
                return {
                    statusCode: 400,
                    headers,
                    body: JSON.stringify({ error: "Enter a valid phone number." }),
                };
            }

            if (!/^\S+@\S+\.\S+$/.test(emailAddress)) {
                return {
                    statusCode: 400,
                    headers,
                    body: JSON.stringify({ error: "Enter a valid email address." }),
                };
            }

            if (accountPassword.length < 8) {
                return {
                    statusCode: 400,
                    headers,
                    body: JSON.stringify({ error: "Password must contain at least 8 characters." }),
                };
            }

            const slug = generateSlug(storeName);
            if (!slug) {
                return {
                    statusCode: 400,
                    headers,
                    body: JSON.stringify({ error: "Business name must contain letters or numbers." }),
                };
            }

            const [existing] = await connection.execute(
                `SELECT id FROM users WHERE email = ? LIMIT 1`,
                [emailAddress]
            );

            if (existing.length > 0) {
                return {
                    statusCode: 400,
                    headers,
                    body: JSON.stringify({ error: "Email already exists" }),
                };
            }

            await connection.execute(
                `UPDATE otp_codes
                 SET used_at = UTC_TIMESTAMP(), verified_at = COALESCE(verified_at, UTC_TIMESTAMP())
                 WHERE purpose = 'signup'
                   AND email = ?
                   AND used_at IS NULL`,
                [emailAddress]
            );

            const hashed = await bcrypt.hash(accountPassword, 10);

            // The store and its owner account are created together.
            let result;
            let ownerUserId;
            await connection.beginTransaction();
            try {
                const storeCode = await identifiers.allocateStoreCode(connection, storeName, slug);
                [result] = await connection.execute(
                    `INSERT INTO stores
                         (store_code, slug, store_name, business_name, email, phone)
                     VALUES (?, ?, ?, ?, ?, ?)`,
                    [storeCode, slug, storeName, storeName, emailAddress, phoneNumber]
                );
                const [ownerResult] = await connection.execute(
                    `INSERT INTO users
                     (store_id, role, full_name, email, password_hash, phone, status, email_verified_at)
                     VALUES (?, 'owner', ?, ?, ?, ?, 'active', UTC_TIMESTAMP())`,
                    [result.insertId, ownerName, emailAddress, hashed, phoneNumber]
                );
                ownerUserId = ownerResult.insertId;
                await connection.commit();
            } catch (signupError) {
                await connection.rollback();
                throw signupError;
            }

            const token = jwt.sign(
                {
                    store_id: result.insertId,
                    user_id: ownerUserId,
                    email: emailAddress,
                    role: "owner",
                },
                JWT_SECRET,
                { expiresIn: "7d" }
            );

            return {
                statusCode: 201,
                headers,
                body: JSON.stringify({
                    token,
                    role: "owner",
                    store_id: result.insertId,
                    store_name: storeName,
                    store_slug: slug,
                    owner_name: ownerName,
                    phone_number: phoneNumber,
                }),
            };
        }

        // GET STORE BY SLUG
        if (action === "get_store_by_slug") {
            const { slug } = body;

            if (!slug) {
                return {
                    statusCode: 400,
                    headers,
                    body: JSON.stringify({ error: "Missing slug" }),
                };
            }

            let [rows] = await connection.execute(
                `SELECT id, store_name, slug
                 FROM stores
                 WHERE slug = ?
                     LIMIT 1`,
                [slug]
            );

            /*
             * Compatibility fallback for older/demo store records.
             *
             * Some existing records use seeded slugs such as
             * "demo-v1-party-store-001", while older customer links were
             * generated from the store name, for example:
             * "happy-party-supplies-quezon-city".
             *
             * Keep the database slug as the primary lookup. Only when it does
             * not match do we compare the requested URL slug with a slug
             * generated from each existing store name.
             */
            if (!rows.length) {
                const [storeRows] = await connection.execute(
                    `SELECT id, store_name, slug
                     FROM stores
                     ORDER BY id ASC`
                );

                const fallbackStore = storeRows.find(
                    (store) => generateSlug(store.store_name || "") === slug
                );

                if (fallbackStore) {
                    rows = [fallbackStore];
                }
            }

            if (!rows.length) {
                return {
                    statusCode: 404,
                    headers,
                    body: JSON.stringify({ error: "Store not found" }),
                };
            }

            return {
                statusCode: 200,
                headers,
                body: JSON.stringify({ store: rows[0] }),
            };
        }

        // GET PUBLIC BRANCHES BY STORE
        if (action === "get_public_branches") {
            const { storeId } = body;

            if (!storeId) {
                return {
                    statusCode: 400,
                    headers,
                    body: JSON.stringify({ error: "Missing storeId" }),
                };
            }

            const [branchRows] = await connection.execute(
                `SELECT
                     id,
                     branch_name,
                     phone AS contact_number,
                     address
                 FROM branches
                 WHERE store_id = ?
                 ORDER BY branch_name ASC`,
                [Number(storeId)]
            );

            return {
                statusCode: 200,
                headers,
                body: JSON.stringify({
                    branches: branchRows.map((branch) => ({
                        id: branch.id,
                        branch_name: branch.branch_name,
                        contact_number: branch.contact_number || "",
                        address: branch.address || "",
                        branch_slug: generateSlug(branch.branch_name || ""),
                    })),
                }),
            };
        }
        // SAVE ONBOARDING
        if (action === "save_onboarding") {

            const authHeader =
                event.headers?.Authorization || event.headers?.authorization || "";

            const token = authHeader.replace("Bearer ", "");

            if (!token) {
                return {
                    statusCode: 401,
                    headers,
                    body: JSON.stringify({ error: "Missing token" }),
                };
            }

            let decoded;

            try {
                decoded = jwt.verify(token, JWT_SECRET);
            } catch (err) {
                return {
                    statusCode: 401,
                    headers,
                    body: JSON.stringify({ error: "Invalid token" }),
                };
            }

            if (decoded.role !== "owner" || !decoded.store_id) {
                return {
                    statusCode: 403,
                    headers,
                    body: JSON.stringify({
                        error: "Only the store owner can complete onboarding",
                    }),
                };
            }

            const storeId = decoded.store_id;
            const { branches = [] } = body;
            const shouldSendInvitationEmails =
                body.send_invitation_emails !== false;

            if (!Array.isArray(branches) || branches.length === 0) {
                return {
                    statusCode: 400,
                    headers,
                    body: JSON.stringify({ error: "No branches provided" }),
                };
            }

            // Enforce the branch entitlement using the current active plan.
            // This covers both first-time onboarding and later single-branch
            // additions because the endpoint receives the new branch list.
            try {
                await assertPlanLimit(
                    connection,
                    Number(storeId),
                    "branches",
                    branches.length,
                    decoded.role
                );
            } catch (limitError) {
                return {
                    statusCode: limitError?.statusCode || 409,
                    headers,
                    body: JSON.stringify({
                        error: limitError?.message || "Plan limit reached.",
                        code: limitError?.code || "BRANCHES_LIMIT_REACHED",
                        plan_name: limitError?.plan_name,
                        current: limitError?.current,
                        limit: limitError?.limit,
                    }),
                };
            }

            const [storeRows] = await connection.execute(
                `SELECT store_name
                 FROM stores
                 WHERE id = ?
                     LIMIT 1`,
                [storeId]
            );

            if (storeRows.length === 0) {
                return {
                    statusCode: 404,
                    headers,
                    body: JSON.stringify({ error: "Store not found" }),
                };
            }

            const storeName = storeRows[0].store_name || "StockNBook Store";
            const inviteLinks = [];

            // Identifier columns/tables must exist before the transaction (DDL commits implicitly).
            if (!(await identifiers.ensureIdentifierSchema(connection))) {
                throw new Error("Employee ID numbering is not set up. Run scripts/standardize-identifiers.js.");
            }

            await connection.beginTransaction();

            try {
                for (const branch of branches) {
                    const branchName = String(
                        branch.branch_name || ""
                    ).trim();

                    const contactNumber = String(
                        branch.contact_number || ""
                    ).trim();

                    const address = String(
                        branch.address || ""
                    ).trim();

                    const branchStatus = String(
                        branch.status ||
                        branch.branch_status ||
                        "active"
                    )
                        .trim()
                        .toLowerCase();

                    const inactiveReason =
                        branchStatus === "inactive"
                            ? String(
                                branch.inactive_reason ||
                                branch.branch_inactive_reason ||
                                ""
                            ).trim()
                            : "";

                    if (
                        branchStatus !== "active" &&
                        branchStatus !== "inactive"
                    ) {
                        throw new Error(
                            `Invalid branch status for ${branchName}.`
                        );
                    }

                    if (
                        branchStatus === "inactive" &&
                        !inactiveReason
                    ) {
                        throw new Error(
                            `Select an inactive reason for ${branchName}.`
                        );
                    }

                    const managerName = String(
                        branch.manager_name || ""
                    ).trim();

                    const managerEmail = String(
                        branch.manager_email || ""
                    )
                        .trim()
                        .toLowerCase();

                    if (!branchName) {
                        throw new Error("Every branch must have a branch name.");
                    }

                    if (
                        managerEmail &&
                        !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(managerEmail)
                    ) {
                        throw new Error(
                            `Invalid manager email for ${branchName}.`
                        );
                    }

                    const [branchResult] = await connection.execute(
                        `INSERT INTO branches
                         (
                             store_id,
                             branch_code,
                             branch_name,
                             phone,
                             address,
                             status
                         )
                         VALUES (?, ?, ?, ?, ?, ?)`,
                        [
                            storeId,
                            await identifiers.allocateBranchCode(connection, storeId, branchName),
                            branchName,
                            contactNumber || null,
                            address || null,
                            branchStatus,
                        ]
                    );

                    const branchId = branchResult.insertId;

                    // Decide the new branch's permanent ID initials (e.g. Moonwalk = MW).
                    // Saved in identifier_prefixes; the branch record itself is not changed.
                    await identifiers.getIdentifierCodes(connection, storeId, branchId);

                    if (managerEmail) {
                        const [existingManagerRows] =
                            await connection.execute(
                                `SELECT id, store_id
                                 FROM users
                                 WHERE email = ?
                                     LIMIT 1`,
                                [managerEmail]
                            );

                        if (existingManagerRows.length > 0) {
                            throw new Error(
                                `${managerEmail} is already assigned as a manager in this store.`
                            );
                        }

                        const inviteToken = jwt.sign(
                            {
                                store_id: storeId,
                                branch_id: branchId,
                                email: managerEmail,
                                type: "manager_invite",
                            },
                            JWT_SECRET,
                            { expiresIn: "7d" }
                        );

                        const inviteLink =
                            `${APP_BASE_URL}/accept-invite?token=${encodeURIComponent(inviteToken)}`;

                        const permissions = branch.permissions || {};

                        // Permanent role-specific Employee ID within this store and branch.
                        const employeeCode = await identifiers.generateEmployeeCode(connection, {
                            storeId,
                            branchId,
                            roleCode: "MN",
                        });

                        await connection.execute(
                            `INSERT INTO users
                             (
                                 store_id,
                                 branch_id,
                                 role,
                                 full_name,
                                 email,
                                 invite_token_hash,
                                 permissions,
                                 status,
                                 employee_code
                             )
                             VALUES (?, ?, 'manager', COALESCE(?, ''), ?, SHA2(?, 256), ?, ?, ?)`,
                            [
                                storeId,
                                branchId,
                                managerName || null,
                                managerEmail,
                                inviteToken,
                                JSON.stringify(permissions),
                                "pending",
                                employeeCode,
                            ]
                        );

                        inviteLinks.push({
                            manager_email: managerEmail,
                            manager_name: managerName,
                            store_name: storeName,
                            branch_name: branchName,
                            invite_link: inviteLink,
                            permissions,
                            email_sent: false,
                            email_status: "pending",
                            email_error: "",
                        });
                    }
                }

                await connection.commit();
            } catch (err) {
                await connection.rollback();

                return {
                    statusCode: 500,
                    headers,
                    body: JSON.stringify({
                        error: err?.message || "Unable to save onboarding",
                    }),
                };
            }

            let invitationEmailsSent = 0;
            let invitationEmailsFailed = 0;

            if (shouldSendInvitationEmails) {
                for (const invite of inviteLinks) {
                    const delivery = await deliverInvitationEmail({
                        role: "Manager",
                        email: invite.manager_email,
                        name: invite.manager_name,
                        storeName: invite.store_name,
                        branchName: invite.branch_name,
                        inviteLink: invite.invite_link,
                        send: () => sendManagerInvitationEmail(invite),
                    });

                    invite.email_sent = delivery.email_sent;
                    invite.email_status = delivery.email_status;
                    invite.email_error = delivery.email_error;

                    if (delivery.email_sent) {
                        invitationEmailsSent += 1;
                    } else {
                        invitationEmailsFailed += 1;
                    }
                }
            }

            return {
                statusCode: 200,
                headers,
                body: JSON.stringify({
                    message: "Onboarding saved successfully",
                    invite_links: inviteLinks,
                    invitation_emails_sent: invitationEmailsSent,
                    invitation_emails_failed: invitationEmailsFailed,
                }),
            };
        }

        // GET MANAGER INVITATION DETAILS
        if (action === "get_manager_invite") {
            try {
                const { manager } = await getManagerInviteRecord(
                    connection,
                    body.invite_token
                );

                return {
                    statusCode: 200,
                    headers,
                    body: JSON.stringify(manager),
                };
            } catch (inviteError) {
                return {
                    statusCode: inviteError?.statusCode || 500,
                    headers,
                    body: JSON.stringify({
                        error:
                            inviteError?.message ||
                            "Unable to load the invitation.",
                    }),
                };
            }
        }

        // SEND MANAGER INVITATION OTP
        if (action === "send_manager_invite_otp") {
            try {

                const inviteToken = String(body.invite_token || "");
                const { manager } = await getManagerInviteRecord(
                    connection,
                    inviteToken
                );

                if (manager.status !== "pending") {
                    return {
                        statusCode: 400,
                        headers,
                        body: JSON.stringify({
                            error: "This invitation is no longer pending.",
                        }),
                    };
                }

                const otp = generateOtp();
                const otpHash = hashOtp(otp);
                const inviteTokenHash = hashInviteToken(inviteToken);

                await connection.execute(
                    `UPDATE otp_codes
                     SET used_at = UTC_TIMESTAMP()
                     WHERE purpose = 'manager_invite'
                       AND invite_token_hash = ?
                       AND email = ?
                       AND used_at IS NULL`,
                    [inviteTokenHash, manager.manager_email]
                );

                await connection.execute(
                    `INSERT INTO otp_codes
                     (
                         purpose,
                         invite_token_hash,
                         email,
                         otp_hash,
                         expires_at
                     )
                     VALUES ('manager_invite', ?, ?, ?, DATE_ADD(UTC_TIMESTAMP(), INTERVAL ? SECOND))`,
                    [
                        inviteTokenHash,
                        manager.manager_email,
                        otpHash,
                        MANAGER_INVITE_OTP_EXPIRY_SECONDS,
                    ]
                );

                if (INVITATION_TERMINAL_DEBUG) {
                    console.log(
                        `[StockNBook DEV OTP] Manager invitation verification | ` +
                        `Email: ${manager.manager_email} | ` +
                        `OTP: ${otp} | ` +
                        `Expires in: ${MANAGER_INVITE_OTP_EXPIRY_SECONDS}s`
                    );
                }

                let managerOtpDelivery = "email";

                try {
                    await sendManagerInviteOtpEmail(
                        manager.manager_email,
                        otp,
                        manager.manager_name
                    );
                } catch (emailError) {
                    if (INVITATION_TERMINAL_DEBUG) {
                        managerOtpDelivery = "terminal";
                        console.warn(
                            "[StockNBook DEV OTP] Manager invitation OTP email could not be delivered. " +
                            "The OTP remains active for local testing and is shown in the IDE terminal.",
                            {
                                email: manager.manager_email,
                                error: emailError?.message || "Email delivery failed",
                            }
                        );
                    } else {
                        await connection.execute(
                            `UPDATE otp_codes
                             SET used_at = UTC_TIMESTAMP()
                             WHERE purpose = 'manager_invite'
                               AND invite_token_hash = ?
                               AND email = ?
                               AND otp_hash = ?
                               AND used_at IS NULL`,
                            [inviteTokenHash, manager.manager_email, otpHash]
                        );
                        throw emailError;
                    }
                }

                return {
                    statusCode: 200,
                    headers,
                    body: JSON.stringify({
                        message:
                            managerOtpDelivery === "terminal"
                                ? "Verification code generated for local testing. Check the IDE terminal."
                                : "Verification code sent successfully.",
                        expires_in: MANAGER_INVITE_OTP_EXPIRY_SECONDS,
                    }),
                };
            } catch (inviteError) {
                return {
                    statusCode: inviteError?.statusCode || 500,
                    headers,
                    body: JSON.stringify({
                        error:
                            inviteError?.message ||
                            "Unable to send the verification code.",
                    }),
                };
            }
        }

        // VERIFY MANAGER INVITATION OTP
        if (action === "verify_manager_invite_otp") {
            try {

                const inviteToken = String(body.invite_token || "");
                const otp = String(body.otp || "").replace(/\D/g, "");
                const { manager } = await getManagerInviteRecord(
                    connection,
                    inviteToken
                );

                if (!/^\d{6}$/.test(otp)) {
                    return {
                        statusCode: 400,
                        headers,
                        body: JSON.stringify({
                            error: "Enter the complete 6-digit verification code.",
                        }),
                    };
                }

                const inviteTokenHash = hashInviteToken(inviteToken);
                const otpHash = hashOtp(otp);

                await connection.execute(
                    `UPDATE otp_codes
                     SET used_at = UTC_TIMESTAMP()
                     WHERE purpose = 'manager_invite'
                       AND invite_token_hash = ?
                       AND email = ?
                       AND used_at IS NULL
                       AND expires_at <= UTC_TIMESTAMP()`,
                    [inviteTokenHash, manager.manager_email]
                );

                const [otpRows] = await connection.execute(
                    `SELECT id
                     FROM otp_codes
                     WHERE purpose = 'manager_invite'
                       AND invite_token_hash = ?
                       AND email = ?
                       AND otp_hash = ?
                       AND used_at IS NULL
                       AND expires_at > UTC_TIMESTAMP()
                     ORDER BY id DESC
                         LIMIT 1`,
                    [
                        inviteTokenHash,
                        manager.manager_email,
                        otpHash,
                    ]
                );

                if (otpRows.length === 0) {
                    return {
                        statusCode: 400,
                        headers,
                        body: JSON.stringify({
                            error: "Invalid or expired verification code.",
                        }),
                    };
                }

                await connection.execute(
                    `UPDATE otp_codes
                     SET used_at = UTC_TIMESTAMP(),
                         verified_at = UTC_TIMESTAMP()
                     WHERE id = ?`,
                    [otpRows[0].id]
                );

                return {
                    statusCode: 200,
                    headers,
                    body: JSON.stringify({
                        message: "Invited email verified successfully.",
                    }),
                };
            } catch (inviteError) {
                return {
                    statusCode: inviteError?.statusCode || 500,
                    headers,
                    body: JSON.stringify({
                        error:
                            inviteError?.message ||
                            "Unable to verify the invitation code.",
                    }),
                };
            }
        }

        // UPDATE MANAGER INVITATION DETAILS
        if (action === "update_manager_invite_details") {
            try {
                const inviteToken = String(body.invite_token || "");
                const managerName = String(body.manager_name || "").trim();
                const { manager } = await getManagerInviteRecord(
                    connection,
                    inviteToken
                );

                await requireVerifiedManagerInvite(
                    connection,
                    inviteToken,
                    manager.manager_email
                );

                if (managerName.length < 2 || managerName.length > 120) {
                    return {
                        statusCode: 400,
                        headers,
                        body: JSON.stringify({
                            error: "Enter a valid manager name.",
                        }),
                    };
                }

                await connection.execute(
                    `UPDATE users
                     SET full_name = ?
                     WHERE id = ?
                       AND role = 'manager'
                       AND invite_token_hash = SHA2(?, 256)
                       AND status = 'pending'`,
                    [managerName, manager.manager_id, inviteToken]
                );

                const refreshed = await getManagerInviteRecord(
                    connection,
                    inviteToken
                );

                return {
                    statusCode: 200,
                    headers,
                    body: JSON.stringify(refreshed.manager),
                };
            } catch (inviteError) {
                return {
                    statusCode: inviteError?.statusCode || 500,
                    headers,
                    body: JSON.stringify({
                        error:
                            inviteError?.message ||
                            "Unable to update the manager details.",
                    }),
                };
            }
        }

        // ACCEPT MANAGER INVITE
        if (action === "accept_manager_invite") {
            try {
                const inviteToken = String(body.invite_token || "");
                const accountPassword = String(body.password || "");
                const requestedManagerName = String(
                    body.manager_name || ""
                ).trim();

                const { manager } = await getManagerInviteRecord(
                    connection,
                    inviteToken
                );

                await requireVerifiedManagerInvite(
                    connection,
                    inviteToken,
                    manager.manager_email
                );

                const passwordValid =
                    accountPassword.length >= 8 &&
                    /[A-Z]/.test(accountPassword) &&
                    /\d/.test(accountPassword) &&
                    /[^A-Za-z0-9]/.test(accountPassword);

                if (!passwordValid) {
                    return {
                        statusCode: 400,
                        headers,
                        body: JSON.stringify({
                            error:
                                "Password must contain at least 8 characters, one uppercase letter, one number, and one special character.",
                        }),
                    };
                }

                const finalManagerName =
                    requestedManagerName || manager.manager_name || "Manager";
                const hashedPassword = await bcrypt.hash(
                    accountPassword,
                    10
                );

                const [result] = await connection.execute(
                    `UPDATE users
                     SET full_name = ?,
                         password_hash = ?,
                         status = 'active',
                         email_verified_at = UTC_TIMESTAMP(),
                         invite_token_hash = NULL
                     WHERE id = ?
                       AND role = 'manager'
                       AND invite_token_hash = SHA2(?, 256)
                       AND email = ?
                       AND status = 'pending'`,
                    [
                        finalManagerName,
                        hashedPassword,
                        manager.manager_id,
                        inviteToken,
                        manager.manager_email,
                    ]
                );

                if (result.affectedRows === 0) {
                    return {
                        statusCode: 404,
                        headers,
                        body: JSON.stringify({
                            error: "Invitation not found or already accepted.",
                        }),
                    };
                }

                await connection.execute(
                    `UPDATE otp_codes
                     SET used_at = UTC_TIMESTAMP(),
                         verified_at = NULL
                     WHERE purpose = 'manager_invite'
                       AND invite_token_hash = ?
                       AND email = ?`,
                    [
                        hashInviteToken(inviteToken),
                        manager.manager_email,
                    ]
                );

                const sessionToken = jwt.sign(
                    {
                        manager_id: manager.manager_id,
                        store_id: manager.store_id,
                        branch_id: manager.branch_id,
                        email: manager.manager_email,
                        role: "manager",
                    },
                    JWT_SECRET,
                    { expiresIn: "7d" }
                );

                return {
                    statusCode: 200,
                    headers,
                    body: JSON.stringify({
                        message: "Manager account activated successfully.",
                        token: sessionToken,
                        manager_id: manager.manager_id,
                        manager_name: finalManagerName,
                        manager_email: manager.manager_email,
                        store_id: manager.store_id,
                        store_name: manager.store_name,
                        branch_id: manager.branch_id,
                        branch_name: manager.branch_name,
                        role: "manager",
                        status: "active",
                        permissions: manager.permissions,
                    }),
                };
            } catch (inviteError) {
                return {
                    statusCode: inviteError?.statusCode || 500,
                    headers,
                    body: JSON.stringify({
                        error:
                            inviteError?.message ||
                            "Unable to activate the manager account.",
                    }),
                };
            }
        }

        // INVITE STAFF
        if (action === "invite_staff") {
            const authHeader =
                event.headers?.Authorization || event.headers?.authorization || "";

            const token = authHeader.replace("Bearer ", "");

            if (!token) {
                return {
                    statusCode: 401,
                    headers,
                    body: JSON.stringify({ error: "Missing token" }),
                };
            }

            let decoded;

            try {
                decoded = jwt.verify(token, JWT_SECRET);
            } catch {
                return {
                    statusCode: 401,
                    headers,
                    body: JSON.stringify({ error: "Invalid token" }),
                };
            }

            if (decoded.role !== "manager") {
                return {
                    statusCode: 403,
                    headers,
                    body: JSON.stringify({
                        error: "Only branch managers can invite staff",
                    }),
                };
            }

            const staffName = String(body.staff_name || "").trim();
            const staffEmail = String(body.staff_email || "")
                .trim()
                .toLowerCase();
            const permissions = body.permissions || {};

            if (!staffName || !staffEmail) {
                return {
                    statusCode: 400,
                    headers,
                    body: JSON.stringify({
                        error: "Missing staff name or email",
                    }),
                };
            }

            if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(staffEmail)) {
                return {
                    statusCode: 400,
                    headers,
                    body: JSON.stringify({
                        error: "Enter a valid staff email address",
                    }),
                };
            }

            const managerId = decoded.manager_id;
            const storeId = decoded.store_id;
            const branchId = decoded.branch_id;

            const [managerRows] = await connection.execute(
                `SELECT
                     managers.permissions,
                     managers.full_name AS manager_name,
                     branches.branch_name,
                     stores.store_name
                 FROM users managers
                          JOIN branches ON branches.id = managers.branch_id AND branches.store_id = managers.store_id
                          JOIN stores ON stores.id = managers.store_id
                 WHERE managers.id = ?
                   AND managers.role = 'manager'
                   AND managers.store_id = ?
                   AND managers.branch_id = ?
                   AND managers.status = 'active'
                     LIMIT 1`,
                [managerId, storeId, branchId]
            );

            if (managerRows.length === 0) {
                return {
                    statusCode: 404,
                    headers,
                    body: JSON.stringify({ error: "Manager not found" }),
                };
            }

            const manager = managerRows[0];

            const managerPermissions =
                typeof manager.permissions === "string"
                    ? JSON.parse(manager.permissions || "{}")
                    : manager.permissions || {};

            if (!managerPermissions.staff_management) {
                return {
                    statusCode: 403,
                    headers,
                    body: JSON.stringify({
                        error: "You do not have permission to invite staff",
                    }),
                };
            }

            const [existingStaff] = await connection.execute(
                `SELECT id
                 FROM users
                 WHERE email = ?
                     LIMIT 1`,
                [staffEmail]
            );

            if (existingStaff.length > 0) {
                return {
                    statusCode: 400,
                    headers,
                    body: JSON.stringify({
                        error: "Staff email already exists in this branch",
                    }),
                };
            }

            try {
                await assertPlanLimit(
                    connection,
                    Number(storeId),
                    "staff",
                    1,
                    decoded.role
                );
            } catch (limitError) {
                return {
                    statusCode: limitError?.statusCode || 409,
                    headers,
                    body: JSON.stringify({
                        error: limitError?.message || "Plan limit reached.",
                        code: limitError?.code || "STAFF_LIMIT_REACHED",
                        plan_name: limitError?.plan_name,
                        current: limitError?.current,
                        limit: limitError?.limit,
                    }),
                };
            }

            const inviteToken = jwt.sign(
                {
                    store_id: storeId,
                    branch_id: branchId,
                    manager_id: managerId,
                    email: staffEmail,
                    type: "staff_invite",
                },
                JWT_SECRET,
                { expiresIn: "7d" }
            );

            const inviteLink =
                `${APP_BASE_URL}/accept-staff-invite?token=${encodeURIComponent(inviteToken)}`;

            // Permanent role-specific Employee ID within this store and branch.
            if (!(await identifiers.ensureIdentifierSchema(connection))) {
                throw new Error("Employee ID numbering is not set up. Run scripts/standardize-identifiers.js.");
            }
            const employeeCode = await identifiers.generateEmployeeCode(connection, {
                storeId,
                branchId,
                roleCode: "SF",
            });

            await connection.execute(
                `INSERT INTO users
                 (
                     store_id,
                     branch_id,
                     manager_id,
                     role,
                     full_name,
                     email,
                     invite_token_hash,
                     status,
                     permissions,
                     employee_code
                 )
                 VALUES (?, ?, ?, 'staff', COALESCE(?, ''), ?, SHA2(?, 256), ?, ?, ?)`,
                [
                    storeId,
                    branchId,
                    managerId,
                    staffName,
                    staffEmail,
                    inviteToken,
                    "pending",
                    JSON.stringify(permissions),
                    employeeCode,
                ]
            );

            const invitation = {
                staff_email: staffEmail,
                staff_name: staffName,
                manager_name: manager.manager_name || "Branch Manager",
                store_name: manager.store_name || "StockNBook Store",
                branch_name: manager.branch_name || "Assigned Branch",
                invite_link: inviteLink,
                permissions,
            };

            const delivery = await deliverInvitationEmail({
                role: "Staff",
                email: staffEmail,
                name: staffName,
                storeName: manager.store_name || "StockNBook Store",
                branchName: manager.branch_name || "Assigned Branch",
                inviteLink,
                send: () => sendStaffInvitationEmail(invitation),
            });

            return {
                statusCode: 201,
                headers,
                body: JSON.stringify({
                    message: delivery.email_sent
                        ? "Staff invitation created and emailed successfully."
                        : "Staff invitation created successfully, but the email could not be delivered. Copy the backup invite link or use Resend later.",
                    invite_link: inviteLink,
                    staff_email: staffEmail,
                    staff_name: staffName,
                    email_sent: delivery.email_sent,
                    email_status: delivery.email_status,
                    email_error: delivery.email_error,
                }),
            };
        }

        // PLATFORM ADMIN LOGIN
        // Platform administrators are stored in platform_admins,
        // which uses the `password` column for the bcrypt hash.
        if (action === "platform_admin_login") {
            if (!email || !password) {
                return {
                    statusCode: 400,
                    headers,
                    body: JSON.stringify({
                        error: "Missing email or password",
                    }),
                };
            }

            const adminEmail = String(email).trim().toLowerCase();

            const [adminRows] = await connection.execute(
                `SELECT
                     id AS platform_admin_id,
                     full_name,
                     email,
                     password_hash AS password,
                     status,
                     role,
                     CASE WHEN LOWER(status) = 'active' THEN 1 ELSE 0 END AS is_active
                 FROM platform_admins
                 WHERE LOWER(email) = ?
                     LIMIT 1`,
                [adminEmail]
            );

            if (adminRows.length === 0) {
                return {
                    statusCode: 401,
                    headers,
                    body: JSON.stringify({
                        error: "Invalid email or password",
                    }),
                };
            }

            const admin = adminRows[0];
            const adminStatus = String(admin.status || "")
                .trim()
                .toLowerCase();

            if (adminStatus !== "active" || Number(admin.is_active) !== 1) {
                return {
                    statusCode: 403,
                    headers,
                    body: JSON.stringify({
                        error: "Platform administrator account is inactive.",
                        code: "ACCOUNT_INACTIVE",
                    }),
                };
            }

            if (!admin.password) {
                return {
                    statusCode: 401,
                    headers,
                    body: JSON.stringify({
                        error: "Invalid email or password",
                    }),
                };
            }

            const passwordMatches = await bcrypt.compare(
                String(password),
                admin.password
            );

            if (!passwordMatches) {
                return {
                    statusCode: 401,
                    headers,
                    body: JSON.stringify({
                        error: "Invalid email or password",
                    }),
                };
            }

            const token = jwt.sign(
                {
                    platform_admin_id: admin.platform_admin_id,
                    email: admin.email,
                    full_name: admin.full_name,
                    role: "PLATFORM_ADMIN",
                },
                JWT_SECRET,
                { expiresIn: "8h" }
            );

            return {
                statusCode: 200,
                headers,
                body: JSON.stringify({
                    token,
                    role: "PLATFORM_ADMIN",
                    user: {
                        id: admin.platform_admin_id,
                        platform_admin_id: admin.platform_admin_id,
                        full_name: admin.full_name,
                        email: admin.email,
                        role: "PLATFORM_ADMIN",
                    },
                }),
            };
        }

        // LOGIN
        if (action === "login") {
            if (!email || !password) {
                return {
                    statusCode: 400,
                    headers,
                    body: JSON.stringify({ error: "Missing email or password" }),
                };
            }

            // 1. Try owner login first
            const [storeRows] = await connection.execute(
                `SELECT s.id, s.store_name, s.slug, u.id AS user_id, u.full_name AS owner_name,
                        u.email, u.password_hash AS password, u.status
                 FROM users u
                          JOIN stores s ON s.id = u.store_id
                 WHERE u.email = ?
                   AND u.role = 'owner'
                     LIMIT 1`,
                [email]
            );

            if (storeRows.length > 0) {
                const store = storeRows[0];
                const match = await bcrypt.compare(password, store.password);

                if (!match) {
                    return {
                        statusCode: 401,
                        headers,
                        body: JSON.stringify({ error: "Invalid email or password" }),
                    };
                }



                const token = jwt.sign(
                    {
                        store_id: store.id,
                        user_id: store.user_id,
                        email: store.email,
                        role: "owner",
                    },
                    JWT_SECRET,
                    { expiresIn: "7d" }
                );

                return {
                    statusCode: 200,
                    headers,
                    body: JSON.stringify({
                        token,
                        role: "owner",
                        store_id: store.id,
                        owner_name: store.owner_name,
                        store_name: store.store_name,
                        store_slug: store.slug,
                    }),
                };
            }

            // 2. Try manager login
            const [managerRows] = await connection.execute(
                `SELECT
                     managers.id,
                     managers.store_id,
                     managers.branch_id,
                     managers.full_name AS manager_name,
                     managers.email AS manager_email,
                     managers.password_hash AS password,
                     managers.permissions,
                     managers.status,
                     managers.employee_code,
                     branches.branch_name,
                     stores.store_name
                 FROM users managers
                          JOIN branches ON managers.branch_id = branches.id
                          JOIN stores ON managers.store_id = stores.id
                 WHERE managers.email = ?
                   AND managers.role = 'manager'
                     LIMIT 1`,
                [email]
            );

            if (managerRows.length > 0) {
                const manager = managerRows[0];
                const managerStatus = String(
                    manager.status || ""
                ).trim().toLowerCase();

                if (managerStatus === "inactive") {
                    return {
                        statusCode: 403,
                        headers,
                        body: JSON.stringify({
                            error:
                                "Your branch manager account has already been deactivated. Please contact the store owner if you think this was a mistake.",
                            code: "ACCOUNT_DEACTIVATED",
                            message:
                                "Your branch manager account has already been deactivated. Please contact the store owner if you think this was a mistake.",
                        }),
                    };
                }

                if (managerStatus === "pending" || !manager.password) {
                    return {
                        statusCode: 403,
                        headers,
                        body: JSON.stringify({
                            error: "Account activation required",
                            code: "ACCOUNT_PENDING",
                            message:
                                "Your manager invitation has not been accepted yet. Open the invitation email and complete the account activation first.",
                        }),
                    };
                }

                if (managerStatus !== "active") {
                    return {
                        statusCode: 403,
                        headers,
                        body: JSON.stringify({
                            error: "Account unavailable",
                            code: "ACCOUNT_UNAVAILABLE",
                            message:
                                "Your branch manager account is not currently active. Please contact the store owner.",
                        }),
                    };
                }

                const managerMatch = await bcrypt.compare(
                    password,
                    manager.password
                );

                if (!managerMatch) {
                    return {
                        statusCode: 401,
                        headers,
                        body: JSON.stringify({
                            error: "Invalid email or password",
                        }),
                    };
                }

                const token = jwt.sign(
                    {
                        manager_id: manager.id,
                        store_id: manager.store_id,
                        branch_id: manager.branch_id,
                        email: manager.manager_email,
                        role: "manager",
                    },
                    JWT_SECRET,
                    { expiresIn: "7d" }
                );

                return {
                    statusCode: 200,
                    headers,
                    body: JSON.stringify({
                        token,
                        role: "manager",
                        manager_id: manager.id,
                        manager_name: manager.manager_name,
                        manager_email: manager.manager_email,
                        store_id: manager.store_id,
                        store_name: manager.store_name,
                        branch_id: manager.branch_id,
                        branch_name: manager.branch_name,
                        permissions:
                            typeof manager.permissions === "string"
                                ? JSON.parse(manager.permissions || "{}")
                                : manager.permissions || {},
                    }),
                };
            }

            // 3. Try staff login
            const [staffRows] = await connection.execute(
                `SELECT
                     staff.id,
                     staff.store_id,
                     staff.branch_id,
                     staff.manager_id,
                     staff.full_name AS staff_name,
                     staff.email AS staff_email,
                     staff.password_hash AS password,
                     staff.permissions,
                     staff.status,
                     staff.employee_code,
                     branches.branch_name,
                     stores.store_name
                 FROM users staff
                          JOIN branches ON staff.branch_id = branches.id
                          JOIN stores ON staff.store_id = stores.id
                 WHERE staff.email = ?
                   AND staff.role = 'staff'
                   AND staff.status = 'active'
                     LIMIT 1`,
                [email]
            );

            if (staffRows.length > 0) {
                const staff = staffRows[0];

                if (!staff.password) {
                    return {
                        statusCode: 401,
                        headers,
                        body: JSON.stringify({
                            error: "Staff invitation has not been accepted yet",
                        }),
                    };
                }

                const staffMatch = await bcrypt.compare(password, staff.password);

                if (!staffMatch) {
                    return {
                        statusCode: 401,
                        headers,
                        body: JSON.stringify({ error: "Invalid email or password" }),
                    };
                }

                const token = jwt.sign(
                    {
                        staff_id: staff.id,
                        store_id: staff.store_id,
                        branch_id: staff.branch_id,
                        manager_id: staff.manager_id,
                        email: staff.staff_email,
                        role: "staff",
                    },
                    JWT_SECRET,
                    { expiresIn: "7d" }
                );

                return {
                    statusCode: 200,
                    headers,
                    body: JSON.stringify({
                        token,
                        role: "staff",
                        staff_id: staff.id,
                        staff_name: staff.staff_name,
                        staff_email: staff.staff_email,
                        store_id: staff.store_id,
                        store_name: staff.store_name,
                        branch_id: staff.branch_id,
                        branch_name: staff.branch_name,
                        permissions:
                            typeof staff.permissions === "string"
                                ? JSON.parse(staff.permissions || "{}")
                                : staff.permissions || {},
                    }),
                };
            }

            return {
                statusCode: 401,
                headers,
                body: JSON.stringify({ error: "Invalid email or password" }),
            };
        }

        // GET STAFF INVITATION DETAILS
        if (action === "get_staff_invite") {
            try {
                const { staff } = await getStaffInviteRecord(
                    connection,
                    body.invite_token
                );

                return {
                    statusCode: 200,
                    headers,
                    body: JSON.stringify(staff),
                };
            } catch (inviteError) {
                return {
                    statusCode: inviteError?.statusCode || 500,
                    headers,
                    body: JSON.stringify({
                        error:
                            inviteError?.message ||
                            "Unable to load the invitation.",
                    }),
                };
            }
        }

        // SEND STAFF INVITATION OTP
        if (action === "send_staff_invite_otp") {
            try {

                const inviteToken = String(body.invite_token || "");
                const { staff } = await getStaffInviteRecord(
                    connection,
                    inviteToken
                );

                if (staff.status !== "pending") {
                    return {
                        statusCode: 400,
                        headers,
                        body: JSON.stringify({
                            error: "This invitation is no longer pending.",
                        }),
                    };
                }

                const otp = generateOtp();
                const otpHash = hashOtp(otp);
                const inviteTokenHash = hashInviteToken(inviteToken);

                await connection.execute(
                    `UPDATE otp_codes
                     SET used_at = UTC_TIMESTAMP()
                     WHERE purpose = 'staff_invite'
                       AND invite_token_hash = ?
                       AND email = ?
                       AND used_at IS NULL`,
                    [inviteTokenHash, staff.staff_email]
                );

                await connection.execute(
                    `INSERT INTO otp_codes
                     (
                         purpose,
                         invite_token_hash,
                         email,
                         otp_hash,
                         expires_at
                     )
                     VALUES ('staff_invite', ?, ?, ?, DATE_ADD(UTC_TIMESTAMP(), INTERVAL ? SECOND))`,
                    [
                        inviteTokenHash,
                        staff.staff_email,
                        otpHash,
                        STAFF_INVITE_OTP_EXPIRY_SECONDS,
                    ]
                );

                if (INVITATION_TERMINAL_DEBUG) {
                    console.log(
                        `[StockNBook DEV OTP] Staff invitation verification | ` +
                        `Email: ${staff.staff_email} | ` +
                        `OTP: ${otp} | ` +
                        `Expires in: ${STAFF_INVITE_OTP_EXPIRY_SECONDS}s`
                    );
                }

                let staffOtpDelivery = "email";

                try {
                    await sendStaffInviteOtpEmail(
                        staff.staff_email,
                        otp,
                        staff.staff_name
                    );
                } catch (emailError) {
                    if (INVITATION_TERMINAL_DEBUG) {
                        staffOtpDelivery = "terminal";
                        console.warn(
                            "[StockNBook DEV OTP] Staff invitation OTP email could not be delivered. " +
                            "The OTP remains active for local testing and is shown in the IDE terminal.",
                            {
                                email: staff.staff_email,
                                error: emailError?.message || "Email delivery failed",
                            }
                        );
                    } else {
                        await connection.execute(
                            `UPDATE otp_codes
                             SET used_at = UTC_TIMESTAMP()
                             WHERE purpose = 'staff_invite'
                               AND invite_token_hash = ?
                               AND email = ?
                               AND otp_hash = ?
                               AND used_at IS NULL`,
                            [inviteTokenHash, staff.staff_email, otpHash]
                        );
                        throw emailError;
                    }
                }

                return {
                    statusCode: 200,
                    headers,
                    body: JSON.stringify({
                        message:
                            staffOtpDelivery === "terminal"
                                ? "Verification code generated for local testing. Check the IDE terminal."
                                : "Verification code sent successfully.",
                        expires_in: STAFF_INVITE_OTP_EXPIRY_SECONDS,
                    }),
                };
            } catch (inviteError) {
                return {
                    statusCode: inviteError?.statusCode || 500,
                    headers,
                    body: JSON.stringify({
                        error:
                            inviteError?.message ||
                            "Unable to send the verification code.",
                    }),
                };
            }
        }

        // VERIFY STAFF INVITATION OTP
        if (action === "verify_staff_invite_otp") {
            try {

                const inviteToken = String(body.invite_token || "");
                const otp = String(body.otp || "").replace(/\D/g, "");
                const { staff } = await getStaffInviteRecord(
                    connection,
                    inviteToken
                );

                if (!/^\d{6}$/.test(otp)) {
                    return {
                        statusCode: 400,
                        headers,
                        body: JSON.stringify({
                            error: "Enter the complete 6-digit verification code.",
                        }),
                    };
                }

                const inviteTokenHash = hashInviteToken(inviteToken);
                const otpHash = hashOtp(otp);

                await connection.execute(
                    `UPDATE otp_codes
                     SET used_at = UTC_TIMESTAMP()
                     WHERE purpose = 'staff_invite'
                       AND invite_token_hash = ?
                       AND email = ?
                       AND used_at IS NULL
                       AND expires_at <= UTC_TIMESTAMP()`,
                    [inviteTokenHash, staff.staff_email]
                );

                const [otpRows] = await connection.execute(
                    `SELECT id
                     FROM otp_codes
                     WHERE purpose = 'staff_invite'
                       AND invite_token_hash = ?
                       AND email = ?
                       AND otp_hash = ?
                       AND used_at IS NULL
                       AND expires_at > UTC_TIMESTAMP()
                     ORDER BY id DESC
                         LIMIT 1`,
                    [
                        inviteTokenHash,
                        staff.staff_email,
                        otpHash,
                    ]
                );

                if (otpRows.length === 0) {
                    return {
                        statusCode: 400,
                        headers,
                        body: JSON.stringify({
                            error: "Invalid or expired verification code.",
                        }),
                    };
                }

                await connection.execute(
                    `UPDATE otp_codes
                     SET used_at = UTC_TIMESTAMP(),
                         verified_at = UTC_TIMESTAMP()
                     WHERE id = ?`,
                    [otpRows[0].id]
                );

                return {
                    statusCode: 200,
                    headers,
                    body: JSON.stringify({
                        message: "Invited email verified successfully.",
                    }),
                };
            } catch (inviteError) {
                return {
                    statusCode: inviteError?.statusCode || 500,
                    headers,
                    body: JSON.stringify({
                        error:
                            inviteError?.message ||
                            "Unable to verify the invitation code.",
                    }),
                };
            }
        }

        // UPDATE STAFF INVITATION DETAILS
        if (action === "update_staff_invite_details") {
            try {
                const inviteToken = String(body.invite_token || "");
                const staffName = String(body.staff_name || "").trim();
                const { staff } = await getStaffInviteRecord(
                    connection,
                    inviteToken
                );

                await requireVerifiedStaffInvite(
                    connection,
                    inviteToken,
                    staff.staff_email
                );

                if (staffName.length < 2 || staffName.length > 120) {
                    return {
                        statusCode: 400,
                        headers,
                        body: JSON.stringify({
                            error: "Enter a valid staff name.",
                        }),
                    };
                }

                await connection.execute(
                    `UPDATE users
                     SET full_name = ?
                     WHERE id = ?
                       AND role = 'staff'
                       AND invite_token_hash = SHA2(?, 256)
                       AND status = 'pending'`,
                    [staffName, staff.staff_id, inviteToken]
                );

                const refreshed = await getStaffInviteRecord(
                    connection,
                    inviteToken
                );

                return {
                    statusCode: 200,
                    headers,
                    body: JSON.stringify(refreshed.staff),
                };
            } catch (inviteError) {
                return {
                    statusCode: inviteError?.statusCode || 500,
                    headers,
                    body: JSON.stringify({
                        error:
                            inviteError?.message ||
                            "Unable to update the staff details.",
                    }),
                };
            }
        }

        // ACCEPT STAFF INVITE
        if (action === "accept_staff_invite") {
            try {
                const inviteToken = String(body.invite_token || "");
                const accountPassword = String(body.password || "");
                const requestedStaffName = String(
                    body.staff_name || ""
                ).trim();

                const { staff } = await getStaffInviteRecord(
                    connection,
                    inviteToken
                );

                await requireVerifiedStaffInvite(
                    connection,
                    inviteToken,
                    staff.staff_email
                );

                const passwordValid =
                    accountPassword.length >= 8 &&
                    /[A-Z]/.test(accountPassword) &&
                    /\d/.test(accountPassword) &&
                    /[^A-Za-z0-9]/.test(accountPassword);

                if (!passwordValid) {
                    return {
                        statusCode: 400,
                        headers,
                        body: JSON.stringify({
                            error:
                                "Password must contain at least 8 characters, one uppercase letter, one number, and one special character.",
                        }),
                    };
                }

                const finalStaffName =
                    requestedStaffName || staff.staff_name || "Staff";
                const hashedPassword = await bcrypt.hash(
                    accountPassword,
                    10
                );

                try {
                    // The pending invitation already occupies one staff slot.
                    // Activating it changes the existing row from pending -> active,
                    // so it must NOT consume a second plan slot.
                    //
                    // We still validate with increment 0 so a downgrade or other
                    // plan change that leaves current usage above the limit can
                    // correctly block activation.
                    await assertPlanLimit(
                        connection,
                        Number(staff.store_id),
                        "staff",
                        0,
                        "staff"
                    );
                } catch (limitError) {
                    return {
                        statusCode: limitError?.statusCode || 409,
                        headers,
                        body: JSON.stringify({
                            error: limitError?.message || "Plan limit reached.",
                            code: limitError?.code || "STAFF_LIMIT_REACHED",
                            plan_name: limitError?.plan_name,
                            current: limitError?.current,
                            limit: limitError?.limit,
                        }),
                    };
                }

                const [result] = await connection.execute(
                    `UPDATE users
                     SET full_name = ?,
                         password_hash = ?,
                         status = 'active',
                         email_verified_at = UTC_TIMESTAMP(),
                         invite_token_hash = NULL
                     WHERE id = ?
                       AND role = 'staff'
                       AND invite_token_hash = SHA2(?, 256)
                       AND email = ?
                       AND status = 'pending'`,
                    [
                        finalStaffName,
                        hashedPassword,
                        staff.staff_id,
                        inviteToken,
                        staff.staff_email,
                    ]
                );

                if (result.affectedRows === 0) {
                    return {
                        statusCode: 404,
                        headers,
                        body: JSON.stringify({
                            error: "Invitation not found or already accepted.",
                        }),
                    };
                }

                await connection.execute(
                    `UPDATE otp_codes
                     SET used_at = UTC_TIMESTAMP(),
                         verified_at = NULL
                     WHERE purpose = 'staff_invite'
                       AND invite_token_hash = ?
                       AND email = ?`,
                    [
                        hashInviteToken(inviteToken),
                        staff.staff_email,
                    ]
                );

                const sessionToken = jwt.sign(
                    {
                        staff_id: staff.staff_id,
                        manager_id: staff.manager_id,
                        store_id: staff.store_id,
                        branch_id: staff.branch_id,
                        email: staff.staff_email,
                        role: "staff",
                    },
                    JWT_SECRET,
                    { expiresIn: "7d" }
                );

                return {
                    statusCode: 200,
                    headers,
                    body: JSON.stringify({
                        message: "Staff account activated successfully.",
                        token: sessionToken,
                        staff_id: staff.staff_id,
                        staff_name: finalStaffName,
                        staff_email: staff.staff_email,
                        manager_id: staff.manager_id,
                        manager_name: staff.manager_name,
                        store_id: staff.store_id,
                        store_name: staff.store_name,
                        branch_id: staff.branch_id,
                        branch_name: staff.branch_name,
                        role: "staff",
                        status: "active",
                        permissions: staff.permissions,
                    }),
                };
            } catch (inviteError) {
                return {
                    statusCode: inviteError?.statusCode || 500,
                    headers,
                    body: JSON.stringify({
                        error:
                            inviteError?.message ||
                            "Unable to activate the staff account.",
                    }),
                };
            }
        }

        // GET STAFF BY MANAGER BRANCH
        if (action === "get_staff") {
            const authHeader =
                event.headers?.Authorization || event.headers?.authorization || "";

            const token = authHeader.replace("Bearer ", "");

            if (!token) {
                return {
                    statusCode: 401,
                    headers,
                    body: JSON.stringify({ error: "Missing token" }),
                };
            }

            let decoded;

            try {
                decoded = jwt.verify(token, JWT_SECRET);
            } catch (err) {
                return {
                    statusCode: 401,
                    headers,
                    body: JSON.stringify({ error: "Invalid token" }),
                };
            }

            if (decoded.role !== "manager") {
                return {
                    statusCode: 403,
                    headers,
                    body: JSON.stringify({ error: "Only managers can view branch staff" }),
                };
            }

            const managerId = decoded.manager_id;
            const storeId = decoded.store_id;
            const branchId = decoded.branch_id;

            const [managerRows] = await connection.execute(
                `SELECT permissions
                 FROM users
                 WHERE id = ?
                   AND role = 'manager'
                   AND store_id = ?
                   AND branch_id = ?
                   AND status = 'active'
                     LIMIT 1`,
                [managerId, storeId, branchId]
            );

            if (managerRows.length === 0) {
                return {
                    statusCode: 404,
                    headers,
                    body: JSON.stringify({ error: "Manager not found" }),
                };
            }

            const managerPermissions =
                typeof managerRows[0].permissions === "string"
                    ? JSON.parse(managerRows[0].permissions || "{}")
                    : managerRows[0].permissions || {};

            if (!managerPermissions.staff_management) {
                return {
                    statusCode: 403,
                    headers,
                    body: JSON.stringify({
                        error: "You do not have permission to view staff",
                    }),
                };
            }

            const employeeCodeReady = await identifiers.ensureIdentifierSchema(connection);
            const [staffRows] = await connection.execute(
                `SELECT
                     id,
                     full_name AS staff_name,
                     email AS staff_email,
                     status,
                     permissions,
                     NULL AS invite_token,
                     employee_code,
                     NULL AS created_at
                 FROM users
                 WHERE role = 'staff'
                   AND store_id = ?
                   AND branch_id = ?
                   AND manager_id = ?
                 ORDER BY id DESC`,
                [storeId, branchId, managerId]
            );

            const staff = [];
            const pendingInvites = [];

            for (const row of staffRows) {
                const parsedPermissions =
                    typeof row.permissions === "string"
                        ? JSON.parse(row.permissions || "{}")
                        : row.permissions || {};

                if (
                    row.status === "active" ||
                    row.status === "inactive"
                ) {
                    staff.push({
                        id: row.id,
                        employee_code: row.employee_code || "",
                        name: row.staff_name || "Unnamed staff",
                        email: row.staff_email || "",
                        status:
                            row.status === "inactive"
                                ? "Inactive"
                                : "Accepted",
                        permissions: parsedPermissions,
                    });
                } else if (row.status === "pending") {
                    pendingInvites.push({
                        id: row.id,
                        employee_code: row.employee_code || "",
                        email: row.staff_email || "",
                        invitedAt: row.created_at || "Recently",
                        expiresAt: "7 days after invite",
                        status: "Pending",
                        permissions: parsedPermissions,
                    });
                }
            }

            return {
                statusCode: 200,
                headers,
                body: JSON.stringify({
                    staff,
                    pending_invites: pendingInvites,
                }),
            };
        }

        // DEACTIVATE OR REACTIVATE STAFF
        if (
            action === "deactivate_staff" ||
            action === "reactivate_staff"
        ) {
            const authHeader =
                event.headers?.Authorization ||
                event.headers?.authorization ||
                "";

            const token = authHeader.replace("Bearer ", "");

            if (!token) {
                return {
                    statusCode: 401,
                    headers,
                    body: JSON.stringify({
                        error: "Missing token",
                    }),
                };
            }

            let decoded;

            try {
                decoded = jwt.verify(token, JWT_SECRET);
            } catch {
                return {
                    statusCode: 401,
                    headers,
                    body: JSON.stringify({
                        error: "Invalid token",
                    }),
                };
            }

            if (decoded.role !== "manager") {
                return {
                    statusCode: 403,
                    headers,
                    body: JSON.stringify({
                        error:
                            "Only managers can update staff account status",
                    }),
                };
            }

            const managerId = decoded.manager_id;
            const storeId = decoded.store_id;
            const branchId = decoded.branch_id;
            const staffId = Number(body.staff_id);
            const staffEmail = String(
                body.staff_email || ""
            )
                .trim()
                .toLowerCase();

            if (!staffId && !staffEmail) {
                return {
                    statusCode: 400,
                    headers,
                    body: JSON.stringify({
                        error: "Missing staff id or email",
                    }),
                };
            }

            const [managerRows] =
                await connection.execute(
                    `SELECT permissions
                     FROM users
                     WHERE id = ?
                       AND role = 'manager'
                       AND store_id = ?
                       AND branch_id = ?
                       AND status = 'active'
                         LIMIT 1`,
                    [managerId, storeId, branchId]
                );

            if (managerRows.length === 0) {
                return {
                    statusCode: 403,
                    headers,
                    body: JSON.stringify({
                        error:
                            "Your manager account is not active",
                    }),
                };
            }

            const managerPermissions =
                typeof managerRows[0].permissions ===
                "string"
                    ? JSON.parse(
                        managerRows[0].permissions ||
                        "{}"
                    )
                    : managerRows[0].permissions || {};

            if (!managerPermissions.staff_management) {
                return {
                    statusCode: 403,
                    headers,
                    body: JSON.stringify({
                        error:
                            "You do not have permission to update staff accounts",
                    }),
                };
            }

            const nextStatus =
                action === "reactivate_staff"
                    ? "active"
                    : "inactive";

            if (nextStatus === "active") {
                try {
                    // Re-activation consumes a staff seat too. This prevents
                    // an inactive account from being used to bypass the plan.
                    await assertPlanLimit(
                        connection,
                        Number(storeId),
                        "staff",
                        1,
                        decoded.role
                    );
                } catch (limitError) {
                    return {
                        statusCode: limitError?.statusCode || 409,
                        headers,
                        body: JSON.stringify({
                            error: limitError?.message || "Plan limit reached.",
                            code: limitError?.code || "STAFF_LIMIT_REACHED",
                            plan_name: limitError?.plan_name,
                            current: limitError?.current,
                            limit: limitError?.limit,
                        }),
                    };
                }
            }

            let result;

            if (staffId) {
                [result] = await connection.execute(
                    `UPDATE users
                     SET status = ?
                     WHERE id = ?
                       AND role = 'staff'
                       AND store_id = ?
                       AND branch_id = ?
                       AND manager_id = ?
                       AND status IN ('active', 'inactive')`,
                    [
                        nextStatus,
                        staffId,
                        storeId,
                        branchId,
                        managerId,
                    ]
                );
            } else {
                [result] = await connection.execute(
                    `UPDATE users
                     SET status = ?
                     WHERE email = ?
                       AND role = 'staff'
                       AND store_id = ?
                       AND branch_id = ?
                       AND manager_id = ?
                       AND status IN ('active', 'inactive')`,
                    [
                        nextStatus,
                        staffEmail,
                        storeId,
                        branchId,
                        managerId,
                    ]
                );
            }

            if (result.affectedRows === 0) {
                return {
                    statusCode: 404,
                    headers,
                    body: JSON.stringify({
                        error:
                            "Staff account was not found or is still pending activation",
                    }),
                };
            }

            return {
                statusCode: 200,
                headers,
                body: JSON.stringify({
                    message:
                        nextStatus === "active"
                            ? "Staff account reactivated successfully"
                            : "Staff account deactivated successfully",
                    staff_status: nextStatus,
                    staff_updated: result.affectedRows,
                }),
            };
        }

        // UPDATE STAFF PERMISSIONS
        if (action === "update_staff_permissions") {
            const authHeader =
                event.headers?.Authorization || event.headers?.authorization || "";

            const token = authHeader.replace("Bearer ", "");

            if (!token) {
                return {
                    statusCode: 401,
                    headers,
                    body: JSON.stringify({ error: "Missing token" }),
                };
            }

            let decoded;

            try {
                decoded = jwt.verify(token, JWT_SECRET);
            } catch (err) {
                return {
                    statusCode: 401,
                    headers,
                    body: JSON.stringify({ error: "Invalid token" }),
                };
            }

            if (decoded.role !== "manager") {
                return {
                    statusCode: 403,
                    headers,
                    body: JSON.stringify({ error: "Only managers can update staff access" }),
                };
            }

            const managerId = decoded.manager_id;
            const storeId = decoded.store_id;
            const branchId = decoded.branch_id;
            const { staff_id, staff_email, permissions = {} } = body;

            if (!staff_id && !staff_email) {
                return {
                    statusCode: 400,
                    headers,
                    body: JSON.stringify({ error: "Missing staff id or email" }),
                };
            }

            const [managerRows] = await connection.execute(
                `SELECT permissions
                 FROM users
                 WHERE id = ?
                   AND role = 'manager'
                   AND store_id = ?
                   AND branch_id = ?
                   AND status = 'active'
                     LIMIT 1`,
                [managerId, storeId, branchId]
            );

            if (managerRows.length === 0) {
                return {
                    statusCode: 404,
                    headers,
                    body: JSON.stringify({ error: "Manager not found" }),
                };
            }

            const managerPermissions =
                typeof managerRows[0].permissions === "string"
                    ? JSON.parse(managerRows[0].permissions || "{}")
                    : managerRows[0].permissions || {};

            if (!managerPermissions.staff_management) {
                return {
                    statusCode: 403,
                    headers,
                    body: JSON.stringify({
                        error: "You do not have permission to update staff access",
                    }),
                };
            }

            let result;

            if (staff_id) {
                [result] = await connection.execute(
                    `UPDATE users
                     SET permissions = ?
                     WHERE id = ?
                       AND role = 'staff'
                       AND store_id = ?
                       AND branch_id = ?
                       AND manager_id = ?`,
                    [
                        JSON.stringify(permissions || {}),
                        staff_id,
                        storeId,
                        branchId,
                        managerId,
                    ]
                );
            } else {
                [result] = await connection.execute(
                    `UPDATE users
                     SET permissions = ?
                     WHERE email = ?
                       AND role = 'staff'
                       AND store_id = ?
                       AND branch_id = ?
                       AND manager_id = ?`,
                    [
                        JSON.stringify(permissions || {}),
                        staff_email,
                        storeId,
                        branchId,
                        managerId,
                    ]
                );
            }

            if (result.affectedRows === 0) {
                return {
                    statusCode: 404,
                    headers,
                    body: JSON.stringify({ error: "Staff not found" }),
                };
            }

            return {
                statusCode: 200,
                headers,
                body: JSON.stringify({
                    message: "Staff permissions updated successfully",
                    staff_updated: result.affectedRows,
                }),
            };
        }

        // RESEND STAFF INVITE
        if (action === "resend_staff_invite") {
            const authHeader =
                event.headers?.Authorization || event.headers?.authorization || "";

            const token = authHeader.replace("Bearer ", "");

            if (!token) {
                return {
                    statusCode: 401,
                    headers,
                    body: JSON.stringify({ error: "Missing token" }),
                };
            }

            let decoded;

            try {
                decoded = jwt.verify(token, JWT_SECRET);
            } catch {
                return {
                    statusCode: 401,
                    headers,
                    body: JSON.stringify({ error: "Invalid token" }),
                };
            }

            if (decoded.role !== "manager") {
                return {
                    statusCode: 403,
                    headers,
                    body: JSON.stringify({
                        error: "Only managers can resend staff invites",
                    }),
                };
            }

            const managerId = decoded.manager_id;
            const storeId = decoded.store_id;
            const branchId = decoded.branch_id;
            const staffEmail = String(body.staff_email || "")
                .trim()
                .toLowerCase();

            if (!staffEmail) {
                return {
                    statusCode: 400,
                    headers,
                    body: JSON.stringify({ error: "Missing staff email" }),
                };
            }

            const [managerRows] = await connection.execute(
                `SELECT
                     managers.permissions,
                     managers.full_name AS manager_name,
                     branches.branch_name,
                     stores.store_name
                 FROM users managers
                          JOIN branches ON branches.id = managers.branch_id AND branches.store_id = managers.store_id
                          JOIN stores ON stores.id = managers.store_id
                 WHERE managers.id = ?
                   AND managers.role = 'manager'
                   AND managers.store_id = ?
                   AND managers.branch_id = ?
                   AND managers.status = 'active'
                     LIMIT 1`,
                [managerId, storeId, branchId]
            );

            if (managerRows.length === 0) {
                return {
                    statusCode: 404,
                    headers,
                    body: JSON.stringify({ error: "Manager not found" }),
                };
            }

            const manager = managerRows[0];

            const managerPermissions =
                typeof manager.permissions === "string"
                    ? JSON.parse(manager.permissions || "{}")
                    : manager.permissions || {};

            if (!managerPermissions.staff_management) {
                return {
                    statusCode: 403,
                    headers,
                    body: JSON.stringify({
                        error: "You do not have permission to resend staff invites",
                    }),
                };
            }

            const [staffRows] = await connection.execute(
                `SELECT id, full_name AS staff_name, email AS staff_email, status, permissions
                 FROM users
                 WHERE email = ?
                   AND role = 'staff'
                   AND store_id = ?
                   AND branch_id = ?
                   AND manager_id = ?
                     LIMIT 1`,
                [staffEmail, storeId, branchId, managerId]
            );

            if (staffRows.length === 0) {
                return {
                    statusCode: 404,
                    headers,
                    body: JSON.stringify({
                        error: "Pending staff invite not found",
                    }),
                };
            }

            const staff = staffRows[0];

            if (staff.status !== "pending") {
                return {
                    statusCode: 400,
                    headers,
                    body: JSON.stringify({
                        error: "This staff account is already accepted or inactive",
                    }),
                };
            }

            const inviteToken = jwt.sign(
                {
                    store_id: storeId,
                    branch_id: branchId,
                    manager_id: managerId,
                    email: staff.staff_email,
                    type: "staff_invite",
                },
                JWT_SECRET,
                { expiresIn: "7d" }
            );

            const inviteLink =
                `${APP_BASE_URL}/accept-staff-invite?token=${encodeURIComponent(inviteToken)}`;

            await connection.execute(
                `UPDATE users
                 SET invite_token_hash = SHA2(?, 256)
                 WHERE id = ?
                   AND role = 'staff'
                   AND store_id = ?
                   AND branch_id = ?
                   AND manager_id = ?`,
                [inviteToken, staff.id, storeId, branchId, managerId]
            );

            const staffPermissions =
                typeof staff.permissions === "string"
                    ? JSON.parse(staff.permissions || "{}")
                    : staff.permissions || {};

            const resendInvitation = {
                staff_email: staff.staff_email,
                staff_name: staff.staff_name,
                manager_name: manager.manager_name || "Branch Manager",
                store_name: manager.store_name || "StockNBook Store",
                branch_name: manager.branch_name || "Assigned Branch",
                invite_link: inviteLink,
                permissions: staffPermissions,
            };

            const delivery = await deliverInvitationEmail({
                role: "Staff",
                email: staff.staff_email,
                name: staff.staff_name,
                storeName: manager.store_name || "StockNBook Store",
                branchName: manager.branch_name || "Assigned Branch",
                inviteLink,
                send: () => sendStaffInvitationEmail(resendInvitation),
            });

            return {
                statusCode: 200,
                headers,
                body: JSON.stringify({
                    message: delivery.email_sent
                        ? "Staff invitation emailed successfully."
                        : "The staff invitation link was refreshed, but the email could not be delivered. Copy the backup link or try Resend later.",
                    invite_link: inviteLink,
                    staff_email: staff.staff_email,
                    staff_name: staff.staff_name,
                    email_sent: delivery.email_sent,
                    email_status: delivery.email_status,
                    email_error: delivery.email_error,
                }),
            };
        }

        // ADD MANAGER TO AN EXISTING BRANCH
        if (action === "add_manager_to_branch") {
            const authHeader =
                event.headers?.Authorization ||
                event.headers?.authorization ||
                "";

            const token = authHeader.replace("Bearer ", "");

            if (!token) {
                return {
                    statusCode: 401,
                    headers,
                    body: JSON.stringify({ error: "Missing token" }),
                };
            }

            let decoded;

            try {
                decoded = jwt.verify(token, JWT_SECRET);
            } catch {
                return {
                    statusCode: 401,
                    headers,
                    body: JSON.stringify({ error: "Invalid token" }),
                };
            }

            if (
                decoded.role !== "owner" ||
                !decoded.store_id
            ) {
                return {
                    statusCode: 403,
                    headers,
                    body: JSON.stringify({
                        error:
                            "Only the store owner can add a branch manager",
                    }),
                };
            }

            const storeId = Number(decoded.store_id);
            const branchId = Number(body.branch_id);
            const managerName = String(
                body.manager_name || ""
            ).trim();
            const managerEmail = String(
                body.manager_email || ""
            )
                .trim()
                .toLowerCase();

            const permissions =
                body.permissions &&
                typeof body.permissions === "object" &&
                !Array.isArray(body.permissions)
                    ? body.permissions
                    : {};

            if (!branchId) {
                return {
                    statusCode: 400,
                    headers,
                    body: JSON.stringify({
                        error: "Select a branch",
                    }),
                };
            }

            if (!managerName) {
                return {
                    statusCode: 400,
                    headers,
                    body: JSON.stringify({
                        error: "Manager name is required",
                    }),
                };
            }

            if (
                !managerEmail ||
                !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(
                    managerEmail
                )
            ) {
                return {
                    statusCode: 400,
                    headers,
                    body: JSON.stringify({
                        error:
                            "Enter a valid manager email address",
                    }),
                };
            }

            const [branchRows] = await connection.execute(
                `SELECT
                     branches.id,
                     branches.branch_name,
                     stores.store_name
                 FROM branches
                          JOIN stores
                               ON stores.id = branches.store_id
                 WHERE branches.id = ?
                   AND branches.store_id = ?
                     LIMIT 1`,
                [branchId, storeId]
            );

            if (branchRows.length === 0) {
                return {
                    statusCode: 404,
                    headers,
                    body: JSON.stringify({
                        error:
                            "The selected branch was not found",
                    }),
                };
            }

            const branch = branchRows[0];

            const [branchManagerRows] =
                await connection.execute(
                    `SELECT id
                     FROM users
                     WHERE branch_id = ?
                       AND store_id = ?
                       AND role = 'manager'
                         LIMIT 1`,
                    [branchId, storeId]
                );

            if (branchManagerRows.length > 0) {
                return {
                    statusCode: 409,
                    headers,
                    body: JSON.stringify({
                        error:
                            "This branch already has an assigned or pending manager",
                    }),
                };
            }

            const [existingEmailRows] =
                await connection.execute(
                    `SELECT id
                     FROM users
                     WHERE email = ?
                         LIMIT 1`,
                    [managerEmail]
                );

            if (existingEmailRows.length > 0) {
                return {
                    statusCode: 409,
                    headers,
                    body: JSON.stringify({
                        error:
                            "This email is already assigned to a manager in your store",
                    }),
                };
            }

            const inviteToken = jwt.sign(
                {
                    store_id: storeId,
                    branch_id: branchId,
                    email: managerEmail,
                    type: "manager_invite",
                },
                JWT_SECRET,
                { expiresIn: "7d" }
            );

            const inviteLink =
                `${APP_BASE_URL}/accept-invite?token=${encodeURIComponent(
                    inviteToken
                )}`;

            // Permanent role-specific Employee ID within this store and branch.
            if (!(await identifiers.ensureIdentifierSchema(connection))) {
                throw new Error("Employee ID numbering is not set up. Run scripts/standardize-identifiers.js.");
            }
            const employeeCode = await identifiers.generateEmployeeCode(connection, {
                storeId,
                branchId,
                roleCode: "MN",
            });

            const [managerResult] =
                await connection.execute(
                    `INSERT INTO users
                     (
                         store_id,
                         branch_id,
                         role,
                         full_name,
                         email,
                         invite_token_hash,
                         permissions,
                         status,
                         employee_code
                     )
                     VALUES (?, ?, 'manager', COALESCE(?, ''), ?, SHA2(?, 256), ?, ?, ?)`,
                    [
                        storeId,
                        branchId,
                        managerName,
                        managerEmail,
                        inviteToken,
                        JSON.stringify(permissions),
                        "pending",
                        employeeCode,
                    ]
                );

            const invitation = {
                manager_email: managerEmail,
                manager_name: managerName,
                store_name:
                    branch.store_name ||
                    "StockNBook Store",
                branch_name:
                    branch.branch_name ||
                    "Assigned Branch",
                invite_link: inviteLink,
                permissions,
            };

            const delivery = await deliverInvitationEmail({
                role: "Manager",
                email: managerEmail,
                name: managerName,
                storeName: branch.store_name || "StockNBook Store",
                branchName: branch.branch_name || "Assigned Branch",
                inviteLink,
                send: () => sendManagerInvitationEmail(invitation),
            });

            return {
                statusCode: 201,
                headers,
                body: JSON.stringify({
                    message: delivery.email_sent
                        ? "Manager added and invitation email sent successfully."
                        : "Manager added successfully, but the invitation email could not be delivered. Copy the backup invite link or use Resend later.",
                    manager: {
                        id: managerResult.insertId,
                        name: managerName,
                        email: managerEmail,
                        branch:
                            branch.branch_name ||
                            "No branch assigned",
                        status: "pending",
                        permissions,
                    },
                    invite_link: inviteLink,
                    email_sent: delivery.email_sent,
                    email_status: delivery.email_status,
                    email_error: delivery.email_error,
                }),
            };
        }

        // RESEND MANAGER INVITATION
        if (action === "resend_manager_invite") {
            const token = getBearerTokenFromEvent(event);

            if (!token) {
                return {
                    statusCode: 401,
                    headers,
                    body: JSON.stringify({ error: "Missing token" }),
                };
            }

            let decoded;
            try {
                decoded = jwt.verify(token, JWT_SECRET);
            } catch {
                return {
                    statusCode: 401,
                    headers,
                    body: JSON.stringify({ error: "Invalid token" }),
                };
            }

            if (decoded.role !== "owner" || !decoded.store_id) {
                return {
                    statusCode: 403,
                    headers,
                    body: JSON.stringify({
                        error: "Only the store owner can resend a manager invitation.",
                    }),
                };
            }

            const storeId = Number(decoded.store_id);
            const managerId = Number(body.manager_id);
            const managerEmail = String(body.manager_email || "")
                .trim()
                .toLowerCase();

            if ((!Number.isInteger(managerId) || managerId <= 0) && !managerEmail) {
                return {
                    statusCode: 400,
                    headers,
                    body: JSON.stringify({
                        error: "Select a pending manager invitation to resend.",
                    }),
                };
            }

            const whereClause =
                Number.isInteger(managerId) && managerId > 0
                    ? "managers.id = ?"
                    : "LOWER(managers.manager_email) = ?";

            const lookupValue =
                Number.isInteger(managerId) && managerId > 0
                    ? managerId
                    : managerEmail;

            const [managerRows] = await connection.execute(
                `SELECT
                     managers.id,
                     managers.full_name AS manager_name,
                     managers.email AS manager_email,
                     managers.permissions,
                     managers.status,
                     managers.branch_id,
                     branches.branch_name,
                     stores.store_name
                 FROM users managers
                          JOIN branches ON branches.id = managers.branch_id AND branches.store_id = managers.store_id
                          JOIN stores ON stores.id = managers.store_id
                 WHERE managers.role = 'manager'
                   AND managers.store_id = ?
                   AND ${whereClause}
                     LIMIT 1`,
                [storeId, lookupValue]
            );

            if (managerRows.length === 0) {
                return {
                    statusCode: 404,
                    headers,
                    body: JSON.stringify({
                        error: "Pending manager invitation not found.",
                    }),
                };
            }

            const manager = managerRows[0];

            if (String(manager.status || "").toLowerCase() !== "pending") {
                return {
                    statusCode: 409,
                    headers,
                    body: JSON.stringify({
                        error: "Only pending manager invitations can be resent.",
                    }),
                };
            }

            const inviteToken = jwt.sign(
                {
                    store_id: storeId,
                    branch_id: manager.branch_id,
                    email: manager.manager_email,
                    type: "manager_invite",
                },
                JWT_SECRET,
                { expiresIn: "7d" }
            );

            const inviteLink =
                `${APP_BASE_URL}/accept-invite?token=${encodeURIComponent(inviteToken)}`;

            await connection.execute(
                `UPDATE users
                 SET invite_token_hash = SHA2(?, 256)
                 WHERE id = ?
                   AND role = 'manager'
                   AND store_id = ?
                   AND status = 'pending'`,
                [inviteToken, manager.id, storeId]
            );

            const permissions =
                typeof manager.permissions === "string"
                    ? JSON.parse(manager.permissions || "{}")
                    : manager.permissions || {};

            const invitation = {
                manager_email: manager.manager_email,
                manager_name: manager.manager_name,
                store_name: manager.store_name || "StockNBook Store",
                branch_name: manager.branch_name || "Assigned Branch",
                invite_link: inviteLink,
                permissions,
            };

            const delivery = await deliverInvitationEmail({
                role: "Manager",
                email: manager.manager_email,
                name: manager.manager_name,
                storeName: manager.store_name || "StockNBook Store",
                branchName: manager.branch_name || "Assigned Branch",
                inviteLink,
                send: () => sendManagerInvitationEmail(invitation),
            });

            return {
                statusCode: 200,
                headers,
                body: JSON.stringify({
                    message: delivery.email_sent
                        ? "Manager invitation emailed successfully."
                        : "The manager invitation link was refreshed, but the email could not be delivered. Copy the backup link or try Resend later.",
                    manager_id: Number(manager.id),
                    manager_email: manager.manager_email,
                    manager_name: manager.manager_name,
                    invite_link: inviteLink,
                    email_sent: delivery.email_sent,
                    email_status: delivery.email_status,
                    email_error: delivery.email_error,
                }),
            };
        }

        // GET BRANCH MANAGERS
        if (action === "get_branch_managers") {
            const authHeader =
                event.headers?.Authorization || event.headers?.authorization || "";

            const token = authHeader.replace("Bearer ", "");

            if (!token) {
                return {
                    statusCode: 401,
                    headers,
                    body: JSON.stringify({ error: "Missing token" }),
                };
            }

            let decoded;

            try {
                decoded = jwt.verify(token, JWT_SECRET);
            } catch (err) {
                return {
                    statusCode: 401,
                    headers,
                    body: JSON.stringify({ error: "Invalid token" }),
                };
            }

            if (!decoded.store_id) {
                return {
                    statusCode: 403,
                    headers,
                    body: JSON.stringify({ error: "Only store owners can view branch managers" }),
                };
            }

            const storeId = decoded.store_id;

            const employeeCodeReady = await identifiers.ensureIdentifierSchema(connection);
            const [managerRows] = await connection.execute(
                `SELECT
                     managers.id,
                     managers.employee_code AS employeeCode,
                     managers.full_name AS name,
                     managers.email AS email,
                     managers.status,
                     managers.permissions,
                     branches.branch_name AS branch
                 FROM users managers
                          JOIN branches ON managers.branch_id = branches.id
                 WHERE managers.store_id = ?
                   AND managers.role = 'manager'
                 ORDER BY branches.branch_name ASC, managers.full_name ASC`,
                [storeId]
            );

            return {
                statusCode: 200,
                headers,
                body: JSON.stringify({
                    managers: managerRows.map((manager) => ({
                        id: manager.id,
                        employee_code: manager.employeeCode || "",
                        name: manager.name || "Unnamed manager",
                        email: manager.email || "",
                        branch: manager.branch || "No branch assigned",
                        status: manager.status || "pending",
                        permissions:
                            typeof manager.permissions === "string"
                                ? JSON.parse(manager.permissions || "{}")
                                : manager.permissions || {},
                    })),
                }),
            };
        }

        // GET BRANCHES
        if (action === "get_branches") {

            const authHeader =
                event.headers?.Authorization || event.headers?.authorization || "";

            const token = authHeader.replace("Bearer ", "");

            if (!token) {
                return {
                    statusCode: 401,
                    headers,
                    body: JSON.stringify({ error: "Missing token" }),
                };
            }

            let decoded;

            try {
                decoded = jwt.verify(token, JWT_SECRET);
            } catch (err) {
                return {
                    statusCode: 401,
                    headers,
                    body: JSON.stringify({ error: "Invalid token" }),
                };
            }

            const storeId = decoded.store_id;

            if (!storeId) {
                return {
                    statusCode: 403,
                    headers,
                    body: JSON.stringify({ error: "Missing store access" }),
                };
            }

            const [branchRows] = await connection.execute(
                `SELECT
                     branches.id,
                     branches.branch_name,
                     branches.phone AS contact_number,
                     branches.address,
                     COALESCE(branches.status, 'active') AS branch_status,
                     '' AS inactive_reason,
                     COALESCE(managers.full_name, '') AS manager_name,
                     COALESCE(managers.email, '') AS manager_email,
                     COALESCE(managers.status, 'setup_pending') AS manager_status,
                     managers.permissions,
                     COUNT(
                             DISTINCT CASE
                                          WHEN staff.status = 'active'
                                              THEN staff.id
                                          ELSE NULL
                         END
                     ) AS staff_count
                 FROM branches
                          LEFT JOIN users managers
                                    ON managers.branch_id = branches.id
                                        AND managers.role = 'manager'
                          LEFT JOIN users staff
                                    ON staff.branch_id = branches.id
                                        AND staff.role = 'staff'
                 WHERE branches.store_id = ?
                 GROUP BY
                     branches.id,
                     branches.branch_name,
                     branches.phone,
                     branches.address,
                     branches.status,
                     managers.full_name,
                     managers.email,
                     managers.status,
                     managers.permissions
                 ORDER BY branches.id ASC`,
                [storeId]
            );

            return {
                statusCode: 200,
                headers,
                body: JSON.stringify({
                    branches: branchRows.map((branch) => ({
                        id: branch.id,
                        branch_name: branch.branch_name,
                        contact_number: branch.contact_number || "",
                        address: branch.address || "",
                        branch_status:
                            branch.branch_status || "active",
                        status:
                            branch.branch_status || "active",
                        inactive_reason:
                            branch.inactive_reason || "",
                        branch_inactive_reason:
                            branch.inactive_reason || "",
                        manager_name: branch.manager_name || "",
                        manager_email: branch.manager_email || "",
                        manager_status: branch.manager_status || "setup_pending",
                        staff_count: Number(branch.staff_count || 0),
                        revenue: 0,
                        bookings: 0,
                        permissions:
                            typeof branch.permissions === "string"
                                ? JSON.parse(branch.permissions || "{}")
                                : branch.permissions || {},
                    }))
                }),
            };
        }

        // UPDATE BRANCH
        if (action === "update_branch") {

            const authHeader =
                event.headers?.Authorization || event.headers?.authorization || "";

            const token = authHeader.replace("Bearer ", "");

            if (!token) {
                return {
                    statusCode: 401,
                    headers,
                    body: JSON.stringify({ error: "Missing token" }),
                };
            }

            let decoded;

            try {
                decoded = jwt.verify(token, JWT_SECRET);
            } catch (err) {
                return {
                    statusCode: 401,
                    headers,
                    body: JSON.stringify({ error: "Invalid token" }),
                };
            }

            const storeId = decoded.store_id;

            // Only the store owner may change branch details or manager permissions.
            if (decoded.role !== "owner" || !storeId) {
                return {
                    statusCode: 403,
                    headers,
                    body: JSON.stringify({ error: "Only the store owner can update branches." }),
                };
            }

            const {
                branch_id,
                branch_name,
                contact_number,
                address,
                status,
                branch_status,
                inactive_reason,
                branch_inactive_reason,
                manager_name,
                manager_email,
                permissions = {},
            } = body;

            if (!branch_id || !branch_name) {
                return {
                    statusCode: 400,
                    headers,
                    body: JSON.stringify({ error: "Missing branch id or branch name" }),
                };
            }

            const normalizedBranchStatus = String(
                status || branch_status || "active"
            )
                .trim()
                .toLowerCase();

            const normalizedInactiveReason =
                normalizedBranchStatus === "inactive"
                    ? String(
                        inactive_reason ||
                        branch_inactive_reason ||
                        ""
                    ).trim()
                    : "";

            if (
                normalizedBranchStatus !== "active" &&
                normalizedBranchStatus !== "inactive"
            ) {
                return {
                    statusCode: 400,
                    headers,
                    body: JSON.stringify({
                        error:
                            "Branch status must be active or inactive",
                    }),
                };
            }

            if (
                normalizedBranchStatus === "inactive" &&
                !normalizedInactiveReason
            ) {
                return {
                    statusCode: 400,
                    headers,
                    body: JSON.stringify({
                        error:
                            "Select a reason before marking the branch inactive",
                    }),
                };
            }

            await connection.beginTransaction();

            try {
                const [branchResult] = await connection.execute(
                    `UPDATE branches
                     SET branch_name = ?,
                         phone = ?,
                         address = ?,
                         status = ?
                     WHERE id = ?
                       AND store_id = ?`,
                    [
                        branch_name,
                        contact_number || null,
                        address || null,
                        normalizedBranchStatus,
                        branch_id,
                        storeId,
                    ]
                );

                if (branchResult.affectedRows === 0) {
                    await connection.rollback();

                    return {
                        statusCode: 404,
                        headers,
                        body: JSON.stringify({ error: "Branch not found" }),
                    };
                }

                const [managerResult] = await connection.execute(
                    `UPDATE users
                     SET full_name = COALESCE(?, ''),
                         email = COALESCE(?, email),
                         permissions = ?
                     WHERE branch_id = ?
                       AND store_id = ?
                       AND role = 'manager'`,
                    [
                        manager_name || null,
                        manager_email || null,
                        JSON.stringify(permissions || {}),
                        branch_id,
                        storeId,
                    ]
                );

                await connection.commit();

                return {
                    statusCode: 200,
                    headers,
                    body: JSON.stringify({
                        message: "Branch updated successfully",
                        branch_updated: branchResult.affectedRows,
                        manager_updated: managerResult.affectedRows,
                        branch_status: normalizedBranchStatus,
                        inactive_reason:
                        normalizedInactiveReason,
                        saved_permissions: permissions,
                    }),
                };
            } catch (err) {
                await connection.rollback();

                return {
                    statusCode: 500,
                    headers,
                    body: JSON.stringify({ error: err.message }),
                };
            }
        }

// DELETE BRANCH
        if (action === "delete_branch") {
            const authHeader =
                event.headers?.Authorization || event.headers?.authorization || "";

            const token = authHeader.replace("Bearer ", "");

            if (!token) {
                return {
                    statusCode: 401,
                    headers,
                    body: JSON.stringify({ error: "Missing token" }),
                };
            }

            let decoded;

            try {
                decoded = jwt.verify(token, JWT_SECRET);
            } catch (err) {
                return {
                    statusCode: 401,
                    headers,
                    body: JSON.stringify({ error: "Invalid token" }),
                };
            }

            const storeId = decoded.store_id;
            const { branch_id } = body;

            // Branch deletion also removes assigned employees: owner approval is required.
            if (decoded.role !== "owner" || !storeId) {
                return {
                    statusCode: 403,
                    headers,
                    body: JSON.stringify({ error: "Only the store owner can delete branches." }),
                };
            }

            if (!branch_id) {
                return {
                    statusCode: 400,
                    headers,
                    body: JSON.stringify({ error: "Missing store or branch id" }),
                };
            }

            await connection.beginTransaction();

            try {
                await connection.execute(
                    `DELETE FROM users WHERE branch_id = ? AND store_id = ? AND role = 'staff'`,
                    [branch_id, storeId]
                );

                await connection.execute(
                    `DELETE FROM users WHERE branch_id = ? AND store_id = ? AND role = 'manager'`,
                    [branch_id, storeId]
                );

                const [branchResult] = await connection.execute(
                    `DELETE FROM branches WHERE id = ? AND store_id = ?`,
                    [branch_id, storeId]
                );

                if (branchResult.affectedRows === 0) {
                    await connection.rollback();

                    return {
                        statusCode: 404,
                        headers,
                        body: JSON.stringify({ error: "Branch not found" }),
                    };
                }

                await connection.commit();

                return {
                    statusCode: 200,
                    headers,
                    body: JSON.stringify({
                        message: "Branch deleted successfully",
                    }),
                };
            } catch (err) {
                await connection.rollback();

                return {
                    statusCode: 500,
                    headers,
                    body: JSON.stringify({ error: err.message }),
                };
            }
        }

        // GET CURRENT USER
        if (action === "get_current_user") {
            const authHeader =
                event.headers?.Authorization || event.headers?.authorization || "";

            const token = authHeader.replace("Bearer ", "");

            if (!token) {
                return {
                    statusCode: 401,
                    headers,
                    body: JSON.stringify({ error: "Missing token" }),
                };
            }

            let decoded;

            try {
                decoded = jwt.verify(token, JWT_SECRET);
            } catch (err) {
                return {
                    statusCode: 401,
                    headers,
                    body: JSON.stringify({ error: "Invalid token" }),
                };
            }

            // Platform administrator sessions do not belong to a store.
            // Return the admin identity directly so the dashboard's
            // get_current_user check succeeds instead of treating the token
            // as an invalid/unknown role and redirecting to the landing page.
            if (decoded.role === "PLATFORM_ADMIN") {
                const platformAdminId = Number(decoded.platform_admin_id);

                if (!platformAdminId) {
                    return {
                        statusCode: 401,
                        headers,
                        body: JSON.stringify({ error: "Invalid platform admin token" }),
                    };
                }

                const [adminRows] = await connection.execute(
                    `SELECT
                         id AS platform_admin_id,
                         full_name,
                         email,
                         role,
                         status,
                         CASE WHEN LOWER(status) = 'active' THEN 1 ELSE 0 END AS is_active
                     FROM platform_admins
                     WHERE id = ?
                         LIMIT 1`,
                    [platformAdminId]
                );

                if (!adminRows.length) {
                    return {
                        statusCode: 404,
                        headers,
                        body: JSON.stringify({ error: "Platform administrator not found" }),
                    };
                }

                const admin = adminRows[0];
                const adminStatus = String(admin.status || "")
                    .trim()
                    .toLowerCase();

                if (adminStatus !== "active" || Number(admin.is_active) !== 1) {
                    return {
                        statusCode: 403,
                        headers,
                        body: JSON.stringify({
                            error: "Platform administrator account is inactive.",
                            code: "ACCOUNT_INACTIVE",
                        }),
                    };
                }

                return {
                    statusCode: 200,
                    headers,
                    body: JSON.stringify({
                        role: "PLATFORM_ADMIN",
                        platform_admin_id: admin.platform_admin_id,
                        full_name: admin.full_name,
                        email: admin.email,
                    }),
                };
            }

            if (decoded.role === "owner") {
                const [storeRows] = await connection.execute(
                    `SELECT s.id, s.store_name, u.full_name AS owner_name, u.email, s.slug
                     FROM stores s
                              LEFT JOIN users u ON u.store_id = s.id AND u.role = 'owner'
                     WHERE s.id = ?
                         LIMIT 1`,
                    [decoded.store_id]
                );

                if (!storeRows.length) {
                    return {
                        statusCode: 404,
                        headers,
                        body: JSON.stringify({ error: "Owner store not found" }),
                    };
                }

                const store = storeRows[0];



                return {
                    statusCode: 200,
                    headers,
                    body: JSON.stringify({
                        role: "owner",
                        store_id: store.id,
                        store_name: store.store_name,
                        store_slug: store.slug,
                        owner_name: store.owner_name,
                        email: store.email,
                    }),
                };
            }

            if (decoded.role === "manager") {
                const [managerRows] = await connection.execute(
                    `SELECT
                         managers.id,
                         managers.full_name AS manager_name,
                         managers.email AS manager_email,
                         managers.permissions,
                         managers.status,
                         managers.store_id,
                         managers.branch_id,
                         branches.branch_name,
                         stores.store_name
                     FROM users managers
                              JOIN branches ON managers.branch_id = branches.id
                              JOIN stores ON managers.store_id = stores.id
                     WHERE managers.id = ?
                       AND managers.role = 'manager'
                       AND managers.store_id = ?
                       AND managers.branch_id = ?
                         LIMIT 1`,
                    [decoded.manager_id, decoded.store_id, decoded.branch_id]
                );

                if (!managerRows.length) {
                    return {
                        statusCode: 404,
                        headers,
                        body: JSON.stringify({ error: "Manager not found" }),
                    };
                }

                const manager = managerRows[0];

                if (manager.status !== "active") {
                    return {
                        statusCode: 403,
                        headers,
                        body: JSON.stringify({
                            error: "Account deactivated",
                            code: "ACCOUNT_DEACTIVATED",
                            message:
                                "Your branch manager account has been deactivated. Please contact the store owner if you think this was a mistake.",
                        }),
                    };
                }

                return {
                    statusCode: 200,
                    headers,
                    body: JSON.stringify({
                        role: "manager",
                        manager_id: manager.id,
                        manager_name: manager.manager_name,
                        manager_email: manager.manager_email,
                        store_id: manager.store_id,
                        store_name: manager.store_name,
                        branch_id: manager.branch_id,
                        branch_name: manager.branch_name,
                        permissions:
                            typeof manager.permissions === "string"
                                ? JSON.parse(manager.permissions || "{}")
                                : manager.permissions || {},
                    }),
                };
            }

            if (decoded.role === "staff") {
                const [staffRows] = await connection.execute(
                    `SELECT
                         staff.id,
                         staff.full_name AS staff_name,
                         staff.email AS staff_email,
                         staff.permissions,
                         staff.store_id,
                         staff.branch_id,
                         staff.manager_id,
                         branches.branch_name,
                         stores.store_name
                     FROM users staff
                              JOIN branches ON staff.branch_id = branches.id
                              JOIN stores ON staff.store_id = stores.id
                     WHERE staff.id = ?
                       AND staff.role = 'staff'
                       AND staff.store_id = ?
                       AND staff.branch_id = ?
                       AND staff.status = 'active'
                         LIMIT 1`,
                    [decoded.staff_id, decoded.store_id, decoded.branch_id]
                );

                if (!staffRows.length) {
                    return {
                        statusCode: 404,
                        headers,
                        body: JSON.stringify({ error: "Staff not found" }),
                    };
                }

                const staff = staffRows[0];

                return {
                    statusCode: 200,
                    headers,
                    body: JSON.stringify({
                        role: "staff",
                        staff_id: staff.id,
                        staff_name: staff.staff_name,
                        staff_email: staff.staff_email,
                        store_id: staff.store_id,
                        store_name: staff.store_name,
                        branch_id: staff.branch_id,
                        branch_name: staff.branch_name,
                        manager_id: staff.manager_id,
                        permissions:
                            typeof staff.permissions === "string"
                                ? JSON.parse(staff.permissions || "{}")
                                : staff.permissions || {},
                    }),
                };
            }

            // DEACTIVATE MANAGER


            return {
                statusCode: 400,
                headers,
                body: JSON.stringify({ error: "Invalid role" }),
            };
        }
        // DELETE MANAGER ACCOUNT
        if (action === "delete_manager") {
            const authHeader =
                event.headers?.Authorization ||
                event.headers?.authorization ||
                "";

            const token = authHeader.replace("Bearer ", "");

            if (!token) {
                return {
                    statusCode: 401,
                    headers,
                    body: JSON.stringify({
                        error: "Missing token",
                    }),
                };
            }

            let decoded;

            try {
                decoded = jwt.verify(token, JWT_SECRET);
            } catch {
                return {
                    statusCode: 401,
                    headers,
                    body: JSON.stringify({
                        error: "Invalid token",
                    }),
                };
            }

            if (decoded.role !== "owner") {
                return {
                    statusCode: 403,
                    headers,
                    body: JSON.stringify({
                        error: "Only owners can delete managers",
                    }),
                };
            }

            const storeId = Number(decoded.store_id);
            const managerId = Number(body.manager_id);

            if (!storeId || !managerId) {
                return {
                    statusCode: 400,
                    headers,
                    body: JSON.stringify({
                        error: "Missing manager id",
                    }),
                };
            }

            const [managerRows] = await connection.execute(
                `SELECT id, branch_id, full_name AS manager_name, email AS manager_email
                 FROM users
                 WHERE id = ?
                   AND role = 'manager'
                   AND store_id = ?
                     LIMIT 1`,
                [managerId, storeId]
            );

            if (managerRows.length === 0) {
                return {
                    statusCode: 404,
                    headers,
                    body: JSON.stringify({
                        error: "Manager not found",
                    }),
                };
            }

            await connection.beginTransaction();

            try {
                // Staff accounts belong to this manager through staff.manager_id.
                // Remove them first so the manager can be deleted cleanly and
                // no staff account remains attached to a deleted manager.
                const [staffDeleteResult] = await connection.execute(
                    `DELETE FROM users WHERE manager_id = ? AND store_id = ? AND role = 'staff'`,
                    [managerId, storeId]
                );

                const [managerDeleteResult] = await connection.execute(
                    `DELETE FROM users WHERE id = ? AND store_id = ? AND role = 'manager'`,
                    [managerId, storeId]
                );

                if (managerDeleteResult.affectedRows === 0) {
                    await connection.rollback();

                    return {
                        statusCode: 404,
                        headers,
                        body: JSON.stringify({
                            error: "Manager not found",
                        }),
                    };
                }

                await connection.commit();

                return {
                    statusCode: 200,
                    headers,
                    body: JSON.stringify({
                        message: "Manager account deleted successfully",
                        manager_deleted: managerDeleteResult.affectedRows,
                        staff_deleted: staffDeleteResult.affectedRows,
                    }),
                };
            } catch (deleteError) {
                await connection.rollback();
                throw deleteError;
            }
        }

        return {
            statusCode: 400,
            headers,
            body: JSON.stringify({ error: "Invalid action" }),
        };
    } catch (err) {
        console.error("[stocknbook-auth] Error:", {
            action,
            message: err?.message,
            code: err?.code,
            stack: err?.stack,
        });

        return {
            statusCode: Number(err?.statusCode) || 500,
            headers,
            body: JSON.stringify({
                error: err?.message || "Internal server error",
                code: err?.code || "UNKNOWN_ERROR",
            }),
        };
    } finally {
        if (connection) {
            connection.release();
        }
    }
};