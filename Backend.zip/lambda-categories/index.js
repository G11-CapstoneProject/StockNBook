/* eslint-disable @typescript-eslint/no-require-imports */
const mysql = require("mysql2/promise");
const jwt = require("jsonwebtoken");
const fs = require("fs");
const JWT_SECRET = "stocknbook-secret-key";

const dbConfig = {
    host: process.env.DB_HOST || "127.0.0.1",
    user: process.env.DB_USER || "root",
    password: process.env.DB_PASSWORD || "BTA5EYVWLfWcebF",
    database: process.env.DB_NAME || "stocknbook_v2",
    port: Number(process.env.DB_PORT || 3306),
    ssl: { rejectUnauthorized: false },
};

// Category reads happen on Inventory/POS startup. Pooling avoids repeating the
// TCP/TLS/database handshake for each module refresh as the app scales.
const dbPool = mysql.createPool({
    ...dbConfig,
    waitForConnections: true,
    connectionLimit: Number(process.env.DB_POOL_SIZE || 6),
    queueLimit: 0,
    enableKeepAlive: true,
    keepAliveInitialDelay: 0,
});

function badRequest(headers, message) {
    return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: message }),
    };
}

function unauthorized(headers, message) {
    return {
        statusCode: 401,
        headers,
        body: JSON.stringify({ error: message }),
    };
}

function serverError(headers, err) {
    const errorMessage =
        err?.sqlMessage ||
        err?.message ||
        "Internal server error";

    const errorCode =
        err?.code ||
        "UNKNOWN_ERROR";

    console.error("[lambda-categories] Detailed error:", {
        code: errorCode,
        message: errorMessage,
        errno: err?.errno,
        sqlState: err?.sqlState,
        sqlMessage: err?.sqlMessage,
        stack: err?.stack,
    });

    return {
        statusCode: 500,
        headers,
        body: JSON.stringify({
            error: errorMessage,
            code: errorCode,
        }),
    };
}

function toSafeString(value, max = 255) {
    return String(value ?? "").trim().slice(0, max);
}

function buildCategoryReference(id) {
    return `CAT-${String(id).padStart(6, "0")}`;
}

/*
 * The JWT issued at login only carries ids (store_id / manager_id /
 * staff_id) and an email — never a display name. To log a real,
 * human-readable employee_actions row we look the acting user's name up
 * from their own table using the id that's already in the token.
 */
async function getActingEmployee(connection, decoded, tokenRole, storeId) {
    const role = String(tokenRole || "").toLowerCase();

    if (role === "manager" && decoded?.manager_id) {
        const [rows] = await connection.execute(
            `SELECT full_name AS manager_name FROM users WHERE id = ? AND store_id = ? AND role = 'manager' LIMIT 1`,
            [Number(decoded.manager_id), storeId]
        );

        return {
            id: Number(decoded.manager_id),
            name: toSafeString(rows[0]?.manager_name, 255) || "Manager",
            role: "Manager",
        };
    }

    if (role === "staff" && decoded?.staff_id) {
        const [rows] = await connection.execute(
            `SELECT full_name AS staff_name FROM users WHERE id = ? AND store_id = ? AND role = 'staff' LIMIT 1`,
            [Number(decoded.staff_id), storeId]
        );

        return {
            id: Number(decoded.staff_id),
            name: toSafeString(rows[0]?.staff_name, 255) || "Staff",
            role: "Staff",
        };
    }

    if (role === "owner") {
        const [rows] = await connection.execute(
            `SELECT id AS owner_user_id, full_name AS owner_name FROM users WHERE store_id = ? AND role = 'owner' ORDER BY id ASC LIMIT 1`,
            [storeId]
        );

        return {
            id: rows[0]?.owner_user_id ? Number(rows[0].owner_user_id) : null,
            name: toSafeString(rows[0]?.owner_name, 255) || "Owner",
            role: "Owner",
        };
    }

    return { id: null, name: "Unknown", role: "Staff" };
}

/*
 * Writes one row to employee_actions. Called from inside the same DB
 * transaction as the category action it's logging, so the log and the
 * action succeed or fail together.
 */
async function logEmployeeAction(connection, entry) {
    // employee_actions.user_id references users.id (owners included).
    const userId = Number(entry?.employee?.id);
    if (!Number.isSafeInteger(userId) || userId <= 0) return;
    const entityId = Number(entry.referenceId);
    await connection.execute(
        `INSERT INTO employee_actions
         (store_id, branch_id, user_id, user_name, user_role,
          module, reference_number, action, entity_id, details)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
            entry.storeId,
            entry.branchId ?? null,
            userId,
            String(entry.employee.name || "Unknown").slice(0, 150),
            entry.employee.role,
            entry.module,
            entry.referenceNumber ?? null,
            entry.action,
            Number.isSafeInteger(entityId) && entityId > 0 ? entityId : null,
            entry.details === undefined || entry.details === null
                ? null
                : JSON.stringify(entry.details),
        ]
    );
}

const DEFAULT_CATEGORIES = [
    "Balloons",
    "Backdrops",
    "Tables & Chairs",
    "Linens & Covers",
    "Decorations",
    "Party Favors",
    "Catering / Food",
    "Cake & Desserts",
    "Lights & Sounds",
    "Costumes & Props",
    "Candles & Accessories",
    "Miscellaneous",
];

async function ensureDefaultCategories(connection, storeId) {
    const parsedStoreId = Number(storeId);

    if (!Number.isInteger(parsedStoreId) || parsedStoreId <= 0) {
        return;
    }

    // The old implementation issued one SELECT per default category on every
    // Inventory/POS load. Read the existing names once, then insert only the
    // genuinely missing defaults in a single multi-row statement.
    const [rows] = await connection.execute(
        `SELECT category_name
         FROM categories
         WHERE store_id = ?
           AND category_type = 'product'`,
        [parsedStoreId]
    );

    const existingNames = new Set(
        rows.map((row) => String(row.category_name || "").trim().toLowerCase())
    );

    const missing = DEFAULT_CATEGORIES.filter(
        (categoryName) => !existingNames.has(categoryName.toLowerCase())
    );

    if (missing.length === 0) return;

    const placeholders = missing.map(() => "(?, ?, ?, 'product')").join(", ");
    const params = missing.flatMap((categoryName) => [
        parsedStoreId,
        categoryName,
        "active",
    ]);

    await connection.execute(
        `INSERT INTO categories (store_id, category_name, status, category_type)
         VALUES ${placeholders}`,
        params
    );
}

async function ensureStoreExists(connection, storeId) {
    const parsedStoreId = Number(storeId);

    if (!Number.isInteger(parsedStoreId) || parsedStoreId <= 0) {
        return false;
    }

    const [rows] = await connection.execute(
        `SELECT id
         FROM stores
         WHERE id = ?
             LIMIT 1`,
        [parsedStoreId]
    );

    return rows.length > 0;
}

// Category changes are product-catalog administration, not staff restocking.
async function canManageCategories(connection, decoded, role, storeId) {
    if (role === "owner") return true;
    if (role !== "manager") return false;

    const managerId = Number(decoded?.manager_id);
    const branchId = Number(decoded?.branch_id);
    if (!Number.isInteger(managerId) || managerId <= 0 ||
        !Number.isInteger(branchId) || branchId <= 0) return false;

    const [rows] = await connection.execute(
        `SELECT permissions FROM users
         WHERE id = ? AND store_id = ? AND branch_id = ? AND role = 'manager' AND status = 'active'
             LIMIT 1`,
        [managerId, storeId, branchId]
    );
    if (!rows.length) return false;
    let permissions = rows[0].permissions || {};
    if (typeof permissions === "string") {
        try { permissions = JSON.parse(permissions); } catch { permissions = {}; }
    }
    if (!permissions || typeof permissions !== "object" || Array.isArray(permissions)) {
        permissions = {};
    }
    const access = permissions.inventory;
    return access === undefined || access === true ||
        access === "full" || access === "true";
}

exports.handler = async (event) => {
    const headers = {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type, Authorization",
        "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
        "Content-Type": "application/json",
    };

    const method =
        event?.requestContext?.http?.method ||
        event?.httpMethod;

    if (method === "OPTIONS") {
        return {
            statusCode: 204,
            headers,
            body: "",
        };
    }

    let body = {};

    try {
        body = JSON.parse(event?.body || "{}");
    } catch {
        return badRequest(headers, "Invalid JSON body");
    }

    const action = body.action;
    let connection;

    try {
        connection = await dbPool.getConnection();

        console.log("[lambda-categories] action:", action);

        // ── PUBLIC: get_public_categories ────────────────────────────────
        if (action === "get_public_categories") {
            const storeId = Number(body.storeId);

            if (!Number.isInteger(storeId) || storeId <= 0) {
                return badRequest(
                    headers,
                    "Missing or invalid storeId"
                );
            }

            await ensureDefaultCategories(connection, storeId);

            const [rows] = await connection.execute(
                `SELECT
                     id,
                     store_id AS storeId,
                     category_name AS categoryName,
                     status,
                     created_at AS createdAt,
                     updated_at AS updatedAt
                 FROM categories
                 WHERE store_id = ?
                   AND category_type = 'product'
                 ORDER BY created_at DESC`,
                [storeId]
            );

            return {
                statusCode: 200,
                headers,
                body: JSON.stringify({
                    categories: rows,
                }),
            };
        }

        // ── PROTECTED: verify token ──────────────────────────────────────
        const authHeader =
            event?.headers?.authorization ||
            event?.headers?.Authorization ||
            "";

        if (!authHeader) {
            return unauthorized(headers, "No token provided");
        }

        let decoded;
        let storeId;
        let tokenRole;
        let branchId;

        try {
            const token = authHeader.replace("Bearer ", "");
            decoded = jwt.verify(token, JWT_SECRET);

            storeId = Number(decoded.store_id);
            tokenRole = String(decoded.role || "").toLowerCase();
            branchId = decoded.branch_id ? Number(decoded.branch_id) : null;
        } catch {
            return unauthorized(headers, "Invalid token");
        }

        if (!Number.isInteger(storeId) || storeId <= 0) {
            return unauthorized(
                headers,
                "Invalid store in token"
            );
        }

        const storeExists = await ensureStoreExists(
            connection,
            storeId
        );

        if (!storeExists) {
            return badRequest(
                headers,
                "Store account not found"
            );
        }

        // The inventory module's view permission does not authorize catalog edits.
        if (["create_category", "update_category", "delete_category"].includes(action)) {
            if (!(await canManageCategories(connection, decoded, tokenRole, storeId))) {
                return {
                    statusCode: 403,
                    headers,
                    body: JSON.stringify({ error: "Only owners and authorized managers can manage categories." }),
                };
            }
        }

        // ── PROTECTED: create_category ───────────────────────────────────
        if (action === "create_category") {
            const safeName = toSafeString(
                body.categoryName,
                120
            );

            if (!safeName) {
                return badRequest(
                    headers,
                    "categoryName is required"
                );
            }

            const [existing] = await connection.execute(
                `SELECT id
                 FROM categories
                 WHERE store_id = ?
                   AND category_type = 'product'
                   AND LOWER(category_name) = LOWER(?)
                     LIMIT 1`,
                [storeId, safeName]
            );

            if (existing.length > 0) {
                return badRequest(
                    headers,
                    "Category already exists for this store"
                );
            }

            await connection.beginTransaction();

            const [result] = await connection.execute(
                `INSERT INTO categories (
                    store_id,
                    category_name,
                    status,
                    category_type
                )
                 VALUES (?, ?, ?, 'product')`,
                [storeId, safeName, "active"]
            );

            const [rows] = await connection.execute(
                `SELECT
                     id,
                     store_id AS storeId,
                     category_name AS categoryName,
                     status,
                     created_at AS createdAt,
                     updated_at AS updatedAt
                 FROM categories
                 WHERE id = ?
                     LIMIT 1`,
                [result.insertId]
            );

            const actingEmployee = await getActingEmployee(
                connection,
                decoded,
                tokenRole,
                storeId
            );

            await logEmployeeAction(connection, {
                storeId,
                branchId,
                employee: actingEmployee,
                module: "Inventory",
                referenceNumber: buildCategoryReference(result.insertId),
                action: "Added category",
                referenceId: String(result.insertId),
                details: `Added ${safeName} to categories`,
            });

            await connection.commit();

            return {
                statusCode: 201,
                headers,
                body: JSON.stringify({
                    success: true,
                    category:
                        rows[0] || {
                            id: result.insertId,
                        },
                }),
            };
        }

        // ── PROTECTED: get_categories ────────────────────────────────────
        if (action === "get_categories") {
            await ensureDefaultCategories(connection, storeId);

            const [rows] = await connection.execute(
                `SELECT
                     id,
                     store_id AS storeId,
                     category_name AS categoryName,
                     status,
                     created_at AS createdAt,
                     updated_at AS updatedAt
                 FROM categories
                 WHERE store_id = ?
                   AND category_type = 'product'
                 ORDER BY created_at DESC`,
                [storeId]
            );

            return {
                statusCode: 200,
                headers,
                body: JSON.stringify({
                    categories: rows,
                }),
            };
        }

        // ── PROTECTED: update_category ───────────────────────────────────
        if (action === "update_category") {
            const categoryId = Number(body.category_id);
            const safeName = toSafeString(
                body.categoryName,
                120
            );

            if (
                !Number.isInteger(categoryId) ||
                categoryId <= 0
            ) {
                return badRequest(
                    headers,
                    "Missing or invalid category_id"
                );
            }

            if (!safeName) {
                return badRequest(
                    headers,
                    "categoryName is required"
                );
            }

            const [duplicate] = await connection.execute(
                `SELECT id
                 FROM categories
                 WHERE store_id = ?
                   AND category_type = 'product'
                   AND LOWER(category_name) = LOWER(?)
                   AND id <> ?
                     LIMIT 1`,
                [storeId, safeName, categoryId]
            );

            if (duplicate.length > 0) {
                return badRequest(
                    headers,
                    "Category already exists for this store"
                );
            }

            const [beforeRows] = await connection.execute(
                `SELECT category_name FROM categories WHERE id = ? AND store_id = ? AND category_type = 'product' LIMIT 1`,
                [categoryId, storeId]
            );

            const previousName = beforeRows[0]?.category_name || null;

            await connection.beginTransaction();

            const [result] = await connection.execute(
                `UPDATE categories
                 SET
                     category_name = ?,
                     updated_at = CURRENT_TIMESTAMP
                 WHERE id = ?
                   AND store_id = ?
                   AND category_type = 'product'`,
                [safeName, categoryId, storeId]
            );

            if (result.affectedRows === 0) {
                await connection.rollback();
                return {
                    statusCode: 404,
                    headers,
                    body: JSON.stringify({
                        error: "Category not found",
                    }),
                };
            }

            const actingEmployee = await getActingEmployee(
                connection,
                decoded,
                tokenRole,
                storeId
            );

            await logEmployeeAction(connection, {
                storeId,
                branchId,
                employee: actingEmployee,
                module: "Inventory",
                referenceNumber: buildCategoryReference(categoryId),
                action: "Updated category",
                referenceId: String(categoryId),
                details: previousName && previousName !== safeName
                    ? `Renamed ${previousName} to ${safeName}`
                    : `Updated ${safeName}`,
            });

            await connection.commit();

            return {
                statusCode: 200,
                headers,
                body: JSON.stringify({
                    success: true,
                }),
            };
        }

        // ── PROTECTED: delete_category ───────────────────────────────────
        if (action === "delete_category") {
            const categoryId = Number(body.category_id);

            if (
                !Number.isInteger(categoryId) ||
                categoryId <= 0
            ) {
                return badRequest(
                    headers,
                    "Missing or invalid category_id"
                );
            }

            const [existingRows] = await connection.execute(
                `SELECT category_name FROM categories WHERE id = ? AND store_id = ? AND category_type = 'product' LIMIT 1`,
                [categoryId, storeId]
            );

            if (existingRows.length === 0) {
                return {
                    statusCode: 404,
                    headers,
                    body: JSON.stringify({
                        error: "Category not found",
                    }),
                };
            }

            const categoryName = existingRows[0].category_name;

            await connection.beginTransaction();

            // Products keep existing; they simply lose the deleted category.
            await connection.execute(
                `UPDATE products SET category_id = NULL WHERE category_id = ? AND store_id = ?`,
                [categoryId, storeId]
            );

            const [result] = await connection.execute(
                `DELETE FROM categories
                 WHERE id = ?
                   AND store_id = ?
                   AND category_type = 'product'`,
                [categoryId, storeId]
            );

            if (result.affectedRows === 0) {
                await connection.rollback();
                return {
                    statusCode: 404,
                    headers,
                    body: JSON.stringify({
                        error: "Category not found",
                    }),
                };
            }

            const actingEmployee = await getActingEmployee(
                connection,
                decoded,
                tokenRole,
                storeId
            );

            await logEmployeeAction(connection, {
                storeId,
                branchId,
                employee: actingEmployee,
                module: "Inventory",
                referenceNumber: buildCategoryReference(categoryId),
                action: "Deleted category",
                referenceId: String(categoryId),
                details: `Removed ${categoryName} from categories`,
            });

            await connection.commit();

            return {
                statusCode: 200,
                headers,
                body: JSON.stringify({
                    success: true,
                }),
            };
        }

        return badRequest(headers, "Invalid action");
    } catch (err) {
        if (connection) {
            try {
                await connection.rollback();
            } catch {
                // ignore rollback errors, original error is what matters
            }
        }
        return serverError(headers, err);
    } finally {
        if (connection) {
            connection.release();
        }
    }
};