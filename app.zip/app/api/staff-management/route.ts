import { NextRequest, NextResponse } from "next/server";
import { handler } from "../../../lambda-auth/index.js";

export const runtime = "nodejs";

export async function POST(req: NextRequest) {
    try {
        const body = await req.json();

        const event = {
            headers: {
                "Content-Type": "application/json",
                Authorization: req.headers.get("authorization") || "",
            },
            body: JSON.stringify(body),
            requestContext: {
                http: {
                    method: "POST",
                },
            },
        };

        const response = await handler(event);

        let data: unknown = {};

        try {
            data = response.body ? JSON.parse(response.body) : {};
        } catch {
            data = {
                error:
                    response.body ||
                    "Invalid response from staff management server",
            };
        }

        return NextResponse.json(data, {
            status: response.statusCode || 200,
        });
    } catch (error) {
        console.error("Local staff management route error:", error);
        return NextResponse.json(
            { error: "Staff management server error" },
            { status: 500 }
        );
    }
}
