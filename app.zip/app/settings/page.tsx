"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import RoleSidebar from "@/components/sidebar/RoleSidebar";
import { ModuleSkeleton } from "@/components/loading/ModuleSkeletons";
import RequirePermission from "@/components/permissions/RequirePermission";
import { QRCodeCanvas } from "qrcode.react";
import { usePOS } from "@/hooks/usePOS";
import {
    Check,
    Copy,
    Download,
    ExternalLink,
    Link2,
    QrCode,
    RefreshCw,
    Save,
    Store,
    ReceiptText,
    AlertTriangle,
    X,
} from "lucide-react";

function makeSlug(value: string) {
    return value
        .toLowerCase()
        .trim()
        .replace(/[^a-z0-9\s-]/g, "")
        .replace(/\s+/g, "-")
        .replace(/-+/g, "-");
}

function formatCurrentDateTime(value: Date) {
    const dateLabel = value.toLocaleDateString("en-US", {
        month: "long",
        day: "numeric",
        year: "numeric",
    });

    const timeLabel = value
        .toLocaleTimeString("en-US", {
            hour: "numeric",
            minute: "2-digit",
            hour12: true,
        })
        .toLowerCase();

    return `${dateLabel} | ${timeLabel}`;
}

export default function SettingsPage() {
    const [mounted, setMounted] = useState(false);
    const [storeName, setStoreName] = useState("Store Name");
    const [storeSlug, setStoreSlug] = useState("");
    const [role, setRole] = useState("");
    const [branchId, setBranchId] = useState("");
    const [branchName, setBranchName] = useState("");
    const [copied, setCopied] = useState(false);
    const [saved, setSaved] = useState(false);
    const [isSaving, setIsSaving] = useState(false);
    const [isRefreshing, setIsRefreshing] = useState(false);
    const [currentDateTime, setCurrentDateTime] = useState<Date | null>(null);

    const qrContainerRef = useRef<HTMLDivElement>(null);

    const isOwner = role === "owner";

    const loadSettings = useCallback(async () => {
        let savedStoreName =
            sessionStorage.getItem("store_name") ||
            sessionStorage.getItem("stocknbook_store_name") ||
            "Store Name";

        let savedSlug =
            sessionStorage.getItem("store_slug") ||
            sessionStorage.getItem("slug");

        const savedRole = (sessionStorage.getItem("role") || "").toLowerCase();
        const token = sessionStorage.getItem("token");
        if (token) {
            try {
                const response = await fetch("/api/current-user?refresh=1", {
                    headers: { Authorization: `Bearer ${token}` },
                    cache: "no-store",
                });
                if (response.ok) {
                    const data = await response.json() as { store_name?: string; store_slug?: string };
                    if (data.store_name) {
                        savedStoreName = data.store_name;
                        sessionStorage.setItem("store_name", savedStoreName);
                        sessionStorage.setItem("stocknbook_store_name", savedStoreName);
                        sessionStorage.setItem("business_name", savedStoreName);
                    }
                    if (data.store_slug) {
                        savedSlug = data.store_slug;
                        sessionStorage.setItem("store_slug", savedSlug);
                        sessionStorage.setItem("slug", savedSlug);
                    }
                }
            } catch (error) {
                console.warn("Unable to refresh business settings from the server:", error);
            }
        }

        const savedBranchId =
            sessionStorage.getItem("branch_id") ||
            sessionStorage.getItem("stocknbook_branch_id") ||
            "";

        const savedBranchName =
            sessionStorage.getItem("branch_name") ||
            sessionStorage.getItem("stocknbook_branch_name") ||
            "";

        const generatedSlug = savedSlug || makeSlug(savedStoreName);

        if (generatedSlug && !savedSlug) {
            sessionStorage.setItem("store_slug", generatedSlug);
        }

        setStoreName(savedStoreName);
        setStoreSlug(generatedSlug);
        setRole(savedRole);
        setBranchId(savedBranchId);
        setBranchName(savedBranchName);
        setMounted(true);
    }, []);

    useEffect(() => {
        const frame = window.requestAnimationFrame(loadSettings);

        return () => window.cancelAnimationFrame(frame);
    }, [loadSettings]);

    useEffect(() => {
        const updateDateTime = () => setCurrentDateTime(new Date());

        updateDateTime();
        const timer = window.setInterval(updateDateTime, 30_000);

        return () => window.clearInterval(timer);
    }, []);

    const branchSlug = useMemo(() => {
        return branchName ? makeSlug(branchName) : "";
    }, [branchName]);

    const bookingLink = useMemo(() => {
        if (!storeSlug || !mounted) return "";

        if ((role === "manager" || role === "staff") && branchId) {
            return `${window.location.origin}/book/${storeSlug}?branchId=${branchId}`;
        }

        if (role === "owner") {
            return `${window.location.origin}/book/${storeSlug}`;
        }

        return "";
    }, [branchId, mounted, role, storeSlug]);

    const handleRefresh = () => {
        setIsRefreshing(true);
        loadSettings();

        window.setTimeout(() => {
            setIsRefreshing(false);
        }, 250);
    };

    const handleSave = async () => {
        if (!isOwner || isSaving) return;
        const cleanedName = storeName.trim().replace(/\s+/g, " ");
        const cleanedSlug = makeSlug(storeSlug || cleanedName);

        if (!cleanedName || !cleanedSlug) {
            alert("Please enter a business name and store slug.");
            return;
        }
        const token = sessionStorage.getItem("token");
        if (!token) {
            alert("Please log in again to save business settings.");
            return;
        }
        setIsSaving(true);
        setSaved(false);
        try {
            const response = await fetch("/api/auth", {
                method: "POST",
                headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
                body: JSON.stringify({
                    action: "update_store_profile",
                    store_name: cleanedName,
                    store_slug: cleanedSlug,
                }),
            });
            const data = await response.json() as { success?: boolean; error?: string; store_name?: string; store_slug?: string };
            if (!response.ok || !data.success || !data.store_name || !data.store_slug) {
                throw new Error(data.error || "Business details could not be saved.");
            }
            // Update this session only AFTER the database confirms its update.
            sessionStorage.setItem("store_name", data.store_name);
            sessionStorage.setItem("stocknbook_store_name", data.store_name);
            sessionStorage.setItem("business_name", data.store_name);
            sessionStorage.setItem("store_slug", data.store_slug);
            sessionStorage.setItem("slug", data.store_slug);
            setStoreName(data.store_name);
            setStoreSlug(data.store_slug);
            setSaved(true);
            window.dispatchEvent(new Event("stocknbook-business-updated"));
            window.setTimeout(() => setSaved(false), 2000);
        } catch (error) {
            alert(error instanceof Error ? error.message : "Failed to save business details.");
        } finally {
            setIsSaving(false);
        }
    };

    const handleCopy = async () => {
        if (!bookingLink) return;

        try {
            await navigator.clipboard.writeText(bookingLink);
            setCopied(true);

            window.setTimeout(() => setCopied(false), 2000);
        } catch (error) {
            console.error("Copy failed:", error);
            alert("Failed to copy the booking link.");
        }
    };

    const downloadQR = () => {
        const canvas =
            qrContainerRef.current?.querySelector<HTMLCanvasElement>("canvas");

        if (!canvas) return;

        const link = document.createElement("a");
        link.href = canvas.toDataURL("image/png");
        link.download = `${branchSlug || storeSlug || "booking"}-qr.png`;
        link.click();
    };

    const handlePreview = () => {
        if (!bookingLink) return;

        window.open(bookingLink, "_blank", "noopener,noreferrer");
    };

    if (!mounted) {
        return (
            <div className="flex min-h-screen bg-[#FDFAF4] font-sans text-[#1A1220]">
                <RoleSidebar />
                <main className="min-w-0 flex-1 overflow-y-auto px-6 py-4">
                    <ModuleSkeleton variant="settings" />
                </main>
            </div>
        );
    }

    return (
        <RequirePermission>
            <div
                className="flex min-h-screen font-sans text-[#1A1220]"
                style={{ backgroundColor: "#FDFAF4" }}
            >
                <RoleSidebar />

                <main className="min-w-0 flex-1 overflow-y-auto">
                    <header className="sticky top-0 z-20 border-b border-[#E9E0EF] bg-[#FFFDF8]/95 backdrop-blur">
                        <div className="flex min-h-[72px] flex-wrap items-center justify-between gap-4 px-6 py-3">
                            <h1 className="text-[25px] font-bold text-[#1A1220]">
                                Settings
                            </h1>

                            <div className="flex items-center gap-2.5">
                                <span className="inline-flex h-[42px] items-center rounded-xl border border-[#E6DDF0] bg-white px-3.5 text-sm font-semibold text-[#2B174C] shadow-sm">
                                    {currentDateTime
                                        ? formatCurrentDateTime(currentDateTime)
                                        : "Loading date..."}
                                </span>

                                <button
                                    type="button"
                                    onClick={handleRefresh}
                                    disabled={isRefreshing}
                                    aria-label="Refresh settings"
                                    title="Refresh settings"
                                    className="inline-flex h-[42px] items-center gap-2 rounded-xl bg-[#2B174C] px-4 text-sm font-semibold text-white shadow-sm transition hover:bg-[#1B0D31] disabled:cursor-not-allowed disabled:opacity-60"
                                >
                                    <RefreshCw
                                        size={16}
                                        className={
                                            isRefreshing ? "animate-spin" : ""
                                        }
                                    />
                                    Refresh
                                </button>
                            </div>
                        </div>
                    </header>

                    <section className="space-y-4 px-6 py-4">
                        {isOwner ? (
                            <OwnerSettings
                                storeName={storeName}
                                storeSlug={storeSlug}
                                setStoreName={setStoreName}
                                setStoreSlug={setStoreSlug}
                                isSaving={isSaving}
                                saved={saved}
                                onSave={handleSave}
                                bookingLink={bookingLink}
                                copied={copied}
                                qrContainerRef={qrContainerRef}
                                onCopy={() => void handleCopy()}
                                onPreview={handlePreview}
                                onDownloadQR={downloadQR}
                            />
                        ) : (
                            <BranchSettings
                                storeName={storeName}
                                storeSlug={storeSlug}
                                branchName={branchName}
                                branchSlug={branchSlug}
                                bookingLink={bookingLink}
                                copied={copied}
                                qrContainerRef={qrContainerRef}
                                onCopy={() => void handleCopy()}
                                onPreview={handlePreview}
                                onDownloadQR={downloadQR}
                            />
                        )}
                    </section>
                </main>
            </div>
        </RequirePermission>
    );
}

function OwnerSettings({
                           storeName,
                           storeSlug,
                           setStoreName,
                           setStoreSlug,
                           isSaving,
                           saved,
                           onSave,
                           bookingLink,
                           copied,
                           qrContainerRef,
                           onCopy,
                           onPreview,
                           onDownloadQR,
                       }: {
    storeName: string;
    storeSlug: string;
    setStoreName: (value: string) => void;
    setStoreSlug: (value: string) => void;
    isSaving: boolean;
    saved: boolean;
    onSave: () => void;
    bookingLink: string;
    copied: boolean;
    qrContainerRef: React.RefObject<HTMLDivElement | null>;
    onCopy: () => void;
    onPreview: () => void;
    onDownloadQR: () => void;
}) {
    return (
        <div className="grid items-start gap-4 xl:grid-cols-[minmax(0,1.15fr)_minmax(320px,0.85fr)]">
            <div className="space-y-4">
                <section className="rounded-[14px] border border-[#E6DDF0] bg-white p-5 shadow-sm">
                    <SettingsCardHeading
                        icon={<Store size={18} />}
                        title="Business Information"
                        detail="Update the business details used across your booking page and operations."
                    />

                    <div className="mt-5 space-y-4">
                        <FieldLabel label="Business Name">
                            <input
                                type="text"
                                value={storeName}
                                onChange={(event) =>
                                    setStoreName(event.target.value)
                                }
                                placeholder="Enter your business name"
                                className="h-[42px] w-full rounded-xl border border-[#E6DDF0] bg-[#FFFDF8] px-3 text-sm text-[#1A1220] outline-none placeholder:text-[#9B8AAA] transition focus:border-[#2B174C] focus:ring-4 focus:ring-[#2B174C]/10"
                            />
                        </FieldLabel>

                        <FieldLabel
                            label="Store Slug"
                            detail="Used in your public booking page URL."
                        >
                            <input
                                type="text"
                                value={storeSlug}
                                onChange={(event) =>
                                    setStoreSlug(event.target.value)
                                }
                                placeholder="store-slug"
                                className="h-[42px] w-full rounded-xl border border-[#E6DDF0] bg-[#FFFDF8] px-3 text-sm text-[#1A1220] outline-none placeholder:text-[#9B8AAA] transition focus:border-[#2B174C] focus:ring-4 focus:ring-[#2B174C]/10"
                            />
                        </FieldLabel>

                        <button
                            type="button"
                            onClick={onSave}
                            disabled={isSaving}
                            className="inline-flex h-[42px] w-full items-center justify-center gap-2 rounded-xl bg-[#2B174C] px-4 text-sm font-semibold text-white shadow-sm transition hover:bg-[#1B0D31] disabled:cursor-not-allowed disabled:opacity-60"
                        >
                            {saved ? <Check size={16} /> : <Save size={16} />}
                            {isSaving
                                ? "Saving..."
                                : saved
                                    ? "Saved"
                                    : "Save Changes"}
                        </button>

                        <p className="text-center text-xs text-[#7A6A84]">
                            Changes are saved to the store database for all branches and modules.
                        </p>
                    </div>
                </section>

                <BusinessTaxSettings />


            </div>
            <div className="space-y-4">

                <section className="rounded-[14px] border border-[#E6DDF0] bg-white p-5 shadow-sm">
                    <SettingsCardHeading
                        icon={<QrCode size={18} />}
                        title="Store QR Code"
                        detail="Customers can scan this code to open your store's booking page."
                    />

                    <div
                        ref={qrContainerRef}
                        className="mt-5 flex min-h-[228px] items-center justify-center rounded-xl border border-dashed border-[#D8CBE7] bg-[#FFFDF8] p-5"
                    >
                        {bookingLink ? (
                            <QRCodeCanvas value={bookingLink} size={148} />
                        ) : (
                            <p className="text-sm text-[#9B8AAA]">
                                No booking link available.
                            </p>
                        )}
                    </div>

                    <button
                        type="button"
                        onClick={onDownloadQR}
                        disabled={!bookingLink}
                        className="mt-4 inline-flex h-[42px] w-full items-center justify-center gap-2 rounded-xl border border-[#E6DDF0] bg-white px-4 text-sm font-semibold text-[#2B174C] transition hover:bg-[#F7F1FF] disabled:cursor-not-allowed disabled:opacity-50"
                    >
                        <Download size={16} />
                        Download QR
                    </button>
                </section>

                <section className="rounded-[14px] border border-[#E6DDF0] bg-white p-5 shadow-sm">
                    <SettingsCardHeading
                        icon={<Link2 size={18} />}
                        title="Store Booking Link"
                        detail="Share this link so customers can book with any of your branches."
                    />

                    <div className="mt-5 rounded-xl border border-[#E6DDF0] bg-[#FFFDF8] p-3">
                        <p className="break-all font-mono text-xs leading-5 text-[#4E2C66]">
                            {bookingLink ||
                                "No store booking link available yet."}
                        </p>
                    </div>

                    <div className="mt-4 grid grid-cols-2 gap-3">
                        <button
                            type="button"
                            onClick={onCopy}
                            disabled={!bookingLink}
                            className="inline-flex h-[42px] items-center justify-center gap-2 rounded-xl bg-[#2B174C] px-4 text-sm font-semibold text-white shadow-sm transition hover:bg-[#1B0D31] disabled:cursor-not-allowed disabled:opacity-50"
                        >
                            {copied ? <Check size={16} /> : <Copy size={16} />}
                            {copied ? "Copied" : "Copy Link"}
                        </button>

                        <button
                            type="button"
                            onClick={onPreview}
                            disabled={!bookingLink}
                            className="inline-flex h-[42px] items-center justify-center gap-2 rounded-xl border border-[#E6DDF0] bg-white px-4 text-sm font-semibold text-[#2B174C] transition hover:bg-[#F7F1FF] disabled:cursor-not-allowed disabled:opacity-50"
                        >
                            <ExternalLink size={16} />
                            Preview
                        </button>
                    </div>
                </section>
            </div>
        </div>
    );
}

/** Tax registration belongs to the store, and is saved by the existing POS API. */
type TaxRegistration = "NON_VAT" | "VAT_REGISTERED";

function BusinessTaxSettings() {
    // Uses the SAME backend and permissions as the POS checkout.
    const pos = usePOS();
    const [pendingRegistration, setPendingRegistration] = useState<TaxRegistration | null>(null);
    const [savedRegistration, setSavedRegistration] = useState<TaxRegistration | null>(null);
    const [saving, setSaving] = useState(false);
    const [message, setMessage] = useState("");
    const [dialogError, setDialogError] = useState("");
    const cancelButtonRef = useRef<HTMLButtonElement>(null);
    const dialogRef = useRef<HTMLDivElement>(null);

    // Never make a tax decision from sessionStorage; the POS hook reads the store setting.
    const reportedRegistration = pos.ownerRevenue?.taxRegistration;
    const databaseRegistration: TaxRegistration | null = reportedRegistration === "NON_VAT"
        ? "NON_VAT" : reportedRegistration === "VAT_REGISTERED" ? "VAT_REGISTERED" : null;
    const currentRegistration = savedRegistration ?? databaseRegistration;

    // Clear the temporary display value once the POS hook reflects the persisted value.
    useEffect(() => {
        if (savedRegistration && savedRegistration === databaseRegistration) {
            setSavedRegistration(null);
        }
    }, [databaseRegistration, savedRegistration]);

    useEffect(() => {
        if (!pendingRegistration) return;
        const previousFocus = document.activeElement as HTMLElement | null;
        const previousOverflow = document.body.style.overflow;
        document.body.style.overflow = "hidden";
        cancelButtonRef.current?.focus();
        return () => {
            document.body.style.overflow = previousOverflow;
            previousFocus?.focus();
        };
    }, [pendingRegistration]);

    const requestTaxChange = (next: TaxRegistration) => {
        if (saving || next === currentRegistration) return;
        setDialogError("");
        setMessage("");
        setPendingRegistration(next);
    };

    const closeDialog = () => {
        if (saving) return;
        setPendingRegistration(null);
        setDialogError("");
    };

    const confirmTaxChange = async () => {
        if (!pendingRegistration || saving) return;
        const next = pendingRegistration;
        setSaving(true);
        setDialogError("");
        setMessage("");

        try {
            // The Lambda verifies that the signed-in account is the owner and
            // persists stores.tax_registration for all its branches.
            const result: unknown = await pos.updateTaxRegistration(next);
            if (result === false) {
                throw new Error("The tax setting could not be saved. Please try again.");
            }

            // Only switch the radio after the backend call has completed successfully.
            setSavedRegistration(next);
            setPendingRegistration(null);
            const label = next === "NON_VAT" ? "Non-VAT Registered" : "VAT Registered (12%)";
            setMessage(`Tax setting saved: ${label}. Only future POS transactions are affected.`);
            window.dispatchEvent(new Event("stocknbook-business-updated"));

            // Refresh the hook's store-wide tax snapshot. The save is already
            // confirmed at this point; a refresh failure must not imply rollback.
            try {
                await pos.refreshAll();
            } catch (refreshError) {
                console.warn("Saved tax registration; POS refresh was unsuccessful:", refreshError);
            }
        } catch (error) {
            setDialogError(
                error instanceof Error ? error.message : "Unable to save the tax setting. Please try again."
            );
        } finally {
            setSaving(false);
        }
    };

    const handleDialogKeyDown = (event: React.KeyboardEvent<HTMLDivElement>) => {
        if (event.key === "Escape") {
            event.preventDefault();
            closeDialog();
        }
        if (event.key !== "Tab") return;

        const buttons = dialogRef.current?.querySelectorAll<HTMLButtonElement>(
            'button:not([disabled])'
        );
        if (!buttons?.length) return;
        const first = buttons[0];
        const last = buttons[buttons.length - 1];
        if (event.shiftKey && document.activeElement === first) {
            event.preventDefault();
            last.focus();
        } else if (!event.shiftKey && document.activeElement === last) {
            event.preventDefault();
            first.focus();
        }
    };

    const pendingLabel = pendingRegistration === "NON_VAT"
        ? "Non-VAT Registered"
        : "VAT Registered (12%)";

    return (
        <>
            <section className="rounded-[14px] border border-[#E6DDF0] bg-white p-5 shadow-sm">
                <SettingsCardHeading
                    icon={<ReceiptText size={18} />}
                    title="Business Tax Settings"
                    detail="Configure tax registration for all branches. Only the Owner can change this setting."
                />
                <fieldset className="mt-5 space-y-4" disabled={saving || pendingRegistration !== null || currentRegistration === null}>
                    <legend className="sr-only">Business tax registration</legend>
                    <label className="flex cursor-pointer items-center gap-3 text-sm font-semibold text-[#1A1220]">
                        <input
                            type="radio"
                            name="taxRegistration"
                            value="NON_VAT"
                            className="h-4 w-4 accent-[#5F3CB0]"
                            checked={currentRegistration === "NON_VAT"}
                            onChange={() => requestTaxChange("NON_VAT")}
                        />
                        Non-VAT Registered
                    </label>
                    <label className="flex cursor-pointer items-center gap-3 text-sm font-semibold text-[#1A1220]">
                        <input
                            type="radio"
                            name="taxRegistration"
                            value="VAT_REGISTERED"
                            className="h-4 w-4 accent-[#5F3CB0]"
                            checked={currentRegistration === "VAT_REGISTERED"}
                            onChange={() => requestTaxChange("VAT_REGISTERED")}
                        />
                        VAT Registered (12%)
                    </label>
                </fieldset>
                {currentRegistration === null && (
                    <p role="status" className="mt-3 text-xs text-[#806A8C]">
                        {pos.loading ? "Loading saved tax registration..." : "Tax registration could not be verified. Refresh the page before changing it."}
                    </p>
                )}
                <p className="mt-4 text-xs leading-5 text-[#7A6A84]">
                    Listed POS product prices already include VAT when registered. Invoices separate
                    VATable sales and VAT instead of adding another 12% at checkout.
                </p>
                {message && (
                    <p role="status" className="mt-3 text-xs font-semibold text-[#237A44]">
                        {message}
                    </p>
                )}
            </section>

            {pendingRegistration && (
                <div
                    className="fixed inset-0 z-[150] flex items-center justify-center bg-[#180C2B]/55 p-4 backdrop-blur-[2px]"
                >
                    <div
                        ref={dialogRef}
                        role="dialog"
                        aria-modal="true"
                        aria-labelledby="tax-confirm-title"
                        aria-describedby="tax-confirm-description"
                        onKeyDown={handleDialogKeyDown}
                        className="w-full max-w-[470px] rounded-[20px] border border-[#E6DDF0] bg-white p-6 shadow-[0_20px_60px_rgba(30,12,50,0.25)]"
                    >
                        <div className="flex items-start justify-between gap-4">
                            <div className="flex items-center gap-3">
                                <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-[#F1E9FF] text-[#5B2FC6]">
                                    <AlertTriangle size={21} strokeWidth={1.8} />
                                </span>
                                <div>
                                    <h2 id="tax-confirm-title" className="text-lg font-bold text-[#1A1220]">
                                        Confirm Tax Registration
                                    </h2>
                                    <p className="mt-0.5 text-xs text-[#806A8C]">
                                        Owner Settings
                                    </p>
                                </div>
                            </div>
                            <button
                                type="button"
                                aria-label="Close confirmation dialog"
                                onClick={closeDialog}
                                disabled={saving}
                                className="rounded-lg p-1 text-[#806A8C] transition hover:bg-[#F7F1FF] hover:text-[#2B174C] disabled:opacity-50"
                            >
                                <X size={18} />
                            </button>
                        </div>

                        <p id="tax-confirm-description" className="mt-5 text-sm leading-6 text-[#5F4E75]">
                            Set this business to <strong className="text-[#1A1220]">{pendingLabel}</strong>?
                            The change will apply to <strong>future POS sales across all branches</strong>.
                            Existing invoices will keep their originally recorded tax information.
                        </p>

                        <div className="mt-4 rounded-xl border border-[#E6DDF0] bg-[#FBF9FE] px-4 py-3">
                            <p className="text-xs font-semibold text-[#2B174C]">
                                {pendingRegistration === "NON_VAT"
                                    ? "Future POS sales will show zero VAT."
                                    : "Future POS sales will show a 12% VAT-inclusive breakdown."}
                            </p>
                        </div>

                        {dialogError && (
                            <p role="alert" className="mt-4 text-xs font-medium text-[#B42318]">
                                {dialogError}
                            </p>
                        )}

                        <div className="mt-6 flex flex-col-reverse gap-3 sm:flex-row sm:justify-end">
                            <button
                                ref={cancelButtonRef}
                                type="button"
                                onClick={closeDialog}
                                disabled={saving}
                                className="inline-flex h-[42px] w-full items-center justify-center rounded-xl border border-[#D8CBE7] bg-white px-5 text-sm font-semibold text-[#2B174C] transition hover:bg-[#F7F1FF] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#5B2FC6] disabled:opacity-50 sm:w-auto"
                            >
                                Cancel
                            </button>
                            <button
                                type="button"
                                onClick={() => void confirmTaxChange()}
                                disabled={saving}
                                className="inline-flex h-[42px] w-full items-center justify-center gap-2 rounded-xl bg-[#2B174C] px-5 text-sm font-semibold text-white transition hover:bg-[#1B0D31] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#5B2FC6] disabled:cursor-not-allowed disabled:opacity-60 sm:w-auto"
                            >
                                {saving ? "Saving..." : "Confirm Change"}
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </>
    );
}

function BranchSettings({
                            storeName,
                            storeSlug,
                            branchName,
                            branchSlug,
                            bookingLink,
                            copied,
                            qrContainerRef,
                            onCopy,
                            onPreview,
                            onDownloadQR,
                        }: {
    storeName: string;
    storeSlug: string;
    branchName: string;
    branchSlug: string;
    bookingLink: string;
    copied: boolean;
    qrContainerRef: React.RefObject<HTMLDivElement | null>;
    onCopy: () => void;
    onPreview: () => void;
    onDownloadQR: () => void;
}) {
    return (
        <>
            <div className="grid gap-4 xl:grid-cols-[minmax(0,1.05fr)_minmax(360px,0.95fr)]">
                <section className="rounded-[14px] border border-[#E6DDF0] bg-white p-5 shadow-sm">
                    <SettingsCardHeading
                        icon={<Store size={18} />}
                        title="Business Information"
                        detail="Business details provided by the store owner."
                    />

                    <div className="mt-5 grid gap-4 sm:grid-cols-2">
                        <ReadOnlyField
                            label="Business Name"
                            value={storeName}
                        />
                        <ReadOnlyField label="Store Slug" value={storeSlug} />
                        <ReadOnlyField
                            label="Assigned Branch"
                            value={branchName || "Assigned Branch"}
                        />
                        <ReadOnlyField
                            label="Branch Slug"
                            value={branchSlug || "Not available"}
                        />
                    </div>
                </section>

                <section className="rounded-[14px] border border-[#E6DDF0] bg-white p-5 shadow-sm">
                    <SettingsCardHeading
                        icon={<Link2 size={18} />}
                        title="Branch Booking Link"
                        detail="Share this link so bookings are sent directly to your branch."
                    />

                    <div className="mt-5 rounded-xl border border-[#E6DDF0] bg-[#FFFDF8] p-3">
                        <p className="break-all font-mono text-xs leading-5 text-[#4E2C66]">
                            {bookingLink ||
                                "No branch booking link available yet."}
                        </p>
                    </div>

                    {branchName && (
                        <p className="mt-3 text-xs text-[#7A6A84]">
                            Booking destination:{" "}
                            <span className="font-semibold text-[#1A1220]">
                                {branchName}
                            </span>
                        </p>
                    )}

                    <div className="mt-4 grid grid-cols-2 gap-3">
                        <button
                            type="button"
                            onClick={onCopy}
                            disabled={!bookingLink}
                            className="inline-flex h-[42px] items-center justify-center gap-2 rounded-xl bg-[#2B174C] px-4 text-sm font-semibold text-white shadow-sm transition hover:bg-[#1B0D31] disabled:cursor-not-allowed disabled:opacity-50"
                        >
                            {copied ? <Check size={16} /> : <Copy size={16} />}
                            {copied ? "Copied" : "Copy Link"}
                        </button>

                        <button
                            type="button"
                            onClick={onPreview}
                            disabled={!bookingLink}
                            className="inline-flex h-[42px] items-center justify-center gap-2 rounded-xl border border-[#E6DDF0] bg-white px-4 text-sm font-semibold text-[#2B174C] transition hover:bg-[#F7F1FF] disabled:cursor-not-allowed disabled:opacity-50"
                        >
                            <ExternalLink size={16} />
                            Preview
                        </button>
                    </div>
                </section>
            </div>

            <div className="grid gap-4 lg:grid-cols-[minmax(290px,0.75fr)_minmax(0,1.25fr)]">
                <section className="rounded-[14px] border border-[#E6DDF0] bg-white p-5 shadow-sm">
                    <SettingsCardHeading
                        icon={<QrCode size={18} />}
                        title="Branch QR Code"
                        detail="Customers can scan this code to open your branch booking page."
                    />

                    <div
                        ref={qrContainerRef}
                        className="mt-5 flex min-h-[228px] items-center justify-center rounded-xl border border-dashed border-[#D8CBE7] bg-[#FFFDF8] p-5"
                    >
                        {bookingLink ? (
                            <QRCodeCanvas value={bookingLink} size={148} />
                        ) : (
                            <p className="text-sm text-[#9B8AAA]">
                                No booking link available.
                            </p>
                        )}
                    </div>

                    <button
                        type="button"
                        onClick={onDownloadQR}
                        disabled={!bookingLink}
                        className="mt-4 inline-flex h-[42px] w-full items-center justify-center gap-2 rounded-xl border border-[#E6DDF0] bg-white px-4 text-sm font-semibold text-[#2B174C] transition hover:bg-[#F7F1FF] disabled:cursor-not-allowed disabled:opacity-50"
                    >
                        <Download size={16} />
                        Download QR
                    </button>
                </section>

                <section className="rounded-[14px] border border-[#E6DDF0] bg-white p-5 shadow-sm">
                    <h2 className="text-[16px] font-bold text-[#1A1220]">
                        Sharing Tips
                    </h2>
                    <p className="mt-1 text-xs text-[#7A6A84]">
                        Simple ways to make your branch booking page easier for
                        customers to find.
                    </p>

                    <div className="mt-5 grid gap-3 sm:grid-cols-2">
                        <TipCard
                            number="01"
                            title="Social Media"
                            detail="Add the booking link to your Facebook page bio or pin it in a post."
                        />
                        <TipCard
                            number="02"
                            title="Direct Messages"
                            detail="Send the link to customers who ask through chat or Messenger."
                        />
                        <TipCard
                            number="03"
                            title="QR Displays"
                            detail="Place the QR code in your store or on printed event materials."
                        />
                        <TipCard
                            number="04"
                            title="Preview First"
                            detail="Open the booking link before sharing to confirm the correct branch."
                        />
                    </div>
                </section>
            </div>
        </>
    );
}

function SettingsCardHeading({
                                 icon,
                                 title,
                                 detail,
                             }: {
    icon: React.ReactNode;
    title: string;
    detail: string;
}) {
    return (
        <div className="flex items-start gap-3">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#EFE8F8] text-[#4E2C66]">
                {icon}
            </div>

            <div>
                <h2 className="text-[16px] font-bold text-[#1A1220]">
                    {title}
                </h2>
                <p className="mt-0.5 text-xs leading-5 text-[#7A6A84]">
                    {detail}
                </p>
            </div>
        </div>
    );
}

function FieldLabel({
                        label,
                        detail,
                        children,
                    }: {
    label: string;
    detail?: string;
    children: React.ReactNode;
}) {
    return (
        <div>
            <label className="mb-2 block text-sm font-medium text-[#1A1220]">
                {label}
            </label>
            {children}
            {detail && (
                <p className="mt-1.5 text-xs text-[#7A6A84]">{detail}</p>
            )}
        </div>
    );
}

function ReadOnlyField({ label, value }: { label: string; value: string }) {
    return (
        <div>
            <p className="mb-2 text-sm font-medium text-[#1A1220]">{label}</p>
            <div
                title={value}
                className="flex h-[42px] items-center truncate rounded-xl border border-[#E6DDF0] bg-[#FFFDF8] px-3 text-sm text-[#5F4E75]"
            >
                {value}
            </div>
        </div>
    );
}

function TipCard({
                     number,
                     title,
                     detail,
                 }: {
    number: string;
    title: string;
    detail: string;
}) {
    return (
        <div className="rounded-xl border border-[#E6DDF0] bg-[#FFFDF8] p-4">
            <span className="text-xs font-bold tracking-[0.12em] text-[#806A8C]">
                {number}
            </span>
            <p className="mt-2 text-sm font-semibold text-[#1A1220]">
                {title}
            </p>
            <p className="mt-1 text-xs leading-5 text-[#7A6A84]">{detail}</p>
        </div>
    );
}