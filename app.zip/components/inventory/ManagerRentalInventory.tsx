"use client";

import * as React from "react";
import * as XLSX from "xlsx";
import { useCurrentUser } from "@/hooks/useCurrentUser";
import {
    Boxes, CalendarClock, CheckCircle2,
    PackagePlus, Pencil, Plus, Search, Settings2, Wrench, X, Trash2,
    Download, Upload, ChevronDown,
} from "lucide-react";
import {
    useRentalInventory, availableNow, hasRentalStockDiscrepancy,
    type RentalEquipment, type RentalActivity, type RentalMaintenanceRecord,
    type RentalMaintenanceHistory, type RentalPendingInspection, type RentalMissingReport,
    type RentalMutation, type RentalSummary, type RentalImportRow, type RentalPurchaseDetails,
    type RentalPricingMethod,
    calculateCostBasedRentalRate,
} from "@/hooks/useRentalInventory";
import { SuccessToast } from "./_shared";

// Use the shared StockNBook report format for the manager's read-only panels.
async function exportRentalPanelPdf(title: string, headers: string[], rows: string[][], range: string) {
    const { exportTableAsPdf } = await import("@/components/dashboard/_shared");
    exportTableAsPdf({title, headers, rows}, {
        storeName: sessionStorage.getItem("store_name") || "StockNBook",
        branch: sessionStorage.getItem("branch_name") || "Assigned branch",
        dateRange: range,
    }, `stocknbook_${title.toLowerCase().replace(/[^a-z0-9]+/g, "_")}`);
}

// Keep Inventory filters visually consistent without changing their values or handlers.
function RentalInventoryFilterSelect({ containerClassName = "", className = "", children, ...props }:
                                         React.ComponentProps<"select"> & { containerClassName?: string }) {
    return (
        <span className={`relative inline-flex min-w-0 ${containerClassName}`}>
            <select {...props} className={`h-9 w-full min-w-0 appearance-none rounded-xl border border-[#E3D8EA] bg-white py-1 pl-3 pr-9 text-xs font-semibold text-[#2B174C] outline-none focus:border-[#BFA8E2] focus-visible:ring-2 focus-visible:ring-[#F1EBFF] ${className}`}>
                {children}
            </select>
            <ChevronDown aria-hidden="true" size={14} className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-[#806A8C]" />
        </span>
    );
}

// Inclusive YYYY-MM-DD date range used by the Rental Stock Activity and
// Equipment Condition & Monitoring "Date range" filters.
function isValidInventoryDateRange(start: string, end: string) {
    return /^\d{4}-\d{2}-\d{2}$/.test(start) && /^\d{4}-\d{2}-\d{2}$/.test(end) && start <= end;
}
function inventoryDateRangeLabel(start: string, end: string) {
    return isValidInventoryDateRange(start, end) ? `${start} to ${end}` : "Choose a date range";
}
// Start/End Date inputs shown under a panel header while "Date range" is selected.
function InventoryDateRangeFields({ label, start, end, onStartChange, onEndChange }: {
    label: string; start: string; end: string;
    onStartChange: (value: string) => void; onEndChange: (value: string) => void;
}) {
    const reversed = Boolean(start && end && start > end);
    return (
        <div className="flex shrink-0 flex-wrap items-center gap-2 border-b border-[#E9E1EE] bg-[#FCFAFF] px-4 py-2 text-[11px]">
            <label className="flex items-center gap-1.5 font-semibold text-[#4E2C66]">Start Date
                <input type="date" aria-label={`${label} start date`} value={start} max={end || undefined}
                       onChange={e => onStartChange(e.target.value)}
                       className="h-9 rounded-xl border border-[#E3D8EA] bg-white px-2 text-[11px] font-normal text-[#2B174C]"/>
            </label>
            <label className="flex items-center gap-1.5 font-semibold text-[#4E2C66]">End Date
                <input type="date" aria-label={`${label} end date`} value={end} min={start || undefined}
                       onChange={e => onEndChange(e.target.value)}
                       className="h-9 rounded-xl border border-[#E3D8EA] bg-white px-2 text-[11px] font-normal text-[#2B174C]"/>
            </label>
            {reversed
                ? <p role="alert" className="font-medium text-[#D92C3F]">Start Date cannot be later than End Date.</p>
                : (!start || !end) && <p className="text-[#86778F]">Choose a Start Date and End Date (both dates included).</p>}
        </div>
    );
}

// Only actual rental receipts, booking-linked returns/replacements, releases and
// equipment deletion belong in the Stock In / Stock Out table.
function rentalActivityDirection(record: RentalActivity): "in" | "out" | "other" {
    if (["received", "returned", "missing_replaced"].includes(record.type)) return "in";
    if (record.type === "rented_out" || (record.type === "adjustment" &&
        /^Equipment retired:/.test(record.description || ""))) return "out";
    return "other";
}

// The manager manages physical equipment and maintenance, not checkout/return
// transactions. Staff's booking workflow is the authority for rentals/returns.
export default function ManagerRentalInventory({ branchId }: { branchId?: number }) {
    const rental = useRentalInventory(branchId);
    const {user}=useCurrentUser();
    const inventoryPermission=user?.permissions?.inventory_access ?? user?.permissions?.inventory;
    // Legacy Managers default to Full unless explicitly denied; the Lambda is authoritative.
    const canManage=user?.role==="manager" && (inventoryPermission==null || inventoryPermission===true ||
        inventoryPermission==="true" || inventoryPermission==="full");
    const [search, setSearch] = React.useState("");
    const [category, setCategory] = React.useState("All Categories");
    const [status, setStatus] = React.useState("All Status");
    const [activityDateFilter, setActivityDateFilter] = React.useState<"today" | "all" | "range">("today");
    const [activityStartDate, setActivityStartDate] = React.useState("");
    const [activityEndDate, setActivityEndDate] = React.useState("");
    const [activityDirection, setActivityDirection] = React.useState<"all" | "in" | "out">("all");
    const [dialog, setDialog] = React.useState<{
        mode: "add" | "edit" | "receive" | "maintenance" | "review" | "correct";
        item: RentalEquipment | null;
    } | null>(null);
    const [retireItem,setRetireItem] = React.useState<RentalEquipment|null>(null);
    const [notice, setNotice] = React.useState("");
    const [noticeTitle, setNoticeTitle] = React.useState("Rental inventory updated");
    const [exportError, setExportError] = React.useState("");
    const closeInventoryToast = React.useCallback(() => { setNotice(""); setExportError(""); }, []);
    const [importOpen, setImportOpen] = React.useState(false);
    const [conditionStatusFilter,setConditionStatusFilter] = React.useState("all");
    // Defaults to all loaded records so unresolved issues from earlier days stay visible.
    const [conditionDateFilter,setConditionDateFilter] = React.useState<"today" | "all" | "range">("all");
    const [conditionStartDate,setConditionStartDate] = React.useState("");
    const [conditionEndDate,setConditionEndDate] = React.useState("");
    const [conditionDetail,setConditionDetail] = React.useState<ManagerConditionIssue|RentalMaintenanceHistory|null>(null);
    const [categoriesOpen, setCategoriesOpen] = React.useState(false);
    const [exportOpen, setExportOpen] = React.useState(false);
    const [dateFiltersOpen, setDateFiltersOpen] = React.useState(false);
    // Date Availability opens on today (Asia/Manila) and loads automatically (see below).
    const [fromDate, setFromDate] = React.useState(rentalToday);
    const [toDate, setToDate] = React.useState(rentalToday);
    const [appliedDates, setAppliedDates] = React.useState<{from:string;to:string}|null>(null);
    const [datesAvailability, setDatesAvailability] = React.useState<Map<number,number>|null>(null);
    const [datesReserved, setDatesReserved] = React.useState<Map<number,number>|null>(null);
    const [datesLoading, setDatesLoading] = React.useState(false);
    const [datesError, setDatesError] = React.useState("");

    const categories = rental.categories;
    // The equipment list search also narrows the activity and condition panels and their exports.
    const searchQuery = search.trim().toLowerCase();
    const searchLabel = searchQuery ? ` · Search: “${search.trim()}”` : "";
    // Filter the branch-scoped recent activity that is actually returned by the API.
    // The backend limits this feed, so "All loaded" never implies lifetime history.
    const filteredRentalActivity = React.useMemo(() => {
        const todayKey = new Date().toLocaleDateString("sv-SE", { timeZone: "Asia/Manila" });
        return rental.recentActivity.filter(record => {
            const occurredAt = new Date(record.occurredAt);
            if (Number.isNaN(occurredAt.getTime())) return false;
            const key = occurredAt.toLocaleDateString("sv-SE", { timeZone: "Asia/Manila" });
            if (activityDateFilter === "today" && key !== todayKey) return false;
            // Date Range includes both selected days; an incomplete or reversed range shows no records.
            if (activityDateFilter === "range" && (!isValidInventoryDateRange(activityStartDate, activityEndDate) ||
                key < activityStartDate || key > activityEndDate)) return false;
            // Missing report replacements are shown only when the backend resolves
            // a real booking reference; keep legacy/stale MISS-###### rows hidden.
            if (record.type === "missing_replaced" &&
                (!record.referenceNumber || /^MISS-\d+$/i.test(record.referenceNumber))) return false;
            // A stale API may still send maintenance or correction events; never display them here.
            const direction = rentalActivityDirection(record);
            if (direction === "other") return false;
            if (searchQuery && ![record.equipmentName, record.referenceNumber].join(" ").toLowerCase().includes(searchQuery)) return false;
            return activityDirection === "all" || direction === activityDirection;
        });
    }, [rental.recentActivity, activityDateFilter, activityStartDate, activityEndDate, activityDirection, searchQuery]);
    const activityRange = `${activityDateFilter === "all" ? "All loaded dates" : activityDateFilter === "today" ? "Today" : inventoryDateRangeLabel(activityStartDate, activityEndDate)} · ${activityDirection === "all" ? "All activity" : activityDirection === "in" ? "Stock In" : "Stock Out"}${searchLabel}`;
    const downloadPanel = (title: string, headers: string[], rows: string[][], range = "All loaded records") => {
        void exportRentalPanelPdf(title, headers, rows, range)
            .then(() => { setExportError(""); setNotice(`${title} PDF downloaded. Check your browser downloads.`); })
            .catch(() => setExportError(`Unable to download ${title.toLowerCase()}.`));
    };
    const filtered = React.useMemo(() => rental.equipment.filter(item => {
        // Retired equipment stays in history but not the default active catalog.
        if(!item.active && status!=="Archived")return false;
        const query = search.trim().toLowerCase();
        const found = !query || [item.name, item.category, item.equipmentNumber, ...item.unitNumbers]
            .some(value => value.toLowerCase().includes(query));
        const availability = appliedDates ? datesAvailability?.get(item.id) : item.bookableToday;
        return found && (category === "All Categories" || item.category === category) &&
            (status === "All Status" || equipmentStatusGroup(item, availability) === status);
    }), [rental.equipment, search, category, status, datesAvailability, appliedDates]);

    const managerConditionIssues=React.useMemo(()=>buildManagerConditionIssues(
            rental.maintenanceRecords,rental.missingReports,rental.pendingInspections),
        [rental.maintenanceRecords,rental.missingReports,rental.pendingInspections]);
    // One list for open issues and completed work, filtered by status.
    const conditionRows=React.useMemo(()=>buildManagerConditionRows(managerConditionIssues,rental.maintenanceHistory),
        [managerConditionIssues,rental.maintenanceHistory]);
    // Status and date filters combine. Dates use each row's existing recorded date
    // (the date shown under its Status) in Philippine time; Date Range includes both days.
    const conditionRangeValid=isValidInventoryDateRange(conditionStartDate,conditionEndDate);
    const visibleConditionRows=React.useMemo(()=>{
        const todayKey=new Date().toLocaleDateString("sv-SE",{timeZone:"Asia/Manila"});
        return conditionRows.filter(row=>{
            if(conditionStatusFilter!=="all"&&row.status!==conditionStatusFilter)return false;
            if(searchQuery&&![row.bookingReference||"",row.equipmentName,row.issue,row.status,row.recordedBy].join(" ").toLowerCase().includes(searchQuery))return false;
            if(conditionDateFilter==="all")return true;
            const key=managerConditionDateKey(row.date);
            if(!key)return false;
            if(conditionDateFilter==="today")return key===todayKey;
            return conditionRangeValid&&key>=conditionStartDate&&key<=conditionEndDate;
        });
    },[conditionRows,conditionStatusFilter,conditionDateFilter,conditionStartDate,conditionEndDate,conditionRangeValid,searchQuery]);
    const conditionRange=`${conditionDateFilter==="all"?"All loaded records":conditionDateFilter==="today"?"Today":inventoryDateRangeLabel(conditionStartDate,conditionEndDate)} · ${conditionStatusFilter==="all"?"All status":conditionStatusFilter}${searchLabel}`;

    const resetDates = () => {
        setAppliedDates(null); setDatesAvailability(null); setDatesReserved(null);
        // Returning to today retains the valid Fully Booked status filter.
        setDatesError("");
    };
    const checkDates = async (from = fromDate, to = toDate) => {
        if (!from || !to || to < from) {
            setDatesError("Choose a valid start and end date."); return;
        }
        setDatesError(""); setDatesLoading(true); setAppliedDates(null); setDatesAvailability(null); setDatesReserved(null);
        try {
            const rows = await rental.checkAvailability(from, to);
            setDatesAvailability(new Map(rows.map(row => [row.equipmentId,row.availableUnits]))); setDatesReserved(new Map(rows.map(row=>[row.equipmentId,row.reservedUnits])));
            setAppliedDates({from,to});
        } catch(error) {
            setDatesError(error instanceof Error ? error.message : "Unable to check availability.");
        } finally { setDatesLoading(false); }
    };
    // Load today's availability when the page opens (no Check Dates click needed).
    const initialDatesChecked = React.useRef(false);
    React.useEffect(() => {
        if (initialDatesChecked.current) return;
        initialDatesChecked.current = true;
        void checkDates();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);
    React.useEffect(() => {
        if (!appliedDates) return;
        let active=true;
        const update = async () => {
            if (document.visibilityState !== "visible") return;
            try {
                const rows=await rental.checkAvailability(appliedDates.from,appliedDates.to);
                if (active) {
                    setDatesAvailability(new Map(rows.map(row=>[row.equipmentId,row.availableUnits]))); setDatesReserved(new Map(rows.map(row=>[row.equipmentId,row.reservedUnits])));
                    setDatesError("");
                }
            } catch (error) {
                if (active) {
                    setDatesAvailability(null); setDatesReserved(null); // Never leave a stale date availability on screen.
                    setDatesError(error instanceof Error ? error.message : "Unable to refresh rental availability.");
                }
            }
        };
        const onFocus=()=>{void update();};
        window.addEventListener("focus",onFocus);
        const timer=window.setInterval(onFocus,15_000);
        return ()=>{active=false;window.removeEventListener("focus",onFocus);window.clearInterval(timer);};
    }, [appliedDates, rental.checkAvailability]);
    const onSaved = async (mutation:RentalMutation) => {
        if(!canManage)throw new Error("Full Inventory access is required to change equipment records.");
        const reference = await rental.mutate(mutation);
        if (appliedDates) {
            // Keep the selected booking period after a stock operation; the
            // quantities may have changed and must be rechecked immediately.
            try {
                const rows=await rental.checkAvailability(appliedDates.from,appliedDates.to);
                setDatesAvailability(new Map(rows.map(row=>[row.equipmentId,row.availableUnits]))); setDatesReserved(new Map(rows.map(row=>[row.equipmentId,row.reservedUnits])));
                setDatesError("");
            } catch (error) {
                setDatesAvailability(null); setDatesReserved(null);
                setDatesError(error instanceof Error ? error.message : "Unable to refresh rental availability.");
            }
        } else resetDates();
        if (mutation.action === "receive_equipment") {
            // Same confirmation as Consumable Inventory's Receive Stock.
            const restocked = rental.equipment.find(item => item.id === mutation.equipmentId) || dialog?.item;
            setNoticeTitle("Stock restocked successfully");
            setNotice(`“${restocked?.name || "Rental equipment"}” received +${mutation.quantity.toLocaleString("en-PH")} units in inventory.`);
            return;
        }
        if (mutation.action === "update_equipment") {
            // Same confirmation as Consumable Inventory's Update Product.
            setNoticeTitle("Product updated successfully");
            setNotice(mutation.totalUnits !== undefined
                ? `“${mutation.name}” was updated in inventory. Stock count corrected to ${mutation.totalUnits.toLocaleString("en-PH")} units.`
                : `“${mutation.name}” was updated in inventory.`);
            return;
        }
        if (mutation.action === "archive_equipment") {
            // Same confirmation as Consumable Inventory's Delete Product.
            setNoticeTitle("Product deleted successfully");
            setNotice(`“${mutation.confirmName}” was removed from future operations while its historical records were preserved.`);
            return;
        }
        setNoticeTitle("Rental inventory updated");
        setNotice(mutation.action === "resolve_missing_equipment"
            ? mutation.resolution === "found"
                ? "Missing equipment recovered. Staff must inspect and complete the recovery-care task before units become ready."
                : "Permanent loss confirmed. The equipment stock has been adjusted."
            : mutation.action === "correct_equipment_stock"
                ? "Verified rental stock count corrected and audited. Booking-date availability will refresh automatically."
                : mutation.action === "approve_maintenance_repair"
                    ? "Repair authorized. Equipment stays on hold until Staff completes repairs and the Manager approves stock release."
                    : mutation.action === "approve_repair_completion"
                        ? "Repaired units released to ready stock after Manager approval."
                        : mutation.action === "import_equipment" || (mutation.action==="create_equipment" && Boolean(mutation.initialPurchase))
                            ? `Rental units received and recorded${reference ? ` · ${reference}` : ""}. Availability and today’s stock activity have been updated.`
                            : `Rental inventory saved${reference ? ` · ${reference}` : ""}.`);
    };
    const downloadExport = (format:"xlsx"|"pdf") => {
        setExportOpen(false);
        const details = {category,status,appliedDates,reserved:datesReserved};
        try {
            if (format === "xlsx") exportRentalExcel(filtered, details, datesAvailability);
            else exportRentalPdf(filtered, details, datesAvailability);
            setExportError("");
            setNotice(`${format === "xlsx" ? "Excel" : "PDF"} rental inventory export started. Check your browser downloads.`);
        } catch (error) {
            setNotice("");
            setExportError(error instanceof Error ? error.message : "Unable to export rental inventory.");
        }
    };

    return (
        <div className="space-y-4" aria-label="Rental inventory">
            {!canManage&&<p role="status" className="rounded-xl border border-[#E6DDF0] bg-[#F7F1FF] px-4 py-3 text-xs text-[#5330B6]">View-only Inventory access: product details and maintenance reports remain visible, but catalog changes and purchases require Full access.</p>}
            {rental.error && (
                <div role="alert" className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-[#E8CAD2] bg-[#FFF5F7] px-4 py-3 text-sm text-[#A92741]">
                    <span>{rental.error}{rental.connected ? " Showing the last loaded data." : ""}</span>
                    <button type="button" onClick={() => void rental.refresh()} className="rounded-lg border border-[#E8CAD2] px-3 py-1.5 font-semibold hover:bg-white">Try Again</button>
                </div>
            )}


            <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
                <RentalMetric label="Total Equipment Units" value={rental.summary.totalUnits}
                              description="Total rental units owned by this branch" tone="purple" icon={<Boxes size={20}/>} loading={rental.loading}/>
                <RentalMetric label="Physically Ready Now" value={rental.summary.availableUnits}
                              description="On hand now; future reservations checked by date" tone="green" icon={<CheckCircle2 size={20}/>} loading={rental.loading}/>
                <RentalMetric label="Out on Rental" value={rental.summary.rentedOutUnits}
                              description="Units physically with customers" tone="blue" icon={<CalendarClock size={20}/>} loading={rental.loading}/>
                <RentalMetric label="On Hold" value={rental.summary.maintenanceUnits}
                              description="Pending inspection, cleaning, or repair" tone="amber" icon={<Wrench size={20}/>} loading={rental.loading}/>
            </div>

            {notice.startsWith("Missing equipment") || notice.startsWith("Permanent loss") ? (
                <div role="status" className="flex items-center justify-between gap-3 rounded-xl border border-[#D9CDF0] bg-[#F7F1FF] px-4 py-3 text-xs font-semibold text-[#5330B6]">
                    <span>{notice}</span>
                    <button type="button" onClick={() => setNotice("")} aria-label="Dismiss missing equipment update"><X size={16}/></button>
                </div>
            ) : null}

            <div className="grid items-stretch gap-4 xl:grid-cols-[1.15fr_1fr]">
                {/* Read-only oversight: Staff owns routine repairs/recoveries. */}
                <section className="flex h-[470px] min-h-0 flex-col overflow-hidden rounded-2xl border border-[#E7DFEC] bg-white shadow-sm" aria-label="Equipment condition and monitoring">
                    <div className="flex min-w-0 shrink-0 flex-wrap items-center justify-between gap-3 border-b border-[#E9E1EE] px-4 py-3.5">
                        <div className="flex min-w-0 flex-1 items-center gap-3">
                            <span className="shrink-0 rounded-xl bg-[#F1EBFF] p-2 text-[#5A35A5]"><Wrench size={18}/></span>
                            <div className="min-w-0">
                                <h3 className="text-[15px] font-bold text-[#21132E]">Equipment Condition &amp; Monitoring</h3>
                                <p className="text-[11px] leading-4 text-[#86778F]">Monitor unresolved equipment issues and verified Staff work.</p>
                            </div>
                        </div>
                        <div className="ml-auto flex shrink-0 items-center gap-2">
                            <RentalInventoryFilterSelect containerClassName="w-[105px]" value={conditionDateFilter} aria-label="Filter equipment condition by date"
                                                         onChange={e => setConditionDateFilter(e.target.value as "today" | "all" | "range")}>
                                <option value="today">Today</option><option value="all">All loaded</option><option value="range">Date range</option>
                            </RentalInventoryFilterSelect>
                            <RentalInventoryFilterSelect containerClassName="w-[160px]" value={conditionStatusFilter} aria-label="Filter equipment condition by status"
                                                         onChange={e => setConditionStatusFilter(e.target.value)}>
                                <option value="all">All Status</option>
                                {MANAGER_CONDITION_STATUSES.map(status => <option key={status} value={status}>{status}</option>)}
                            </RentalInventoryFilterSelect>
                            <button type="button" title="Download displayed equipment condition report (PDF)" aria-label="Download equipment condition report"
                                    disabled={conditionDateFilter === "range" && !conditionRangeValid}
                                    onClick={() => downloadPanel("Equipment Condition & Monitoring", ["Equipment", "Units", "Issue", "Status", "Recorded By"],
                                        visibleConditionRows.map(row => [row.equipmentName, String(row.units), row.issue, row.status, row.recordedBy || "Not recorded"]), conditionRange)}
                                    className="flex h-9 w-9 items-center justify-center rounded-xl border border-[#E3D8EA] bg-white text-[#5A35A5] hover:bg-[#F7F1FF] disabled:opacity-40"><Download size={16}/></button>
                        </div>
                    </div>
                    {conditionDateFilter === "range" && <InventoryDateRangeFields label="Equipment condition" start={conditionStartDate} end={conditionEndDate}
                                                                                  onStartChange={setConditionStartDate} onEndChange={setConditionEndDate}/>}
                    {rental.loading ? <PanelSkeleton/> : !rental.connected ?
                        <EmptyPanel label="Connect rental inventory to view equipment condition."/> :
                        !rental.monitoringDataReady ?
                            <EmptyPanel label="Update the rental inventory Lambda and hook to display maintenance monitoring history."/> :
                            visibleConditionRows.length===0 ?
                                <EmptyPanel label={conditionDateFilter==="range"&&!conditionRangeValid
                                    ? "Choose a valid Start Date and End Date to view equipment condition records."
                                    : (conditionDateFilter!=="all"||searchQuery)
                                        ? "No equipment condition records match the selected filters."
                                        : conditionStatusFilter==="all" ? "No equipment issues or repair activity recorded yet." : `No equipment with status “${conditionStatusFilter}”.`}/> :
                                <ManagerConditionTable rows={visibleConditionRows} onView={setConditionDetail}/>}
                </section>

                <section className="flex h-[470px] min-h-0 flex-col overflow-hidden rounded-2xl border border-[#E7DFEC] bg-white shadow-sm">
                    <PanelHeading icon={<CalendarClock size={18}/>} title="Rental Stock Activity"
                                  subtitle="Restocks, replacements, returns, releases, and equipment deletions."
                                  actions={<div className="flex shrink-0 items-center gap-1.5">
                                      <RentalInventoryFilterSelect containerClassName="w-[104px]" value={activityDateFilter} aria-label="Filter rental activity date" onChange={e => setActivityDateFilter(e.target.value as "today" | "all" | "range")}>
                                          <option value="today">Today</option><option value="all">All loaded</option><option value="range">Date range</option>
                                      </RentalInventoryFilterSelect>
                                      <RentalInventoryFilterSelect containerClassName="w-[114px]" value={activityDirection} aria-label="Filter rental activity movement" onChange={e => setActivityDirection(e.target.value as "all" | "in" | "out")}>
                                          <option value="all">All Activity</option><option value="in">Stock In</option><option value="out">Stock Out</option>
                                      </RentalInventoryFilterSelect>
                                      <button type="button" disabled={rental.loading || (activityDateFilter === "range" && !isValidInventoryDateRange(activityStartDate, activityEndDate))}
                                              title="Download filtered rental activity PDF" aria-label="Download filtered rental stock activity"
                                              onClick={() => downloadPanel("Rental Stock Activity", ["Date", "Time", "Equipment", "Activity", "Qty", "Reference No."],
                                                  filteredRentalActivity.map(record => {
                                                      const occurred = new Date(record.occurredAt);
                                                      return [occurred.toLocaleDateString("en-PH", { timeZone: "Asia/Manila", month: "short", day: "numeric", year: "numeric" }),
                                                          occurred.toLocaleTimeString("en-PH", { timeZone: "Asia/Manila", hour: "numeric", minute: "2-digit" }),
                                                          record.equipmentName, rentalActivityDirection(record) === "in" ? "Stock In" : "Stock Out",
                                                          `${rentalActivityDirection(record) === "in" ? "+" : "−"}${record.quantity}`, record.referenceNumber || "—"];
                                                  }), activityRange)}
                                              className="flex h-9 w-9 items-center justify-center rounded-xl border border-[#E3D8EA] bg-white text-[#5A35A5] hover:bg-[#F7F1FF] disabled:opacity-40"><Download size={16}/></button>
                                  </div>}/>
                    {activityDateFilter === "range" && <InventoryDateRangeFields label="Rental activity" start={activityStartDate} end={activityEndDate}
                                                                                 onStartChange={setActivityStartDate} onEndChange={setActivityEndDate}/>}
                    {rental.loading ? <PanelSkeleton/> : !rental.connected ? <EmptyPanel label="Connect rental records to view activity."/> :
                        filteredRentalActivity.length === 0 ? <EmptyPanel label="No rental movements match the selected filters."/> : (
                            <div className="min-h-0 flex-1 overflow-auto">
                                <table className="w-full min-w-0 table-fixed text-center text-[11px] [&_th]:align-middle [&_td]:align-middle [&_th]:whitespace-nowrap [&_th]:overflow-hidden [&_th]:text-ellipsis [&_th]:text-[10px] [&_th]:font-semibold [&_th]:uppercase [&_th]:leading-tight [&_th]:tracking-normal [&_th]:text-[#806A8C] [&_td]:leading-snug [&_td]:[overflow-wrap:anywhere]">
                                    <colgroup><col className="w-[16%]"/><col className="w-[30%]"/><col className="w-[18%]"/><col className="w-[9%]"/><col className="w-[27%]"/></colgroup>
                                    <thead className="sticky top-0 z-10 bg-[#FFFCF8] text-[10px] uppercase text-[#806A8C]">
                                    <tr className="border-b border-[#E9E1EE]">
                                        <th className="truncate px-2 py-2 font-semibold text-center text-[10px] uppercase tracking-normal text-[#806A8C]">Date &amp; Time</th>
                                        <th className="truncate px-2 py-2 font-semibold text-center text-[10px] uppercase tracking-normal text-[#806A8C]">Equipment</th>
                                        <th className="truncate px-2 py-2 text-center font-semibold text-[10px] uppercase tracking-normal text-[#806A8C]">Activity</th>
                                        <th className="truncate px-2 py-2 text-center font-semibold text-[10px] uppercase tracking-normal text-[#806A8C]">Qty</th>
                                        <th className="truncate px-2 py-2 font-semibold text-center text-[10px] uppercase tracking-normal text-[#806A8C]">Reference No.</th>
                                    </tr></thead>
                                    <tbody>{filteredRentalActivity.map(record => (
                                        <ActivityRow key={record.id} item={record}/>
                                    ))}</tbody>
                                </table>
                            </div>
                        )}
                </section>
            </div>



            {conditionDetail&&<ManagerConditionDetails entry={conditionDetail} onClose={()=>setConditionDetail(null)}/>}

            <section className="overflow-hidden rounded-2xl border border-[#E7DFEC] bg-white shadow-sm">
                <div className="flex flex-wrap items-start justify-between gap-3 px-4 py-3.5">
                    <div className="flex items-start gap-3">
                        <span className="flex h-9 w-9 items-center justify-center rounded-[10px] bg-[#F1EBFF] text-[#5A35A5]"><Boxes size={18}/></span>
                        <div>
                            <h2 className="text-[15px] font-bold text-[#21132E]">Branch Rental Equipment List</h2>
                            <p className="mt-0.5 text-[11px] text-[#86778F]">Check physical stock and condition, or choose dates to check booking availability.</p>
                        </div>
                    </div>
                    <div className="flex flex-wrap items-center gap-2">
                        <RentalInventoryFilterSelect containerClassName="w-[154px]" value={category} onChange={e=>setCategory(e.target.value)} aria-label="Filter rental category">
                            <option>All Categories</option>{categories.map(name=><option key={name}>{name}</option>)}
                        </RentalInventoryFilterSelect>
                        <RentalInventoryFilterSelect containerClassName="w-[148px]" value={status} onChange={e=>setStatus(e.target.value)} aria-label="Filter rental equipment status">
                            {/* Available / Unavailable group the existing availability labels (see equipmentStatusGroup). */}
                            {["All Status","Available","Unavailable"].map(value=><option key={value}>{value}</option>)}
                        </RentalInventoryFilterSelect>
                        <button type="button" aria-expanded={dateFiltersOpen} onClick={()=>setDateFiltersOpen(v=>!v)}
                                className="flex h-9 items-center gap-2 rounded-xl border border-[#E3D8EA] bg-white px-3 text-xs font-semibold text-[#2B174C] hover:bg-[#F8F3FC]">
                            <CalendarClock size={15}/> {appliedDates ? (appliedDates.from === rentalToday() && appliedDates.to === rentalToday() ? "Today" : "Dates Applied") : "Date Availability"} <ChevronDown size={14}/>
                        </button>
                        <div className="relative">
                            <button type="button" aria-expanded={exportOpen} onClick={()=>setExportOpen(v=>!v)}
                                    aria-label="Download filtered rental inventory list" title="Download filtered rental inventory list"
                                    className="flex h-9 w-9 items-center justify-center rounded-xl border border-[#D9CDF0] bg-white text-[#2B174C] hover:bg-[#F8F3FC]">
                                <Download size={17}/>
                            </button>
                            {exportOpen && <div className="absolute right-0 top-full z-20 mt-1 min-w-[155px] rounded-xl border border-[#E3D8EA] bg-white p-1 shadow-lg">
                                <button type="button" onClick={()=>downloadExport("xlsx")} className="block w-full rounded-lg px-3 py-2 text-left text-xs text-[#2B174C] hover:bg-[#F5F0FF]">Export Excel (.xlsx)</button>
                                <button type="button" onClick={()=>downloadExport("pdf")} className="block w-full rounded-lg px-3 py-2 text-left text-xs text-[#2B174C] hover:bg-[#F5F0FF]">Export PDF (.pdf)</button>
                            </div>}
                        </div>
                    </div>
                </div>
                {dateFiltersOpen && <div className="flex flex-wrap items-end gap-3 border-t border-[#E9E1EE] bg-[#FCFAFF] px-4 py-3 text-xs">
                    <label className="space-y-1 font-semibold text-[#4E2C66]">From
                        <input type="date" value={fromDate} onChange={e=>{setFromDate(e.target.value);resetDates();}} className="block h-10 rounded-xl border border-[#E3D8EA] bg-white px-3 text-[#2B174C]"/>
                    </label>
                    <label className="space-y-1 font-semibold text-[#4E2C66]">To (inclusive)
                        <input type="date" min={fromDate||undefined} value={toDate} onChange={e=>{setToDate(e.target.value);resetDates();}} className="block h-10 rounded-xl border border-[#E3D8EA] bg-white px-3 text-[#2B174C]"/>
                    </label>
                    <button type="button" disabled={!fromDate||!toDate||toDate<fromDate||datesLoading} onClick={()=>void checkDates()}
                            className="h-10 rounded-xl bg-[#2B174C] px-4 font-semibold text-white disabled:opacity-50">{datesLoading?"Checking...":"Check Dates"}</button>
                    <button type="button" onClick={()=>{const today=rentalToday();setFromDate(today);setToDate(today);void checkDates(today,today);}}
                            className="h-10 rounded-xl border border-[#E3D8EA] bg-white px-4 font-semibold text-[#2B174C]">Clear</button>
                    {datesError && <p role="alert" className="w-full text-red-700">{datesError}</p>}
                    <p className="w-full text-[#86778F]">Checking dates changes the Status and available quantity for that period. Fully Booked counts only confirmed reservations. Physical stock and equipment conditions are shown separately.</p>
                </div>}
                <div className="grid gap-3 px-4 pb-4 xl:grid-cols-[minmax(0,1fr)_auto_auto_auto]">
                    <label className="relative min-w-0">
                        <Search size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-[#9B8AAA]"/>
                        <input value={search} onChange={e=>setSearch(e.target.value)}
                               placeholder="Search product no., equipment no., rental products, or categories..." aria-label="Search rental equipment"
                               className="h-11 w-full rounded-xl border border-[#E3D8EA] bg-white pl-11 pr-3 text-sm text-[#2B174C] outline-none placeholder:text-[#9B8AAA] focus:border-[#5A35A5]"/>
                    </label>
                    <button type="button" disabled={!canManage} onClick={()=>setImportOpen(true)} className="flex h-11 items-center justify-center gap-2 rounded-xl border border-[#D9CDF0] bg-[#F5F0FF] px-4 text-sm font-semibold text-[#5330B6] hover:bg-[#ECE3FF]">
                        <Upload size={16}/> Upload File
                    </button>
                    <button type="button" disabled={!canManage} onClick={()=>setCategoriesOpen(true)} className="flex h-11 items-center justify-center gap-2 rounded-xl border border-[#D9CDF0] bg-[#F5F0FF] px-4 text-sm font-semibold text-[#5330B6] hover:bg-[#ECE3FF]">
                        <Settings2 size={16}/> Manage Categories
                    </button>
                    <button type="button" disabled={!canManage} onClick={()=>setDialog({mode:"add",item:null})} className="flex h-11 items-center justify-center gap-2 rounded-xl border border-[#D9CDF0] bg-[#F5F0FF] px-4 text-sm font-semibold text-[#5330B6] hover:bg-[#ECE3FF]">
                        <Plus size={16}/> Add Equipment
                    </button>
                </div>
                <div className="max-h-[360px] w-full overflow-y-auto overflow-x-auto overscroll-contain border-t border-[#E9E1EE]" style={{ maxHeight: 360 }} role="region" aria-label="Branch rental equipment list" tabIndex={0}>
                    <table className="w-full min-w-0 table-auto text-center text-[11px] [&_th]:align-middle [&_td]:align-middle [&_th]:whitespace-nowrap [&_th]:overflow-hidden [&_th]:text-ellipsis [&_th]:text-[10px] [&_th]:font-semibold [&_th]:uppercase [&_th]:leading-tight [&_th]:tracking-normal [&_th]:text-[#806A8C] [&_td]:leading-snug [&_td]:[overflow-wrap:anywhere]">
                        <colgroup><col className="w-[12%]"/><col className="w-[13%]"/><col className="w-[8%]"/><col className="w-[7%]"/><col className="w-[8%]"/><col className="w-[8%]"/><col className="w-[7.5%]"/><col className="w-[7.5%]"/><col className="w-[9%]"/><col className="w-[20%]"/></colgroup>
                        <thead className="sticky top-0 z-10 bg-[#FFFCF8] text-[10px] uppercase tracking-wide text-[#806A8C]">
                        <tr className="border-b border-[#E9E1EE]">
                            <th className="truncate px-2 py-2 text-center font-semibold text-[10px] uppercase tracking-normal text-[#806A8C]">Equipment No.</th>
                            <th className="truncate px-2 py-2 font-semibold text-center text-[10px] uppercase tracking-normal text-[#806A8C]">Rental Product</th>
                            <th className="truncate px-2 py-2 font-semibold text-center text-[10px] uppercase tracking-normal text-[#806A8C]">Category</th>
                            <th className="truncate px-2 py-2 text-center font-semibold text-[10px] uppercase tracking-normal text-[#806A8C]">Total Units</th>
                            <th className="truncate px-2 py-2 text-center font-semibold text-[10px] uppercase tracking-normal text-[#806A8C]">Available</th>
                            <th className="truncate px-2 py-2 text-center font-semibold text-[10px] uppercase tracking-normal text-[#806A8C]">Reserved</th>
                            <th className="truncate px-2 py-2 text-center font-semibold text-[10px] uppercase tracking-normal text-[#806A8C]">Rented Out</th>
                            <th className="truncate px-2 py-2 text-center font-semibold text-[10px] uppercase tracking-normal text-[#806A8C]">On Hold</th>
                            <th className="truncate px-2 py-2 text-center font-semibold text-[10px] uppercase tracking-normal text-[#806A8C]">Status</th>
                            <th className="truncate px-2 py-2 text-center font-semibold text-[10px] uppercase tracking-normal text-[#806A8C]">Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        {rental.loading ? <tr><td colSpan={10} className="p-5"><PanelSkeleton/></td></tr> :
                            !rental.connected ? <tr><td colSpan={10} className="px-5 py-12 text-center text-sm text-[#86778F]">Rental data is not connected. No equipment is displayed here.</td></tr> :
                                filtered.length === 0 ? <tr><td colSpan={10} className="px-5 py-12 text-center text-sm text-[#86778F]">No matching rental equipment.</td></tr> :
                                    filtered.map(item => (
                                        <tr key={item.id} className="h-12 border-b border-[#EFE8F2] text-[#2B174C] last:border-0 hover:bg-[#FFFCF8]">
                                            {/* Same typography as the Rental Product column; the complete number stays on one line. */}
                                            <td className="whitespace-nowrap py-2 px-4 text-left font-semibold text-[#2B174C]">{item.equipmentNumber || "—"}</td>
                                            <td className="px-2 py-2 font-semibold text-[#2B174C]">{item.name}</td>
                                            <td className="px-2 py-2 text-[#5F4E75]">{item.category}</td>
                                            <td className="px-2 py-2 text-center font-semibold">{item.totalUnits}</td>
                                            <td className="px-2 py-2 text-center font-semibold" title={appliedDates ? "Available units for the selected date range" : "Available today after confirmed reservations; physically ready units are tracked separately"}>{appliedDates ? (datesAvailability?.get(item.id) ?? "—") : item.bookableToday}</td>
                                            <td className="px-2 py-2 text-center" title="Confirmed bookings not yet released, for the selected dates">{appliedDates ? (datesReserved?.get(item.id) ?? "—") : "—"}</td>
                                            <td className="px-2 py-2 text-center">{item.rentedOutUnits}</td>
                                            <td className="px-2 py-2 text-center" title={`On hold for inspection, care, or repair: ${item.maintenanceUnits}. Unrecovered missing units: ${item.missingUnits}.`}>
                                                <span>{item.maintenanceUnits}</span>
                                                {item.missingUnits > 0 && <span className="mt-1 block whitespace-nowrap text-[10px] font-semibold text-[#B45309]">Missing: {item.missingUnits}</span>}
                                            </td>
                                            <td className="px-2 py-2 text-center"><IssueBadge issue={equipmentDisplayStatus(item, true, appliedDates ? datesAvailability?.get(item.id) : item.bookableToday)} /></td>
                                            <td className="px-2 py-2 text-center">
                                                <div className="flex flex-nowrap items-center justify-center gap-1.5 whitespace-nowrap">
                                                    <button type="button" onClick={()=>setDialog({mode:"receive",item})} disabled={!canManage||!item.active}
                                                            aria-label={`Restock ${item.name}`}
                                                            className="inline-flex items-center gap-1 rounded-lg bg-[#E5F8EC] px-2.5 py-1.5 font-semibold text-[#23834A] hover:bg-[#D5F0DF] disabled:opacity-40"><PackagePlus size={13}/> Restock</button>
                                                    <button type="button" onClick={()=>setDialog({mode:"edit",item})} disabled={!canManage||!item.active}
                                                            className="inline-flex items-center gap-1 rounded-lg bg-[#F1EBFF] px-2.5 py-1.5 font-semibold text-[#5330B6] hover:bg-[#EAE0FF] disabled:opacity-40"><Pencil size={13}/> Edit</button>
                                                    <button type="button" onClick={()=>setRetireItem(item)} disabled={!canManage||!item.active}
                                                            className="inline-flex items-center gap-1 rounded-lg bg-[#FFF0F0] px-2.5 py-1.5 font-semibold text-[#C52C45] hover:bg-[#FFE2E6] disabled:opacity-40"><Trash2 size={13}/> Delete</button>
                                                </div>
                                            </td>
                                        </tr>
                                    ))}
                        </tbody>
                    </table>
                </div>
            </section>


            <SuccessToast
                toast={exportError ? {title:"Rental inventory export failed",message:exportError,tone:"error"} :
                    notice && !notice.startsWith("Missing equipment") && !notice.startsWith("Permanent loss")
                        ? {title:noticeTitle,message:notice} : null}
                onClose={closeInventoryToast}
            />
            {dialog?.mode === "receive" && dialog.item && <RentalReceiveStockDialog key={`receive-${dialog.item.id}`}
                                                                                    item={dialog.item} saving={rental.saving}
                                                                                    close={() => setDialog(null)}
                                                                                    onSave={async (mutation) => { await onSaved(mutation); setDialog(null); }}/>}
            {dialog && dialog.mode !== "receive" && <EquipmentDialog key={`${dialog.mode}-${dialog.item?.id ?? "new"}`} mode={dialog.mode} item={dialog.item} saving={rental.saving}
                                                                     close={() => setDialog(null)}
                                                                     onNavigate={(mode) => setDialog({mode, item:dialog.item})}
                                                                     categories={categories}
                                                                     equipment={rental.equipment}
                                                                     onDelete={dialog.mode === "edit" && dialog.item ? () => {
                                                                         // Same as Consumable Edit Product: close the editor, then confirm deletion.
                                                                         const target = dialog.item;
                                                                         setDialog(null);
                                                                         setRetireItem(target);
                                                                     } : undefined}
                                                                     onSave={async (mutation) => { await onSaved(mutation); setDialog(null); }}/>
            }
            {retireItem&&<RetireEquipmentDialog item={retireItem} saving={rental.saving}
                                                close={()=>setRetireItem(null)} onSave={async (mutation)=>{await onSaved(mutation);setRetireItem(null);}}/>}
            {importOpen && <RentalImportDialog close={()=>setImportOpen(false)} onSave={async (rows)=>{
                await onSaved({action:"import_equipment",rows}); setImportOpen(false);
            }} saving={rental.saving} existingEquipment={rental.equipment}/>}
            {categoriesOpen && <RentalCategoriesDialog categories={categories} equipment={rental.equipment}
                                                       saving={rental.saving} close={()=>setCategoriesOpen(false)}
                                                       onSave={async mutation => {await onSaved(mutation); setNotice("");}}/>}
        </div>
    );
}

type RentalAvailabilityLabel = "Fully Available" | "Available" | "Low Availability" | "Unavailable" | "Fully Booked" | "Archived" | "Not Checked";

// Bookable-on-dates comes ONLY from the existing server-side allocation check.
// Physical readiness is separate: future reservations do not reduce Ready Now.
function equipmentDisplayStatus(item: RentalEquipment, checkingDates: boolean, onDates?: number): RentalAvailabilityLabel {
    if (!item.active) return "Archived";
    if (checkingDates && (onDates === undefined || !Number.isFinite(onDates))) return "Not Checked";
    const quantity = checkingDates ? Math.max(0, onDates as number) : availableNow(item);
    const maximumUsable = Math.max(0, item.totalUnits - item.maintenanceUnits - item.missingUnits);
    if (quantity <= 0) {
        // With usable equipment but no date availability, confirmed allocations occupy every unit.
        // Otherwise equipment itself is physically unavailable (not "fully booked").
        return checkingDates && maximumUsable > 0 ? "Fully Booked" : "Unavailable";
    }
    if (item.alertLevel > 0 && quantity <= item.alertLevel) return "Low Availability";
    // "Fully Available" means there are no stock holds, missing/out units or
    // confirmed reservations for the relevant period.
    if (quantity === item.totalUnits && item.maintenanceUnits === 0 && item.missingUnits === 0 &&
        (checkingDates || item.rentedOutUnits === 0)) return "Fully Available";
    return "Available";
}

// Condition alerts should not conceal available units: e.g. 27 tables may
// still be available even though 1 table is missing and needs review.
function equipmentConditionLabels(item: RentalEquipment): string[] {
    if (!item.active) return [];
    const labels: string[] = [];
    if (hasRentalStockDiscrepancy(item) || item.missingUnits > 0) labels.push("Needs Review");
    if (item.maintenanceUnits > 0) labels.push("On Hold");
    return labels;
}

// The Branch Rental Equipment List Status filter offers only Available and Unavailable.
// It groups the existing availability labels using the same calculation as the Status
// column; no status is added, renamed or stored. Archived and Not Checked match neither.
function equipmentStatusGroup(item: RentalEquipment, onDates?: number): "Available" | "Unavailable" | null {
    const label = equipmentDisplayStatus(item, true, onDates);
    if (label === "Fully Available" || label === "Available" || label === "Low Availability") return "Available";
    if (label === "Unavailable" || label === "Fully Booked") return "Unavailable";
    return null;
}

function IssueBadge({issue}:{issue:string}) {
    const style = ["Fully Available", "Available"].includes(issue) ? "text-[#23834A]" :
        ["Needs Review", "Unavailable", "Fully Booked"].includes(issue) ? "text-[#D92C3F]" :
            issue === "Low Availability" ? "text-[#A66A00]" :
                issue === "Archived" || issue === "Not Checked" ? "text-[#6B6174]" :
                    "text-[#6944C9]";
    const explanation:Record<string,string> = {
        "Fully Available": "All units are available in the current context (now or on the checked dates).",
        "Available": "Some units are available; other units may be booked, rented out, missing or on hold.",
        "Low Availability": "Bookable units are at or below this equipment's configured alert level.",
        "Unavailable": "No physically usable units available.",
        "Fully Booked": "All usable units are allocated to overlapping confirmed rentals for the selected dates.",
        "Needs Review": "Missing units or a stock discrepancy needs Manager attention.",
        "On Hold": "Equipment awaiting inspection, cleaning or repair.",
        "Not Checked": "No date availability result returned for this equipment.",
    };
    return <span title={explanation[issue]} className={`inline-block text-[10px] font-semibold ${style}`}>{issue}</span>;
}

// Read-only Manager oversight. Staff retains full responsibility for confirming
// actual repairs/recoveries; customer liability is settled in Bookings.
type ManagerConditionIssue = {
    kind:"maintenance"|"missing"|"inspection"; key:string; equipmentName:string;
    units:number; title:string; issue:string; status:string; recordedBy:string; notes:string; reportedAt:string;
    reference:string; bookingReference:string|null;
};
// Issues reported while preparing a booking are saved as "Booking REF: notes";
// the booking has its own column, so show only the notes.
function conditionIssueNotes(reason:string|null|undefined, bookingReference:string|null|undefined) {
    const text=String(reason||"").trim();
    const prefix=bookingReference?`Booking ${bookingReference}: `:"";
    return prefix&&text.startsWith(prefix)?text.slice(prefix.length).trim():text;
}
function buildManagerConditionIssues(records:RentalMaintenanceRecord[], missing:RentalMissingReport[],
                                     inspections:RentalPendingInspection[]):ManagerConditionIssue[] {
    const active:ManagerConditionIssue[]=[];
    for(const record of records){
        active.push({kind:"maintenance",key:`maintenance-${record.id}`,equipmentName:record.equipmentName,
            units:record.units,title:record.status==='Routine'?'Routine care':record.status==='For Inspection'?'Safety inspection':'Repair / safety check',
            issue:record.status==='Routine'?'Routine Care':'Damage',status:'Under Repair',recordedBy:record.reportedBy||'',
            notes:conditionIssueNotes(record.reason,record.bookingReference),reportedAt:record.dateReported,reference:`MNT-${String(record.id).padStart(6,'0')}`,
            bookingReference:record.bookingReference||null});
    }
    for(const report of missing){
        const units=Number(report.remainingUnits??report.quantity);
        if(!Number.isSafeInteger(units)||units<=0)continue;
        active.push({kind:"missing",key:`missing-${report.id}`,equipmentName:report.equipmentName,
            units,title:"Missing equipment",issue:"Missing",status:"Unresolved",recordedBy:report.reportedBy||'',
            notes:conditionIssueNotes(report.reason,report.bookingReference),
            reportedAt:report.reportedAt,reference:`MISS-${String(report.id).padStart(6,'0')}`,
            bookingReference:report.bookingReference||null});
    }
    for(const inspection of inspections){
        active.push({kind:"inspection",key:`inspection-${inspection.allocationId}`,
            equipmentName:inspection.equipmentName,units:inspection.units,
            title:inspection.observedDamageUnits>0?`Return inspection (${inspection.observedDamageUnits} suspected damaged)`:'Previous return inspection',
            issue:inspection.observedDamageUnits>0?"Damage":"Return Inspection",status:"Pending Inspection",
            recordedBy:inspection.receivedBy||'',notes:inspection.notes||'Awaiting Staff condition verification.',
            reportedAt:inspection.reportedAt,reference:`Allocation #${inspection.allocationId}`,
            bookingReference:inspection.bookingReference||null});
    }
    const priority={missing:0,maintenance:1,inspection:2};
    return active.sort((a,b)=>priority[a.kind]-priority[b.kind]||b.reportedAt.localeCompare(a.reportedAt));
}
function ManagerConditionDate({value}:{value:string|null|undefined}) {
    if(!value)return <>—</>;
    const parsed=/^\d{4}-\d{2}-\d{2}$/.test(value)?new Date(`${value}T12:00:00+08:00`):new Date(value);
    return <>{Number.isNaN(parsed.getTime())?'—':parsed.toLocaleDateString('en-PH',{timeZone:'Asia/Manila',month:'short',day:'numeric',year:'numeric'})}</>;
}
// Calendar day (Asia/Manila) of a condition row, read the same way ManagerConditionDate displays it.
function managerConditionDateKey(value:string|null|undefined):string{
    if(!value)return "";
    if(/^\d{4}-\d{2}-\d{2}$/.test(value))return value;
    const parsed=new Date(value);
    return Number.isNaN(parsed.getTime())?"":parsed.toLocaleDateString("sv-SE",{timeZone:"Asia/Manila"});
}
const MANAGER_CONDITION_STATUSES=["Under Repair","Pending Inspection","Unresolved","Repair Completed","Replaced","Recovered"];
type ManagerConditionRow = {
    key:string; bookingReference:string|null; equipmentName:string; units:number; issue:string; status:string; recordedBy:string;
    date:string; entry:ManagerConditionIssue|RentalMaintenanceHistory;
};
// Open issues first (most urgent first), then completed repairs, replacements and recoveries.
function buildManagerConditionRows(issues:ManagerConditionIssue[], history:RentalMaintenanceHistory[]):ManagerConditionRow[] {
    const rows:ManagerConditionRow[]=issues.map(issue=>({key:issue.key,bookingReference:issue.bookingReference,
        equipmentName:issue.equipmentName,units:issue.units,
        issue:issue.issue,status:issue.status,recordedBy:issue.recordedBy,date:issue.reportedAt,entry:issue}));
    for(const record of history){
        rows.push({key:`history-${record.id}`,bookingReference:record.bookingReference||null,
            equipmentName:record.equipmentName,units:record.quantity,
            issue:record.type==='maintenance_completed'?(record.conditionStatus==='Routine'?'Routine Care':'Damage'):'Missing',
            status:record.type==='maintenance_completed'?'Repair Completed':record.type==='missing_replaced'?'Replaced':'Recovered',
            recordedBy:record.actorName||'',date:record.occurredAt,entry:record});
    }
    return rows;
}
function managerConditionStatusClass(status:string){
    if(status==='Unresolved')return 'text-[#A43D48]';
    if(status==='Under Repair'||status==='Pending Inspection')return 'text-[#C27416]';
    return 'text-[#23834A]';
}
function ManagerConditionTable({rows,onView}:{rows:ManagerConditionRow[];onView:(value:ManagerConditionIssue|RentalMaintenanceHistory)=>void}){
    return <div className="min-h-0 flex-1 overflow-y-auto overflow-x-hidden overscroll-contain" role="region" aria-label="Equipment condition records" tabIndex={0}>
        <table className="w-full min-w-0 table-fixed text-center text-[11px] [&_th]:align-middle [&_td]:align-middle [&_th]:whitespace-nowrap [&_th]:overflow-hidden [&_th]:text-ellipsis [&_th]:text-[10px] [&_th]:font-semibold [&_th]:uppercase [&_th]:leading-tight [&_th]:tracking-normal [&_th]:text-[#806A8C] [&_td]:leading-snug [&_td]:[overflow-wrap:anywhere]">
            <colgroup><col className="w-[23%]"/><col className="w-[9%]"/><col className="w-[15%]"/><col className="w-[19%]"/><col className="w-[17%]"/><col className="w-[17%]"/></colgroup>
            <thead className="sticky top-0 z-10 bg-[#FFFCF8] text-[10px] uppercase text-[#806A8C]"><tr className="border-b border-[#E9E1EE]">
                {['Equipment','Units','Issue','Status','Recorded By','Action'].map(label=><th key={label} className="truncate px-2 py-2 text-center text-[10px] font-semibold uppercase tracking-normal text-[#806A8C]">{label}</th>)}
            </tr></thead>
            <tbody>{rows.map(row=><tr key={row.key} className="border-b border-[#EFE8F2] align-top last:border-0 text-[#2B174C]">
                <td className="py-2 px-4 text-left font-semibold">{row.equipmentName}</td>
                <td className="px-2 py-2 text-center font-semibold tabular-nums">{row.units}</td>
                <td className="px-2 py-2 text-center">{row.issue}</td>
                <td className="px-2 py-2 text-center"><p className={`font-semibold ${managerConditionStatusClass(row.status)}`}>{row.status}</p>
                    <p className="mt-1 text-[10px] text-[#86778F]"><ManagerConditionDate value={row.date}/></p></td>
                <td className="px-2 py-2 text-center text-[#5F4E75]">{row.recordedBy||'Not recorded'}</td>
                <td className="px-2 py-2 text-center"><button type="button" onClick={()=>onView(row.entry)}
                                                              className="inline-flex min-h-[30px] w-[100px] max-w-full items-center justify-center rounded-lg border border-[#E2D7FA] bg-[#F4EFFD] px-2 py-1 text-center text-[11px] font-medium leading-4 text-[#5B32C5] transition-colors hover:border-[#C6B2F1] hover:bg-[#EAE0FF] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#6F3FD3]">View Details</button></td>
            </tr>)}</tbody>
        </table>
    </div>;
}
function ManagerConditionDetails({entry,onClose}:{entry:ManagerConditionIssue|RentalMaintenanceHistory;onClose:()=>void}) {
    const issue='kind' in entry;
    const bookingReference=entry.bookingReference||null;
    const date=issue?entry.reportedAt:entry.occurredAt;
    const notes=entry.notes;
    return <div className="fixed inset-0 z-[90] flex items-center justify-center bg-[#160C26]/65 p-4" onClick={onClose} role="presentation">
        <section role="dialog" aria-modal="true" aria-label="Equipment condition details"
                 onClick={event=>event.stopPropagation()} className="w-full max-w-lg rounded-2xl border border-[#E6DDF0] bg-white p-5 shadow-xl">
            <div className="flex items-start justify-between gap-3"><div>
                <h3 className="text-base font-bold text-[#21132E]">{entry.equipmentName}</h3>
                <p className="mt-1 text-xs text-[#806A8C]">{issue?entry.status:entry.type==='maintenance_completed'?'Repair completed':entry.type==='missing_replaced'?'Replacement recorded':'Recovery recorded'}</p>
            </div><button type="button" onClick={onClose} aria-label="Close details" className="rounded-lg border border-[#E6DDF0] p-2 text-[#2B174C] hover:bg-[#F7F1FF]"><X size={17}/></button></div>
            <dl className="mt-4 grid grid-cols-2 gap-x-4 gap-y-3 text-xs">
                <div><dt className="text-[#86778F]">Recorded quantity</dt><dd className="mt-1 font-semibold text-[#21132E]">{issue?entry.units:entry.quantity} unit(s)</dd></div>
                <div><dt className="text-[#86778F]">Recorded date</dt><dd className="mt-1 font-semibold text-[#21132E]"><ManagerConditionDate value={date}/></dd></div>
                <div><dt className="text-[#86778F]">Booking Reference</dt><dd className="mt-1 break-all font-semibold text-[#21132E]">{bookingReference||'—'}</dd></div>
                <div><dt className="text-[#86778F]">{issue?'Issue type':'Recorded by'}</dt><dd className="mt-1 font-semibold text-[#21132E]">{issue?entry.title:entry.actorName||'Not recorded'}</dd></div>
            </dl>
            <div className="mt-4 rounded-xl border border-[#E9E1EE] bg-[#FCFAFF] p-3">
                <p className="text-xs font-semibold text-[#21132E]">{issue?'Incident / condition notes':'Staff activity notes'}</p>
                <p className="mt-1 whitespace-pre-wrap break-words text-xs leading-5 text-[#5F4E75]">{notes||'No notes recorded.'}</p>
            </div>
        </section>
    </div>;
}
// Delete Rental Product mirrors the Consumable Delete Product dialog. The Rental
// backend (archive_equipment) re-checks every restriction when confirmed, keeps
// bookings and history, and records any remaining units as Stock Out. Rental
// products are always removed from the active list, never hard-deleted.
const RENTAL_PRODUCT_DELETE_REASON = "Deleted from the active rental inventory list.";
function RetireEquipmentDialog({item,saving,close,onSave}:{
    item:RentalEquipment;saving:boolean;close:()=>void;onSave:(mutation:RentalMutation)=>Promise<void>;
}) {
    const [error,setError]=React.useState("");
    const [submitting,setSubmitting]=React.useState(false);
    const submittingRef=React.useRef(false);
    // The same restrictions the backend enforces before deletion.
    const blockers=[
        ...(item.rentedOutUnits>0?[`${item.rentedOutUnits} unit(s) are out on rental. Complete the rental return first.`]:[]),
        ...(item.maintenanceUnits>0?[`${item.maintenanceUnits} unit(s) are on hold for inspection, cleaning, or repair. Finish the equipment care first.`]:[]),
        ...(item.missingUnits>0?[`${item.missingUnits} unit(s) are reported missing. Resolve the missing report first.`]:[]),
    ];
    const blocked=blockers.length>0;
    const confirmDelete=async()=>{
        if(blocked||saving||submittingRef.current)return;
        submittingRef.current=true;setSubmitting(true);setError("");
        // confirmName is the selected product's current name; the backend rejects the
        // request if it no longer matches this equipment ID (wrong or renamed product).
        try{await onSave({action:"archive_equipment",equipmentId:item.id,confirmName:item.name,reason:RENTAL_PRODUCT_DELETE_REASON});}
        catch(cause){setError(cause instanceof Error?cause.message:"Unable to delete this rental product.");}
        finally{submittingRef.current=false;setSubmitting(false);}
    };
    return <div className="fixed inset-0 z-[150] flex items-center justify-center bg-black/40 px-4 backdrop-blur-sm" role="presentation">
        <div role="dialog" aria-modal="true" aria-label="Delete Rental Product" className="w-full max-w-xl rounded-2xl bg-white p-5 shadow-xl sm:p-6">
            <div className="flex items-start justify-between gap-4">
                <div>
                    <h3 className="text-[18px] font-bold text-[#1A1220]">Delete Rental Product</h3>
                    <p className="mt-1 text-sm text-[#6A5D6F]">StockNBook checks business usage before removing{" "}
                        <span className="font-semibold text-[#1A1220]">{item.name}</span>.</p>
                </div>
                <button type="button" onClick={close} disabled={submitting} aria-label="Close rental product removal dialog"
                        className="shrink-0 text-[#9B8AAA] hover:text-[#1A1220]">✕</button>
            </div>
            <div className="mt-4">
                {blocked ? (
                    <div className="rounded-xl border border-[#F1D39D] bg-[#FFF8E8] px-4 py-3">
                        <p className="text-sm font-semibold text-[#9A6500]">This rental product cannot be removed yet.</p>
                        <div className="mt-1 space-y-1 text-xs leading-5 text-[#785C27]">
                            {blockers.map(blocker=><p key={blocker}>• {blocker}</p>)}
                        </div>
                        <p className="mt-2 text-xs leading-5 text-[#785C27]">Resolve the rented-out, on-hold, or missing units before removing the product.</p>
                    </div>
                ) : (
                    <div className="rounded-xl border border-[#D8CBE9] bg-[#F8F3FF] px-4 py-3">
                        <p className="text-sm font-semibold text-[#4E2C66]">This rental product will be deleted from the active inventory list.</p>
                        <p className="mt-1 text-xs leading-5 text-[#6A5D6F]">It will disappear from future bookings, restocks, and active rental inventory selections,
                            while historical bookings, reports, and stock activity remain preserved. Any remaining units will be recorded as Stock Out.</p>
                        {item.totalUnits>0&&<p className="mt-2 text-xs font-semibold leading-5 text-[#69402A]">
                            {item.totalUnits} remaining unit(s) will be deducted as Stock Out. Confirm only if they are being removed from service.</p>}
                        <p className="mt-2 text-xs font-medium text-[#5A476A]">Products with active or upcoming booking reservations cannot be removed; this is checked again when you confirm.</p>
                    </div>
                )}
                {error&&<div role="alert" className="mt-3 rounded-xl border border-[#F2C7CC] bg-[#FFF3F4] px-4 py-3">
                    <p className="text-sm font-semibold text-[#B42335]">Product removal could not be completed.</p>
                    <p className="mt-1 text-xs leading-5 text-[#7F5960]">{error}</p>
                </div>}
            </div>
            <div className="mt-5 flex justify-end gap-2">
                <button type="button" onClick={close} disabled={submitting}
                        className="rounded-xl border border-[#E6DDF0] bg-white px-4 py-2 text-sm font-medium text-[#6A5D6F] hover:bg-[#F7F1FF]">Cancel</button>
                <button type="button" disabled={saving||submitting||blocked} onClick={()=>void confirmDelete()}
                        className="rounded-xl bg-[#2B174C] px-4 py-2 text-sm font-semibold text-white transition hover:bg-[#1B0D31] disabled:cursor-not-allowed disabled:opacity-40">
                    {submitting?"Deleting...":blocked?"Removal Blocked":"Delete Product"}</button>
            </div>
        </div>
    </div>;
}

function PanelHeading({title,subtitle,icon,actions}:{title:string;subtitle:string;icon:React.ReactNode;actions?:React.ReactNode}) {
    return <div className="flex min-w-0 flex-col gap-2 border-b border-[#E9E1EE] px-4 py-3.5 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex min-w-0 flex-1 items-start gap-3">
            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-[10px] bg-[#F1EBFF] text-[#5A35A5]">{icon}</span>
            <div className="min-w-0"><h2 className="text-[15px] font-bold text-[#21132E]">{title}</h2>
                <p className="mt-0.5 text-[11px] text-[#86778F]">{subtitle}</p></div>
        </div>
        {actions && <div className="flex shrink-0 items-center justify-end">{actions}</div>}
    </div>;
}
function EmptyPanel({label}:{label:string}) {
    return <div className="flex min-h-[156px] flex-col items-center justify-center gap-2 px-5 py-8 text-center">
        <Boxes size={24} className="text-[#9C8EB8]"/><p className="text-xs text-[#86778F]">{label}</p></div>;
}
function PanelSkeleton() {
    return <div aria-label="Loading rental inventory" className="space-y-3 px-4 py-5">
        {[0,1,2].map(index => <div key={index} className="h-8 animate-pulse rounded-lg bg-[#F3EFF8]"/>)}
    </div>;
}
function RentalMetric({label,value,description,icon,tone,loading}: {
    label:string; value:RentalSummary[keyof RentalSummary]; description:string;
    icon:React.ReactNode; tone:"purple"|"green"|"blue"|"amber"; loading:boolean;
}) {
    const iconClassName = {
        purple:"bg-[#F1ECFF] text-[#5F35D8]",
        green:"bg-[#E5F8EC] text-[#23834A]",
        blue:"bg-[#E9F2FF] text-[#1E6FE8]",
        amber:"bg-[#FFF3DE] text-[#E68A00]",
    }[tone];
    return (
        <section aria-busy={loading} className="flex min-h-[146px] min-w-0 w-full items-center gap-4 rounded-[16px] border border-[#E6DDF0] bg-white px-5 py-4 text-left shadow-sm">
            {loading ? <>
                <span className="h-14 w-14 shrink-0 animate-pulse rounded-full bg-[#EEE8F3]" aria-hidden="true"/>
                <span className="min-w-0 flex-1 space-y-2.5" role="status" aria-label={`Loading ${label}`}>
                    <span className="block h-3.5 w-32 max-w-full animate-pulse rounded-lg bg-[#EEE8F3]"/>
                    <span className="block h-7 w-24 max-w-full animate-pulse rounded-lg bg-[#EEE8F3]"/>
                    <span className="block h-2.5 w-40 max-w-full animate-pulse rounded-lg bg-[#EEE8F3]"/>
                </span>
            </> : <>
                <span className={`flex h-14 w-14 shrink-0 items-center justify-center rounded-full ${iconClassName}`} aria-hidden="true">{icon}</span>
                <span className="min-w-0 flex-1">
                    <span className="block text-[14px] font-semibold leading-5 text-[#4B3E55]">{label}</span>
                    <span className="mt-1 block break-words text-[28px] font-bold leading-tight tracking-[-0.03em] text-[#1A1220] tabular-nums">{value === null ? "—" : value.toLocaleString("en-PH")}</span>
                    <span className="mt-2 block text-[11px] leading-4 text-[#8A7D92]">{description}</span>
                </span>
            </>}
        </section>
    );
}
function ActivityRow({item}:{item:RentalActivity}) {
    const isPositive = rentalActivityDirection(item) === "in";
    const actionReason = item.type === "received" ? "Restocked" :
        item.type === "missing_replaced" ? "Replaced" :
            item.type === "returned" ? "Returned items" :
                item.type === "rented_out" ? "Released" : "Deleted";
    const when = new Date(item.occurredAt);
    return <tr className="border-b border-[#EFE8F2] last:border-0">
        <td className="whitespace-nowrap py-2 text-[#5F4E75] px-4 text-left">
            {when.toLocaleDateString("en-PH",{timeZone:"Asia/Manila",month:"short",day:"numeric",year:"numeric"})}
            <div className="mt-0.5 text-[10px] text-[#8A7D90]">{when.toLocaleTimeString("en-PH",{timeZone:"Asia/Manila",hour:"numeric",minute:"2-digit"})}</div>
        </td>
        <td className="px-2 py-2 font-semibold text-[#2B174C]">{item.equipmentName}</td>
        <td title={actionReason} className={`px-2 py-2 text-center font-medium ${isPositive ? "text-[#23834A]" : "text-[#D92C3F]"}`}>
            {isPositive ? "Stock In" : "Stock Out"}
        </td>
        <td className={`px-2 py-2 text-center font-semibold ${isPositive ? "text-[#23834A]" : "text-[#D92C3F]"}`}>
            {isPositive ? "+" : "−"}{item.quantity}
        </td>
        <td className="break-all px-2 py-2 text-[#5F4E75]">{item.referenceNumber || "—"}</td>
    </tr>;
}

type EditorMode = "add"|"edit"|"receive"|"maintenance"|"review"|"correct";
/* Add/Edit follows Sales Inventory's sections, spacing, category dropdown,
 * pricing and confirmation. Rentals have no variants or reorder point. */
const rentalFieldClass = "w-full rounded-xl border border-[#E3D8EA] bg-white p-3 text-sm text-[#1A1220] placeholder:text-[#9B8AAA] focus:border-[#2B174C] focus:outline-none focus:ring-1 focus:ring-[#2B174C]";
const rentalLabelClass = "text-xs font-semibold text-[#5A476A]";
function validRentalMoney(value:string) {
    return /^\d+(?:\.\d{1,2})?$/.test(value.trim()) && Number(value) <= 100000000;
}
function rentalToday() { return new Date().toLocaleDateString("sv-SE",{timeZone:"Asia/Manila"}); }
function validRentalDate(value:string) {
    if(!/^\d{4}-\d{2}-\d{2}$/.test(value))return false;
    const parsed=new Date(`${value}T00:00:00Z`);
    return Number.isFinite(parsed.getTime())&&parsed.toISOString().slice(0,10)===value;
}
function EquipmentDialog({mode,item,close,onNavigate,onSave,saving,categories,equipment=[],onDelete}:{
    mode:EditorMode;item:RentalEquipment|null;close:()=>void;
    onNavigate:(mode:EditorMode)=>void;onSave:(mutation:RentalMutation)=>Promise<void>;saving:boolean;
    categories:string[];
    // Edit Rental Product only: duplicate-name check and the dialog's Delete Product button.
    equipment?:RentalEquipment[];onDelete?:()=>void;
}) {
    const [name,setName]=React.useState(item?.name||"");
    const [category,setCategory]=React.useState(item?.category||"");
    const [quantity,setQuantity]=React.useState(mode==="add"?"0":(mode==="correct"||mode==="edit")?String(item?.totalUnits??0):"");
    const [physicalCountVerified,setPhysicalCountVerified]=React.useState(false);
    const [unitCost,setUnitCost]=React.useState("");
    const [rentalRate,setRentalRate]=React.useState(item?.rentalRatePerDay==null?"":String(item.rentalRatePerDay));
    const [reason,setReason]=React.useState("");
    const [maintenanceMode,setMaintenanceMode]=React.useState<"start"|"complete">("start");
    const [conditionStatus,setConditionStatus]=React.useState<"In Repair"|"For Inspection">("In Repair");
    const [estimatedCompletionDate,setEstimatedCompletionDate]=React.useState("");
    const [error,setError]=React.useState("");
    const [pending,setPending]=React.useState<RentalMutation|null>(null);
    const [submitting,setSubmitting]=React.useState(false);
    const submittingRef=React.useRef(false);
    const qty=Number(quantity);
    const limited=maintenanceMode==="start"?(item?availableNow(item):0):(item?.maintenanceUnits??0);
    const purchaseTotal=qty*Number(unitCost||0);
    const title=mode==="add"?"Add Rental Equipment":mode==="edit"?"Edit Rental Equipment":
        mode==="correct"?"Correct Equipment Stock":mode==="maintenance"?"Manage Maintenance":"Equipment Stock Review";

    const purchaseDetails=():RentalPurchaseDetails|null=>{
        if(!Number.isSafeInteger(qty)||qty<1||qty>2147483647||!validRentalMoney(unitCost)){
            setError("Enter a valid received quantity and unit cost.");return null;
        }
        if(!Number.isSafeInteger(Math.round(purchaseTotal*100))||purchaseTotal>100000000000){
            setError("The purchase total is too large.");return null;
        }
        return {quantity:qty,unitCost:Number(unitCost)};
    };
    const prepare=(event:React.FormEvent)=>{
        event.preventDefault();setError("");if(saving||submitting||pending)return;
        let mutation:RentalMutation;
        if(mode==="add"||mode==="edit"){
            if(!name.trim()||name.trim().length>150||!category.trim()){
                setError("Enter a product name and select a category.");return;
            }
            if(!validRentalMoney(rentalRate)){
                setError("Rental Rate must be a nonnegative amount with up to two decimals.");return;
            }
            // Same rule as Consumable Edit Product: names are unique among active products
            // in the branch. The Rental backend still enforces this when saving.
            if(mode==="edit"&&equipment.some(other=>other.active&&other.id!==item?.id&&
                other.name.trim().toLowerCase()===name.trim().toLowerCase())){
                setError(`Rental product “${name.trim()}” already exists in this branch.`);return;
            }
            if(mode==="add"){
                if(!Number.isSafeInteger(qty)||qty<0||qty>2147483647){
                    setError("Stock must be a nonnegative whole number.");return;
                }
                const purchase=qty>0?purchaseDetails():undefined;
                if(qty>0&&!purchase)return;
                mutation={action:"create_equipment",name:name.trim(),category:category.trim(),
                    alertLevel:0,rentalRatePerDay:Number(rentalRate), pricingMethod:"manual",
                    ...(purchase?{initialPurchase:purchase}:{})};
            }else{
                // Stock (Units) is edited directly. A changed count is an audited physical stock
                // correction (never a restock), saved only by this Update Product request.
                if(quantity.trim()===""||!Number.isSafeInteger(qty)||qty<0||qty>2147483647){
                    setError("Stock must be a nonnegative whole number.");return;
                }
                const stockChanged=qty!==item!.totalUnits;
                if(stockChanged&&(reason.trim().length<10||!physicalCountVerified)){
                    setError("Explain the stock count correction (10+ characters) and confirm the physical count.");return;
                }
                mutation={action:"update_equipment",equipmentId:item!.id,name:name.trim(),category:category.trim(),
                    alertLevel:item!.alertLevel,rentalRatePerDay:Number(rentalRate), pricingMethod:"manual",
                    ...(stockChanged?{totalUnits:qty,expectedTotalUnits:item!.totalUnits,
                        reason:reason.trim(),physicalCountVerified:true as const}:{})};
            }
        }else if(mode==="correct"&&item){
            if(!Number.isSafeInteger(qty)||qty<0||qty>2147483647||qty===item.totalUnits){
                setError("Enter a different, nonnegative whole-number physical count.");return;
            }
            if(reason.trim().length<10||!physicalCountVerified){
                setError("Explain the corrected stock count (10+ characters) and verify the physical count.");return;
            }
            mutation={action:"correct_equipment_stock",equipmentId:item.id,totalUnits:qty,
                reason:reason.trim(),physicalCountVerified:true};
        }else if(mode==="maintenance"&&item){
            if(!Number.isSafeInteger(qty)||qty<1||qty>limited||reason.trim().length<5){
                setError(`Enter 1–${limited} units and a reason of at least 5 characters.`);return;
            }
            if(maintenanceMode==="start" && estimatedCompletionDate &&
                (!validRentalDate(estimatedCompletionDate) || estimatedCompletionDate<rentalToday())){
                setError("Estimated completion must be today or a future date.");return;
            }
            mutation=maintenanceMode==="start"
                ? {action:"start_maintenance",equipmentId:item.id,quantity:qty,reason:reason.trim(),
                    conditionStatus,estimatedCompletionDate:estimatedCompletionDate||null}
                : {action:"complete_maintenance",equipmentId:item.id,quantity:qty,reason:reason.trim()};
        }else{return;}
        setPending(mutation);
    };
    const confirm=async()=>{
        if(!pending||submittingRef.current||saving)return;
        submittingRef.current=true;setSubmitting(true);setError("");
        try{await onSave(pending);setPending(null);}
        catch(cause){setPending(null);setError(cause instanceof Error?cause.message:"Unable to save equipment.");}
        finally{submittingRef.current=false;setSubmitting(false);}
    };
    const btn="rounded-xl bg-[#2B174C] px-5 py-3 text-sm font-semibold text-white hover:bg-[#1B0D31] disabled:opacity-40";
    // Edit Rental Product uses the Consumable Edit Product layout, buttons and
    // confirmation. It shares this dialog's state, validation and save logic.
    // Rental products have no variants; stock stays read-only (Restock / Correct Stock Count).
    if(mode==="edit"&&item){
        const editStockValid=quantity.trim()!==""&&Number.isSafeInteger(qty)&&qty>=0&&qty<=2147483647;
        const editStockChanged=!(editStockValid&&qty===item.totalUnits);
        return <>
            <div className="fixed inset-0 z-[140] flex items-center justify-center bg-black/40 px-4 backdrop-blur-sm" role="presentation">
                <div role="dialog" aria-modal="true" aria-label="Edit Rental Product"
                     className="max-h-[90vh] w-full max-w-5xl overflow-y-auto rounded-2xl bg-white p-5 shadow-xl sm:p-6">
                    <div className="mb-4 flex items-center justify-between">
                        <h2 className="text-[18px] font-bold text-[#1A1220]">Edit Rental Product</h2>
                        <button type="button" onClick={close} disabled={submitting} aria-label="Close" className="text-[#9B8AAA] hover:text-[#1A1220]">✕</button>
                    </div>
                    <form onSubmit={prepare} className="space-y-3">
                        <div className="rounded-xl bg-[#F7F1FF] px-3 py-2 text-xs font-medium text-[#4E2C66]">Product No.: {item.equipmentNumber || "—"} · {item.name}</div>
                        <h3 className="pt-2 text-sm font-bold text-[#1A1220]">Product Information</h3>
                        <div className="space-y-1"><label className={rentalLabelClass}>Rental Product Name</label>
                            <input required maxLength={150} value={name} onChange={e=>setName(e.target.value)} className={rentalFieldClass} placeholder="Enter rental product name"/></div>
                        <div className="space-y-1"><label className={rentalLabelClass}>Category</label>
                            <select required value={category} onChange={e=>setCategory(e.target.value)} className={rentalFieldClass}>
                                <option value="">Select category</option>{categories.map(value=><option key={value} value={value}>{value}</option>)}
                            </select>
                            {categories.length===0&&<p className="text-[11px] text-[#9B8AAA]">Create a rental category in Manage Categories first.</p>}
                        </div>
                        <h3 className="border-t border-[#E6DDF0] pt-5 text-sm font-bold text-[#1A1220]">Inventory &amp; Pricing</h3>
                        <div className="grid grid-cols-2 gap-2">
                            <div className="space-y-1"><label className={rentalLabelClass}>Stock (Units)</label>
                                <input type="number" min="0" max="2147483647" step="1" required value={quantity}
                                       onChange={e=>setQuantity(e.target.value)} className={rentalFieldClass}/></div>
                            <div className="space-y-1"><label className={rentalLabelClass}>Average Unit Cost</label>
                                <input readOnly className={`${rentalFieldClass} bg-[#F7F1FF]`} value={peso(item.averageUnitCost)}/></div>
                        </div>
                        <p className="text-[11px] text-[#9B8AAA]">Change Stock only to correct a verified physical count. Record newly received equipment through Restock. Changes are saved only when you click Update Product.</p>
                        {editStockChanged&&<section className="space-y-3 rounded-xl border border-[#E6DDF0] bg-[#FFFCF8] p-4" aria-label="Stock count correction">
                            <h4 className="text-sm font-bold text-[#21132E]">Stock Count Correction</h4>
                            <p className="text-[11px] text-[#806A8C]">Current total: <strong>{item.totalUnits}</strong> · New total: <strong>{editStockValid?qty:"—"}</strong>
                                {editStockValid&&<> · Difference: <strong>{qty-item.totalUnits>0?"+":""}{qty-item.totalUnits}</strong></>}.
                                {" "}Confirmed reservations, rented-out, held and missing units stay protected. This is recorded as an audited correction, not a restock.</p>
                            <div className="space-y-1"><label className={rentalLabelClass}>Reason / Physical Count Evidence</label>
                                <textarea required minLength={10} maxLength={500} rows={3} className={rentalFieldClass} value={reason} onChange={e=>setReason(e.target.value)}
                                          placeholder="Explain the verified recount and why the previous quantity was incorrect"/></div>
                            <label className="flex items-center gap-2 text-xs font-medium text-[#5A476A]">
                                <input type="checkbox" checked={physicalCountVerified} onChange={e=>setPhysicalCountVerified(e.target.checked)}/>
                                I physically verified these units; this is not a new delivery.
                            </label>
                        </section>}
                        <div className="space-y-1"><label className={rentalLabelClass}>Rental Rate (₱ / item)</label>
                            <input type="number" min="0" max="100000000" step="0.01" required value={rentalRate}
                                   onChange={e=>setRentalRate(e.target.value)}
                                   className={rentalFieldClass} placeholder="Enter rental rate"/>
                        </div>
                        {error&&<p role="alert" className="rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-700">{error}</p>}
                        <div className="grid grid-cols-1 gap-2 pt-1 sm:grid-cols-2">
                            <button type="button" onClick={onDelete} disabled={!onDelete||submitting}
                                    className="w-full rounded-xl border border-red-200 bg-red-50 py-3 text-sm font-semibold text-red-600 transition hover:bg-red-100 disabled:opacity-40">
                                <span className="inline-flex items-center justify-center gap-2"><Trash2 size={15}/>DELETE PRODUCT</span>
                            </button>
                            <button type="submit" disabled={saving||submitting}
                                    className="w-full rounded-xl bg-[#2B174C] py-3 text-sm font-semibold text-white transition hover:bg-[#1B0D31] disabled:opacity-40">UPDATE PRODUCT</button>
                        </div>
                    </form>
                </div>
            </div>
            {pending&&<div className="fixed inset-0 z-[160] flex items-center justify-center bg-black/40 px-4 backdrop-blur-sm" role="presentation">
                <div role="alertdialog" aria-modal="true" aria-label="Confirm rental product update"
                     className="max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-2xl bg-white p-5 shadow-xl sm:p-6">
                    <div className="mb-3 flex items-start justify-between gap-4">
                        <div>
                            <h3 className="text-[19px] font-bold text-[#1A1220]">Update Product</h3>
                            <p className="mt-1 text-sm text-[#6A5D6F]">Are you sure you want to save this product?</p>
                            {pending.action==="update_equipment"&&pending.totalUnits!==undefined&&<p className="mt-2 text-xs font-semibold text-[#69402A]">
                                Stock will be corrected from {item.totalUnits} to {pending.totalUnits} units as an audited stock correction, not a restock.</p>}
                        </div>
                        <button type="button" disabled={submitting} onClick={()=>setPending(null)} aria-label="Close confirmation" className="text-[#9B8AAA] hover:text-[#1A1220]">✕</button>
                    </div>
                    <div className="mt-4 flex justify-end gap-2">
                        <button type="button" disabled={submitting} onClick={()=>setPending(null)}
                                className="rounded-xl border border-[#E6DDF0] bg-white px-4 py-2 text-sm font-medium text-[#6A5D6F] hover:bg-[#F7F1FF]">Cancel</button>
                        <button type="button" disabled={saving||submitting} onClick={()=>void confirm()}
                                className="rounded-xl bg-[#2B174C] px-4 py-2 text-sm font-semibold text-white hover:bg-[#1B0D31] disabled:opacity-40">{submitting?"Saving...":"Update Product"}</button>
                    </div>
                </div>
            </div>}
        </>;
    }
    return <div className="fixed inset-0 z-[140] flex items-center justify-center bg-black/40 px-3 py-4 backdrop-blur-sm" role="presentation">
        <div role="dialog" aria-modal="true" aria-label={title} className="flex max-h-[90vh] w-full max-w-5xl flex-col overflow-hidden rounded-2xl bg-white shadow-xl">
            <div className="flex items-center justify-between border-b border-[#E6DDF0] px-5 py-4 sm:px-6">
                <h2 className="text-[18px] font-bold text-[#1A1220]">{title}</h2>
                <button type="button" onClick={close} disabled={submitting} aria-label="Close" className="text-[#9B8AAA] hover:text-[#1A1220]"><X size={20}/></button>
            </div>
            <form onSubmit={prepare} className="min-h-0 space-y-5 overflow-y-auto p-5 sm:p-6">
                {item&&<div className="rounded-xl bg-[#F7F1FF] px-3 py-2 text-xs font-semibold text-[#4E2C66]">Product No.: {item.equipmentNumber} · {item.name}</div>}
                {mode==="review"&&item&&<>
                    <h3 className="text-sm font-bold text-[#1A1220]">Rental Equipment Summary</h3>
                    <div className="grid gap-3 rounded-xl border border-[#E6DDF0] bg-[#FFFCF7] p-4 sm:grid-cols-3">
                        {[["Total Units",item.totalUnits],["Available Now",availableNow(item)],
                            ["Rented Out",item.rentedOutUnits],["Under Maintenance",item.maintenanceUnits],
                            ["Missing Units",item.missingUnits],["Rental Rate",peso(item.rentalRatePerDay)],
                            ["Average Unit Cost",peso(item.averageUnitCost)]].map(([label,value])=><div key={label}>
                            <p className="text-xs text-[#86778F]">{label}</p><strong className="text-sm text-[#2B174C]">{value}</strong></div>)}
                    </div>
                    <p className="mb-3 text-xs text-[#86778F]">Pricing: {item.pricingMethod==="cost_based"?"Suggested Cost-Based Rate":"Manual Rental Rate"}. Rental rates are reviewed by the manager; equipment age does not automatically reduce customer charges.</p>
                    {hasRentalStockDiscrepancy(item)&&<p role="alert" className="rounded-xl bg-red-50 p-3 text-xs text-red-700">Assigned units exceed physical stock. Review booking, repair and missing records before correcting.</p>}
                    <p className="text-xs text-[#86778F]">Staff handle rental check-outs and returns through the booking workflow. The manager maintains equipment, pricing and repairs.</p>
                    <div className="flex flex-wrap gap-2">
                        <button type="button" onClick={()=>onNavigate("edit")} className={btn}><Pencil size={14} className="mr-1 inline"/> Edit Product</button>
                        <button type="button" onClick={()=>onNavigate("receive")} className={btn}><PackagePlus size={14} className="mr-1 inline"/> Restock Equipment</button>
                        <button type="button" onClick={()=>onNavigate("correct")} className={btn}>Correct Stock Count</button>
                        <button type="button" onClick={()=>onNavigate("maintenance")} className={btn}><Wrench size={14} className="mr-1 inline"/> Maintenance</button>
                    </div>
                </>}
                {(mode==="add"||mode==="edit")&&<>
                    <h3 className="text-sm font-bold text-[#1A1220]">Product Information</h3>
                    <div className="space-y-1"><label className={rentalLabelClass}>Rental Product Name</label>
                        <input required maxLength={150} value={name} onChange={e=>setName(e.target.value)} className={rentalFieldClass} placeholder="Enter rental product name"/></div>
                    <div className="space-y-1"><label className={rentalLabelClass}>Category</label>
                        <select required value={category} onChange={e=>setCategory(e.target.value)} className={rentalFieldClass}>
                            <option value="">Select category</option>{categories.map(value=><option key={value} value={value}>{value}</option>)}
                        </select>
                        {categories.length===0&&<p className="text-xs text-[#9B8AAA]">Create a rental category in Manage Categories first.</p>}
                    </div>
                    <h3 className="border-t border-[#E6DDF0] pt-5 text-sm font-bold text-[#1A1220]">Inventory &amp; Pricing</h3>
                    <div className="grid gap-3 sm:grid-cols-2">
                        <div className="space-y-1"><label className={rentalLabelClass}>Stock (Units)</label>
                            <input type="number" min="0" step="1" required readOnly={mode==="edit"} value={mode==="edit"?item?.totalUnits??0:quantity}
                                   title={mode==="edit"?"Record only equipment that was physically received through Restock":undefined}
                                   onChange={e=>setQuantity(e.target.value)} className={rentalFieldClass}/>
                            {mode==="edit"&&<div className="space-y-2"><p className="text-xs text-[#9B8AAA]">Stock is read-only here. Record physically received equipment through Restock; verified count errors use a separate audited correction.</p>
                                <button type="button" onClick={()=>onNavigate("correct")} className="rounded-lg border border-[#D9CDF0] bg-[#F5F0FF] px-3 py-2 text-xs font-semibold text-[#5330B6] hover:bg-[#ECE3FF]">Correct Stock Count</button>
                            </div>}
                        </div>
                        {mode==="add"&&<div className="space-y-1"><label className={rentalLabelClass}>Cost Price (₱ / unit)</label>
                            <input type="number" min="0" step="0.01" required={qty>0} disabled={qty===0} value={unitCost} onChange={e=>setUnitCost(e.target.value)} className={rentalFieldClass} placeholder="0.00"/></div>}
                        {mode==="edit"&&<div className="space-y-1"><label className={rentalLabelClass}>Average Unit Cost</label>
                            <input readOnly className={`${rentalFieldClass} bg-[#F7F1FF]`} value={peso(item?.averageUnitCost)}/></div>}
                        <div className="space-y-1 sm:col-span-2"><label className={rentalLabelClass}>Rental Rate (₱ / item)</label>
                            <input type="number" min="0" max="100000000" step="0.01" required value={rentalRate}
                                   onChange={e=>setRentalRate(e.target.value)}
                                   className={rentalFieldClass} placeholder="Enter rental rate"/>
                        </div>
                    </div>
                    {mode==="edit"&&<p className="text-xs text-[#86778F]">Use Restock for newly received units; do not count deliveries that have not arrived.</p>}
                </>}
                {mode==="correct"&&item&&<section className="space-y-4 rounded-xl border border-[#E6DDF0] bg-[#FFFCF8] p-4">
                    <h3 className="text-sm font-bold text-[#21132E]">Physical Count Correction</h3>
                    <p className="text-xs text-[#806A8C]">Use only after a verified physical recount. This is NOT a restock or rental return. Existing confirmed reservations, rented-out units and held equipment remain protected.</p>
                    <p className="text-xs text-[#5A476A]">Current total units: <strong>{item.totalUnits}</strong> · Physically ready: <strong>{availableNow(item)}</strong> · Available today: <strong>{item.bookableToday}</strong></p>
                    <label className="block space-y-1"><span className={rentalLabelClass}>Corrected Total Units</span>
                        <input required type="number" min="0" max="2147483647" step="1" className={rentalFieldClass} value={quantity} onChange={e=>setQuantity(e.target.value)}/>
                    </label>
                    <label className="block space-y-1"><span className={rentalLabelClass}>Reason / Physical Count Evidence</span>
                        <textarea required minLength={10} maxLength={500} rows={3} className={rentalFieldClass} value={reason} onChange={e=>setReason(e.target.value)} placeholder="Explain the verified recount and why the previous quantity was incorrect"/>
                    </label>
                    <label className="flex items-center gap-2 text-xs font-medium text-[#5A476A]">
                        <input type="checkbox" checked={physicalCountVerified} onChange={e=>setPhysicalCountVerified(e.target.checked)}/>
                        I physically verified these units; this is not a new delivery.
                    </label>
                </section>}
                {mode==="maintenance"&&item&&<>
                    <h3 className="text-sm font-bold text-[#1A1220]">Equipment Inspection &amp; Repair</h3>
                    <div className="space-y-1"><label className={rentalLabelClass}>Maintenance Action</label>
                        <select className={rentalFieldClass} value={maintenanceMode} onChange={e=>{setMaintenanceMode(e.target.value as "start"|"complete");setQuantity("");}}>
                            <option value="start">Move available units into maintenance</option><option value="complete">Return repaired units to available</option>
                        </select></div>
                    <p className="text-xs text-[#86778F]">Maximum eligible units: {limited}. Checked-out and missing equipment cannot enter maintenance.</p>
                    <div className="space-y-1"><label className={rentalLabelClass}>Quantity</label>
                        <input type="number" min="1" max={limited} required step="1" className={rentalFieldClass} value={quantity} onChange={e=>setQuantity(e.target.value)}/></div>
                    <div className="space-y-1"><label className={rentalLabelClass}>Inspection / Repair Notes</label>
                        <textarea required className={`${rentalFieldClass} min-h-24`} value={reason} onChange={e=>setReason(e.target.value)} placeholder="Reason and inspection details"/></div>
                    {maintenanceMode==="start"&&<div className="grid gap-3 sm:grid-cols-2">
                        <div className="space-y-1"><label className={rentalLabelClass}>Condition Status</label>
                            <select className={rentalFieldClass} value={conditionStatus} onChange={e=>setConditionStatus(e.target.value as typeof conditionStatus)}>
                                <option value="In Repair">In Repair</option><option value="For Inspection">For Inspection</option>
                            </select></div>
                        <div className="space-y-1"><label className={rentalLabelClass}>Estimated Completion (Optional)</label>
                            <input type="date" min={rentalToday()} className={rentalFieldClass}
                                   value={estimatedCompletionDate} onChange={e=>setEstimatedCompletionDate(e.target.value)}/>
                        </div>
                    </div>}
                </>}
                {error&&<p role="alert" className="rounded-xl border border-red-200 bg-red-50 p-3 text-xs text-red-700">{error}</p>}
                <div className="flex justify-end gap-2 border-t border-[#E6DDF0] pt-4">
                    <button type="button" disabled={submitting} onClick={close} className="rounded-xl border border-[#E6DDF0] px-5 py-3 text-sm font-medium text-[#6A5D6F] hover:bg-[#F7F1FF]">{mode==="review"?"Close":"Cancel"}</button>
                    {mode!=="review"&&<button type="submit" disabled={saving||submitting||(mode==="maintenance"&&limited===0)} className={btn}>
                        {mode==="add"?"Save Equipment":mode==="edit"?"Update Equipment":mode==="correct"?"Save Correction":"Save Maintenance"}</button>}
                </div>
            </form>
        </div>
        {pending&&<div className="fixed inset-0 z-[160] flex items-center justify-center bg-[#21132E]/55 p-3 sm:p-4" role="presentation">
            <div role="alertdialog" aria-modal="true" aria-label="Confirm rental inventory changes" className="w-full max-w-md space-y-4 rounded-2xl bg-white p-6 shadow-2xl">
                <h3 className="text-lg font-bold text-[#1A1220]">{mode==="add"?"Confirm Add Equipment":mode==="edit"?"Confirm Update":mode==="correct"?"Confirm Stock Correction":"Confirm Maintenance"}</h3>
                <p className="text-sm text-[#6A5D6F]">{mode==="add"?`Add ${name.trim()} to rental inventory${qty>0 ? ` with ${qty} physically received units` : ""}?`:mode==="edit"?`Save the changes to ${name.trim()}?`:mode==="correct"?`Change the verified physical total of ${item?.name} from ${item?.totalUnits} to ${qty} units? Confirmed reservations and held units are protected.`:`Record this maintenance action for ${item?.name}?`}</p>
                <div className="flex justify-end gap-2"><button type="button" disabled={submitting} onClick={()=>setPending(null)} className="rounded-xl border border-[#E6DDF0] px-4 py-2 text-sm">Cancel</button>
                    <button type="button" disabled={saving||submitting} onClick={()=>void confirm()} className="rounded-xl bg-[#2B174C] px-4 py-2 text-sm font-semibold text-white disabled:opacity-40">{submitting?"Saving...":"Confirm"}</button></div>
            </div>
        </div>}
    </div>;
}

/* Restock mirrors Consumable Inventory's Receive Stock: it only adds quantity.
 * Rental equipment has no variants, so there is always exactly one line, and
 * equipment does not expire, so there is no expiration date. */
function RentalReceiveStockDialog({item,saving,close,onSave}:{
    item:RentalEquipment;saving:boolean;close:()=>void;onSave:(mutation:RentalMutation)=>Promise<void>;
}) {
    const [quantity,setQuantity]=React.useState("");
    const [error,setError]=React.useState("");
    const [submitting,setSubmitting]=React.useState(false);
    const submittingRef=React.useRef(false);
    const busy=saving||submitting;
    const qty=Number(quantity)||0;
    const availableBefore=availableNow(item);
    const needsReconciliation=hasRentalStockDiscrepancy(item);
    const formatUnits=(value:number)=>value.toLocaleString("en-PH");
    const save=async(event:React.FormEvent)=>{
        event.preventDefault();
        if(submittingRef.current||saving)return;
        setError("");
        if(quantity.trim()===""||!Number.isSafeInteger(Number(quantity))||Number(quantity)<=0||Number(quantity)>2147483647){
            setError("Enter a positive whole quantity to add.");return;
        }
        submittingRef.current=true;setSubmitting(true);
        try{await onSave({action:"receive_equipment",equipmentId:item.id,quantity:Number(quantity)});}
        catch(cause){setError(cause instanceof Error?cause.message:"Unable to receive stock.");}
        finally{submittingRef.current=false;setSubmitting(false);}
    };
    return (
        <div role="dialog" aria-modal="true" aria-label="Receive Stock"
             className="fixed inset-0 z-[130] flex items-center justify-center bg-black/50 px-3 py-5">
            <div className="flex max-h-[92vh] w-full max-w-3xl flex-col overflow-hidden rounded-2xl bg-white shadow-2xl">
                <div className="flex items-center justify-between border-b border-[#E9E1EE] px-6 py-4">
                    <h2 className="text-xl font-bold text-[#21132E]">Receive Stock</h2>
                    <button type="button" onClick={close} disabled={busy} aria-label="Close Receive Stock"
                            className="text-2xl text-[#806A8C] hover:text-[#2B174C] disabled:opacity-50">×</button>
                </div>
                <form onSubmit={save} className="flex min-h-0 flex-col">
                    <div className="space-y-5 overflow-y-auto px-6 py-5">
                        <div>
                            <h3 className="text-base font-bold text-[#21132E]">{item.name}</h3>
                            <p className="mt-1 text-xs text-[#806A8C]">Product No. {item.equipmentNumber || "—"} · {item.category}</p>
                            <div className="mt-3 grid grid-cols-2 gap-3 rounded-xl bg-[#F7F1FF] p-4">
                                <div><div className="text-xs text-[#806A8C]">Available Now (Physically Ready)</div>
                                    <div className="mt-1 text-xl font-bold text-[#2B174C]">{formatUnits(availableBefore)}</div></div>
                                <div><div className="text-xs text-[#806A8C]">Available After Receiving</div>
                                    <div className="mt-1 text-xl font-bold text-[#2B174C]">{needsReconciliation ? "—" : formatUnits(availableBefore + qty)}</div></div>
                            </div>
                            {needsReconciliation && <p role="alert" className="mt-2 rounded-lg border border-amber-200 bg-amber-50 px-3 py-2 text-xs leading-5 text-amber-900">
                                Assigned units exceed physical stock. Review booking, repair and missing records before receiving more stock; no new availability is projected until the records agree.
                            </p>}
                        </div>
                        <section className="space-y-3">
                            <h3 className="text-sm font-bold text-[#21132E]">Stock to Receive</h3>
                            <p className="text-xs text-[#806A8C]">Enter the quantity to add.</p>
                            <div className="space-y-3 rounded-xl border border-[#E3D8EA] p-4">
                                <div className="flex justify-between gap-3">
                                    <div><strong className="text-sm text-[#2B174C]">Regular</strong></div>
                                    <span className="text-xs text-[#806A8C]">Available: {formatUnits(availableBefore)} pcs</span>
                                </div>
                                <div className="grid gap-3 sm:grid-cols-2">
                                    <div className="space-y-1"><label className={rentalLabelClass}>Quantity to Add</label>
                                        <input type="number" min="0" step="1" value={quantity}
                                               onChange={e => setQuantity(e.target.value)}
                                               placeholder="0" className={rentalFieldClass}/></div>
                                </div>
                                <p className="text-xs text-[#806A8C]">Available after receiving: {needsReconciliation ? "Reconciliation required" : `${formatUnits(availableBefore + qty)} pcs`}</p>
                            </div>
                            <div className="flex justify-between border-t border-[#E3D8EA] pt-3 text-sm font-semibold text-[#2B174C]">
                                <span>Total Stock to Add</span><span>+{formatUnits(qty)} pcs</span>
                            </div>
                        </section>
                        {error && <p role="alert" className="rounded-xl bg-red-50 p-3 text-sm text-red-700">{error}</p>}
                    </div>
                    <div className="flex justify-end gap-2 border-t border-[#E3D8EA] bg-white px-6 py-4">
                        <button type="button" onClick={close} disabled={busy}
                                className="rounded-xl border border-[#E3D8EA] px-5 py-2.5 text-sm font-semibold text-[#2B174C]">Cancel</button>
                        <button type="submit" disabled={busy || qty <= 0}
                                className="rounded-xl bg-[#2B174C] px-5 py-2.5 text-sm font-semibold text-white disabled:opacity-50">
                            {busy ? "Saving..." : "Confirm Stock In"}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
}

/* -------------------------------------------------------------------------- */
/*    RENTAL INVENTORY IMPORT / CATEGORIES / EXPORT — SALES DATA UNTOUCHED     */
/* -------------------------------------------------------------------------- */

function peso(value:number|null|undefined) {
    return value == null ? "—" : `₱${value.toLocaleString("en-PH",{minimumFractionDigits:2,maximumFractionDigits:2})}`;
}

type RentalExportFilters = {
    category:string;status:string;appliedDates:{from:string;to:string}|null;
    reserved?:Map<number,number>|null;
};
function rentalReportRows(items:RentalEquipment[],filters:RentalExportFilters,availability:Map<number,number>|null) {
    const headings = ["Product No.","Rental Product","Category","Avg. Unit Cost (PHP)",
        "Rental Rate (PHP)","Total Units","Available Now",
        ...(filters.appliedDates?["Available in Selected Dates","Reserved in Selected Dates"]:[]),
        "Rented Out","Maintenance","Missing","Status","Condition / Alert"];
    const rows = items.map(item => [item.equipmentNumber||"—",item.name,item.category,
        item.averageUnitCost??"—",item.rentalRatePerDay??"—",item.totalUnits,availableNow(item),
        ...(filters.appliedDates?[availability?.get(item.id)??"—",filters.reserved?.get(item.id)??"—"]:[]),
        item.rentedOutUnits,item.maintenanceUnits,item.missingUnits,
        // Same Status as the table column, so a Status-filtered export matches the screen.
        equipmentDisplayStatus(item,true,filters.appliedDates?availability?.get(item.id):item.bookableToday),
        equipmentConditionLabels(item).join(", ")||"—"]);
    return {headings,rows};
}
function rentalFilename(ext:"xlsx"|"pdf") {
    const d=new Date();
    return `StockNBook_Rental_Inventory_${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}.${ext}`;
}
function exportRentalExcel(items:RentalEquipment[],filters:RentalExportFilters,availability:Map<number,number>|null) {
    const {headings,rows}=rentalReportRows(items,filters,availability);
    const meta:(string|number)[][] = [
        ["StockNBook — Branch Rental Inventory"],
        ["Category Filter",filters.category],
        ["Status Filter",filters.status],
        ["Availability Dates",filters.appliedDates?`${filters.appliedDates.from} to ${filters.appliedDates.to}`:"Not applied"],
        ["Availability Scope",filters.appliedDates?"Selected booking dates":"Physical stock now"],
        ["Exported On",new Date().toLocaleString("en-PH")],
        ["Matching Equipment",items.length],[],headings,...rows,
    ];
    const sheet=XLSX.utils.aoa_to_sheet(meta);
    sheet["!cols"]=headings.map((_,i)=>({wch:[21,34,24,23,24,16,18,22,16,16,15,23,24][i]||18}));
    const book=XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(book,sheet,"Rental Inventory");
    XLSX.writeFile(book,rentalFilename("xlsx"),{bookType:"xlsx"});
}

// Direct downloadable PDF, using the same built-in canvas/JPEG approach as Sales;
// intentionally does not require another library or a browser print dialog.
function exportRentalPdf(items:RentalEquipment[],filters:RentalExportFilters,availability:Map<number,number>|null) {
    const {headings,rows}=rentalReportRows(items,filters,availability);
    const pageWidth=1190.55,pageHeight=841.89,scale=1.5,pad=3,lineHeight=11;
    const canvas=document.createElement("canvas");
    canvas.width=Math.round(pageWidth*scale);canvas.height=Math.round(pageHeight*scale);
    const context=canvas.getContext("2d");
    if(!context) throw new Error("PDF export is unavailable in this browser.");
    const ctx:CanvasRenderingContext2D=context;
    ctx.setTransform(scale,0,0,scale,0,0);
    const margin=25,tableWidth=pageWidth-2*margin;
    const baseWidths=filters.appliedDates?[95,150,94,105,78,85,62,72,78,60,72,53,90,93]:
        [105,160,105,115,85,90,67,77,66,74,59,90,93];
    const totalBase=baseWidths.reduce((a,b)=>a+b,0);
    const widths=baseWidths.map(w=>w/totalBase*tableWidth);
    function wrapCell(v:unknown,w:number) {
        const text=String(v??"—").replace(/\s+/g," ").trim()||"—";
        const lines:string[]=[];let line="";
        for(const word of text.split(" ")){
            const candidate=line?`${line} ${word}`:word;
            if(ctx.measureText(candidate).width<=w){line=candidate;continue;}
            if(line){lines.push(line);line="";}
            for(const c of word){if(line && ctx.measureText(line+c).width>w){lines.push(line);line="";}line+=c;}
        }
        if(line)lines.push(line);
        return lines.length?lines:["—"];
    }
    ctx.font="9px Arial,sans-serif";
    const cells=[headings,...rows].map((row,index)=>{
        ctx.font=index===0?"bold 8px Arial,sans-serif":"9px Arial,sans-serif";
        const wrapped=row.map((value,i)=>wrapCell(value,widths[i]-2*pad));
        const height=Math.max(24,Math.max(...wrapped.map(lines=>lines.length))*lineHeight+8);
        return {wrapped,height};
    });
    const top=125,limit=pageHeight-50;
    const grouped:Array<typeof cells>=[];
    const header=cells[0];
    let segment:typeof cells=[header];let used=top+header.height;
    for(const cell of cells.slice(1)){
        if(used+cell.height>limit && segment.length>1){
            grouped.push(segment);segment=[header];used=top+header.height;
        }
        segment.push(cell);used+=cell.height;
    }
    grouped.push(segment);
    const images:Uint8Array[]=[];
    grouped.forEach((page,pageIndex)=>{
        ctx.fillStyle="#FFFFFF";ctx.fillRect(0,0,pageWidth,pageHeight);
        ctx.fillStyle="#2B174C";ctx.font="bold 18px Arial,sans-serif";
        ctx.fillText("StockNBook — Branch Rental Inventory",margin,34);
        ctx.font="10px Arial,sans-serif";
        ctx.fillText(`Category: ${filters.category}  |  Status: ${filters.status}  |  Equipment: ${items.length}`,margin,57);
        ctx.fillText(`Availability: ${filters.appliedDates?`${filters.appliedDates.from} to ${filters.appliedDates.to} (confirmed bookings)`:"Physical stock now"}`,margin,75);
        ctx.fillText(`Generated: ${new Date().toLocaleString("en-PH")}`,margin,92);
        let y=top;
        page.forEach((cell,index)=>{
            const isHeading=index===0;
            ctx.fillStyle=isHeading?"#F1EBFF":index%2?"#FAF8FD":"#FFFFFF";
            ctx.fillRect(margin,y,tableWidth,cell.height);
            let x=margin;
            cell.wrapped.forEach((lines,i)=>{
                ctx.strokeStyle="#E3D8EA";ctx.lineWidth=0.5;
                ctx.strokeRect(x,y,widths[i],cell.height);
                ctx.fillStyle=isHeading?"#4E2C66":"#21132E";
                ctx.font=isHeading?"bold 8px Arial,sans-serif":"9px Arial,sans-serif";
                lines.forEach((line,j)=>ctx.fillText(line,x+pad,y+12+j*lineHeight));
                x+=widths[i];
            });
            y+=cell.height;
        });
        ctx.fillStyle="#806A8C";ctx.font="10px Arial,sans-serif";
        ctx.fillText(`Page ${pageIndex+1} of ${grouped.length}`,margin,pageHeight-20);
        const bin=atob(canvas.toDataURL("image/jpeg",0.87).split(",")[1]);
        const bytes=new Uint8Array(bin.length);
        for(let i=0;i<bin.length;i++)bytes[i]=bin.charCodeAt(i);
        images.push(bytes);
    });
    const encoder=new TextEncoder(),chunks:BlobPart[]=[],offsets:number[]=[];
    let written=0;
    function write(part:string|Uint8Array){const data=typeof part==="string"?encoder.encode(part):part;
        chunks.push(data as BlobPart);written+=data.byteLength;}
    function object(id:number,writer:()=>void){offsets[id]=written;write(`${id} 0 obj\n`);writer();write("\nendobj\n");}
    write("%PDF-1.4\n%StockNBook\n");
    object(1,()=>write("<< /Type /Catalog /Pages 2 0 R >>"));
    const refs=images.map((_,i)=>`${3+i*3} 0 R`).join(" ");
    object(2,()=>write(`<< /Type /Pages /Kids [${refs}] /Count ${images.length} >>`));
    images.forEach((jpeg,i)=>{
        const id=3+i*3,imageId=id+1,streamId=id+2;
        object(id,()=>write(`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${pageWidth} ${pageHeight}] /Resources << /XObject << /PageImage ${imageId} 0 R >> >> /Contents ${streamId} 0 R >>`));
        object(imageId,()=>{write(`<< /Type /XObject /Subtype /Image /Width ${canvas.width} /Height ${canvas.height} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${jpeg.length} >>\nstream\n`);write(jpeg);write("\nendstream");});
        const stream=`q\n${pageWidth} 0 0 ${pageHeight} 0 0 cm\n/PageImage Do\nQ\n`;
        object(streamId,()=>write(`<< /Length ${encoder.encode(stream).length} >>\nstream\n${stream}endstream`));
    });
    const count=images.length*3+2,xref=written;
    write(`xref\n0 ${count+1}\n0000000000 65535 f \n`);
    for(let i=1;i<=count;i++)write(`${String(offsets[i]).padStart(10,"0")} 00000 n \n`);
    write(`trailer\n<< /Size ${count+1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`);
    const url=URL.createObjectURL(new Blob(chunks,{type:"application/pdf"}));
    const link=document.createElement("a");link.href=url;link.download=rentalFilename("pdf");
    document.body.appendChild(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),60000);
}

/* SAME SALES WORKFLOW: select XLSX → preview → confirm.
 * No variants / reorder point. */
const RENTAL_EQUIPMENT_HEADERS = ["Equipment Name","Category","Stock","Unit Purchase Cost (₱)","Rental Rate Per Day (₱)"];
// The no-Product-No. template mirrors Add Rental Equipment. The backend
// assigns a unique Product No. to every created rental product during import.
const RENTAL_FORM_REQUIRED = ["Rental Product","Category","Total Units","Cost Price (₱ / unit)","Final Daily Rental Rate (₱ for one item)"];
// Continue accepting the previous extended and original five-column imports.
const RENTAL_IMPORT_REQUIRED = ["Rental Product","Category","Total Units","Unit Purchase Cost (₱)","Rental Rate Per Day (₱)"];
const RENTAL_PRICING_HEADERS = ["Pricing Method","Target Paid Rental Days to Recover Cost","Residual Value (₱)","Operating Cost / Paid Day (₱)","Target Margin (%)"];
const LEGACY_PRICING_HEADERS = ["Pricing Method","Useful Life (Years)","Paid Rental Days / Year","Residual Value (₱)","Operating Cost / Paid Day (₱)","Target Margin (%)"];
type ParsedRentalImport = {rows:RentalImportRow[]};
function downloadRentalTemplate() {
    // Keep the formatted in-app download identical to the accepted XLSX upload.
    const link=document.createElement("a");
    link.href="/templates/StockNBook_Rental_Bulk_Import_Format.xlsx";
    link.download="StockNBook_Rental_Bulk_Import_Format.xlsx";
    document.body.appendChild(link);
    link.click();
    link.remove();
}
function rentalWorkbookMoney(raw:unknown,label:string,location:string){
    const value=String(raw??"").replace(/[₱,\s]/g,"").trim();
    if(!/^\d+(?:\.\d{1,2})?$/.test(value)||Number(value)>100000000)throw new Error(`${location}: ${label} must be a nonnegative amount with at most 2 decimals.`);
    return Number(value);
}
function rentalWorkbookTable(sheet:XLSX.WorkSheet,sheetName:string,headers:string[]){
    const raw=XLSX.utils.sheet_to_json<unknown[]>(sheet,{header:1,raw:true,defval:""});
    const key=(value:unknown)=>String(value??"").toLowerCase().replace(/[^a-z0-9]/g,"");
    const heading=raw.findIndex(row=>headers.every(header=>row.some(value=>key(value)===key(header))));
    if(heading<0)throw new Error(`${sheetName}: expected columns ${headers.join(", ")}. Download the rental format.`);
    const indexes=headers.map(header=>raw[heading].findIndex(value=>key(value)===key(header)));
    return raw.slice(heading+1).map((row,index)=>({rowNumber:heading+index+2,values:indexes.map(column=>row[column]??"")}))
        .filter(record=>record.values.some(value=>String(value??"").trim()!==""));
}
function parseRentalImport(buffer:ArrayBuffer,existingEquipment:RentalEquipment[]):ParsedRentalImport {
    const workbook=XLSX.read(buffer,{type:"array",cellDates:true});
    const equipSheet=workbook.Sheets["RENTAL EQUIPMENT"];
    if(!equipSheet)throw new Error('The XLSX file must include a "RENTAL EQUIPMENT" sheet.');
    const rawEquip=XLSX.utils.sheet_to_json<unknown[]>(equipSheet,{header:1,raw:true,defval:""});
    const headerKey=(v:unknown)=>String(v??"").toLowerCase().replace(/[^a-z0-9]/g,"");
    const hasFormHeaders=rawEquip.some(row=>RENTAL_FORM_REQUIRED.every(h=>row.some(v=>headerKey(v)===headerKey(h))));
    const hasPreviousHeaders=!hasFormHeaders&&rawEquip.some(row=>RENTAL_IMPORT_REQUIRED.every(h=>row.some(v=>headerKey(v)===headerKey(h))));
    const requiredHeaders=hasFormHeaders?RENTAL_FORM_REQUIRED:hasPreviousHeaders?RENTAL_IMPORT_REQUIRED:RENTAL_EQUIPMENT_HEADERS;
    const productCells=rentalWorkbookTable(equipSheet,"RENTAL EQUIPMENT",requiredHeaders);
    if(productCells.length<1||productCells.length>500)throw new Error("Enter between 1 and 500 rental equipment rows.");
    const existing=new Set(existingEquipment.filter(item=>item.active).map(item=>item.name.toLowerCase().trim().replace(/\s+/g," ")));
    const seen=new Set<string>();
    // Optional extra columns are detected by header name. Legacy five-column XLSX files still work.
    const headerRow=rawEquip.findIndex(row=>requiredHeaders.every(h=>row.some(v=>headerKey(v)===headerKey(h))));
    const headerIndexes=new Map<string,number>();
    rawEquip[headerRow].forEach((value,index)=>headerIndexes.set(headerKey(value),index));
    const extra=(rowNumber:number,label:string)=>{
        const index=headerIndexes.get(headerKey(label));
        return index===undefined ? "" : rawEquip[rowNumber-1]?.[index]??"";
    };
    // Updated templates support cost-based pricing; older five-column workbooks
    // retain their manually entered rates. Old extended templates still parse
    // explicitly supplied years × annual days as a recovery target.
    const hasCostBasedColumns=RENTAL_PRICING_HEADERS.every(label=>headerIndexes.has(headerKey(label)));
    const hasLegacyPricingColumns=LEGACY_PRICING_HEADERS.every(label=>headerIndexes.has(headerKey(label)));
    const rows:RentalImportRow[]=productCells.map(({values,rowNumber})=>{
        const location=`RENTAL EQUIPMENT · row ${rowNumber}`;
        const name=String(values[0]??"").trim(),category=String(values[1]??"").trim();
        if(!name||!category||name.length>150||category.length>100)throw new Error(`${location}: name and category are required (max 150 / 100 characters).`);
        const signature=name.toLowerCase().replace(/\s+/g," ");
        if(seen.has(signature)||existing.has(signature))throw new Error(`${location}: "${name}" is already listed in this file or active branch inventory.`);
        seen.add(signature);
        const stockText=String(values[2]??"").trim();
        if(!/^\d+$/.test(stockText)||!Number.isSafeInteger(Number(stockText))||Number(stockText)<=0||Number(stockText)>2147483647){
            throw new Error(`${location}: Stock must be a positive whole number. Add zero-stock products through Add Product.`);
        }
        const unitCost=rentalWorkbookMoney(values[3],"Unit Purchase Cost",location);
        const selectedMethod=String(extra(rowNumber,"Pricing Method")??"").trim().toLowerCase();
        const rawMethod=selectedMethod||((hasCostBasedColumns||hasLegacyPricingColumns)&&String(values[4]??"").trim()===""?"cost-based":"manual");
        const method:RentalPricingMethod=rawMethod==="cost-based"||rawMethod==="cost_based"?"cost_based":"manual";
        if(!["cost-based","cost_based","manual"].includes(rawMethod)) throw new Error(`${location}: Pricing Method must be Manual or Cost-Based.`);
        if(method==="manual") return {name,category,openingUnits:Number(stockText),unitCost,
            rentalRatePerDay:rentalWorkbookMoney(values[4],"Rental Rate Per Day",location),pricingMethod:"manual"};
        const cleanMoney=(label:string)=>rentalWorkbookMoney(extra(rowNumber,label),label,location);
        const targetText=String(extra(rowNumber,"Target Paid Rental Days to Recover Cost")??"").trim();
        let recoveryDays:number;
        if(targetText){
            if(!/^\d+$/.test(targetText)||Number(targetText)<1||Number(targetText)>10980)
                throw new Error(`${location}: Target Paid Rental Days to Recover Cost must be 1–10,980.`);
            recoveryDays=Number(targetText);
        }else if(hasLegacyPricingColumns){
            // Compatibility for files that EXPLICITLY specify the old two inputs.
            const oldYears=String(extra(rowNumber,"Useful Life (Years)")??"").trim();
            const oldDays=String(extra(rowNumber,"Paid Rental Days / Year")??"").trim();
            if(!/^\d+$/.test(oldYears)||!/^\d+$/.test(oldDays)||Number(oldYears)<1||Number(oldYears)>30||Number(oldDays)<1||Number(oldDays)>366)
                throw new Error(`${location}: Enter a recovery target, or explicitly provide both legacy Years and Paid Rental Days / Year.`);
            recoveryDays=Number(oldYears)*Number(oldDays);
        }else{
            throw new Error(`${location}: Enter Target Paid Rental Days to Recover Cost for automatic pricing.`);
        }
        const residual=cleanMoney("Residual Value (₱)");
        const operating=cleanMoney("Operating Cost / Paid Day (₱)");
        const target=String(extra(rowNumber,"Target Margin (%)")??"").trim();
        if(!/^\d+(?:\.\d{1,2})?$/.test(target)||Number(target)>80) throw new Error(`${location}: Target Margin must be 0–80%.`);
        const rate=calculateCostBasedRentalRate(unitCost,residual,recoveryDays,operating,Number(target));
        if(rate===null)throw new Error(`${location}: Cost-based pricing inputs are invalid. Check recovery target, residual value and costs.`);
        if(values[4]!==""&&rentalWorkbookMoney(values[4],"Rental Rate Per Day",location)!==rate)
            throw new Error(`${location}: Suggested Rate does not match formula. Leave the rental rate blank for Cost-Based pricing.`);
        return {name,category,openingUnits:Number(stockText),unitCost,rentalRatePerDay:rate,
            pricingMethod:"cost_based",pricingRecoveryDays:recoveryDays,
            pricingResidualValue:residual,pricingOperatingCostPerDay:operating,pricingMarginPercent:Number(target)};
    });
    const totalCents=rows.reduce((sum,row)=>sum+row.openingUnits*Math.round(row.unitCost*100),0);
    if(!Number.isSafeInteger(totalCents))throw new Error("Total purchase cost is too large.");
    return {rows};
}
function RentalImportDialog({close,onSave,saving,existingEquipment}:{close:()=>void;
    onSave:(rows:RentalImportRow[])=>Promise<void>;
    saving:boolean;existingEquipment:RentalEquipment[]}) {
    const [file,setFile]=React.useState<File|null>(null);
    const [preview,setPreview]=React.useState<ParsedRentalImport|null>(null);
    const [step,setStep]=React.useState<"select"|"confirm">("select");
    const [error,setError]=React.useState("");
    const [reading,setReading]=React.useState(false);
    const [submitting,setSubmitting]=React.useState(false);
    const running=React.useRef(false);
    const parse=async()=>{
        if(!file||reading)return;
        setError("");setReading(true);
        try{
            if(!/\.xlsx$/i.test(file.name))throw new Error("Use the StockNBook .xlsx rental format.");
            if(file.size>5*1024*1024)throw new Error("Choose a file smaller than 5 MB.");
            const data=parseRentalImport(await file.arrayBuffer(),existingEquipment);
            setPreview(data);setStep("confirm");
        }catch(cause){setPreview(null);setError(cause instanceof Error?cause.message:"Unable to preview file.");}
        finally{setReading(false);}
    };
    const confirm=async()=>{
        if(!preview||submitting||saving||running.current)return;
        running.current=true;setSubmitting(true);setError("");
        try{await onSave(preview.rows);}
        catch(cause){setError(cause instanceof Error?cause.message:"Import failed. No products should be saved unless the server confirms success.");}
        finally{running.current=false;setSubmitting(false);}
    };
    const secondary="rounded-xl border border-[#E6DDF0] bg-white px-4 py-2 text-sm font-medium text-[#6A5D6F] hover:bg-[#F7F1FF]";
    return <div role="presentation" className="fixed inset-0 z-[145] flex items-center justify-center bg-[#21132E]/55 p-3 backdrop-blur-sm sm:p-4">
        <div role="dialog" aria-modal="true" aria-label={step==="select"?"Upload rental inventory file":"Confirm imported rental products"}
             className={`flex max-h-[90dvh] w-full flex-col overflow-hidden rounded-2xl border border-[#E6DDF0] bg-white shadow-xl ${step==="select"?"max-w-lg":"max-w-6xl"}`}>
            {step==="select"?<>
                <div className="p-5 sm:p-6">
                    <div className="mb-4 flex items-start justify-between gap-3"><div>
                        <h2 className="text-[19px] font-bold text-[#1A1220]">Upload Rental Inventory File</h2>
                        <p className="mt-1 text-sm text-[#6A5D6F]">Select the StockNBook XLSX rental format. No equipment is added until you confirm.</p>
                    </div><button type="button" disabled={submitting} onClick={close} aria-label="Close upload" className="text-[#9B8AAA]"><X size={18}/></button></div>
                    <input type="file" accept=".xlsx" disabled={reading} onChange={e=>{setFile(e.target.files?.[0]||null);setError("");setPreview(null);}}
                           className="w-full rounded-xl border border-[#E3D8EA] bg-white p-3 text-sm text-[#1A1220] file:mr-4 file:rounded-lg file:border-0 file:bg-[#2B174C] file:px-4 file:py-2 file:text-sm file:font-semibold file:text-white"/>
                    {file&&<p className="mt-2 text-xs text-[#6A5D6F]">Selected: <strong>{file.name}</strong></p>}
                    {error&&<div role="alert" className="mt-3 rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-800"><strong>Check your Excel file</strong><p className="mt-1">{error}</p><p className="mt-1 text-xs">No equipment has been saved. Correct the file and preview again.</p></div>}
                    <div className="mt-5 flex flex-wrap items-center justify-between gap-3">
                        <button type="button" onClick={downloadRentalTemplate} className="inline-flex items-center gap-2 rounded-xl border border-[#CDB9E1] bg-[#F7F1FF] px-4 py-2 text-sm font-semibold text-[#2B174C]"><Download size={15}/> Download Format</button>
                        <div className="flex gap-2"><button type="button" onClick={close} className={secondary}>Cancel</button>
                            <button type="button" disabled={!file||reading} onClick={()=>void parse()} className="rounded-xl bg-[#2B174C] px-5 py-2 text-sm font-semibold text-white disabled:opacity-40">{reading?"Reading...":"Preview Import"}</button></div>
                    </div>
                </div>
            </>:<>
                <div className="flex shrink-0 justify-between gap-4 border-b border-[#E6DDF0] px-5 py-4 sm:px-6">
                    <div><h2 className="text-[19px] font-bold text-[#1A1220]">Confirm Imported Rental Products</h2>
                        <p className="mt-1 text-sm text-[#6A5D6F]">Import only quantities already physically received and counted. Confirming the import posts stock receipts and activity.</p>
                        <p className="mt-1 text-xs font-semibold text-[#5A476A]">{preview?.rows.length??0} equipment product(s)</p>
                    </div><button type="button" disabled={submitting} onClick={close} aria-label="Close preview" className="text-[#9B8AAA]"><X size={18}/></button>
                </div>
                <div className="min-h-0 flex-1 space-y-5 overflow-y-auto px-5 py-5 sm:px-6">
                    {error&&<div role="alert" className="rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-800"><strong>Import not saved — check the following</strong><p>{error}</p></div>}
                    <section className="overflow-hidden rounded-xl border border-[#E3D8EA] bg-[#FFFCF8]">
                        <div className="border-b border-[#E3D8EA] bg-white p-4"><h3 className="text-sm font-bold text-[#21132E]">Rental Inventory &amp; Pricing Details</h3><p className="mt-1 text-xs text-[#675875]">Regular equipment only — no variants or Reorder Point.</p></div>
                        <div className="max-h-[320px] overflow-auto overscroll-contain"><table className="w-full min-w-0 table-fixed text-center text-xs [&_th]:align-middle [&_td]:align-middle [&_th]:whitespace-nowrap [&_th]:overflow-hidden [&_th]:text-ellipsis [&_th]:text-[10px] [&_th]:font-semibold [&_th]:uppercase [&_th]:leading-tight [&_th]:tracking-normal [&_th]:text-[#806A8C] [&_td]:leading-snug [&_td]:[overflow-wrap:anywhere]">
                            <colgroup><col className="w-[23%]"/><col className="w-[14%]"/><col className="w-[9%]"/><col className="w-[13%]"/><col className="w-[16%]"/><col className="w-[16%]"/><col className="w-[9%]"/></colgroup>
                            <thead className="sticky top-0 z-10 bg-[#F8F3FC] text-[#5A476A]"><tr>{["Rental Product","Category","Stock","Cost Price","Rental Rate","Purchase Cost","Status"].map(h=><th className="truncate px-2 py-2 text-center text-[10px] font-semibold uppercase tracking-normal text-[#806A8C]" key={h}>{h}</th>)}</tr></thead>
                            <tbody>{(preview?.rows||[]).map((row,i)=><tr key={`${row.name}-${i}`} className="border-t border-[#EFE7F4]">
                                <td className="py-2 font-semibold text-[#2B174C] px-4 text-left">{row.name}</td><td className="px-2 py-2">{row.category}</td>
                                <td className="px-2 py-2 text-center">{row.openingUnits}</td><td className="px-2 py-2 text-center">{peso(row.unitCost)}</td>
                                <td className="px-2 py-2 text-center">{peso(row.rentalRatePerDay)}<div className="text-[10px] text-[#806A8C]">{row.pricingMethod==="cost_based"?"Cost-Based":"Manual"}</div></td><td className="px-2 py-2 text-center">{peso(row.openingUnits*row.unitCost)}</td>
                                <td className="px-2 py-2 text-center font-semibold text-[#23834A]">Valid</td>
                            </tr>)}</tbody></table></div>
                    </section>
                </div>
                <div className="flex shrink-0 flex-wrap justify-end gap-2 border-t border-[#E6DDF0] px-5 py-4 sm:px-6">
                    <button type="button" disabled={submitting} onClick={close} className={secondary}>Cancel</button>
                    <button type="button" disabled={!preview||submitting||saving} onClick={()=>void confirm()} className="rounded-xl bg-[#2B174C] px-5 py-2 text-sm font-semibold text-white disabled:opacity-40">{submitting?"Importing...":"Confirm Import"}</button>
                </div>
            </>}
        </div>
    </div>;
}
type RentalCategoryMutation = Extract<RentalMutation,
    { action: "create_rental_category" | "rename_rental_category" | "delete_rental_category" }>;
function RentalCategoriesDialog({categories,equipment,close,onSave,saving}:{
    categories:string[];equipment:RentalEquipment[];close:()=>void;onSave:(action:RentalMutation)=>Promise<void>;saving:boolean;
}) {
    const [draft,setDraft]=React.useState("");
    const [editing,setEditing]=React.useState<string|null>(null);
    const [editDraft,setEditDraft]=React.useState("");
    const [confirmAction,setConfirmAction]=React.useState<RentalCategoryMutation|null>(null);
    const [blocked,setBlocked]=React.useState<string|null>(null);
    const [error,setError]=React.useState("");
    const [success,setSuccess]=React.useState("");
    const closeCategoryToast = React.useCallback(() => setSuccess(""), []);
    const [working,setWorking]=React.useState(false);
    const inFlight=React.useRef(false);
    const matches=(name:string)=>categories.some(c=>c.toLowerCase().trim()===name.toLowerCase().trim());
    const beginAdd=()=>{
        setError("");setSuccess("");const name=draft.trim();
        if(!name||name.length>100){setError("Enter a category name (max 100 characters).");return;}
        if(matches(name)){setError(`Category "${name}" already exists.`);return;}
        setConfirmAction({action:"create_rental_category",name});
    };
    const beginEdit=()=>{
        const name=editDraft.trim();setError("");
        if(!editing||!name||name.length>100){setError("Enter a valid category name (max 100 characters).");return;}
        if(name===editing){setError("No changes made.");return;}
        if(matches(name)){setError(`Category "${name}" already exists.`);return;}
        setEditing(null);setConfirmAction({action:"rename_rental_category",previousName:editing,name});
    };
    const beginDelete=(name:string)=>{
        const linked=equipment.filter(item=>item.category===name).length;
        setError("");if(linked>0){setBlocked(name);return;}
        setConfirmAction({action:"delete_rental_category",name});
    };
    const confirm=async()=>{
        if(!confirmAction||working||saving||inFlight.current)return;
        inFlight.current=true;setWorking(true);setError("");
        try{
            const action=confirmAction;
            await onSave(action);
            if(action.action==="create_rental_category")setDraft("");
            setSuccess(action.action==="create_rental_category"?`“${action.name}” added successfully.`:
                action.action==="rename_rental_category"?`“${action.previousName}” updated to “${action.name}”.`:
                    `“${action.name}” deleted successfully.`);
            setConfirmAction(null);
        }catch(cause){setConfirmAction(null);setError(cause instanceof Error?cause.message:"Unable to save category.");}
        finally{inFlight.current=false;setWorking(false);}
    };
    const shown=categories;
    const secondary="rounded-xl border border-[#E6DDF0] bg-white px-4 py-2 text-sm font-medium text-[#6A5D6F] hover:bg-[#F7F1FF]";
    return <div role="presentation" className="fixed inset-0 z-[145] flex items-center justify-center bg-[#21132E]/55 p-3 backdrop-blur-sm sm:p-4">
        <div role="dialog" aria-modal="true" aria-label="Manage rental categories" className="flex h-[560px] max-h-[90dvh] w-full max-w-5xl flex-col overflow-hidden rounded-2xl border border-[#E6DDF0] bg-white p-5 shadow-xl sm:p-6">
            <div className="mb-4 flex items-center justify-between"><h2 className="text-[18px] font-bold text-[#1A1220]">Manage Categories</h2>
                <button type="button" disabled={working} aria-label="Close" onClick={close} className="text-[#9B8AAA] hover:text-[#1A1220]"><X size={20}/></button></div>
            {error&&<p role="alert" className="mb-3 rounded-xl border border-red-200 bg-red-50 p-3 text-xs text-red-700">{error}</p>}
            <SuccessToast toast={success ? {title:"Category change saved",message:success} : null} onClose={closeCategoryToast} />
            <div className="grid min-h-0 flex-1 gap-4 lg:grid-cols-[minmax(0,360px)_minmax(0,1fr)]">
                <div className="flex min-h-0 flex-col rounded-2xl border border-[#E6DDF0] bg-[#FFFCF7] p-4">
                    <p className="text-sm font-semibold text-[#1A1220]">Add New Category</p>
                    <p className="mt-1 text-xs text-[#9B8AAA]">Type a category name, then click Add.</p>
                    <div className="mt-5 space-y-1"><label className={rentalLabelClass}>Category Name</label>
                        <input maxLength={100} value={draft} onChange={e=>setDraft(e.target.value)} placeholder="Type a new category..." className={rentalFieldClass}/></div>
                    <button type="button" disabled={working||saving||!draft.trim()} onClick={beginAdd} className="mt-3 w-full rounded-xl bg-[#2B174C] px-4 py-3 text-sm font-semibold text-white hover:bg-[#1B0D31] disabled:opacity-40">Add Category</button>
                </div>
                <div className="flex min-h-0 flex-col rounded-2xl border border-[#E6DDF0] bg-white p-4">
                    <div className="mb-3 shrink-0"><p className="text-sm font-semibold text-[#1A1220]">Existing Categories</p>
                        <p className="text-xs text-[#9B8AAA]">{shown.length} shown</p></div>
                    <div className="min-h-0 flex-1 space-y-2 overflow-y-auto pr-2">
                        {shown.length===0?<p className="rounded-xl border border-dashed border-[#E6DDF0] bg-[#FFFCF7] p-4 text-sm text-[#9B8AAA]">No categories yet.</p>:
                            shown.map(name=><div key={name} className="flex flex-wrap items-center justify-between gap-2 rounded-xl bg-[#F8F2EA] p-2 text-[#1A1220]">
                                <div><p className="text-sm font-medium">{name}</p><p className="text-[10px] text-[#86778F]">{equipment.filter(item=>item.active&&item.category===name).length} rental products</p></div>
                                <div className="flex gap-2"><button type="button" disabled={working} onClick={()=>{setEditing(name);setEditDraft(name);setError("");}} className="text-xs font-semibold text-[#2B174C] hover:underline">Edit</button>
                                    <button type="button" disabled={working} onClick={()=>beginDelete(name)} className="text-xs font-semibold text-red-500 hover:underline">Delete</button></div>
                            </div>)}
                    </div>
                </div>
            </div>
            {editing!==null&&<div className="fixed inset-0 z-[160] flex items-center justify-center bg-[#21132E]/55 p-3 sm:p-4" role="presentation">
                <div role="dialog" aria-modal="true" aria-label="Edit category" className="max-h-[90dvh] w-full max-w-md space-y-4 overflow-y-auto rounded-2xl border border-[#E6DDF0] bg-white p-5 shadow-xl">
                    <div className="flex items-center justify-between"><h3 className="text-[18px] font-bold text-[#1A1220]">Edit Category</h3><button type="button" onClick={()=>setEditing(null)}><X size={18}/></button></div>
                    <p className="text-xs text-[#8A7A91]">Change the category name below.</p>
                    <div className="space-y-1"><label className={rentalLabelClass}>Category Name</label><input maxLength={100} className={rentalFieldClass} value={editDraft} onChange={e=>setEditDraft(e.target.value)}/></div>
                    <div className="flex justify-end gap-2"><button type="button" onClick={()=>setEditing(null)} className={secondary}>Cancel</button><button type="button" onClick={beginEdit} className="rounded-xl bg-[#2B174C] px-4 py-2 text-sm font-semibold text-white">Continue</button></div>
                    {error&&<p role="alert" className="text-xs text-red-700">{error}</p>}
                </div>
            </div>}
            {blocked&&<div className="fixed inset-0 z-[160] flex items-center justify-center bg-[#21132E]/55 p-3 sm:p-4" role="presentation">
                <div role="alertdialog" aria-modal="true" aria-label="Cannot delete category" className="max-h-[90dvh] w-full max-w-md space-y-4 overflow-y-auto rounded-2xl border border-[#E6DDF0] bg-white p-5 shadow-xl">
                    <h3 className="text-lg font-bold text-[#1A1220]">Cannot Delete Category</h3>
                    <p className="text-sm text-[#6A5D6F]">You cannot delete <strong>{blocked}</strong> because rental equipment records still use it. Move or update those records before deleting.</p>
                    <div className="flex justify-end"><button type="button" onClick={()=>setBlocked(null)} className="rounded-xl bg-[#2B174C] px-4 py-2 text-sm font-semibold text-white">Okay</button></div>
                </div>
            </div>}
            {confirmAction&&<div className="fixed inset-0 z-[160] flex items-center justify-center bg-[#21132E]/55 p-3 sm:p-4" role="presentation">
                <div role="alertdialog" aria-modal="true" aria-label="Confirm category change" className="max-h-[90dvh] w-full max-w-md space-y-4 overflow-y-auto rounded-2xl border border-[#E6DDF0] bg-white p-5 shadow-xl">
                    <h3 className="text-[18px] font-bold text-[#1A1220]">{confirmAction.action==="create_rental_category"?"Add Category":confirmAction.action==="rename_rental_category"?"Confirm Category Update":"Delete Category"}</h3>
                    <p className="text-sm text-[#6A5D6F]">{confirmAction.action==="create_rental_category"?`Are you sure you want to add “${confirmAction.name}”?`:
                        confirmAction.action==="rename_rental_category"?`Change “${confirmAction.previousName}” to “${confirmAction.name}”?`:
                            `Are you sure you want to delete “${confirmAction.name}”? This action cannot be undone.`}</p>
                    <div className="flex flex-wrap justify-end gap-2">
                        <button type="button" disabled={working} onClick={()=>setConfirmAction(null)} className={secondary}>Cancel</button>
                        <button type="button" disabled={working||saving} onClick={()=>void confirm()} className={`rounded-xl px-4 py-2 text-sm font-semibold text-white disabled:opacity-40 ${confirmAction.action==="delete_rental_category" ? "bg-red-600 hover:bg-red-700" : "bg-[#2B174C] hover:bg-[#1B0D31]"}`}>{working?"Saving...":confirmAction.action==="rename_rental_category"?"Save Changes":confirmAction.action==="create_rental_category"?"Add Category":"Delete Category"}</button></div>
                </div>
            </div>}
        </div>
    </div>;
}