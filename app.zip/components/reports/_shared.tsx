"use client";

import {
    Fragment,
    type ComponentType,
    type ReactNode,
    useCallback,
    useEffect,
    useMemo,
    useState,
    useRef,
} from "react";
import { ModuleSkeleton } from "@/components/loading/ModuleSkeletons";
import {
    ArrowLeft,
    ArrowRight,
    CalendarDays,
    ChevronDown,
    ChevronUp,
    DollarSign,
    Download,
    FileSpreadsheet,
    FileText,
    MapPin,
    Package,
    RefreshCw,
    RotateCcw,
    Search,
    Store,
    Users,
} from "lucide-react";

export type UserRole = "owner" | "manager" | "staff";

export type ReportsViewConfig = {
    showBranchFilter: boolean;
    showBranchColumn: boolean;
};

export type ReportsWorkspaceProps = {
    initialRole: UserRole;
    assignedBranch: string;
    storeName: string;
    viewConfig: ReportsViewConfig;
};
type ReportKey =
    | "inventory"
    | "restock"
    | "bookings"
    | "sales"
    | "forecasting"
    | "staff"
    | "packages";

type InventoryStatus = "In Stock" | "Low Stock" | "Out of Stock";
type ExpirationStatus = "Good" | "Soon to Expire" | "Expired" | "No Expiry";
type InventoryFilter = "all" | "in" | "low" | "out" | "soon" | "expired";
type BookingFilter = "all" | BookingStatus;
type PackageStatusFilter = "all" | "active" | "inactive";
type BookingStatus =
    | "pending"
    | "confirmed"
    | "preparing"
    | "cancelled"
    | "completed";

type LiveApiRecord = Record<string, unknown>;

type LiveProductsResponse = {
    products?: unknown[];
    error?: string;
};

type LiveInventoryLoadState = {
    ready: boolean;
    items: InventoryItem[];
};

type LiveBranchOption = {
    id: string;
    name: string;
};

type LiveBranchesResponse = {
    branches?: unknown[];
    error?: string;
};

type LiveSalesResponse = {
    orders?: unknown[];
    sales?: unknown[];
    transactions?: unknown[];
    data?: unknown;
    error?: string;
};

type LiveSalesLoadState = {
    ready: boolean;
    items: SaleRecord[];
};

type LiveBookingsResponse = {
    bookings?: unknown[];
    records?: unknown[];
    data?: unknown;
    error?: string;
};

type LiveBookingsLoadState = {
    ready: boolean;
    items: BookingRecord[];
};

type LivePackagesResponse = {
    packages?: unknown[];
    data?: unknown;
    error?: string;
};

type LivePackagesLoadState = {
    ready: boolean;
    items: PackageRecord[];
};

type InventoryVariant = {
    id: string;
    name: string;
    sku?: string;
    stock: number;
    reorderLevel?: number;
    status?: InventoryStatus;
    costPrice?: number;
    salesPrice?: number;
    expiryDate?: string;
    lastUpdated?: string;
    updatedBy?: string;
};

type InventoryItem = {
    id: string;
    product: string;
    category: string;
    branch: string;
    branchId?: string;
    stock: number;
    reorderLevel: number;
    status: InventoryStatus;
    costPrice?: number;
    salesPrice?: number;
    expiryDate?: string;
    lastUpdated?: string;
    updatedBy?: string;
    variants?: InventoryVariant[];
};

type RestockRecord = {
    id: string;
    date: string;
    product: string;
    variantName?: string;
    branch: string;
    branchId?: string;
    quantityAdded: number;
    currentStock: number;
    stockBefore?: number;
    receivedBy?: string;
    reference?: string;
    notes?: string;
};

type BookingRecord = {
    id: string;
    reference: string;
    date: string;
    eventDate: string;
    scheduleTime?: string;
    branch: string;
    branchId?: string;
    customer: string;
    phone?: string;
    venue?: string;
    packageName: string;
    status: BookingStatus;
    statusLabel?: string;
    amount: number;
    amountPaid?: number;
    requiredDownPayment?: number;
    balance?: number;
    paymentStatus?: string;
    notes?: string;
    createdBy?: string;
};

type RevenueSource = "pos" | "booking";

type SaleLineItem = {
    name: string;
    quantity: number;
    unitPrice: number;
    lineTotal: number;
};

type SaleRecord = {
    id: string;
    reference: string;
    date: string;
    branch: string;
    branchId?: string;
    customer: string;
    product: string;
    itemsText?: string;
    lineItems?: SaleLineItem[];
    category: string;
    quantity: number;
    amount: number;
    revenueSource: RevenueSource;
    linkedBookingId?: string;
    linkedBookingReference?: string;
    statusLabel?: string;
    cashier?: string;
};

type ForecastRecord = {
    id: string;
    item: string;
    type: "Product" | "Package";
    currentValue: string;
    forecastedDemand: string;
    suggestedRestock: string;
    riskLevel: "Low" | "Medium" | "High";
};

type SeasonalInsight = {
    period: string;
    trend: string;
    recommendation: string;
};

type SystemModule = "Bookings" | "Inventory" | "Packages" | "Sales / POS";
type StaffModuleFilter = "all" | SystemModule;

type StaffActivity = {
    id: string;
    date: string;
    time?: string;
    staffName: string;
    role: string;
    action: string;
    module: SystemModule;
    reference?: string;
    details?: string;
    branch: string;
    branchId?: string;
};

// Raw shape returned by /api/reports -> data.employeeActions, sourced directly
// from the employee_actions table (who did what, in which module, when).
type EmployeeAction = {
    id: string;
    employeeName: string;
    employeeRole: string;
    action: string;
    module: string;
    referenceNumber?: string;
    referenceId?: string;
    details?: string;
    branch?: string;
    branchId?: string;
    date: string;
    time?: string;
};

type PackageRecord = {
    id: string;
    name: string;
    category?: string;
    branch: string;
    branchId?: string;

    price: number;
    downPayment?: number;
    discount?: number;
    isDiscountPercentage?: boolean;

    inclusions?: {
        name: string;
        quantity?: number;
        price?: number;
    }[];

    itemCount?: number;

    status: string;

    updatedAt?: string;
    updatedBy?: string;
};

type BookingSummary = {
    totalBookings: number;
    pending: number;
    confirmed?: number;
    preparing?: number;
    cancelled: number;
    completed: number;
};

type ReportData = {
    branch?: string;
    storeName?: string;
    store_name?: string;
    businessName?: string;
    business_name?: string;
    monthLabel?: string;
    dateRange?: {
        startDate: string;
        endDate: string;
    };
    summary?: {
        grossSales: number;
        bookingRevenue: number;
        totalTransactions: number;
        averageOrderValue: number;
    };
    bookingSummary?: BookingSummary;
    branchOptions?: string[];
    access?: {
        role?: UserRole;
        assignedBranch?: string;
        branchLocked?: boolean;
    };
    inventoryList?: InventoryItem[];
    lowStockItems?: InventoryItem[];
    outOfStockItems?: InventoryItem[];
    restockHistory?: RestockRecord[];
    bookingList?: BookingRecord[];
    salesList?: SaleRecord[];
    forecasting?: ForecastRecord[];
    seasonalInsights?: SeasonalInsight[];
    staffActivities?: StaffActivity[];
    employeeActions?: EmployeeAction[];
    packageList?: PackageRecord[];
};

type ReportCard = {
    key: ReportKey;
    title: string;
    subtitle: string;
    icon: ComponentType<{ size?: number; strokeWidth?: number; className?: string }>;
    iconClassName: string;
};

type ExportTable = {
    title: string;
    headers: string[];
    rows: string[][];
};

const DEFAULT_BRANCH = "Assigned Branch";
const ALL_BRANCHES = "All Branches";

function isAllBranches(value: string) {
    return value.trim().toLowerCase() === "all branches";
}

const REPORT_CARDS: ReportCard[] = [
    {
        key: "inventory",
        title: "Inventory Report",
        subtitle: "View stock levels, item movement, and inventory valuation.",
        icon: Package,
        iconClassName: "bg-[#F1E8FF] text-[#6F3EE8]",
    },
    {
        key: "restock",
        title: "Restock Report",
        subtitle: "Identify low-stock items and recommended restock quantities.",
        icon: RotateCcw,
        iconClassName: "bg-[#FFF0DF] text-[#F47A18]",
    },
    {
        key: "sales",
        title: "POS Report",
        subtitle: "Analyze sales performance, revenue, and transaction summaries.",
        icon: DollarSign,
        iconClassName: "bg-[#E7F7EE] text-[#0E9A53]",
    },
    {
        key: "bookings",
        title: "Booking Report",
        subtitle: "Review booking activity, status, and revenue over time.",
        icon: CalendarDays,
        iconClassName: "bg-[#E8F2FF] text-[#2F7BEA]",
    },
    {
        key: "packages",
        title: "Packages Report",
        subtitle: "View all package offerings, details, and pricing information.",
        icon: Package,
        iconClassName: "bg-[#FFF3DB] text-[#E9A008]",
    },
    {
        key: "staff",
        title: "Employee Actions",
        subtitle: "Monitor ongoing actions and recent activity by employees.",
        icon: Users,
        iconClassName: "bg-[#F1E8FF] text-[#7A3FF2]",
    },
];

function getManilaDateValue(value: Date) {
    const parts = new Intl.DateTimeFormat("en-US", {
        timeZone: "Asia/Manila",
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
    }).formatToParts(value);

    const readPart = (type: Intl.DateTimeFormatPartTypes) =>
        parts.find((part) => part.type === type)?.value || "";

    return `${readPart("year")}-${readPart("month")}-${readPart("day")}`;
}

function getToday() {
    return getManilaDateValue(new Date());
}

function getMonthStart(date: string) {
    return `${date.slice(0, 7)}-01`;
}

function formatPeso(value: number) {
    return new Intl.NumberFormat("en-PH", {
        style: "currency",
        currency: "PHP",
        minimumFractionDigits: 2,
    }).format(Number(value || 0));
}

function formatNumber(value: number) {
    return new Intl.NumberFormat("en-PH").format(Number(value || 0));
}

function formatDate(value: string) {
    const normalizedDate = toReportDateValue(value);

    if (!normalizedDate) return "—";

    const parsedDate = new Date(`${normalizedDate}T12:00:00`);

    if (Number.isNaN(parsedDate.getTime())) return "—";

    return new Intl.DateTimeFormat("en-PH", {
        month: "short",
        day: "numeric",
        year: "numeric",
        timeZone: "Asia/Manila",
    }).format(parsedDate);
}

function formatDateRange(startDate: string, endDate: string) {
    if (!startDate || !endDate) return "Selected period";
    if (startDate === endDate) return formatDate(startDate);

    return `${formatDate(startDate)} – ${formatDate(endDate)}`;
}

function getExpirationStatus(expiryDate?: string): ExpirationStatus {
    const normalizedDate = toReportDateValue(expiryDate);

    if (!normalizedDate) return "No Expiry";

    const today = getToday();

    if (normalizedDate < today) return "Expired";

    const soonLimit = new Date(`${today}T12:00:00`);
    soonLimit.setDate(soonLimit.getDate() + 30);
    const soonLimitValue = soonLimit.toISOString().slice(0, 10);

    return normalizedDate <= soonLimitValue ? "Soon to Expire" : "Good";
}

function expirationStatusClass(status: ExpirationStatus) {
    if (status === "Expired") return "bg-[#FCE9E7] text-[#C7372F]";
    if (status === "Soon to Expire") return "bg-[#FFF4D8] text-[#B66A00]";
    if (status === "Good") return "bg-[#E8F6EC] text-[#17733A]";
    return "bg-[#F2EEF5] text-[#766A7E]";
}

function getEarliestExpiryDate(values: Array<string | undefined>) {
    const dates = values
        .map((value) => toReportDateValue(value))
        .filter(Boolean)
        .sort();

    return dates[0] || "";
}

function getStoredSessionValue(keys: string[]) {
    if (typeof window === "undefined") {
        return "";
    }

    for (const key of keys) {
        const value =
            sessionStorage.getItem(key) ||
            localStorage.getItem(key) ||
            "";

        if (value.trim()) {
            return value.trim();
        }
    }

    return "";
}

function asLiveRecord(value: unknown): LiveApiRecord {
    return value && typeof value === "object"
        ? (value as LiveApiRecord)
        : {};
}

function asLiveNumber(value: unknown) {
    const parsed = Number(value);
    return Number.isFinite(parsed) ? parsed : 0;
}

function asLiveText(...values: unknown[]) {
    for (const value of values) {
        const text = String(value ?? "").trim();

        if (text) {
            return text;
        }
    }

    return "";
}

function getLiveCollection(
    payload: unknown,
    keys: string[]
): unknown[] {
    if (Array.isArray(payload)) {
        return payload;
    }

    const direct = asLiveRecord(payload);

    for (const key of keys) {
        if (Array.isArray(direct[key])) {
            return direct[key] as unknown[];
        }
    }

    const nested = asLiveRecord(direct.data);

    for (const key of keys) {
        if (Array.isArray(nested[key])) {
            return nested[key] as unknown[];
        }
    }

    if (Array.isArray(direct.data)) {
        return direct.data as unknown[];
    }

    return [];
}

function getOrderRevenueSource(
    rawValue: unknown,
    orderId: string
): RevenueSource {
    const raw = asLiveRecord(rawValue);
    const explicitSource = asLiveText(
        raw.revenueSource,
        raw.revenue_source,
        raw.orderSource,
        raw.order_source,
        raw.orderType,
        raw.order_type,
        raw.transactionType,
        raw.transaction_type,
        raw.recordType,
        raw.record_type,
        raw.source,
        raw.module
    ).toLowerCase();

    const hasLinkedBookingField = Boolean(
        raw.bookingId ??
        raw.booking_id ??
        raw.bookingReference ??
        raw.booking_reference ??
        raw.booking_ref ??
        raw.bookingRef
    );

    if (hasLinkedBookingField) {
        return "booking";
    }

    const normalizedOrderId = String(orderId || "")
        .trim()
        .toUpperCase();

    if (
        normalizedOrderId.startsWith("POS-") ||
        normalizedOrderId.includes("-POS-") ||
        normalizedOrderId.includes("_POS_") ||
        // Standardized POS Order ID: STORE-BRANCH-MMDDYY-XXXX (e.g. SPS-B4-110326-0001)
        /^[A-Z0-9]{2,8}-[A-Z0-9]{2,8}-\d{6}-\d{4,}$/.test(normalizedOrderId)
    ) {
        return "pos";
    }

    if (
        explicitSource.includes("booking") ||
        explicitSource.includes("reservation") ||
        explicitSource.includes("package")
    ) {
        return "booking";
    }

    if (explicitSource.includes("pos")) {
        return "pos";
    }

    return "booking";
}

function getBookingReportAmount(raw: LiveApiRecord) {
    const values = [
        raw.agreed_price,
        raw.agreedPrice,
        raw.package_price,
        raw.packagePrice,
        raw.total_price,
        raw.totalPrice,
        raw.total_amount,
        raw.totalAmount,
        raw.amount,
        raw.price,
    ];

    for (const value of values) {
        const amount = asLiveNumber(value);

        if (amount > 0) {
            return amount;
        }
    }

    return 0;
}

function getInventoryStatus(
    stock: number,
    reorderLevel: number
): InventoryStatus {
    if (stock <= 0) {
        return "Out of Stock";
    }

    if (stock <= reorderLevel) {
        return "Low Stock";
    }

    return "In Stock";
}

function getLiveVariantName(variant: LiveApiRecord, index: number) {
    const directName = asLiveText(
        variant.name,
        variant.variantName,
        variant.variant_name,
        variant.label
    );

    if (directName) {
        return directName;
    }

    const rawValues =
        variant.variantValues ??
        variant.variant_values ??
        variant.values ??
        {};

    const values =
        rawValues && typeof rawValues === "object"
            ? Object.values(rawValues as Record<string, unknown>)
                .map((value) => String(value ?? "").trim())
                .filter(Boolean)
            : [];

    return values.join(", ") || `Variant ${index + 1}`;
}

function normalizeLiveInventoryProduct(
    rawValue: unknown,
    index: number,
    fallbackBranch: string
): InventoryItem {
    const raw = asLiveRecord(rawValue);
    const rawVariants = Array.isArray(raw.variants) ? raw.variants : [];
    const productId = asLiveText(raw.id, raw.productId, raw.product_id) || `live-product-${index + 1}`;

    const variants = rawVariants.map((rawVariant, variantIndex) => {
        const variant = asLiveRecord(rawVariant);
        const stock = asLiveNumber(variant.stock);
        const reorderLevel = asLiveNumber(
            variant.alertLevel ?? variant.alert_level ?? variant.reorderLevel ?? variant.reorder_level
        );

        return {
            id:
                asLiveText(variant.id, variant.variantId, variant.variant_id) ||
                `${productId}-variant-${variantIndex + 1}`,
            sku: asLiveText(variant.sku, variant.code) || undefined,
            name: getLiveVariantName(variant, variantIndex),
            stock,
            reorderLevel,
            costPrice: asLiveNumber(
                variant.originalPrice ?? variant.original_price ?? variant.costPrice ?? variant.cost_price
            ),
            salesPrice: asLiveNumber(
                variant.salesPrice ?? variant.sales_price ?? variant.price
            ),
            expiryDate:
                toReportDateValue(
                    variant.expiryDate ??
                    variant.expiry_date ??
                    variant.expirationDate ??
                    variant.expiration_date
                ) || undefined,
            lastUpdated:
                asLiveText(
                    variant.updatedAt,
                    variant.updated_at,
                    variant.lastUpdated,
                    variant.last_updated
                ) || undefined,
            updatedBy:
                asLiveText(
                    variant.updatedByName,
                    variant.updated_by_name,
                    variant.updatedBy,
                    variant.updated_by
                ) || undefined,
            status: getInventoryStatus(stock, reorderLevel),
        } satisfies InventoryVariant;
    });

    const hasVariants = Boolean(
        raw.hasVariants ?? raw.has_variants ?? variants.length > 0
    );

    const stock = hasVariants && variants.length > 0
        ? variants.reduce((total, variant) => total + variant.stock, 0)
        : asLiveNumber(raw.stock);

    const reorderLevel = hasVariants && variants.length > 0
        ? variants.reduce(
            (total, variant) => total + Number(variant.reorderLevel || 0),
            0
        )
        : asLiveNumber(
            raw.alertLevel ??
            raw.alert_level ??
            raw.reorderLevel ??
            raw.reorder_level
        );

    const hasOutOfStockVariant = variants.some(
        (variant) => variant.status === "Out of Stock"
    );
    const hasLowStockVariant = variants.some(
        (variant) => variant.status === "Low Stock"
    );

    const status: InventoryStatus =
        hasVariants && variants.length > 0
            ? hasOutOfStockVariant
                ? "Out of Stock"
                : hasLowStockVariant
                    ? "Low Stock"
                    : "In Stock"
            : getInventoryStatus(stock, reorderLevel);

    return {
        id: productId,
        product: asLiveText(raw.name, raw.productName, raw.product_name) || "Unnamed Product",
        category: asLiveText(raw.category, raw.categoryName, raw.category_name) || "Uncategorized",
        branch:
            asLiveText(raw.branchName, raw.branch_name, raw.branch) ||
            fallbackBranch ||
            "Assigned Branch",
        branchId: asLiveText(raw.branchId, raw.branch_id),
        stock,
        reorderLevel,
        status,
        costPrice: asLiveNumber(
            raw.originalPrice ?? raw.original_price ?? raw.costPrice ?? raw.cost_price
        ),
        salesPrice: asLiveNumber(
            raw.salesPrice ?? raw.sales_price ?? raw.price
        ),
        expiryDate:
            toReportDateValue(
                raw.expiryDate ??
                raw.expiry_date ??
                raw.expirationDate ??
                raw.expiration_date
            ) ||
            getEarliestExpiryDate(variants.map((variant) => variant.expiryDate)) ||
            undefined,
        lastUpdated:
            asLiveText(
                raw.updatedAt,
                raw.updated_at,
                raw.lastUpdated,
                raw.last_updated,
                raw.createdAt,
                raw.created_at
            ) || undefined,
        updatedBy:
            asLiveText(
                raw.updatedByName,
                raw.updated_by_name,
                raw.updatedBy,
                raw.updated_by,
                raw.modifiedBy,
                raw.modified_by
            ) || undefined,
        variants: variants.length > 0 ? variants : undefined,
    };
}

function toReportDateValue(value: unknown) {
    const text = String(value ?? "").trim();

    if (!text || text === "0000-00-00") {
        return "";
    }

    const dateOnlyMatch = text.match(/^(\d{4})-(\d{2})-(\d{2})$/);

    if (dateOnlyMatch) {
        return `${dateOnlyMatch[1]}-${dateOnlyMatch[2]}-${dateOnlyMatch[3]}`;
    }

    const parsed = new Date(text);

    if (Number.isNaN(parsed.getTime())) {
        const leadingDate = text.match(/^(\d{4})-(\d{2})-(\d{2})/);
        return leadingDate
            ? `${leadingDate[1]}-${leadingDate[2]}-${leadingDate[3]}`
            : "";
    }

    return getManilaDateValue(parsed);
}

function isDateInSelectedRange(
    dateValue: string,
    startDate: string,
    endDate: string
) {
    return Boolean(
        dateValue &&
        (!startDate || dateValue >= startDate) &&
        (!endDate || dateValue <= endDate)
    );
}

function getLiveOrderLineItems(raw: LiveApiRecord): SaleLineItem[] {
    const rawItems = Array.isArray(raw.orderItems)
        ? raw.orderItems
        : Array.isArray(raw.order_items)
            ? raw.order_items
            : Array.isArray(raw.items)
                ? raw.items
                : Array.isArray(raw.lineItems)
                    ? raw.lineItems
                    : Array.isArray(raw.line_items)
                        ? raw.line_items
                        : [];

    return rawItems
        .map((rawItem) => {
            const item = asLiveRecord(rawItem);
            const name =
                asLiveText(
                    item.name,
                    item.itemName,
                    item.item_name,
                    item.productName,
                    item.product_name
                ) || "Item";
            const quantity = Math.max(
                0,
                asLiveNumber(item.quantity ?? item.qty)
            );
            const unitPrice = Math.max(
                0,
                asLiveNumber(
                    item.unitPrice ??
                    item.unit_price ??
                    item.price ??
                    item.salesPrice ??
                    item.sales_price
                )
            );
            const explicitLineTotal = Math.max(
                0,
                asLiveNumber(
                    item.lineTotal ??
                    item.line_total ??
                    item.subtotal ??
                    item.total
                )
            );
            const lineTotal =
                explicitLineTotal > 0
                    ? explicitLineTotal
                    : unitPrice * quantity;

            return {
                name,
                quantity,
                unitPrice,
                lineTotal,
            };
        })
        .filter((item) => item.name && item.quantity > 0);
}

function getLiveOrderItemsText(raw: LiveApiRecord) {
    const directItems = asLiveText(
        raw.item,
        raw.itemsText,
        raw.items_text,
        raw.orderItemsText,
        raw.order_items_text
    );

    if (directItems) {
        return directItems;
    }

    const rawItems = Array.isArray(raw.items)
        ? raw.items
        : Array.isArray(raw.order_items)
            ? raw.order_items
            : [];

    const itemLabels = rawItems
        .map((rawItem) => {
            const item = asLiveRecord(rawItem);
            const name =
                asLiveText(
                    item.name,
                    item.itemName,
                    item.item_name,
                    item.productName,
                    item.product_name
                ) || "Item";
            const quantity = asLiveNumber(item.quantity ?? item.qty);

            return quantity > 0 ? `${name} × ${quantity}` : name;
        })
        .filter(Boolean);

    return itemLabels.join(", ") || "No items recorded";
}

function parseItemsTextToLineItems(itemsText: string): SaleLineItem[] {
    if (!itemsText || itemsText === "No items recorded") return [];

    const matches = Array.from(
        itemsText.matchAll(/(.+?)\s+[×x]\s*(\d+)(?:,\s*|$)/g)
    );

    if (matches.length === 0) return [];

    return matches
        .map((match) => ({
            name: match[1].trim(),
            quantity: Math.max(0, Number(match[2]) || 0),
            unitPrice: 0,
            lineTotal: 0,
        }))
        .filter((item) => item.name && item.quantity > 0);
}

function distributeAmountAcrossLineItems(items: SaleLineItem[], totalAmount: number): SaleLineItem[] {
    const totalQty = sumBy(items, (item) => item.quantity) || 1;
    let remaining = Math.round(totalAmount * 100) / 100;

    return items.map((item, idx) => {
        const isLast = idx === items.length - 1;
        const share = isLast
            ? remaining
            : Math.round(((item.quantity / totalQty) * totalAmount) * 100) / 100;

        remaining = Math.round((remaining - share) * 100) / 100;

        return {
            ...item,
            lineTotal: share,
            unitPrice: item.quantity > 0 ? Math.round((share / item.quantity) * 100) / 100 : 0,
        };
    });
}

function normalizeLivePosOrder(
    rawValue: unknown,
    index: number,
    fallbackBranch: string
): SaleRecord {
    const raw = asLiveRecord(rawValue);
    const orderId =
        asLiveText(
            raw.orderId,
            raw.order_id,
            raw.id,
            raw.reference,
            raw.referenceNo,
            raw.reference_no
        ) || `POS-ORDER-${index + 1}`;
    const date =
        [
            raw.orderDate,
            raw.order_date,
            raw.date,
            raw.createdAt,
            raw.created_at,
            raw.transactionDate,
            raw.transaction_date,
        ]
            .map((value) => toReportDateValue(value))
            .find(Boolean) || "";

    let lineItems = getLiveOrderLineItems(raw);
    const itemText = getLiveOrderItemsText(raw);
    const amount = asLiveNumber(raw.total ?? raw.amount ?? raw.grandTotal ?? raw.grand_total);
    const fallbackQuantity = asLiveNumber(raw.quantity ?? raw.totalQuantity ?? raw.total_quantity) || 1;

    // Automatically fallback to mapping root text as line items if a Cart structure is missing.
    // Try to split the concatenated items text into individual entries first;
    // only collapse into a single fake line item as a last resort.
    if (lineItems.length === 0) {
        const parsedFromText = parseItemsTextToLineItems(itemText);

        if (parsedFromText.length > 1) {
            lineItems = distributeAmountAcrossLineItems(parsedFromText, amount);
        } else {
            const fallbackName = asLiveText(raw.product, raw.productName, raw.product_name) || itemText;
            if (fallbackName && fallbackName !== "No items recorded") {
                lineItems = [{
                    name: fallbackName,
                    quantity: fallbackQuantity,
                    unitPrice: amount / fallbackQuantity,
                    lineTotal: amount,
                }];
            }
        }
    }

    const revenueSource = getOrderRevenueSource(raw, orderId);
    const structuredQuantity = sumBy(
        lineItems,
        (item) => item.quantity
    );

    return {
        id: orderId,
        reference: orderId,
        date,
        branch:
            asLiveText(raw.branchName, raw.branch_name, raw.branch) ||
            fallbackBranch ||
            "Assigned Branch",
        branchId: asLiveText(raw.branchId, raw.branch_id),
        customer:
            asLiveText(raw.customerName, raw.customer_name, raw.customer) ||
            "-",
        product: itemText,
        itemsText: itemText,
        lineItems,
        category: asLiveText(raw.category, raw.categoryName, raw.category_name),
        quantity:
            structuredQuantity || fallbackQuantity,
        amount,
        revenueSource,
        linkedBookingId:
            asLiveText(raw.bookingId, raw.booking_id) || undefined,
        linkedBookingReference:
            asLiveText(
                raw.bookingReference,
                raw.booking_reference,
                raw.booking_ref,
                raw.bookingRef
            ) || undefined,
        statusLabel:
            asLiveText(
                raw.status,
                raw.orderStatus,
                raw.order_status,
                raw.bookingStatus,
                raw.booking_status
            ) || undefined,
        cashier:
            asLiveText(
                raw.cashier,
                raw.cashierName,
                raw.cashier_name,
                raw.processedBy,
                raw.processed_by,
                raw.servedBy,
                raw.served_by,
                raw.staffName,
                raw.staff_name,
                raw.employeeName,
                raw.employee_name,
                raw.createdBy,
                raw.created_by,
                raw.soldBy,
                raw.sold_by
            ) || undefined,
    };
}

function normalizeLiveBookingStatus(value: unknown): BookingStatus {
    const normalized = asLiveText(value).toLowerCase();

    if (normalized === "canceled" || normalized === "cancelled") {
        return "cancelled";
    }

    if (normalized.includes("complete")) {
        return "completed";
    }

    if (normalized.includes("confirm")) {
        return "confirmed";
    }

    if (normalized.includes("prepar")) {
        return "preparing";
    }

    return "pending";
}

function normalizeLiveBooking(
    rawValue: unknown,
    index: number,
    fallbackBranch: string
): BookingRecord {
    const raw = asLiveRecord(rawValue);
    const id =
        asLiveText(raw.id, raw.bookingId, raw.booking_id) ||
        `BOOKING-${index + 1}`;
    const reference =
        asLiveText(
            raw.bookingReference,
            raw.booking_reference,
            raw.reference,
            raw.referenceNo,
            raw.reference_no,
            raw.referenceNumber,
            raw.reference_number
        ) || id;
    const status = normalizeLiveBookingStatus(
        raw.status ?? raw.bookingStatus ?? raw.booking_status
    );
    const statusLabel = asLiveText(
        raw.statusLabel,
        raw.status_label,
        raw.status,
        raw.bookingStatus,
        raw.booking_status
    );

    const date =
        [
            raw.completedAt,
            raw.completed_at,
            raw.eventDate,
            raw.event_date,
            raw.scheduleDate,
            raw.schedule_date,
            raw.bookingDate,
            raw.booking_date,
            raw.date,
            raw.updatedAt,
            raw.updated_at,
            raw.createdAt,
            raw.created_at,
        ]
            .map((value) => toReportDateValue(value))
            .find(Boolean) || "";

    const eventDate =
        [
            raw.eventDate,
            raw.event_date,
            raw.scheduleDate,
            raw.schedule_date,
            raw.bookingDate,
            raw.booking_date,
            raw.date,
        ]
            .map((value) => toReportDateValue(value))
            .find(Boolean) || date;

    return {
        id,
        reference,
        date,
        eventDate,
        scheduleTime:
            asLiveText(
                raw.scheduleTime,
                raw.schedule_time,
                raw.eventTime,
                raw.event_time,
                raw.time
            ) || undefined,
        branch:
            asLiveText(raw.branchName, raw.branch_name, raw.branch) ||
            fallbackBranch ||
            "Assigned Branch",
        branchId: asLiveText(raw.branchId, raw.branch_id) || undefined,
        customer:
            asLiveText(
                raw.customerName,
                raw.customer_name,
                raw.customer,
                raw.name,
                raw.fullName,
                raw.full_name,
                raw.facebookName,
                raw.facebook_name
            ) || "Customer",
        phone:
            asLiveText(raw.phone, raw.contactNumber, raw.contact_number) ||
            undefined,
        venue:
            asLiveText(
                raw.venue,
                raw.location,
                raw.eventVenue,
                raw.event_venue
            ) || undefined,
        packageName:
            asLiveText(
                raw.package,
                raw.packageName,
                raw.package_name,
                raw.packageTitle,
                raw.package_title,
                raw.serviceName,
                raw.service_name,
                raw.customOrder,
                raw.custom_order
            ) || "Custom booking",
        status,
        statusLabel:
            statusLabel ||
            `${status.charAt(0).toUpperCase()}${status.slice(1)}`,
        amount: getBookingReportAmount(raw),
        amountPaid:
            asLiveNumber(
                raw.amount_paid ??
                raw.amountPaid ??
                raw.paid_amount ??
                raw.paidAmount
            ) || undefined,
        requiredDownPayment:
            asLiveNumber(
                raw.required_down_payment ??
                raw.requiredDownPayment ??
                raw.down_payment_amount ??
                raw.downPaymentAmount
            ) || undefined,
        balance:
            asLiveNumber(
                raw.balance ?? raw.remainingBalance ?? raw.remaining_balance
            ) || undefined,
        paymentStatus:
            asLiveText(
                raw.payment_status,
                raw.paymentStatus,
                raw.payment
            ) || undefined,
        notes: asLiveText(raw.notes, raw.note) || undefined,
        createdBy:
            asLiveText(
                raw.createdBy,
                raw.created_by,
                raw.createdByName,
                raw.created_by_name,
                raw.bookedBy,
                raw.booked_by,
                raw.handledBy,
                raw.handled_by,
                raw.staffName,
                raw.staff_name,
                raw.employeeName,
                raw.employee_name,
                raw.updatedBy,
                raw.updated_by
            ) || undefined,
    };
}

function getSaleItemsLabel(sale: SaleRecord) {
    const directItems = String(sale.itemsText ?? "").trim();

    if (directItems) {
        return directItems;
    }

    return sale.quantity > 0
        ? `${sale.product} × ${formatNumber(sale.quantity)}`
        : sale.product || "No items recorded";
}

function sumBy<T>(items: T[], callback: (item: T) => number) {
    return items.reduce((total, item) => total + callback(item), 0);
}

// Normalizes the free-text `module` column from employee_actions into the
// fixed SystemModule union the reports UI (badges/filters) expects.
function normalizeSystemModule(value: string): SystemModule {
    const normalized = value.trim().toLowerCase();

    if (normalized.startsWith("book")) return "Bookings";
    if (normalized.startsWith("package")) return "Packages";
    if (normalized.startsWith("sales") || normalized.includes("pos")) return "Sales / POS";
    return "Inventory";
}

// Maps the real, already-logged rows from the employee_actions table
// (who did what, in which module, with which reference number, when) into
// the shape the Employee Actions History view renders. This is the single
// source of truth for "who added/deleted/ordered what" — nothing here is
// inferred or reconstructed from other report records.
function mapEmployeeActionsToStaffActivities(
    actions: EmployeeAction[]
): StaffActivity[] {
    return actions.map((item) => ({
        id: item.id,
        date: toReportDateValue(item.date) || item.date,
        time: item.time || undefined,
        staffName: item.employeeName || "Unknown Employee",
        role: item.employeeRole || "Staff",
        action: item.action || "Recorded action",
        module: normalizeSystemModule(item.module || "Inventory"),
        reference: item.referenceNumber || item.referenceId || undefined,
        details: item.details || undefined,
        branch: item.branch || "—",
        branchId: item.branchId,
    }));
}

function statusClass(status: string) {
    const value = status.toLowerCase();

    if (value.includes("out") || value === "cancelled") {
        return "bg-[#FCE9E7] text-[#B54235]";
    }

    if (
        value.includes("low") ||
        value === "pending" ||
        value === "preparing"
    ) {
        return "bg-[#FFF5D9] text-[#9A650B]";
    }

    if (value === "confirmed") {
        return "bg-[#F0EAFE] text-[#66429A]";
    }

    return "bg-[#E8F6EC] text-[#176C27]";
}

function riskClass(risk: ForecastRecord["riskLevel"]) {
    if (risk === "High") return "bg-[#FCE9E7] text-[#B54235]";
    if (risk === "Medium") return "bg-[#FFF5D9] text-[#9A650B]";
    return "bg-[#E8F6EC] text-[#176C27]";
}

function escapeHtml(value: string) {
    return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;");
}

function normalizePdfText(value: string) {
    return String(value)
        .replace(/₱/g, "PHP ")
        .replace(/[–—]/g, "-")
        .replace(/•/g, "-")
        .replace(/↳/g, "-")
        .replace(/[“”]/g, '"')
        .replace(/[‘’]/g, "'")
        .replace(/\s+/g, " ")
        .trim()
        .replace(/[^\x20-\x7E]/g, "");
}

function escapePdf(value: string) {
    return normalizePdfText(value)
        .replace(/\\/g, "\\\\")
        .replace(/\(/g, "\\(")
        .replace(/\)/g, "\\)");
}

function downloadFile(filename: string, mimeType: string, content: string) {
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");

    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
}

function getPdfColumnWeight(header: string) {
    const key = header.toLowerCase();

    if (
        key.includes("product") ||
        key.includes("package") ||
        key.includes("customer") ||
        key.includes("details") ||
        key.includes("inclusion")
    ) {
        return 1.7;
    }

    if (
        key.includes("reference") ||
        key.includes("branch") ||
        key.includes("category") ||
        key.includes("suggested")
    ) {
        return 1.35;
    }

    if (key.includes("date") || key.includes("schedule")) return 1.15;
    if (key.includes("current") || key.includes("forecast")) return 1.1;
    if (key.includes("status") || key.includes("risk")) return 0.95;

    return 1;
}

function isPdfNumericColumn(header: string) {
    const key = header.toLowerCase();

    return [
        "stock",
        "level",
        "quantity",
        "sales",
        "revenue",
        "price",
        "value",
        "count",
        "added",
        "amount",
        "bookings",
        "downpayment",
        "discount",
    ].some((word) => key.includes(word));
}

function wrapPdfText(value: string, maxCharacters: number, maxLines = 3) {
    const text = normalizePdfText(value) || "-";
    const words = text.split(" ");
    const lines: string[] = [];
    let currentLine = "";

    for (let word of words) {
        while (word.length > maxCharacters) {
            if (currentLine) {
                lines.push(currentLine);
                currentLine = "";
            }

            lines.push(word.slice(0, maxCharacters));
            word = word.slice(maxCharacters);

            if (lines.length >= maxLines) break;
        }

        if (lines.length >= maxLines) break;

        const candidate = currentLine ? `${currentLine} ${word}` : word;

        if (candidate.length <= maxCharacters) {
            currentLine = candidate;
        } else {
            if (currentLine) lines.push(currentLine);
            currentLine = word;
        }

        if (lines.length >= maxLines) break;
    }

    if (currentLine && lines.length < maxLines) {
        lines.push(currentLine);
    }

    const result = lines.length ? lines.slice(0, maxLines) : ["-"];

    if (
        lines.length > maxLines ||
        result.join(" ").length < text.length
    ) {
        const finalIndex = result.length - 1;
        result[finalIndex] =
            result[finalIndex].slice(0, Math.max(1, maxCharacters - 3)) + "...";
    }

    return result;
}

function createTablePdf({
                            title,
                            storeName,
                            branch,
                            dateRange,
                            headers,
                            rows,
                            maxCellLines = 3,
                        }: {
    title: string;
    storeName: string;
    branch: string;
    dateRange: string;
    headers: string[];
    rows: string[][];
    maxCellLines?: number;
}) {
    const pageWidth = 842;
    const pageHeight = 595;
    const marginX = 28;
    const marginBottom = 28;
    const contentWidth = pageWidth - marginX * 2;
    const regularFont = "F1";
    const boldFont = "F2";
    const fontSize = headers.length >= 8 ? 5.8 : headers.length >= 6 ? 6.5 : 7.2;
    const headerFontSize = Math.max(5.6, fontSize - 0.2);
    const lineHeight = fontSize + 2.2;
    const cellPaddingX = 4.5;
    const cellPaddingY = 4.5;

    const weights = headers.map(getPdfColumnWeight);
    const totalWeight = weights.reduce((total, weight) => total + weight, 0);

    let runningX = marginX;
    const columns = headers.map((header, index) => {
        const width = (contentWidth * weights[index]) / totalWeight;
        const column = {
            header,
            x: runningX,
            width,
            numeric: isPdfNumericColumn(header),
        };

        runningX += width;
        return column;
    });

    const characterLimits = columns.map((column) =>
        Math.max(6, Math.floor((column.width - cellPaddingX * 2) / (fontSize * 0.52)))
    );

    const headerLines = headers.map((header, index) =>
        wrapPdfText(header, characterLimits[index], 2)
    );
    const headerLineCount = Math.max(...headerLines.map((lines) => lines.length));
    const headerHeight = Math.max(
        20,
        headerLineCount * (headerFontSize + 1.8) + cellPaddingY * 2
    );

    const pages: string[] = [];
    let commands: string[] = [];
    let cursorY = 0;

    const point = (value: number) => Number(value.toFixed(2));

    function addText(
        value: string,
        x: number,
        y: number,
        size: number,
        font: string,
        color: [number, number, number]
    ) {
        commands.push(
            `q ${color.join(" ")} rg BT /${font} ${point(size)} Tf 1 0 0 1 ${point(
                x
            )} ${point(y)} Tm (${escapePdf(value)}) Tj ET Q`
        );
    }

    function fillRect(
        x: number,
        y: number,
        width: number,
        height: number,
        color: [number, number, number]
    ) {
        commands.push(
            `q ${color.join(" ")} rg ${point(x)} ${point(y)} ${point(width)} ${point(
                height
            )} re f Q`
        );
    }

    function strokeRect(
        x: number,
        y: number,
        width: number,
        height: number,
        color: [number, number, number]
    ) {
        commands.push(
            `q ${color.join(" ")} RG 0.45 w ${point(x)} ${point(y)} ${point(
                width
            )} ${point(height)} re S Q`
        );
    }

    function drawTableHeader() {
        const bottomY = cursorY - headerHeight;

        fillRect(marginX, bottomY, contentWidth, headerHeight, [0.17, 0.09, 0.3]);
        strokeRect(marginX, bottomY, contentWidth, headerHeight, [0.77, 0.69, 0.84]);

        columns.forEach((column, index) => {
            if (index > 0) {
                commands.push(
                    `q 0.92 0.87 0.96 RG 0.35 w ${point(column.x)} ${point(
                        bottomY
                    )} m ${point(column.x)} ${point(cursorY)} l S Q`
                );
            }

            const lines = headerLines[index];
            lines.forEach((line, lineIndex) => {
                const textWidth = line.length * headerFontSize * 0.52;
                const textX = column.numeric
                    ? column.x + column.width - cellPaddingX - textWidth
                    : column.x + cellPaddingX;

                addText(
                    line,
                    textX,
                    cursorY - cellPaddingY - headerFontSize - lineIndex * (headerFontSize + 1.8),
                    headerFontSize,
                    boldFont,
                    [1, 1, 1]
                );
            });
        });

        cursorY = bottomY;
    }

    function drawPageTitle(continued: boolean) {
        addText(
            `StockNBook - ${title}${continued ? " (continued)" : ""}`,
            marginX,
            pageHeight - 32,
            14,
            boldFont,
            [0.1, 0.07, 0.13]
        );

        let metadataY = pageHeight - 49;

        addText(
            `Store: ${storeName}`,
            marginX,
            metadataY,
            8.5,
            regularFont,
            [0.21, 0.15, 0.27]
        );

        if (branch) {
            metadataY -= 13;
            addText(
                `Branch: ${branch}`,
                marginX,
                metadataY,
                8.5,
                regularFont,
                [0.21, 0.15, 0.27]
            );
        }

        metadataY -= 13;
        addText(
            `Date range: ${dateRange}`,
            marginX,
            metadataY,
            8.5,
            regularFont,
            [0.21, 0.15, 0.27]
        );

        const dividerY = metadataY - 8;
        commands.push(
            `q 0.84 0.79 0.9 RG 0.6 w ${marginX} ${dividerY} m ${
                pageWidth - marginX
            } ${dividerY} l S Q`
        );

        cursorY = dividerY - 1;
        drawTableHeader();
    }

    function finishPage() {
        if (commands.length > 0) {
            pages.push(commands.join("\n"));
            commands = [];
        }
    }

    function startPage(continued: boolean) {
        if (commands.length > 0) finishPage();
        drawPageTitle(continued);
    }

    function drawTableRow(row: string[], rowIndex: number) {
        const cellLines = columns.map((_, index) =>
            wrapPdfText(row[index] ?? "-", characterLimits[index], maxCellLines)
        );
        const maxLines = Math.max(...cellLines.map((lines) => lines.length));
        const rowHeight = Math.max(20, maxLines * lineHeight + cellPaddingY * 2);

        if (cursorY - rowHeight < marginBottom + 10) {
            startPage(true);
        }

        const rowBottom = cursorY - rowHeight;
        const rowColor: [number, number, number] =
            rowIndex % 2 === 0 ? [1, 1, 1] : [0.985, 0.977, 0.99];

        fillRect(marginX, rowBottom, contentWidth, rowHeight, rowColor);
        strokeRect(marginX, rowBottom, contentWidth, rowHeight, [0.86, 0.81, 0.9]);

        columns.forEach((column, index) => {
            if (index > 0) {
                commands.push(
                    `q 0.9 0.85 0.94 RG 0.3 w ${point(column.x)} ${point(
                        rowBottom
                    )} m ${point(column.x)} ${point(cursorY)} l S Q`
                );
            }

            cellLines[index].forEach((line, lineIndex) => {
                const textWidth = line.length * fontSize * 0.52;
                const textX = column.numeric
                    ? column.x + column.width - cellPaddingX - textWidth
                    : column.x + cellPaddingX;

                addText(
                    line,
                    textX,
                    cursorY - cellPaddingY - fontSize - lineIndex * lineHeight,
                    fontSize,
                    regularFont,
                    [0.1, 0.07, 0.13]
                );
            });
        });

        cursorY = rowBottom;
    }

    startPage(false);

    if (rows.length === 0) {
        addText(
            "No records found for the selected report period.",
            marginX + 8,
            cursorY - 24,
            9,
            regularFont,
            [0.4, 0.35, 0.46]
        );
    } else {
        rows.forEach((row, index) => drawTableRow(row, index));
    }

    finishPage();

    const pageStreams = pages.map(
        (stream, index) =>
            `${stream}\nq 0.42 0.35 0.48 rg BT /F1 7 Tf 1 0 0 1 ${pageWidth - 100} 16 Tm (Page ${
                index + 1
            } of ${pages.length}) Tj ET Q`
    );

    const pageObjectIds = pageStreams.map((_, index) => 5 + index * 2);
    const contentObjectIds = pageStreams.map((_, index) => 6 + index * 2);

    const objects: Record<number, string> = {
        1: "<< /Type /Catalog /Pages 2 0 R >>",
        2: `<< /Type /Pages /Kids [${pageObjectIds
            .map((id) => `${id} 0 R`)
            .join(" ")}] /Count ${pageObjectIds.length} >>`,
        3: "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
        4: "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>",
    };

    pageStreams.forEach((stream, index) => {
        const pageId = pageObjectIds[index];
        const contentId = contentObjectIds[index];

        objects[pageId] =
            `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${pageWidth} ${pageHeight}] ` +
            `/Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents ${contentId} 0 R >>`;

        objects[contentId] = `<< /Length ${stream.length} >>\nstream\n${stream}\nendstream`;
    });

    const maxObjectId = Math.max(...Object.keys(objects).map(Number));
    let pdf = "%PDF-1.4\n";
    const offsets: number[] = [0];

    for (let id = 1; id <= maxObjectId; id += 1) {
        offsets[id] = pdf.length;
        pdf += `${id} 0 obj\n${objects[id]}\nendobj\n`;
    }

    const xrefOffset = pdf.length;
    pdf += `xref\n0 ${maxObjectId + 1}\n`;
    pdf += "0000000000 65535 f \n";

    for (let id = 1; id <= maxObjectId; id += 1) {
        pdf += `${String(offsets[id]).padStart(10, "0")} 00000 n \n`;
    }

    pdf += `trailer\n<< /Size ${maxObjectId + 1} /Root 1 0 R >>\n`;
    pdf += `startxref\n${xrefOffset}\n%%EOF`;

    return pdf;
}

function getInventoryVariants(item: InventoryItem) {
    return Array.isArray(item.variants) ? item.variants : [];
}

function getVariantStatus(variant: InventoryVariant): InventoryStatus {
    if (variant.status) return variant.status;

    const reorderLevel = variant.reorderLevel ?? 0;

    if (variant.stock <= 0) return "Out of Stock";
    if (reorderLevel > 0 && variant.stock <= reorderLevel) return "Low Stock";

    return "In Stock";
}

type InventoryPriceRange = {
    min: number;
    max: number;
};

function getInventoryPriceRange(
    item: InventoryItem,
    priceKey: "costPrice" | "salesPrice"
): InventoryPriceRange | null {
    const variantPrices = getInventoryVariants(item)
        .map((variant) => variant[priceKey])
        .filter(
            (price): price is number =>
                typeof price === "number" && Number.isFinite(price) && price > 0
        );

    if (variantPrices.length > 0) {
        return {
            min: Math.min(...variantPrices),
            max: Math.max(...variantPrices),
        };
    }

    const directPrice = item[priceKey];

    if (
        typeof directPrice === "number" &&
        Number.isFinite(directPrice) &&
        directPrice > 0
    ) {
        return { min: directPrice, max: directPrice };
    }

    return null;
}

function getPriceRange(
    item: InventoryItem,
    priceKey: "costPrice" | "salesPrice"
) {
    const range = getInventoryPriceRange(item, priceKey);

    if (!range) return "—";

    return range.min === range.max
        ? formatPeso(range.min)
        : `${formatPeso(range.min)} - ${formatPeso(range.max)}`;
}

function InventoryPriceValue({
                                 item,
                                 priceKey,
                             }: {
    item: InventoryItem;
    priceKey: "costPrice" | "salesPrice";
}) {
    const range = getInventoryPriceRange(item, priceKey);

    if (!range) {
        return (
            <span className="flex w-full items-center justify-center text-center tabular-nums">
                —
            </span>
        );
    }

    if (range.min === range.max) {
        return (
            <span className="flex w-full items-center justify-center whitespace-nowrap text-center tabular-nums">
                {formatPeso(range.min)}
            </span>
        );
    }

    return (
        <span className="flex w-full flex-col items-center justify-center text-center tabular-nums leading-[1.15]">
            <span className="whitespace-nowrap">{formatPeso(range.min)}</span>
            <span className="w-full text-center" aria-hidden="true">
                -
            </span>
            <span className="whitespace-nowrap">{formatPeso(range.max)}</span>
        </span>
    );
}

function getBookingStatusLabel(booking: BookingRecord) {
    return (
        booking.statusLabel ||
        `${booking.status.charAt(0).toUpperCase()}${booking.status.slice(1)}`
    );
}

function getBookingPaymentDetails(booking: BookingRecord) {
    const packagePrice = Number(booking.amount || 0);
    const requiredDownPayment =
        Number(booking.requiredDownPayment ?? Math.round(packagePrice * 0.1)) || 0;

    const defaultAmountPaid =
        booking.status === "completed"
            ? packagePrice
            : booking.status === "confirmed" || booking.status === "preparing"
                ? requiredDownPayment
                : 0;

    const amountPaid = Math.min(
        Math.max(Number(booking.amountPaid ?? defaultAmountPaid) || 0, 0),
        packagePrice
    );

    const balance = Math.max(
        Number(booking.balance ?? packagePrice - amountPaid) || 0,
        0
    );

    const paymentStatus =
        booking.paymentStatus ||
        (amountPaid >= packagePrice && packagePrice > 0
            ? "Fully Paid"
            : amountPaid >= requiredDownPayment && amountPaid > 0
                ? "Down Payment Paid"
                : amountPaid > 0
                    ? "Partial Payment"
                    : "Payment Pending");

    return {
        packagePrice,
        requiredDownPayment,
        amountPaid,
        balance,
        paymentStatus,
    };
}

function StatusBadge({ status }: { status: string }) {
    return (
        <span
            className={`inline-flex rounded-full px-2.5 py-1 text-[11px] font-bold ${statusClass(
                status
            )}`}
        >
      {status}
    </span>
    );
}

function ActivityModuleBadge({ module }: { module: SystemModule }) {
    const className =
        module === "Bookings"
            ? "bg-[#F0EAFE] text-[#66429A]"
            : module === "Inventory"
                ? "bg-[#FFF5D9] text-[#9A650B]"
                : module === "Packages"
                    ? "bg-[#E8F4FF] text-[#25638A]"
                    : "bg-[#E8F6EC] text-[#176C27]";

    return (
        <span className={`inline-flex rounded-full px-2.5 py-1 text-[11px] font-bold ${className}`}>
      {module}
    </span>
    );
}

function StatCard({
                      label,
                      value,
                      helper,
                  }: {
    label: string;
    value: string;
    helper: string;
}) {
    return (
        <article className="rounded-[14px] border border-[#E6DDF0] bg-white p-3 shadow-sm">
            <p className="text-xs font-semibold text-[#806A8C]">
                {label}
            </p>
            <p className="mt-1 text-[19px] font-bold text-[#1A1220]">
                {value}
            </p>
            <p className="mt-1 text-xs text-[#7A6A84]">{helper}</p>
        </article>
    );
}

function StaffModuleFilterCard({
                                   label,
                                   value,
                                   active,
                                   onClick,
                               }: {
    label: string;
    value: string;
    active: boolean;
    onClick: () => void;
}) {
    return (
        <button
            type="button"
            onClick={onClick}
            aria-pressed={active}
            className={`group h-[82px] cursor-pointer rounded-[14px] border p-3 text-left shadow-sm transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-[#2B174C]/30 ${
                active
                    ? "border-[#2B174C] bg-[#2B174C] text-white shadow-[0_8px_18px_rgba(43,23,76,0.18)] hover:bg-[#1B0D31] hover:shadow-[0_12px_24px_rgba(43,23,76,0.26)]"
                    : "border-[#E6DDF0] bg-white text-[#1A1220] hover:border-[#BFA3D5] hover:bg-[#FCF9FF] hover:shadow-[0_10px_22px_rgba(43,23,76,0.12)]"
            }`}
        >
            <p
                className={`truncate text-[11px] font-medium tracking-[0.08em] transition-colors ${
                    active
                        ? "text-[#EBDCFF]"
                        : "text-[#9B8AAA] group-hover:text-[#6F4D83]"
                }`}
            >
                {label}
            </p>

            <p className="mt-2 text-[19px] font-bold leading-none">
                {value}
            </p>
        </button>
    );
}

function BookingFilterCard({
                               label,
                               value,
                               active,
                               onClick,
                           }: {
    label: string;
    value: string;
    active: boolean;
    onClick: () => void;
}) {
    return (
        <button
            type="button"
            onClick={onClick}
            aria-pressed={active}
            className={`group h-[82px] cursor-pointer rounded-[14px] border p-3 text-left shadow-sm transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-[#2B174C]/30 ${
                active
                    ? "border-[#2B174C] bg-[#2B174C] text-white shadow-[0_8px_18px_rgba(43,23,76,0.18)] hover:bg-[#1B0D31] hover:shadow-[0_12px_24px_rgba(43,23,76,0.26)]"
                    : "border-[#E6DDF0] bg-white text-[#1A1220] hover:border-[#BFA3D5] hover:bg-[#FCF9FF] hover:shadow-[0_10px_22px_rgba(43,23,76,0.12)]"
            }`}
        >
            <p
                className={`truncate text-[11px] font-medium tracking-[0.08em] transition-colors ${
                    active
                        ? "text-[#EBDCFF]"
                        : "text-[#9B8AAA] group-hover:text-[#6F4D83]"
                }`}
            >
                {label}
            </p>

            <p className="mt-2 text-[19px] font-bold leading-none">
                {value}
            </p>
        </button>
    );
}

function SectionCard({
                         title,
                         subtitle,
                         children,
                     }: {
    title: string;
    subtitle: string;
    children: ReactNode;
}) {
    return (
        <section className="overflow-hidden rounded-[14px] border border-[#E6DDF0] bg-white shadow-sm">
            <div className="border-b border-[#E6DDF0] bg-white px-3 py-3">
                <h3 className="text-[16px] font-bold text-[#1A1220]">
                    {title}
                </h3>
                <p className="mt-0.5 text-xs text-[#8A7A91]">{subtitle}</p>
            </div>
            <div className="p-3">{children}</div>
        </section>
    );
}

function InventoryExportMenu({
                                 onExportPdf,
                                 onExportXlsx,
                                 onExportDoc,
                                 label = "Export Filtered Inventory",
                             }: {
    onExportPdf: () => void;
    onExportXlsx: () => void;
    onExportDoc: () => void;
    label?: string;
}) {
    const [isOpen, setIsOpen] = useState(false);

    const runExport = (callback: () => void) => {
        callback();
        setIsOpen(false);
    };

    return (
        <div
            className="relative mt-4"
            onBlur={(event) => {
                if (!event.currentTarget.contains(event.relatedTarget as Node | null)) {
                    setIsOpen(false);
                }
            }}
        >
            <button
                type="button"
                onClick={() => setIsOpen((current) => !current)}
                aria-expanded={isOpen}
                aria-haspopup="menu"
                className="flex h-10 w-full items-center justify-center gap-2 rounded-lg border border-[#7C4DFF] bg-white text-[12px] font-bold text-[#6334D4] transition-all duration-200 hover:-translate-y-0.5 hover:bg-[#F4EDFF] hover:shadow-md focus:outline-none focus:ring-2 focus:ring-[#7C4DFF]/20"
            >
                <FileSpreadsheet size={14} />
                {label}
                <ChevronDown
                    size={14}
                    className={`transition-transform ${isOpen ? "rotate-180" : ""}`}
                />
            </button>

            {isOpen ? (
                <div
                    role="menu"
                    className="absolute bottom-[46px] left-0 right-0 z-30 overflow-hidden rounded-xl border border-[#E2D7EA] bg-white p-1.5 shadow-[0_14px_35px_rgba(43,23,76,0.18)]"
                >
                    <button
                        type="button"
                        role="menuitem"
                        onClick={() => runExport(onExportPdf)}
                        className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left text-[12px] font-semibold text-[#3C2947] transition hover:bg-[#F6F0FC] hover:text-[#6334D4]"
                    >
                        <FileText size={14} />
                        Export as PDF
                    </button>
                    <button
                        type="button"
                        role="menuitem"
                        onClick={() => runExport(onExportXlsx)}
                        className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left text-[12px] font-semibold text-[#3C2947] transition hover:bg-[#F6F0FC] hover:text-[#6334D4]"
                    >
                        <FileSpreadsheet size={14} />
                        Export as XLSX
                    </button>
                    <button
                        type="button"
                        role="menuitem"
                        onClick={() => runExport(onExportDoc)}
                        className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left text-[12px] font-semibold text-[#3C2947] transition hover:bg-[#F6F0FC] hover:text-[#6334D4]"
                    >
                        <FileText size={14} />
                        Export as DOC
                    </button>
                </div>
            ) : null}
        </div>
    );
}

type SearchableSelectOption<T extends string> = {
    value: T;
    label: string;
};

type SearchableFilterSelectProps<T extends string> = {
    value: T;
    options: ReadonlyArray<SearchableSelectOption<T>>;
    onChange: (value: T) => void;
    icon: ComponentType<{
        size?: number;
        className?: string;
        strokeWidth?: number;
    }>;
    ariaLabel: string;
    className?: string;
};

function SearchableFilterSelect<T extends string>({
                                                      value,
                                                      options,
                                                      onChange,
                                                      icon: Icon,
                                                      ariaLabel,
                                                      className = "",
                                                  }: SearchableFilterSelectProps<T>) {
    const selectedLabel =
        options.find((option) => option.value === value)?.label || "";
    const [query, setQuery] = useState(selectedLabel);
    const [isOpen, setIsOpen] = useState(false);

    useEffect(() => {
        if (!isOpen) {
            setQuery(selectedLabel);
        }
    }, [isOpen, selectedLabel]);

    const filteredOptions = useMemo(() => {
        const normalizedQuery = query.trim().toLowerCase();

        if (!normalizedQuery || normalizedQuery === selectedLabel.toLowerCase()) {
            return options;
        }

        return options.filter((option) =>
            option.label.toLowerCase().includes(normalizedQuery)
        );
    }, [options, query, selectedLabel]);

    const selectOption = (option: SearchableSelectOption<T>) => {
        onChange(option.value);
        setQuery(option.label);
        setIsOpen(false);
    };

    return (
        <div
            className={`relative ${className}`}
            onBlur={(event) => {
                if (!event.currentTarget.contains(event.relatedTarget as Node | null)) {
                    setIsOpen(false);
                    setQuery(selectedLabel);
                }
            }}
        >
            <Icon
                size={14}
                className="pointer-events-none absolute left-3 top-1/2 z-10 -translate-y-1/2 text-[#87748F]"
            />

            <input
                type="text"
                role="combobox"
                aria-label={ariaLabel}
                aria-expanded={isOpen}
                aria-autocomplete="list"
                value={query}
                onFocus={(event) => {
                    setIsOpen(true);
                    event.currentTarget.select();
                }}
                onClick={() => setIsOpen(true)}
                onChange={(event) => {
                    setQuery(event.target.value);
                    setIsOpen(true);
                }}
                onKeyDown={(event) => {
                    if (event.key === "Enter" && filteredOptions.length > 0) {
                        event.preventDefault();
                        selectOption(filteredOptions[0]);
                    }

                    if (event.key === "Escape") {
                        setIsOpen(false);
                        setQuery(selectedLabel);
                    }
                }}
                className="h-11 w-full rounded-xl border border-[#E3D9E9] bg-white pl-9 pr-8 text-[12px] font-semibold text-[#2D2035] shadow-sm outline-none transition focus:border-[#8D63C8] focus:ring-2 focus:ring-[#8D63C8]/10"
            />

            <button
                type="button"
                tabIndex={-1}
                aria-label={`Open ${ariaLabel}`}
                onMouseDown={(event) => event.preventDefault()}
                onClick={() => setIsOpen((current) => !current)}
                className="absolute right-0 top-0 flex h-11 w-9 items-center justify-center text-[#6F5C7C]"
            >
                <ChevronDown
                    size={14}
                    className={`transition-transform ${isOpen ? "rotate-180" : ""}`}
                />
            </button>

            {isOpen ? (
                <div
                    role="listbox"
                    className="absolute left-0 right-0 top-[calc(100%+6px)] z-50 max-h-56 overflow-y-auto rounded-xl border border-[#E3D9E9] bg-white p-1.5 shadow-[0_14px_35px_rgba(43,23,76,0.18)]"
                >
                    {filteredOptions.length > 0 ? (
                        filteredOptions.map((option) => {
                            const isSelected = option.value === value;

                            return (
                                <button
                                    key={option.value}
                                    type="button"
                                    role="option"
                                    aria-selected={isSelected}
                                    onClick={() => selectOption(option)}
                                    className={`flex w-full items-center rounded-lg px-3 py-2 text-left text-[12px] font-semibold transition ${
                                        isSelected
                                            ? "bg-[#F1E9FF] text-[#6334D4]"
                                            : "text-[#3C2947] hover:bg-[#F8F3FF] hover:text-[#6334D4]"
                                    }`}
                                >
                                    {option.label}
                                </button>
                            );
                        })
                    ) : (
                        <p className="px-3 py-2 text-[11px] text-[#8A7A91]">
                            No matching option found.
                        </p>
                    )}
                </div>
            ) : null}
        </div>
    );
}

type ReportFilterBarProps = {
    selectedReport: ReportKey | null;
    searchQuery: string;
    onSearchChange: (value: string) => void;
    startDate: string;
    endDate: string;
    onStartDateChange: (value: string) => void;
    onEndDateChange: (value: string) => void;
    categoryFilter: string;
    inventoryCategories: string[];
    onCategoryChange: (value: string) => void;
    bookingStatusFilter: BookingFilter;
    onBookingStatusChange: (value: BookingFilter) => void;
    packageStatusFilter: PackageStatusFilter;
    onPackageStatusChange: (value: PackageStatusFilter) => void;
    staffModuleFilter: StaffModuleFilter;
    onStaffModuleChange: (value: StaffModuleFilter) => void;
    showBranchFilter: boolean;
    branch: string;
    branchOptions: string[];
    onBranchChange: (value: string) => void;
    onClear: () => void;
};

function ReportFilterBar({
                             selectedReport,
                             searchQuery,
                             onSearchChange,
                             startDate,
                             endDate,
                             onStartDateChange,
                             onEndDateChange,
                             categoryFilter,
                             inventoryCategories,
                             onCategoryChange,
                             bookingStatusFilter,
                             onBookingStatusChange,
                             packageStatusFilter,
                             onPackageStatusChange,
                             staffModuleFilter,
                             onStaffModuleChange,
                             showBranchFilter,
                             branch,
                             branchOptions,
                             onBranchChange,
                             onClear,
                         }: ReportFilterBarProps) {
    const isInventory = selectedReport === "inventory";
    const isBooking = selectedReport === "bookings";
    const isPackages = selectedReport === "packages";
    const isStaff = selectedReport === "staff";
    const hasOptionFilter = isInventory || isBooking || isPackages || isStaff;
    const searchSpan = hasOptionFilter
        ? showBranchFilter
            ? "xl:col-span-3"
            : "xl:col-span-5"
        : showBranchFilter
            ? "xl:col-span-5"
            : "xl:col-span-7";
    const optionSpan = "xl:col-span-2";
    const bookingStatusOptions: Array<SearchableSelectOption<BookingFilter>> = [
        { value: "all", label: "All Status" },
        { value: "pending", label: "Pending" },
        { value: "confirmed", label: "Confirmed" },
        { value: "preparing", label: "Preparing" },
        { value: "completed", label: "Completed" },
        { value: "cancelled", label: "Cancelled" },
    ];
    const packageStatusOptions: Array<SearchableSelectOption<PackageStatusFilter>> = [
        { value: "all", label: "All Status" },
        { value: "active", label: "Active" },
        { value: "inactive", label: "Inactive" },
    ];
    const staffModuleOptions: Array<SearchableSelectOption<StaffModuleFilter>> = [
        { value: "all", label: "All Modules" },
        { value: "Bookings", label: "Bookings" },
        { value: "Inventory", label: "Inventory" },
        { value: "Packages", label: "Packages" },
        { value: "Sales / POS", label: "Sales / POS" },
    ];
    const searchableBranchOptions: Array<SearchableSelectOption<string>> =
        branchOptions.map((option) => ({ value: option, label: option }));

    const placeholder =
        selectedReport === "inventory"
            ? "Search products or variants..."
            : selectedReport === "restock"
                ? "Search restock records..."
                : selectedReport === "sales"
                    ? "Search POS order..."
                    : selectedReport === "bookings"
                        ? "Search booking or customer..."
                        : selectedReport === "staff"
                            ? "Search employee action..."
                            : "Search plans...";

    return (
        <div className="mt-3 grid grid-cols-1 gap-2 sm:grid-cols-2 xl:grid-cols-12">
            <label className={`relative sm:col-span-2 ${searchSpan}`}>
                <Search
                    size={15}
                    className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-[#887496]"
                />
                <input
                    value={searchQuery}
                    onChange={(event) => onSearchChange(event.target.value)}
                    placeholder={placeholder}
                    className="h-11 w-full rounded-xl border border-[#E3D9E9] bg-white pl-9 pr-3 text-[12px] text-[#1A1220] shadow-sm outline-none transition focus:border-[#8D63C8] focus:ring-2 focus:ring-[#8D63C8]/10"
                />
            </label>

            <label className="relative xl:col-span-2">
                <CalendarDays
                    size={14}
                    className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-[#87748F]"
                />
                <span className="pointer-events-none absolute left-9 top-1/2 -translate-y-1/2 text-[9px] font-bold tracking-[0.08em] text-[#8B7695]">
                    FROM
                </span>
                <input
                    type="date"
                    value={startDate}
                    max={endDate}
                    onChange={(event) => onStartDateChange(event.target.value)}
                    aria-label="Report start date"
                    className="h-11 w-full rounded-xl border border-[#E3D9E9] bg-white pb-0 pl-[72px] pr-2 text-[11px] font-semibold text-[#2D2035] shadow-sm outline-none transition focus:border-[#8D63C8]"
                />
            </label>

            <label className="relative xl:col-span-2">
                <CalendarDays
                    size={14}
                    className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-[#87748F]"
                />
                <span className="pointer-events-none absolute left-9 top-1/2 -translate-y-1/2 text-[9px] font-bold tracking-[0.08em] text-[#8B7695]">
                    TO
                </span>
                <input
                    type="date"
                    value={endDate}
                    min={startDate}
                    onChange={(event) => onEndDateChange(event.target.value)}
                    aria-label="Report end date"
                    className="h-11 w-full rounded-xl border border-[#E3D9E9] bg-white pb-0 pl-[58px] pr-2 text-[11px] font-semibold text-[#2D2035] shadow-sm outline-none transition focus:border-[#8D63C8]"
                />
            </label>

            {isInventory ? (
                <label className={`relative ${optionSpan}`}>
                    <Package
                        size={14}
                        className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-[#87748F]"
                    />
                    <select
                        value={categoryFilter}
                        onChange={(event) => onCategoryChange(event.target.value)}
                        className="h-11 w-full appearance-none rounded-xl border border-[#E3D9E9] bg-white pl-9 pr-8 text-[12px] font-semibold text-[#2D2035] shadow-sm outline-none transition focus:border-[#8D63C8]"
                    >
                        <option value="all">All Categories</option>
                        {inventoryCategories.map((category) => (
                            <option key={category} value={category}>
                                {category}
                            </option>
                        ))}
                    </select>
                    <ChevronDown
                        size={14}
                        className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-[#6F5C7C]"
                    />
                </label>
            ) : null}

            {isBooking ? (
                <SearchableFilterSelect
                    className={optionSpan}
                    value={bookingStatusFilter}
                    options={bookingStatusOptions}
                    onChange={onBookingStatusChange}
                    icon={CalendarDays}
                    ariaLabel="Booking status filter"
                />
            ) : null}

            {isPackages ? (
                <SearchableFilterSelect
                    className={optionSpan}
                    value={packageStatusFilter}
                    options={packageStatusOptions}
                    onChange={onPackageStatusChange}
                    icon={Package}
                    ariaLabel="Package status filter"
                />
            ) : null}

            {isStaff ? (
                <SearchableFilterSelect
                    className={optionSpan}
                    value={staffModuleFilter}
                    options={staffModuleOptions}
                    onChange={onStaffModuleChange}
                    icon={Users}
                    ariaLabel="Employee action module filter"
                />
            ) : null}

            {showBranchFilter ? (
                <SearchableFilterSelect
                    className="xl:col-span-2"
                    value={branch}
                    options={searchableBranchOptions}
                    onChange={onBranchChange}
                    icon={Store}
                    ariaLabel="Branch filter"
                />
            ) : null}

            <button
                type="button"
                onClick={onClear}
                className="inline-flex h-11 items-center justify-center gap-2 rounded-xl border border-[#E3D9E9] bg-white px-3 text-[11px] font-semibold text-[#4F3B5C] shadow-sm transition-all duration-200 hover:border-[#A77CE8] hover:bg-[#F8F3FF] hover:text-[#5F2DB9] xl:col-span-1"
            >
                <RotateCcw size={14} />
                Clear
            </button>
        </div>
    );
}

type InventoryItemsTableProps = {
    items: InventoryItem[];
    showBranchColumn: boolean;
    expandedInventoryId: string | null;
    onToggleExpanded: (itemId: string) => void;
};

function InventoryItemsTable({
                                 items,
                                 showBranchColumn,
                                 expandedInventoryId,
                                 onToggleExpanded,
                             }: InventoryItemsTableProps) {
    const columnCount = showBranchColumn ? 10 : 9;

    return (
        <table className="w-full table-fixed border-collapse text-[11px]">
            <colgroup>
                <col className={showBranchColumn ? "w-[18%]" : "w-[25%]"} />
                {showBranchColumn ? <col className="w-[11%]" /> : null}
                <col className={showBranchColumn ? "w-[9%]" : "w-[13%]"} />
                <col className="w-[8%]" />
                <col className="w-[6%]" />
                <col className="w-[6%]" />
                <col className={showBranchColumn ? "w-[9%]" : "w-[10%]"} />
                <col className={showBranchColumn ? "w-[9%]" : "w-[10%]"} />
                <col className={showBranchColumn ? "w-[13%]" : "w-[12%]"} />
                <col className={showBranchColumn ? "w-[11%]" : "w-[10%]"} />
            </colgroup>

            <thead>
            <tr className="border-b border-[#E8DFED] bg-[#FCFAFD]">
                <th className="px-3 py-3 text-left text-[9px] font-semibold uppercase tracking-[0.06em] text-[#685674]">
                    Product
                </th>
                {showBranchColumn ? (
                    <th className="px-2 py-3 text-left text-[9px] font-semibold uppercase tracking-[0.06em] text-[#685674]">
                        Branch
                    </th>
                ) : null}
                <th className="px-2 py-3 text-left text-[9px] font-semibold uppercase tracking-[0.06em] text-[#685674]">
                    Category
                </th>
                <th className="px-2 py-3 text-left text-[9px] font-semibold uppercase tracking-[0.06em] text-[#685674]">
                    Type
                </th>
                <th className="px-2 py-3 text-center text-[9px] font-semibold uppercase tracking-[0.06em] text-[#685674]">
                    Stock
                </th>
                <th className="px-2 py-3 text-center text-[9px] font-semibold uppercase tracking-[0.06em] text-[#685674]">
                    Alert
                </th>
                <th className="px-2 py-3 text-center text-[9px] font-semibold uppercase tracking-[0.06em] text-[#685674]">
                    Cost Price
                </th>
                <th className="px-2 py-3 text-center text-[9px] font-semibold uppercase tracking-[0.06em] text-[#685674]">
                    Selling Price
                </th>
                <th className="px-2 py-3 text-center text-[9px] font-semibold uppercase tracking-[0.06em] text-[#685674]">
                    Expiration Date
                </th>
                <th className="px-2 py-3 text-center text-[9px] font-semibold uppercase tracking-[0.06em] text-[#685674]">
                    Status
                </th>
            </tr>
            </thead>

            <tbody>
            {items.length > 0 ? (
                items.map((item) => {
                    const variants = getInventoryVariants(item);
                    const hasVariants = variants.length > 0;
                    const isExpanded = expandedInventoryId === item.id;
                    const expirationStatus = getExpirationStatus(item.expiryDate);
                    const stockTextClass =
                        item.status === "Out of Stock"
                            ? "text-[#E3322A]"
                            : item.status === "Low Stock"
                                ? "text-[#F07800]"
                                : "text-[#12A150]";
                    const productTextClass =
                        expirationStatus === "Expired"
                            ? "text-[#D7312A]"
                            : "text-[#20152A]";

                    return (
                        <Fragment key={item.id}>
                            <tr
                                className={`border-b border-[#EFE8F2] transition-colors ${
                                    isExpanded
                                        ? "bg-[#F8F2FC]"
                                        : "bg-white hover:bg-[#FCFAFF]"
                                }`}
                            >
                                <td className="px-3 py-3 align-top">
                                    <div className="flex min-w-0 items-start gap-2">
                                        {hasVariants ? (
                                            <button
                                                type="button"
                                                onClick={() => onToggleExpanded(item.id)}
                                                className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded text-[#4E2C66] transition hover:bg-[#EEE4F7] hover:text-[#6D35D1]"
                                                aria-label={
                                                    isExpanded
                                                        ? `Hide ${item.product} variants`
                                                        : `Show ${item.product} variants`
                                                }
                                            >
                                                {isExpanded ? (
                                                    <ChevronUp size={14} />
                                                ) : (
                                                    <ChevronDown size={14} />
                                                )}
                                            </button>
                                        ) : (
                                            <span className="block h-5 w-5 shrink-0" />
                                        )}

                                        <div className="min-w-0">
                                            <div className="flex min-w-0 flex-wrap items-center gap-1.5">
                                                <p className={`break-words font-semibold ${productTextClass}`}>
                                                    {item.product}
                                                </p>
                                                {expirationStatus === "Expired" ? (
                                                    <span className="shrink-0 rounded-full border border-[#F2B5B0] bg-[#FFF0EF] px-1.5 py-0.5 text-[8px] font-bold text-[#D7312A]">
                                                            Expired
                                                        </span>
                                                ) : null}
                                            </div>
                                            {hasVariants ? (
                                                <p className="mt-0.5 break-words text-[9px] text-[#8C7A95]">
                                                    {variants.length} variant{variants.length === 1 ? "" : "s"}
                                                </p>
                                            ) : null}
                                        </div>
                                    </div>
                                </td>

                                {showBranchColumn ? (
                                    <td
                                        className="whitespace-normal break-words px-2 py-3 align-top leading-snug text-[#5F5267]"
                                        title={item.branch}
                                    >
                                        {item.branch}
                                    </td>
                                ) : null}

                                <td className="break-words px-2 py-3 align-top text-[#5F5267]">
                                    {item.category}
                                </td>
                                <td className="break-words px-2 py-3 align-top text-[#5F5267]">
                                    {hasVariants
                                        ? `${variants.length} variant${variants.length === 1 ? "" : "s"}`
                                        : "Regular"}
                                </td>
                                <td className={`px-2 py-3 text-center align-top font-bold ${stockTextClass}`}>
                                    {formatNumber(item.stock)}
                                </td>
                                <td className="px-2 py-3 text-center align-top font-semibold text-[#685674]">
                                    {formatNumber(item.reorderLevel)}
                                </td>
                                <td className="px-2 py-3 text-center align-top font-semibold text-[#5F5267]">
                                    <InventoryPriceValue item={item} priceKey="costPrice" />
                                </td>
                                <td className="px-2 py-3 text-center align-top font-bold text-[#251A2C]">
                                    <InventoryPriceValue item={item} priceKey="salesPrice" />
                                </td>
                                <td
                                    className={`px-2 py-3 text-center align-top text-[10px] font-semibold ${
                                        expirationStatus === "Expired"
                                            ? "text-[#D7312A]"
                                            : expirationStatus === "Soon to Expire"
                                                ? "text-[#D97706]"
                                                : "text-[#685674]"
                                    }`}
                                >
                                    {item.expiryDate ? formatDate(item.expiryDate) : "No Expiry"}
                                </td>
                                <td className="px-2 py-3 text-center align-top">
                                    <StatusBadge status={item.status} />
                                </td>
                            </tr>

                            {hasVariants && isExpanded
                                ? variants.map((variant) => {
                                    const variantExpiration = getExpirationStatus(
                                        variant.expiryDate
                                    );
                                    const variantStatus = getVariantStatus(variant);
                                    const variantStockClass =
                                        variantStatus === "Out of Stock"
                                            ? "text-[#E3322A]"
                                            : variantStatus === "Low Stock"
                                                ? "text-[#F07800]"
                                                : "text-[#12A150]";

                                    return (
                                        <tr
                                            key={variant.id}
                                            className="border-b border-[#E8DDF0] bg-[#FBF7FE] transition hover:bg-[#F6EFFB]"
                                        >
                                            <td className="px-3 py-3 align-top">
                                                <div className="flex min-w-0 items-start gap-3 pl-8">
                                                    <span className="mt-1.5 h-2.5 w-2.5 shrink-0 rounded-full bg-[#9B65D6]" />
                                                    <div className="min-w-0">
                                                        <p className="break-words font-semibold text-[#3C2947]">
                                                            {variant.name}
                                                        </p>
                                                    </div>
                                                </div>
                                            </td>

                                            {showBranchColumn ? (
                                                <td className="px-2 py-3 align-top text-[#9A8CA2]">—</td>
                                            ) : null}
                                            <td className="px-2 py-3 align-top text-[#9A8CA2]">—</td>
                                            <td className="px-2 py-3 align-top text-[#6A5D6F]">Variant</td>
                                            <td className={`px-2 py-3 text-center align-top font-bold ${variantStockClass}`}>
                                                {formatNumber(variant.stock)}
                                            </td>
                                            <td className="px-2 py-3 text-center align-top text-[#6A5D6F]">
                                                {formatNumber(variant.reorderLevel ?? 0)}
                                            </td>
                                            <td className="px-2 py-3 text-center align-top text-[#6A5D6F]">
                                                <span className="flex w-full items-center justify-center whitespace-nowrap text-center tabular-nums">
                                                    {typeof variant.costPrice === "number" && variant.costPrice > 0
                                                        ? formatPeso(variant.costPrice)
                                                        : "—"}
                                                </span>
                                            </td>
                                            <td className="px-2 py-3 text-center align-top font-semibold text-[#251A2C]">
                                                <span className="flex w-full items-center justify-center whitespace-nowrap text-center tabular-nums">
                                                    {typeof variant.salesPrice === "number" && variant.salesPrice > 0
                                                        ? formatPeso(variant.salesPrice)
                                                        : "—"}
                                                </span>
                                            </td>
                                            <td
                                                className={`px-2 py-3 text-center align-top text-[10px] font-semibold ${
                                                    variantExpiration === "Expired"
                                                        ? "text-[#D7312A]"
                                                        : variantExpiration === "Soon to Expire"
                                                            ? "text-[#D97706]"
                                                            : "text-[#685674]"
                                                }`}
                                            >
                                                {variant.expiryDate
                                                    ? formatDate(variant.expiryDate)
                                                    : "No Expiry"}
                                            </td>
                                            <td className="px-2 py-3 text-center align-top">
                                                <StatusBadge status={variantStatus} />
                                            </td>
                                        </tr>
                                    );
                                })
                                : null}
                        </Fragment>
                    );
                })
            ) : (
                <tr>
                    <td
                        colSpan={columnCount}
                        className="px-4 py-14 text-center text-sm text-[#8A7A91]"
                    >
                        No inventory items match the selected filters.
                    </td>
                </tr>
            )}
            </tbody>
        </table>
    );
}

type InventoryReportViewProps = {
    items: InventoryItem[];
    showBranchColumn: boolean;
    expandedInventoryId: string | null;
    onToggleExpanded: (itemId: string) => void;
    inStockCount: number;
    lowStockCount: number;
    outOfStockCount: number;
    soonToExpireCount: number;
    expiredCount: number;
    goodExpirationCount: number;
    categorySummary: Array<{ name: string; count: number }>;
    onExportPdf: () => void;
    onExportXlsx: () => void;
    onExportDoc: () => void;
};

function InventoryReportView({
                                 items,
                                 showBranchColumn,
                                 expandedInventoryId,
                                 onToggleExpanded,
                                 inStockCount,
                                 lowStockCount,
                                 outOfStockCount,
                                 soonToExpireCount,
                                 expiredCount,
                                 goodExpirationCount,
                                 categorySummary,
                                 onExportPdf,
                                 onExportXlsx,
                                 onExportDoc,
                             }: InventoryReportViewProps) {
    const totalStockCounted = inStockCount + lowStockCount + outOfStockCount;
    const totalExpirationCounted =
        goodExpirationCount + soonToExpireCount + expiredCount;

    return (
        <div className="grid grid-cols-1 items-start gap-3 2xl:grid-cols-[minmax(0,1fr)_260px]">
            <section className="min-w-0 self-start overflow-hidden rounded-[14px] border border-[#E5DDEA] bg-white shadow-sm">
                <div className="border-b border-[#ECE5F0] px-4 py-3.5">
                    <h2 className="text-[16px] font-bold text-[#1A1220]">
                        Inventory Report History
                    </h2>
                    <p className="mt-1 text-[11px] text-[#8A7A91]">
                        Review current stock, prices, variants, and expiration status for every item.
                    </p>
                </div>

                <InventoryItemsTable
                    items={items}
                    showBranchColumn={showBranchColumn}
                    expandedInventoryId={expandedInventoryId}
                    onToggleExpanded={onToggleExpanded}
                />
            </section>

            <aside className="self-start rounded-[14px] border border-[#E5DDEA] bg-white p-3 shadow-sm">
                <h2 className="text-[16px] font-bold text-[#1A1220]">
                    Inventory Summary
                </h2>

                <div className="mt-3 divide-y divide-[#EEE7F2]">
                    <SummaryMetricRow label="In Stock" value={inStockCount} dot="bg-[#22B65B]" />
                    <SummaryMetricRow label="Low Stock" value={lowStockCount} dot="bg-[#F6A800]" />
                    <SummaryMetricRow label="Out of Stock" value={outOfStockCount} dot="bg-[#EF3E38]" />
                    <SummaryMetricRow label="Soon to Expire" value={soonToExpireCount} dot="bg-[#F6A800]" />
                    <SummaryMetricRow label="Expired" value={expiredCount} dot="bg-[#EF3E38]" />
                </div>

                <div className="mt-4 border-t border-dashed border-[#E4D9EB] pt-4">
                    <h3 className="text-[12px] font-bold text-[#211629]">
                        Stock Status Breakdown
                    </h3>

                    <div className="mt-3 flex items-center gap-4">
                        <div
                            className="relative h-20 w-20 shrink-0 rounded-full"
                            style={{
                                background: (() => {
                                    const total = Math.max(totalStockCounted, 1);
                                    const inStockEnd = (inStockCount / total) * 100;
                                    const lowStockEnd =
                                        ((inStockCount + lowStockCount) / total) * 100;

                                    return `conic-gradient(
                                        #22B65B 0% ${inStockEnd}%,
                                        #F6A800 ${inStockEnd}% ${lowStockEnd}%,
                                        #EF3E38 ${lowStockEnd}% 100%
                                    )`;
                                })(),
                            }}
                        >
                            <span className="absolute inset-[14px] rounded-full bg-white" />
                        </div>

                        <div className="min-w-0 flex-1 space-y-2">
                            {[
                                { label: "In Stock", count: inStockCount, dot: "bg-[#22B65B]" },
                                { label: "Low Stock", count: lowStockCount, dot: "bg-[#F6A800]" },
                                { label: "Out of Stock", count: outOfStockCount, dot: "bg-[#EF3E38]" },
                            ].map((item) => (
                                <div
                                    key={item.label}
                                    className="flex items-center justify-between gap-2 text-[10px]"
                                >
                                    <span className="flex min-w-0 items-center gap-2 text-[#5F5267]">
                                        <span className={`h-2 w-2 shrink-0 rounded-full ${item.dot}`} />
                                        <span className="truncate">{item.label}</span>
                                    </span>
                                    <span className="font-bold text-[#251A2C]">
                                        {formatNumber(item.count)}
                                    </span>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>

                <div className="mt-4 border-t border-dashed border-[#E4D9EB] pt-4">
                    <h3 className="text-[12px] font-bold text-[#211629]">
                        Expiration Status Breakdown
                    </h3>

                    <div className="mt-3 flex items-center gap-4">
                        <div
                            className="relative h-20 w-20 shrink-0 rounded-full"
                            style={{
                                background: (() => {
                                    const total = Math.max(totalExpirationCounted, 1);
                                    const goodEnd = (goodExpirationCount / total) * 100;
                                    const soonEnd =
                                        ((goodExpirationCount + soonToExpireCount) / total) * 100;

                                    return `conic-gradient(
                                        #22B65B 0% ${goodEnd}%,
                                        #F6A800 ${goodEnd}% ${soonEnd}%,
                                        #EF3E38 ${soonEnd}% 100%
                                    )`;
                                })(),
                            }}
                        >
                            <span className="absolute inset-[14px] rounded-full bg-white" />
                        </div>

                        <div className="min-w-0 flex-1 space-y-2">
                            {[
                                { label: "Good / No Expiry", count: goodExpirationCount, dot: "bg-[#22B65B]" },
                                { label: "Soon to Expire", count: soonToExpireCount, dot: "bg-[#F6A800]" },
                                { label: "Expired", count: expiredCount, dot: "bg-[#EF3E38]" },
                            ].map((item) => (
                                <div
                                    key={item.label}
                                    className="flex items-center justify-between gap-2 text-[10px]"
                                >
                                    <span className="flex min-w-0 items-center gap-2 text-[#5F5267]">
                                        <span className={`h-2 w-2 shrink-0 rounded-full ${item.dot}`} />
                                        <span className="truncate">{item.label}</span>
                                    </span>
                                    <span className="font-bold text-[#251A2C]">
                                        {formatNumber(item.count)}
                                    </span>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>

                <div className="mt-4 border-t border-dashed border-[#E4D9EB] pt-4">
                    <h3 className="text-[12px] font-bold text-[#211629]">All Categories</h3>
                    <div className="mt-3">
                        <SummaryBarList
                            items={categorySummary.map((category) => ({
                                name: category.name,
                                value: category.count,
                            }))}
                            emptyText="No category data available."
                        />
                    </div>
                </div>

                <InventoryExportMenu
                    label="Export Filtered Inventory"
                    onExportPdf={onExportPdf}
                    onExportXlsx={onExportXlsx}
                    onExportDoc={onExportDoc}
                />
            </aside>
        </div>
    );
}

type RestockReportViewProps = {
    records: RestockRecord[];
    showBranchColumn: boolean;
    onExportPdf: () => void;
    onExportXlsx: () => void;
    onExportDoc: () => void;
};

function RestockReportView({
                               records,
                               showBranchColumn,
                               onExportPdf,
                               onExportXlsx,
                               onExportDoc,
                           }: RestockReportViewProps) {
    const totalUnitsAdded = sumBy(records, (item) => item.quantityAdded);
    const productsRestocked = new Set(
        records.map((item) => item.product.trim().toLowerCase()).filter(Boolean)
    ).size;
    const variantsRestocked = new Set(
        records
            .map((item) => item.variantName?.trim().toLowerCase() || "")
            .filter(Boolean)
    ).size;

    const restockByProduct = Array.from(
        records.reduce((summary, item) => {
            const product = item.product || "Unnamed Product";
            summary.set(
                product,
                (summary.get(product) || 0) + Number(item.quantityAdded || 0)
            );
            return summary;
        }, new Map<string, number>())
    )
        .map(([name, quantity]) => ({ name, quantity }))
        .sort((left, right) => right.quantity - left.quantity)
        .slice(0, 6);

    const largestRestockQuantity = Math.max(
        1,
        ...restockByProduct.map((item) => item.quantity)
    );
    const columnCount = showBranchColumn ? 8 : 7;

    return (
        <div className="grid grid-cols-1 items-start gap-3 2xl:grid-cols-[minmax(0,1fr)_260px]">
            <section className="min-w-0 self-start overflow-hidden rounded-[14px] border border-[#E5DDEA] bg-white shadow-sm">
                <div className="border-b border-[#ECE5F0] px-4 py-3.5">
                    <h2 className="text-[16px] font-bold text-[#1A1220]">
                        Restock Report History
                    </h2>
                    <p className="mt-1 text-[11px] text-[#8A7A91]">
                        Review product restocks, quantities added, stock movement, and receiving details.
                    </p>
                </div>

                <table className="w-full table-fixed border-collapse text-[11px]">
                    <colgroup>
                        <col className={showBranchColumn ? "w-[13%]" : "w-[14%]"} />
                        <col className={showBranchColumn ? "w-[22%]" : "w-[27%]"} />
                        {showBranchColumn ? <col className="w-[12%]" /> : null}
                        <col className={showBranchColumn ? "w-[10%]" : "w-[11%]"} />
                        <col className={showBranchColumn ? "w-[9%]" : "w-[10%]"} />
                        <col className={showBranchColumn ? "w-[10%]" : "w-[11%]"} />
                        <col className={showBranchColumn ? "w-[10%]" : "w-[11%]"} />
                        <col className={showBranchColumn ? "w-[14%]" : "w-[16%]"} />
                    </colgroup>

                    <thead>
                    <tr className="border-b border-[#E8DFED] bg-[#FCFAFD]">
                        <th className="px-3 py-3 text-left text-[9px] font-semibold uppercase tracking-[0.06em] text-[#685674]">
                            Date
                        </th>
                        <th className="px-2 py-3 text-left text-[9px] font-semibold uppercase tracking-[0.06em] text-[#685674]">
                            Product
                        </th>
                        {showBranchColumn ? (
                            <th className="px-2 py-3 text-left text-[9px] font-semibold uppercase tracking-[0.06em] text-[#685674]">
                                Branch
                            </th>
                        ) : null}
                        <th className="px-2 py-3 text-left text-[9px] font-semibold uppercase tracking-[0.06em] text-[#685674]">
                            Type
                        </th>
                        <th className="px-2 py-3 text-center text-[9px] font-semibold uppercase tracking-[0.06em] text-[#685674]">
                            Stock Before
                        </th>
                        <th className="px-2 py-3 text-center text-[9px] font-semibold uppercase tracking-[0.06em] text-[#685674]">
                            Qty Added
                        </th>
                        <th className="px-2 py-3 text-center text-[9px] font-semibold uppercase tracking-[0.06em] text-[#685674]">
                            Current Stock
                        </th>
                        <th className="px-2 py-3 text-left text-[9px] font-semibold uppercase tracking-[0.06em] text-[#685674]">
                            Received By
                        </th>
                    </tr>
                    </thead>

                    <tbody>
                    {records.length > 0 ? (
                        records.map((item) => {
                            const stockBefore =
                                typeof item.stockBefore === "number"
                                    ? item.stockBefore
                                    : Math.max(
                                        Number(item.currentStock || 0) -
                                        Number(item.quantityAdded || 0),
                                        0
                                    );

                            return (
                                <tr
                                    key={item.id}
                                    className="border-b border-[#EFE8F2] bg-white transition-colors hover:bg-[#FCFAFF]"
                                >
                                    <td className="px-3 py-3 align-top">
                                        <p className="font-semibold text-[#1A1220]">
                                            {formatDate(item.date)}
                                        </p>
                                        <p className="mt-0.5 break-words text-[9px] text-[#8C7A95]">
                                            {item.reference || item.id}
                                        </p>
                                    </td>

                                    <td className="px-2 py-3 align-top">
                                        <p className="break-words font-semibold text-[#20152A]">
                                            {item.product}
                                        </p>
                                        <p className="mt-0.5 break-words text-[9px] text-[#8C7A95]">
                                            {item.variantName || "Regular product"}
                                        </p>
                                    </td>

                                    {showBranchColumn ? (
                                        <td
                                            className="whitespace-normal break-words px-2 py-3 align-top leading-snug text-[#5F5267]"
                                            title={item.branch}
                                        >
                                            {item.branch}
                                        </td>
                                    ) : null}

                                    <td className="break-words px-2 py-3 align-top text-[#5F5267]">
                                        {item.variantName ? "Variant" : "Regular"}
                                    </td>
                                    <td className="px-2 py-3 text-center align-top font-semibold tabular-nums text-[#685674]">
                                        {formatNumber(stockBefore)}
                                    </td>
                                    <td className="px-2 py-3 text-center align-top font-bold tabular-nums text-[#12A150]">
                                        +{formatNumber(item.quantityAdded)}
                                    </td>
                                    <td className="px-2 py-3 text-center align-top font-bold tabular-nums text-[#1A1220]">
                                        {formatNumber(item.currentStock)}
                                    </td>
                                    <td className="break-words px-2 py-3 align-top text-[#5F5267]">
                                        {item.receivedBy || "Not recorded"}
                                    </td>
                                </tr>
                            );
                        })
                    ) : (
                        <tr>
                            <td
                                colSpan={columnCount}
                                className="px-4 py-14 text-center text-sm text-[#8A7A91]"
                            >
                                No restock records match the selected filters.
                            </td>
                        </tr>
                    )}
                    </tbody>
                </table>
            </section>

            <aside className="self-start rounded-[14px] border border-[#E5DDEA] bg-white p-3 shadow-sm">
                <h2 className="text-[16px] font-bold text-[#1A1220]">
                    Restock Summary
                </h2>

                <div className="mt-3 divide-y divide-[#EEE7F2]">
                    {[
                        {
                            label: "Restock Records",
                            value: records.length,
                            dot: "bg-[#7A45E8]",
                        },
                        {
                            label: "Units Added",
                            value: totalUnitsAdded,
                            dot: "bg-[#22B65B]",
                        },
                        {
                            label: "Products Restocked",
                            value: productsRestocked,
                            dot: "bg-[#FF8A00]",
                        },
                        {
                            label: "Variants Restocked",
                            value: variantsRestocked,
                            dot: "bg-[#2F80ED]",
                        },
                    ].map((summary) => (
                        <div
                            key={summary.label}
                            className="flex w-full items-center justify-between gap-3 px-1 py-2 text-[#392A42]"
                        >
                            <span className="flex items-center gap-2 text-[11px] font-semibold">
                                <span className={`h-2.5 w-2.5 rounded-full ${summary.dot}`} />
                                {summary.label}
                            </span>
                            <span className="text-[12px] font-bold tabular-nums">
                                {formatNumber(summary.value)}
                            </span>
                        </div>
                    ))}
                </div>

                <div className="mt-4 border-t border-dashed border-[#E4D9EB] pt-4">
                    <h3 className="text-[12px] font-bold text-[#211629]">
                        Most Restocked Products
                    </h3>
                    <div className="mt-3 space-y-2">
                        {restockByProduct.length > 0 ? (
                            restockByProduct.map((item) => (
                                <div
                                    key={item.name}
                                    className="grid grid-cols-[72px_1fr_auto] items-center gap-1.5 text-[9px]"
                                >
                                    <span className="truncate text-[#5F5267]" title={item.name}>
                                        {item.name}
                                    </span>
                                    <span className="h-1.5 overflow-hidden rounded-full bg-[#EFE9F4]">
                                        <span
                                            className="block h-full rounded-full bg-[#7041E5]"
                                            style={{
                                                width: `${
                                                    (item.quantity / largestRestockQuantity) * 100
                                                }%`,
                                            }}
                                        />
                                    </span>
                                    <span className="font-bold tabular-nums text-[#251A2C]">
                                        {formatNumber(item.quantity)}
                                    </span>
                                </div>
                            ))
                        ) : (
                            <p className="text-[10px] text-[#8A7A91]">
                                No restock product data available.
                            </p>
                        )}
                    </div>
                </div>

                <InventoryExportMenu
                    label="Export Filtered Restock"
                    onExportPdf={onExportPdf}
                    onExportXlsx={onExportXlsx}
                    onExportDoc={onExportDoc}
                />
            </aside>
        </div>
    );
}

type SummaryMetricRowProps = {
    label: string;
    value: string | number;
    dot: string;
    active?: boolean;
    onClick?: () => void;
};

function SummaryMetricRow({
                              label,
                              value,
                              dot,
                              active = false,
                              onClick,
                          }: SummaryMetricRowProps) {
    const content = (
        <>
            <span className="flex min-w-0 items-center gap-2 text-[11px] font-semibold">
                <span className={`h-2.5 w-2.5 shrink-0 rounded-full ${dot}`} />
                <span className="truncate">{label}</span>
            </span>
            <span className="shrink-0 text-[12px] font-bold tabular-nums">
                {typeof value === "number" ? formatNumber(value) : value}
            </span>
        </>
    );

    if (onClick) {
        return (
            <button
                type="button"
                onClick={onClick}
                className={`flex w-full items-center justify-between gap-3 px-1 py-2 text-left transition hover:bg-[#FAF6FF] ${
                    active ? "text-[#5C2FC0]" : "text-[#392A42]"
                }`}
            >
                {content}
            </button>
        );
    }

    return (
        <div className="flex w-full items-center justify-between gap-3 px-1 py-2 text-[#392A42]">
            {content}
        </div>
    );
}

type SummaryBarItem = {
    name: string;
    value: number;
    orderCount?: number;
    salesAmount?: number;
};

function SummaryBarList({
                            items,
                            emptyText,
                            interactive = false,
                        }: {
    items: SummaryBarItem[];
    emptyText: string;
    interactive?: boolean;
}) {
    const [expandedItem, setExpandedItem] = useState<string | null>(null);
    const maximum = Math.max(1, ...items.map((item) => item.value));

    if (items.length === 0) {
        return <p className="text-[10px] text-[#8A7A91]">{emptyText}</p>;
    }

    return (
        <div className="space-y-2">
            {items.map((item, index) => {
                const isExpanded = interactive && expandedItem === item.name;
                const percentage = Math.round((item.value / maximum) * 100);

                if (!interactive) {
                    return (
                        <div
                            key={item.name}
                            className="grid grid-cols-[72px_1fr_auto] items-center gap-1.5 text-[9px]"
                        >
                            <span className="truncate text-[#5F5267]" title={item.name}>
                                {item.name}
                            </span>
                            <span className="h-1.5 overflow-hidden rounded-full bg-[#EFE9F4]">
                                <span
                                    className="block h-full rounded-full bg-[#7041E5]"
                                    style={{ width: `${percentage}%` }}
                                />
                            </span>
                            <span className="font-bold tabular-nums text-[#251A2C]">
                                {formatNumber(item.value)}
                            </span>
                        </div>
                    );
                }

                return (
                    <div
                        key={item.name}
                        className={`overflow-hidden rounded-[10px] border transition ${
                            isExpanded
                                ? "border-[#CDB8F8] bg-[#FAF7FF]"
                                : "border-transparent bg-white hover:border-[#E7DCF2] hover:bg-[#FCFAFF]"
                        }`}
                    >
                        <button
                            type="button"
                            onClick={() =>
                                setExpandedItem((current) =>
                                    current === item.name ? null : item.name
                                )
                            }
                            className="w-full px-2 py-2 text-left"
                            aria-expanded={isExpanded}
                            title={`View details for ${item.name}`}
                        >
                            <div className="flex items-center justify-between gap-2">
                                <div className="flex min-w-0 items-center gap-2">
                                    <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-[#F0E9FF] text-[9px] font-bold text-[#6840C6]">
                                        {index + 1}
                                    </span>
                                    <span className="truncate text-[10px] font-semibold text-[#392A42]">
                                        {item.name}
                                    </span>
                                </div>
                                <div className="flex shrink-0 items-center gap-1.5">
                                    <span className="text-[10px] font-bold tabular-nums text-[#251A2C]">
                                        {formatNumber(item.value)}
                                    </span>
                                    {isExpanded ? (
                                        <ChevronUp className="h-3.5 w-3.5 text-[#775F86]" />
                                    ) : (
                                        <ChevronDown className="h-3.5 w-3.5 text-[#775F86]" />
                                    )}
                                </div>
                            </div>

                            <div className="mt-2 flex items-center gap-2">
                                <span className="h-1.5 flex-1 overflow-hidden rounded-full bg-[#EFE9F4]">
                                    <span
                                        className="block h-full rounded-full bg-[#7041E5] transition-all duration-300"
                                        style={{ width: `${percentage}%` }}
                                    />
                                </span>
                                <span className="w-8 text-right text-[8px] font-semibold tabular-nums text-[#806F89]">
                                    {percentage}%
                                </span>
                            </div>
                        </button>

                        {isExpanded ? (
                            <div className="grid grid-cols-2 gap-2 border-t border-[#E9DFF1] px-2 py-2.5">
                                <div className="rounded-[8px] bg-white px-2 py-2">
                                    <p className="text-[8px] uppercase tracking-[0.05em] text-[#8A7A91]">
                                        Units Sold
                                    </p>
                                    <p className="mt-1 text-[11px] font-bold tabular-nums text-[#251A2C]">
                                        {formatNumber(item.value)}
                                    </p>
                                </div>
                                <div className="rounded-[8px] bg-white px-2 py-2">
                                    <p className="text-[8px] uppercase tracking-[0.05em] text-[#8A7A91]">
                                        Orders
                                    </p>
                                    <p className="mt-1 text-[11px] font-bold tabular-nums text-[#251A2C]">
                                        {formatNumber(item.orderCount || 0)}
                                    </p>
                                </div>
                                <div className="col-span-2 rounded-[8px] bg-white px-2 py-2">
                                    <p className="text-[8px] uppercase tracking-[0.05em] text-[#8A7A91]">
                                        POS Sales
                                    </p>
                                    <p className="mt-1 text-[11px] font-bold tabular-nums text-[#12A150]">
                                        {formatPeso(item.salesAmount || 0)}
                                    </p>
                                </div>
                            </div>
                        ) : null}
                    </div>
                );
            })}
        </div>
    );
}

function PosRow({ item, showBranchColumn }: { item: SaleRecord; showBranchColumn: boolean }) {
    const [isExpanded, setIsExpanded] = useState(false);
    const lineItems = item.lineItems || [];
    const hasLineItems = lineItems.length > 0;

    return (
        <Fragment>
            <tr className={`border-b border-[#EFE8F2] transition-colors ${isExpanded ? "bg-[#F8F2FC]" : "bg-white hover:bg-[#FCFAFF]"}`}>
                <td className="px-3 py-3 align-top">
                    <div className="flex min-w-0 items-start gap-2">
                        {hasLineItems ? (
                            <button
                                type="button"
                                onClick={() => setIsExpanded(!isExpanded)}
                                className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded text-[#4E2C66] transition hover:bg-[#EEE4F7] hover:text-[#6D35D1]"
                                aria-label={isExpanded ? "Hide items" : "Show items"}
                            >
                                {isExpanded ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
                            </button>
                        ) : (
                            <span className="block h-5 w-5 shrink-0" />
                        )}
                        <div className="min-w-0">
                            <p className="break-words font-mono text-[10px] font-semibold text-[#1A1220]">
                                {item.reference || item.id}
                            </p>
                            {hasLineItems ? (
                                <p className="mt-0.5 break-words text-[9px] text-[#8C7A95]">
                                    {lineItems.length} item{lineItems.length === 1 ? "" : "s"}
                                </p>
                            ) : null}
                        </div>
                    </div>
                </td>
                {showBranchColumn ? (
                    <td className="break-words px-3 py-3 align-top text-[#5F5267]">
                        {item.branch || "—"}
                    </td>
                ) : null}
                <td className="px-3 py-3 text-center align-top text-[#5F5267]">
                    <span className="font-semibold tabular-nums text-[#1A1220]">
                        {formatNumber(item.quantity || sumBy(lineItems, (line) => line.quantity))}
                    </span>
                </td>
                <td className="px-3 py-3 text-right align-top font-bold tabular-nums text-[#1A1220]">
                    {formatPeso(item.amount)}
                </td>
                <td className="whitespace-nowrap px-3 py-3 align-top font-semibold text-[#1A1220]">
                    {formatDate(item.date)}
                </td>
            </tr>

            {hasLineItems && isExpanded ? (
                lineItems.map((line, idx) => {
                    const qty = line.quantity && line.quantity > 0 ? line.quantity : 1;
                    const unitPrice = line.unitPrice || 0;
                    const lineTotal = line.lineTotal || (unitPrice * qty) || 0;

                    return (
                        <tr key={idx} className="border-b border-[#E8DDF0] bg-[#FBF7FE] transition hover:bg-[#F6EFFB]">
                            <td colSpan={showBranchColumn ? 5 : 4} className="px-3 py-3 align-top">
                                <div className="flex min-w-0 items-start justify-between gap-3 pl-8">
                                    <div className="flex min-w-0 items-start gap-3">
                                        <span className="mt-1.5 h-2.5 w-2.5 shrink-0 rounded-full bg-[#9B65D6]" />
                                        <div className="min-w-0">
                                            <p className="break-words font-semibold text-[#3C2947]">
                                                {line.name}
                                            </p>
                                            <p className="mt-0.5 text-[10px] text-[#8C7A95]">
                                                {`× ${qty}`}
                                            </p>
                                        </div>
                                    </div>
                                    {lineTotal > 0 ? (
                                        <div className="shrink-0 text-right">
                                            <p className="font-semibold tabular-nums text-[#3C2947]">
                                                {formatPeso(lineTotal)}
                                            </p>
                                            {unitPrice > 0 ? (
                                                <p className="mt-0.5 text-[10px] tabular-nums text-[#9A8CA2]">
                                                    {`${formatPeso(unitPrice)} each`}
                                                </p>
                                            ) : null}
                                        </div>
                                    ) : null}
                                </div>
                            </td>
                        </tr>
                    );
                })
            ) : null}
        </Fragment>
    );
}

type PosReportViewProps = {
    records: SaleRecord[];
    showBranchColumn: boolean;
    onExportPdf: () => void;
    onExportXlsx: () => void;
    onExportDoc: () => void;
};

function PosReportView({
                           records,
                           showBranchColumn,
                           onExportPdf,
                           onExportXlsx,
                           onExportDoc,
                       }: PosReportViewProps) {
    const totalSalesValue = sumBy(records, (item) => item.amount);
    const totalItemsSold = sumBy(records, (item) => item.quantity);
    const averageTransaction = records.length
        ? totalSalesValue / records.length
        : 0;

    const topSellingSummary = new Map<
        string,
        {
            value: number;
            orderCount: number;
            salesAmount: number;
        }
    >();

    records.forEach((order) => {
        const orderItems =
            Array.isArray(order.lineItems) && order.lineItems.length > 0
                ? order.lineItems
                : [
                    {
                        name:
                            order.product ||
                            order.itemsText ||
                            "Unspecified Item",
                        quantity: Number(order.quantity || 0),
                        unitPrice: 0,
                        lineTotal: Number(order.amount || 0),
                    },
                ];
        const countedInOrder = new Set<string>();

        orderItems.forEach((lineItem) => {
            const name = lineItem.name.trim() || "Unspecified Item";
            const quantity = Math.max(0, Number(lineItem.quantity || 0));

            if (quantity <= 0) {
                return;
            }

            const current =
                topSellingSummary.get(name) || {
                    value: 0,
                    orderCount: 0,
                    salesAmount: 0,
                };

            current.value += quantity;
            current.salesAmount += Math.max(
                0,
                Number(
                    lineItem.lineTotal ||
                    lineItem.unitPrice * quantity ||
                    0
                )
            );

            if (!countedInOrder.has(name)) {
                current.orderCount += 1;
                countedInOrder.add(name);
            }

            topSellingSummary.set(name, current);
        });
    });

    const topSellingItems = Array.from(topSellingSummary.entries())
        .map(([name, summary]) => ({
            name,
            value: summary.value,
            orderCount: summary.orderCount,
            salesAmount: summary.salesAmount,
        }))
        .sort((left, right) =>
            right.value - left.value ||
            right.salesAmount - left.salesAmount ||
            left.name.localeCompare(right.name)
        )
        .slice(0, 6);
    const columnCount = showBranchColumn ? 5 : 4;

    return (
        <div className="grid grid-cols-1 items-start gap-3 2xl:grid-cols-[minmax(0,1fr)_260px]">
            <section className="min-w-0 self-start overflow-hidden rounded-[14px] border border-[#E5DDEA] bg-white shadow-sm">
                <div className="border-b border-[#ECE5F0] px-4 py-3.5">
                    <h2 className="text-[16px] font-bold text-[#1A1220]">
                        POS Report History
                    </h2>
                    <p className="mt-1 text-[11px] text-[#8A7A91]">
                        Review order IDs, items sold, totals, transaction dates, and branch records.
                    </p>
                </div>

                <table className="w-full table-fixed border-collapse text-[11px]">
                    <colgroup>
                        <col className={showBranchColumn ? "w-[20%]" : "w-[22%]"} />
                        {showBranchColumn ? <col className="w-[18%]" /> : null}
                        <col className={showBranchColumn ? "w-[34%]" : "w-[48%]"} />
                        <col className={showBranchColumn ? "w-[14%]" : "w-[15%]"} />
                        <col className={showBranchColumn ? "w-[14%]" : "w-[15%]"} />
                    </colgroup>
                    <thead>
                    <tr className="border-b border-[#E8DFED] bg-[#FCFAFD]">
                        <th className="px-3 py-3 text-left text-[9px] font-semibold uppercase tracking-[0.06em] text-[#685674]">
                            Order ID
                        </th>
                        {showBranchColumn ? (
                            <th className="px-3 py-3 text-left text-[9px] font-semibold uppercase tracking-[0.06em] text-[#685674]">
                                Branch
                            </th>
                        ) : null}
                        <th className="px-3 py-3 text-center text-[9px] font-semibold uppercase tracking-[0.06em] text-[#685674]">
                            Items Sold
                        </th>
                        <th className="px-3 py-3 text-right text-[9px] font-semibold uppercase tracking-[0.06em] text-[#685674]">
                            Total
                        </th>
                        <th className="px-3 py-3 text-left text-[9px] font-semibold uppercase tracking-[0.06em] text-[#685674]">
                            Date
                        </th>
                    </tr>
                    </thead>
                    <tbody>
                    {records.length > 0 ? (
                        records.map((item) => (
                            <PosRow key={item.id} item={item} showBranchColumn={showBranchColumn} />
                        ))
                    ) : (
                        <tr>
                            <td colSpan={columnCount} className="px-4 py-14 text-center text-sm text-[#8A7A91]">
                                No POS orders match the selected filters.
                            </td>
                        </tr>
                    )}
                    </tbody>
                </table>
            </section>

            <aside className="self-start rounded-[14px] border border-[#E5DDEA] bg-white p-3 shadow-sm">
                <h2 className="text-[16px] font-bold text-[#1A1220]">POS Summary</h2>
                <div className="mt-3 divide-y divide-[#EEE7F2]">
                    <SummaryMetricRow label="Total Transactions" value={records.length} dot="bg-[#7A45E8]" />
                    <SummaryMetricRow label="Total POS Sales" value={formatPeso(totalSalesValue)} dot="bg-[#22B65B]" />
                    <SummaryMetricRow label="Average Transaction" value={formatPeso(averageTransaction)} dot="bg-[#FF8A00]" />
                    <SummaryMetricRow label="Items Sold" value={totalItemsSold} dot="bg-[#2F80ED]" />
                </div>

                <div className="mt-4 border-t border-dashed border-[#E4D9EB] pt-4">
                    <h3 className="text-[12px] font-bold text-[#211629]">Top Selling Items</h3>
                    <p className="mt-1 text-[9px] text-[#8A7A91]">
                        Click an item to view its sales details.
                    </p>
                    <div className="mt-3">
                        <SummaryBarList
                            items={topSellingItems}
                            emptyText="No item sales data available."
                            interactive
                        />
                    </div>
                </div>

                <InventoryExportMenu
                    label="Export Filtered POS"
                    onExportPdf={onExportPdf}
                    onExportXlsx={onExportXlsx}
                    onExportDoc={onExportDoc}
                />
            </aside>
        </div>
    );
}

type BookingReportViewProps = {
    records: BookingRecord[];
    searchQuery: string;
    activeFilter: BookingFilter;
    onFilterChange: (filter: BookingFilter) => void;
    showBranchColumn: boolean;
    onExportPdf: () => void;
    onExportXlsx: () => void;
    onExportDoc: () => void;
};

function BookingReportView({
                               records,
                               searchQuery,
                               activeFilter,
                               onFilterChange,
                               showBranchColumn,
                               onExportPdf,
                               onExportXlsx,
                               onExportDoc,
                           }: BookingReportViewProps) {
    const query = searchQuery.trim().toLowerCase();
    const searchedRecords = records.filter((item) =>
        !query ||
        [
            item.id,
            item.reference,
            item.customer,
            item.phone,
            item.venue,
            item.packageName,
            item.statusLabel,
            item.paymentStatus,
            item.branch,
        ]
            .join(" ")
            .toLowerCase()
            .includes(query)
    );
    const displayedRecords =
        activeFilter === "all"
            ? searchedRecords
            : searchedRecords.filter((item) => item.status === activeFilter);
    const topPackages = Array.from(
        searchedRecords.reduce((summary, item) => {
            const name = item.packageName || "Custom Booking";
            summary.set(name, (summary.get(name) || 0) + 1);
            return summary;
        }, new Map<string, number>())
    )
        .map(([name, value]) => ({ name, value }))
        .sort((left, right) => right.value - left.value)
        .slice(0, 6);
    const statusRows: Array<{
        label: string;
        filter: BookingFilter;
        dot: string;
        value: number;
    }> = [
        { label: "Total Bookings", filter: "all", dot: "bg-[#7A45E8]", value: searchedRecords.length },
        { label: "Pending", filter: "pending", dot: "bg-[#FF8A00]", value: searchedRecords.filter((item) => item.status === "pending").length },
        { label: "Confirmed", filter: "confirmed", dot: "bg-[#7A45E8]", value: searchedRecords.filter((item) => item.status === "confirmed").length },
        { label: "Preparing", filter: "preparing", dot: "bg-[#F6A800]", value: searchedRecords.filter((item) => item.status === "preparing").length },
        { label: "Completed", filter: "completed", dot: "bg-[#22B65B]", value: searchedRecords.filter((item) => item.status === "completed").length },
        { label: "Cancelled", filter: "cancelled", dot: "bg-[#EF3E38]", value: searchedRecords.filter((item) => item.status === "cancelled").length },
    ];

    return (
        <div className="grid grid-cols-1 items-start gap-3 2xl:grid-cols-[minmax(0,1fr)_260px]">
            <section className="min-w-0 self-start overflow-hidden rounded-[14px] border border-[#E5DDEA] bg-white shadow-sm">
                <div className="border-b border-[#ECE5F0] px-4 py-3.5">
                    <h2 className="text-[16px] font-bold text-[#1A1220]">Booking Report History</h2>
                    <p className="mt-1 text-[11px] text-[#8A7A91]">
                        Review booking clients, schedules, packages, payments, and status.
                    </p>
                </div>

                <table className="w-full table-fixed border-collapse text-[11px]">
                    <colgroup>
                        <col className={showBranchColumn ? "w-[18%]" : "w-[20%]"} />
                        {showBranchColumn ? <col className="w-[12%]" /> : null}
                        <col className={showBranchColumn ? "w-[14%]" : "w-[16%]"} />
                        <col className={showBranchColumn ? "w-[18%]" : "w-[20%]"} />
                        <col className={showBranchColumn ? "w-[15%]" : "w-[17%]"} />
                        <col className={showBranchColumn ? "w-[11%]" : "w-[13%]"} />
                        <col className={showBranchColumn ? "w-[12%]" : "w-[14%]"} />
                    </colgroup>
                    <thead>
                    <tr className="border-b border-[#E8DFED] bg-[#FCFAFD]">
                        {[
                            ["Client", "text-left"],
                            ...(showBranchColumn ? [["Branch", "text-left"]] : []),
                            ["Schedule", "text-left"],
                            ["Package", "text-left"],
                            ["Payment", "text-left"],
                            ["Status", "text-center"],
                            ["Details", "text-right"],
                        ].map(([label, align]) => (
                            <th key={label} className={`px-2 py-3 text-[9px] font-semibold uppercase tracking-[0.06em] text-[#685674] ${align}`}>
                                {label}
                            </th>
                        ))}
                    </tr>
                    </thead>
                    <tbody>
                    {displayedRecords.length > 0 ? (
                        displayedRecords.map((item) => {
                            const payment = getBookingPaymentDetails(item);

                            return (
                                <tr
                                    key={item.id}
                                    className="border-b border-[#EFE8F2] bg-white transition-colors hover:bg-[#FCFAFF]"
                                >
                                    <td className="px-2 py-3 align-top">
                                        <div className="min-w-0">
                                            <p className="break-words font-semibold text-[#1A1220]">
                                                {item.customer}
                                            </p>
                                            <p className="mt-0.5 break-words text-[9px] text-[#8C7A95]">
                                                {item.phone || item.reference}
                                            </p>
                                        </div>
                                    </td>

                                    {showBranchColumn ? (
                                        <td className="break-words px-2 py-3 align-top text-[#5F5267]">
                                            {item.branch || "—"}
                                        </td>
                                    ) : null}

                                    <td className="px-2 py-3 align-top">
                                        <p className="font-semibold text-[#1A1220]">
                                            {formatDate(item.eventDate)}
                                        </p>
                                        <p className="mt-0.5 text-[9px] text-[#8C7A95]">
                                            {item.scheduleTime || "Time not recorded"}
                                        </p>
                                    </td>

                                    <td className="break-words px-2 py-3 align-top">
                                        <p className="font-semibold text-[#1A1220]">
                                            {item.packageName}
                                        </p>
                                        <p className="mt-0.5 text-[9px] text-[#8C7A95]">
                                            {formatPeso(payment.packagePrice)}
                                        </p>
                                    </td>

                                    <td className="px-2 py-3 align-top">
                                        <StatusBadge status={payment.paymentStatus} />
                                        <p className="mt-1 text-[9px] text-[#8C7A95]">
                                            Paid {formatPeso(payment.amountPaid)}
                                        </p>
                                    </td>

                                    <td className="px-2 py-3 text-center align-top">
                                        <StatusBadge status={getBookingStatusLabel(item)} />
                                    </td>

                                    <td className="break-words px-2 py-3 text-right align-top text-[#5F5267]">
                                        {item.venue || "Venue not recorded"}
                                    </td>
                                </tr>
                            );
                        })
                    ) : (
                        <tr>
                            <td
                                colSpan={showBranchColumn ? 7 : 6}
                                className="px-4 py-14 text-center text-sm text-[#8A7A91]"
                            >
                                No booking records match the selected filters.
                            </td>
                        </tr>
                    )}
                    </tbody>
                </table>
            </section>

            <aside className="self-start rounded-[14px] border border-[#E5DDEA] bg-white p-3 shadow-sm">
                <h2 className="text-[16px] font-bold text-[#1A1220]">Booking Summary</h2>
                <div className="mt-3 divide-y divide-[#EEE7F2]">
                    {statusRows.map((item) => (
                        <SummaryMetricRow
                            key={item.filter}
                            label={item.label}
                            value={item.value}
                            dot={item.dot}
                            active={activeFilter === item.filter}
                            onClick={() => onFilterChange(item.filter)}
                        />
                    ))}
                </div>

                <div className="mt-4 border-t border-dashed border-[#E4D9EB] pt-4">
                    <h3 className="text-[12px] font-bold text-[#211629]">
                        Booking Status Breakdown
                    </h3>

                    <div className="mt-3 flex items-center gap-4">
                        <div
                            className="relative h-20 w-20 shrink-0 rounded-full"
                            style={{
                                background: (() => {
                                    const total = Math.max(searchedRecords.length, 1);

                                    const pending = searchedRecords.filter(
                                        (item) => item.status === "pending"
                                    ).length;

                                    const confirmed = searchedRecords.filter(
                                        (item) => item.status === "confirmed"
                                    ).length;

                                    const preparing = searchedRecords.filter(
                                        (item) => item.status === "preparing"
                                    ).length;

                                    const completed = searchedRecords.filter(
                                        (item) => item.status === "completed"
                                    ).length;

                                    const pendingEnd = (pending / total) * 100;
                                    const confirmedEnd =
                                        ((pending + confirmed) / total) * 100;
                                    const preparingEnd =
                                        ((pending + confirmed + preparing) / total) * 100;
                                    const completedEnd =
                                        ((pending + confirmed + preparing + completed) / total) * 100;

                                    return `conic-gradient(
                                        #FF8A00 0% ${pendingEnd}%,
                                        #7A45E8 ${pendingEnd}% ${confirmedEnd}%,
                                        #F6A800 ${confirmedEnd}% ${preparingEnd}%,
                                        #22B65B ${preparingEnd}% ${completedEnd}%,
                                        #EF3E38 ${completedEnd}% 100%
                                    )`;
                                })(),
                            }}
                        >
                            <span className="absolute inset-[14px] rounded-full bg-white" />
                        </div>

                        <div className="min-w-0 flex-1 space-y-2">
                            {[
                                {
                                    label: "Pending",
                                    count: searchedRecords.filter(
                                        (item) => item.status === "pending"
                                    ).length,
                                    dot: "bg-[#FF8A00]",
                                },
                                {
                                    label: "Confirmed",
                                    count: searchedRecords.filter(
                                        (item) => item.status === "confirmed"
                                    ).length,
                                    dot: "bg-[#7A45E8]",
                                },
                                {
                                    label: "Preparing",
                                    count: searchedRecords.filter(
                                        (item) => item.status === "preparing"
                                    ).length,
                                    dot: "bg-[#F6A800]",
                                },
                                {
                                    label: "Completed",
                                    count: searchedRecords.filter(
                                        (item) => item.status === "completed"
                                    ).length,
                                    dot: "bg-[#22B65B]",
                                },
                                {
                                    label: "Cancelled",
                                    count: searchedRecords.filter(
                                        (item) => item.status === "cancelled"
                                    ).length,
                                    dot: "bg-[#EF3E38]",
                                },
                            ].map((item) => (
                                <div
                                    key={item.label}
                                    className="flex items-center justify-between gap-2 text-[10px]"
                                >
                                    <span className="flex min-w-0 items-center gap-2 text-[#5F5267]">
                                        <span
                                            className={`h-2 w-2 shrink-0 rounded-full ${item.dot}`}
                                        />
                                        <span className="truncate">
                                            {item.label}
                                        </span>
                                    </span>

                                    <span className="font-bold text-[#251A2C]">
                                        {formatNumber(item.count)}
                                    </span>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>

                <div className="mt-4 border-t border-dashed border-[#E4D9EB] pt-4">
                    <h3 className="text-[12px] font-bold text-[#211629]">Top Packages</h3>
                    <div className="mt-3">
                        <SummaryBarList items={topPackages} emptyText="No package booking data available." />
                    </div>
                </div>

                <InventoryExportMenu
                    label="Export Filtered Booking"
                    onExportPdf={onExportPdf}
                    onExportXlsx={onExportXlsx}
                    onExportDoc={onExportDoc}
                />
            </aside>
        </div>
    );
}

function PackageRow({ item, showBranchColumn }: { item: PackageRecord; showBranchColumn: boolean }) {
    const [isExpanded, setIsExpanded] = useState(false);
    const inclusions = item.inclusions || [];
    const hasInclusions = inclusions.length > 0;

    return (
        <Fragment>
            <tr className={`border-b border-[#EFE8F2] transition-colors ${isExpanded ? "bg-[#F8F2FC]" : "bg-white hover:bg-[#FCFAFF]"}`}>
                <td className="px-2 py-3 align-top">
                    <div className="flex min-w-0 items-start gap-2">
                        {hasInclusions ? (
                            <button
                                type="button"
                                onClick={() => setIsExpanded(!isExpanded)}
                                className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded text-[#4E2C66] transition hover:bg-[#EEE4F7] hover:text-[#6D35D1]"
                                aria-label={isExpanded ? "Hide inclusions" : "Show inclusions"}
                            >
                                {isExpanded ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
                            </button>
                        ) : (
                            <span className="block h-5 w-5 shrink-0" />
                        )}
                        <div className="min-w-0">
                            <p className="break-words font-mono text-[10px] font-semibold text-[#1A1220]">
                                {item.id}
                            </p>
                            {hasInclusions ? (
                                <p className="mt-0.5 break-words text-[9px] text-[#8C7A95]">
                                    {inclusions.length} item{inclusions.length === 1 ? "" : "s"}
                                </p>
                            ) : null}
                        </div>
                    </div>
                </td>
                <td className="px-2 py-3 align-top">
                    <p className="break-words font-semibold text-[#1A1220]">{item.name}</p>
                </td>
                <td className="break-words px-2 py-3 align-top text-[#5F5267]">
                    {item.category || "Event Package"}
                </td>
                {showBranchColumn ? (
                    <td className="break-words px-2 py-3 align-top text-[#5F5267]">{item.branch}</td>
                ) : null}

                <td className="px-2 py-3 text-right align-top font-bold tabular-nums text-[#1A1220]">
                    {formatPeso(item.price)}
                </td>
                <td className="px-2 py-3 text-right align-top font-semibold tabular-nums text-[#1A1220]">
                    {item.downPayment ? formatPeso(item.downPayment) : "₱0.00"}
                </td>
                <td className="px-2 py-3 text-right align-top font-semibold tabular-nums text-[#1A1220]">
                    {item.discount
                        ? (item.isDiscountPercentage ? `${item.discount}%` : formatPeso(item.discount))
                        : "0%"}
                </td>

                <td className="px-2 py-3 text-center align-top">
                    <StatusBadge status={item.status} />
                </td>
            </tr>

            {hasInclusions && isExpanded ? (
                inclusions.map((inc, idx) => {
                    const qty = inc.quantity && inc.quantity > 0 ? inc.quantity : 1;
                    const unitPrice = inc.price || 0;
                    const lineTotal = unitPrice * qty;

                    return (
                        <tr key={idx} className="border-b border-[#E8DDF0] bg-[#FBF7FE] transition hover:bg-[#F6EFFB]">
                            <td colSpan={showBranchColumn ? 8 : 7} className="px-3 py-3 align-top">
                                <div className="flex min-w-0 items-start justify-between gap-3 pl-8">
                                    <div className="flex min-w-0 items-start gap-3">
                                        <span className="mt-1.5 h-2.5 w-2.5 shrink-0 rounded-full bg-[#9B65D6]" />
                                        <div className="min-w-0">
                                            <p className="break-words font-semibold text-[#3C2947]">
                                                {inc.name}
                                            </p>
                                            <p className="mt-0.5 text-[10px] text-[#8C7A95]">
                                                {`× ${qty}`}
                                            </p>
                                        </div>
                                    </div>
                                    {unitPrice > 0 ? (
                                        <div className="shrink-0 text-right">
                                            <p className="font-semibold tabular-nums text-[#3C2947]">
                                                {formatPeso(lineTotal)}
                                            </p>
                                            <p className="mt-0.5 text-[10px] tabular-nums text-[#9A8CA2]">
                                                {`${formatPeso(unitPrice)} each`}
                                            </p>
                                        </div>
                                    ) : null}
                                </div>
                            </td>
                        </tr>
                    );
                })
            ) : null}
        </Fragment>
    );
}

type PackagesReportViewProps = {
    records: PackageRecord[];
    showBranchColumn: boolean;
    onExportPdf: () => void;
    onExportXlsx: () => void;
    onExportDoc: () => void;
};

function PackagesReportView({
                                records,
                                showBranchColumn,
                                onExportPdf,
                                onExportXlsx,
                                onExportDoc,
                            }: PackagesReportViewProps) {
    const activePackages = records.filter((item) => item.status.toLowerCase() === "active");
    const inactivePackages = records.filter((item) => item.status.toLowerCase() !== "active");
    const totalPackageItems = sumBy(records, (item) => item.itemCount || 0);
    const averagePrice = records.length
        ? sumBy(records, (item) => item.price) / records.length
        : 0;
    const categorySummary = Array.from(
        records.reduce((summary, item) => {
            const category = item.category || "Event Package";
            summary.set(category, (summary.get(category) || 0) + 1);
            return summary;
        }, new Map<string, number>())
    )
        .map(([name, value]) => ({ name, value }))
        .sort((left, right) => right.value - left.value);
    const columnCount = showBranchColumn ? 8 : 7;

    return (
        <div className="grid grid-cols-1 items-start gap-3 2xl:grid-cols-[minmax(0,1fr)_260px]">
            <section className="min-w-0 self-start overflow-hidden rounded-[14px] border border-[#E5DDEA] bg-white shadow-sm">
                <div className="border-b border-[#ECE5F0] px-4 py-3.5">
                    <h2 className="text-[16px] font-bold text-[#1A1220]">Packages Report History</h2>
                    <p className="mt-1 text-[11px] text-[#8A7A91]">
                        Review package names, categories, pricing, inclusions, and availability.
                    </p>
                </div>

                <table className="w-full table-fixed border-collapse text-[11px]">
                    <colgroup>
                        <col className={showBranchColumn ? "w-[15%]" : "w-[17%]"} />
                        <col className={showBranchColumn ? "w-[18%]" : "w-[22%]"} />
                        <col className={showBranchColumn ? "w-[12%]" : "w-[14%]"} />
                        {showBranchColumn ? <col className="w-[12%]" /> : null}
                        <col className={showBranchColumn ? "w-[11%]" : "w-[12%]"} />
                        <col className={showBranchColumn ? "w-[12%]" : "w-[13%]"} />
                        <col className={showBranchColumn ? "w-[10%]" : "w-[11%]"} />
                        <col className={showBranchColumn ? "w-[10%]" : "w-[11%]"} />
                    </colgroup>
                    <thead>
                    <tr className="border-b border-[#E8DFED] bg-[#FCFAFD]">
                        <th className="px-2 py-3 text-left text-[9px] font-semibold uppercase tracking-[0.06em] text-[#685674]">Package ID</th>
                        <th className="px-2 py-3 text-left text-[9px] font-semibold uppercase tracking-[0.06em] text-[#685674]">Package Name</th>
                        <th className="px-2 py-3 text-left text-[9px] font-semibold uppercase tracking-[0.06em] text-[#685674]">Category</th>
                        {showBranchColumn ? <th className="px-2 py-3 text-left text-[9px] font-semibold uppercase tracking-[0.06em] text-[#685674]">Branch</th> : null}
                        <th className="px-2 py-3 text-right text-[9px] font-semibold uppercase tracking-[0.06em] text-[#685674]">Price</th>
                        <th className="px-2 py-3 text-right text-[9px] font-semibold uppercase tracking-[0.06em] text-[#685674]">Downpayment</th>
                        <th className="px-2 py-3 text-right text-[9px] font-semibold uppercase tracking-[0.06em] text-[#685674]">Discount</th>
                        <th className="px-2 py-3 text-center text-[9px] font-semibold uppercase tracking-[0.06em] text-[#685674]">Status</th>
                    </tr>
                    </thead>
                    <tbody>
                    {records.length > 0 ? (
                        records.map((item) => (
                            <PackageRow key={item.id} item={item} showBranchColumn={showBranchColumn} />
                        ))
                    ) : (
                        <tr>
                            <td colSpan={columnCount} className="px-4 py-14 text-center text-sm text-[#8A7A91]">
                                No packages match the selected filters.
                            </td>
                        </tr>
                    )}
                    </tbody>
                </table>
            </section>

            <aside className="self-start rounded-[14px] border border-[#E5DDEA] bg-white p-3 shadow-sm">
                <h2 className="text-[16px] font-bold text-[#1A1220]">Packages Summary</h2>
                <div className="mt-3 divide-y divide-[#EEE7F2]">
                    <SummaryMetricRow label="Total Packages" value={records.length} dot="bg-[#7A45E8]" />
                    <SummaryMetricRow label="Active Packages" value={activePackages.length} dot="bg-[#22B65B]" />
                    <SummaryMetricRow label="Inactive Packages" value={inactivePackages.length} dot="bg-[#EF3E38]" />
                    <SummaryMetricRow label="Average Price" value={formatPeso(averagePrice)} dot="bg-[#FF8A00]" />
                    <SummaryMetricRow label="Package Items" value={totalPackageItems} dot="bg-[#2F80ED]" />
                </div>

                <div className="mt-4 border-t border-dashed border-[#E4D9EB] pt-4">
                    <h3 className="text-[12px] font-bold text-[#211629]">Package Status Breakdown</h3>
                    <div className="mt-3 flex items-center gap-4">
                        <div
                            className="relative h-20 w-20 shrink-0 rounded-full"
                            style={{
                                background: (() => {
                                    const total = Math.max(records.length, 1);
                                    const activeEnd = (activePackages.length / total) * 100;
                                    return `conic-gradient(
                                        #22B65B 0% ${activeEnd}%,
                                        #EF3E38 ${activeEnd}% 100%
                                    )`;
                                })(),
                            }}
                        >
                            <span className="absolute inset-[14px] rounded-full bg-white" />
                        </div>

                        <div className="min-w-0 flex-1 space-y-2">
                            {[
                                {
                                    label: "Active",
                                    count: activePackages.length,
                                    dot: "bg-[#22B65B]",
                                },
                                {
                                    label: "Inactive",
                                    count: inactivePackages.length,
                                    dot: "bg-[#EF3E38]",
                                },
                            ].map((item) => (
                                <div
                                    key={item.label}
                                    className="flex items-center justify-between gap-2 text-[10px]"
                                >
                                    <span className="flex min-w-0 items-center gap-2 text-[#5F5267]">
                                        <span className={`h-2 w-2 shrink-0 rounded-full ${item.dot}`} />
                                        <span className="truncate">{item.label}</span>
                                    </span>
                                    <span className="font-bold text-[#251A2C]">
                                        {formatNumber(item.count)}
                                    </span>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>

                <div className="mt-4 border-t border-dashed border-[#E4D9EB] pt-4">
                    <h3 className="text-[12px] font-bold text-[#211629]">Package Categories</h3>
                    <div className="mt-3">
                        <SummaryBarList items={categorySummary} emptyText="No package category data available." />
                    </div>
                </div>

                <InventoryExportMenu
                    label="Export Filtered Packages"
                    onExportPdf={onExportPdf}
                    onExportXlsx={onExportXlsx}
                    onExportDoc={onExportDoc}
                />
            </aside>
        </div>
    );
}

type EmployeeActionsReportViewProps = {
    records: StaffActivity[];
    searchQuery: string;
    activeFilter: StaffModuleFilter;
    onFilterChange: (filter: StaffModuleFilter) => void;
    showBranchColumn: boolean;
    onExportPdf: () => void;
    onExportXlsx: () => void;
    onExportDoc: () => void;
};

function EmployeeActionsReportView({
                                       records,
                                       searchQuery,
                                       activeFilter,
                                       onFilterChange,
                                       showBranchColumn,
                                       onExportPdf,
                                       onExportXlsx,
                                       onExportDoc,
                                   }: EmployeeActionsReportViewProps) {
    const query = searchQuery.trim().toLowerCase();
    const searchedRecords = records.filter((item) =>
        !query ||
        [
            item.id,
            item.staffName,
            item.role,
            item.action,
            item.module,
            item.reference,
            item.details,
            item.branch,
        ]
            .join(" ")
            .toLowerCase()
            .includes(query)
    );
    const displayedRecords =
        activeFilter === "all"
            ? searchedRecords
            : searchedRecords.filter((item) => item.module === activeFilter);
    const employeeSummary = Array.from(
        searchedRecords.reduce((summary, item) => {
            const employee = item.staffName || "Unknown Employee";
            summary.set(employee, (summary.get(employee) || 0) + 1);
            return summary;
        }, new Map<string, number>())
    )
        .map(([name, value]) => ({ name, value }))
        .sort((left, right) => right.value - left.value)
        .slice(0, 6);
    const moduleRows: Array<{
        label: string;
        filter: StaffModuleFilter;
        dot: string;
        value: number;
    }> = [
        { label: "Total Actions", filter: "all", dot: "bg-[#7A45E8]", value: searchedRecords.length },
        { label: "Bookings", filter: "Bookings", dot: "bg-[#7A45E8]", value: searchedRecords.filter((item) => item.module === "Bookings").length },
        { label: "Packages", filter: "Packages", dot: "bg-[#F6A800]", value: searchedRecords.filter((item) => item.module === "Packages").length },
        { label: "Inventory", filter: "Inventory", dot: "bg-[#FF8A00]", value: searchedRecords.filter((item) => item.module === "Inventory").length },
        { label: "Sales / POS", filter: "Sales / POS", dot: "bg-[#22B65B]", value: searchedRecords.filter((item) => item.module === "Sales / POS").length },
    ];
    const columnCount = showBranchColumn ? 6 : 5;

    return (
        <div className="grid grid-cols-1 items-start gap-3 2xl:grid-cols-[minmax(0,1fr)_260px]">
            <section className="min-w-0 self-start overflow-hidden rounded-[14px] border border-[#E5DDEA] bg-white shadow-sm">
                <div className="border-b border-[#ECE5F0] px-4 py-3.5">
                    <h2 className="text-[16px] font-bold text-[#1A1220]">Employee Actions History</h2>
                    <p className="mt-1 text-[11px] text-[#8A7A91]">
                        Review employee actions across Bookings, Inventory, Packages, and Sales / POS.
                    </p>
                </div>

                <table className="w-full table-fixed border-collapse text-[11px]">
                    <colgroup>
                        <col className={showBranchColumn ? "w-[15%]" : "w-[17%]"} />
                        <col className={showBranchColumn ? "w-[18%]" : "w-[20%]"} />
                        <col className={showBranchColumn ? "w-[27%]" : "w-[31%]"} />
                        <col className={showBranchColumn ? "w-[15%]" : "w-[16%]"} />
                        <col className={showBranchColumn ? "w-[15%]" : "w-[16%]"} />
                        {showBranchColumn ? <col className="w-[10%]" /> : null}
                    </colgroup>
                    <thead>
                    <tr className="border-b border-[#E8DFED] bg-[#FCFAFD]">
                        <th className="px-2 py-3 text-left text-[9px] font-semibold uppercase tracking-[0.06em] text-[#685674]">Date / Time</th>
                        <th className="px-2 py-3 text-left text-[9px] font-semibold uppercase tracking-[0.06em] text-[#685674]">Employee</th>
                        <th className="px-2 py-3 text-left text-[9px] font-semibold uppercase tracking-[0.06em] text-[#685674]">Action</th>
                        <th className="px-2 py-3 text-left text-[9px] font-semibold uppercase tracking-[0.06em] text-[#685674]">Module</th>
                        <th className="px-2 py-3 text-left text-[9px] font-semibold uppercase tracking-[0.06em] text-[#685674]">Reference</th>
                        {showBranchColumn ? <th className="px-2 py-3 text-left text-[9px] font-semibold uppercase tracking-[0.06em] text-[#685674]">Branch</th> : null}
                    </tr>
                    </thead>
                    <tbody>
                    {displayedRecords.length > 0 ? (
                        displayedRecords.map((item) => (
                            <tr key={item.id} className="border-b border-[#EFE8F2] bg-white transition-colors hover:bg-[#FCFAFF]">
                                <td className="px-2 py-3 align-top">
                                    <p className="font-semibold text-[#1A1220]">{formatDate(item.date)}</p>
                                    <p className="mt-0.5 text-[9px] text-[#8C7A95]">{item.time || "Time not recorded"}</p>
                                </td>
                                <td className="px-2 py-3 align-top">
                                    <p className="break-words font-semibold text-[#1A1220]">{item.staffName}</p>
                                    <p className="mt-0.5 break-words text-[9px] text-[#8C7A95]">{item.role}</p>
                                </td>
                                <td className="px-2 py-3 align-top">
                                    <p className="break-words font-semibold text-[#1A1220]">{item.action}</p>
                                    <p className="mt-0.5 break-words text-[9px] text-[#8C7A95]">{item.details || "No additional details recorded."}</p>
                                </td>
                                <td className="px-2 py-3 align-top"><ActivityModuleBadge module={item.module} /></td>
                                <td className="break-words px-2 py-3 align-top font-mono text-[10px] font-semibold text-[#5F4E75]">{item.reference || "—"}</td>
                                {showBranchColumn ? <td className="break-words px-2 py-3 align-top text-[#5F5267]">{item.branch}</td> : null}
                            </tr>
                        ))
                    ) : (
                        <tr>
                            <td colSpan={columnCount} className="px-4 py-14 text-center text-sm text-[#8A7A91]">
                                No employee actions match the selected filters.
                            </td>
                        </tr>
                    )}
                    </tbody>
                </table>
            </section>

            <aside className="self-start rounded-[14px] border border-[#E5DDEA] bg-white p-3 shadow-sm">
                <h2 className="text-[16px] font-bold text-[#1A1220]">Employee Actions Summary</h2>
                <div className="mt-3 divide-y divide-[#EEE7F2]">
                    {moduleRows.map((item) => (
                        <SummaryMetricRow
                            key={item.filter}
                            label={item.label}
                            value={item.value}
                            dot={item.dot}
                            active={activeFilter === item.filter}
                            onClick={() => onFilterChange(item.filter)}
                        />
                    ))}
                </div>

                <div className="mt-4 border-t border-dashed border-[#E4D9EB] pt-4">
                    <h3 className="text-[12px] font-bold text-[#211629]">Most Active Employees</h3>
                    <div className="mt-3">
                        <SummaryBarList items={employeeSummary} emptyText="No employee action data available." />
                    </div>
                </div>

                <InventoryExportMenu
                    label="Export Employee Actions"
                    onExportPdf={onExportPdf}
                    onExportXlsx={onExportXlsx}
                    onExportDoc={onExportDoc}
                />
            </aside>
        </div>
    );
}

export function ReportsWorkspace({
                                     initialRole,
                                     assignedBranch,
                                     storeName,
                                     viewConfig,
                                 }: ReportsWorkspaceProps) {
    const role = initialRole;
    const isOwner = role === "owner";
    const showBranchFilter = isOwner && viewConfig.showBranchFilter;
    const showBranchColumn = isOwner || viewConfig.showBranchColumn;
    const [branch, setBranch] = useState(() =>
        initialRole === "owner"
            ? ALL_BRANCHES
            : assignedBranch || DEFAULT_BRANCH
    );
    const [startDate, setStartDate] = useState(getMonthStart(getToday()));
    const [endDate, setEndDate] = useState(getToday());
    const [selectedReport, setSelectedReport] = useState<ReportKey | null>("inventory");
    const [searchQuery, setSearchQuery] = useState("");
    const [categoryFilter, setCategoryFilter] = useState("all");
    const [inventoryFilter, setInventoryFilter] = useState<InventoryFilter>("all");
    const [expandedInventoryId, setExpandedInventoryId] = useState<string | null>(null);
    const [bookingFilter, setBookingFilter] = useState<BookingFilter>("all");
    const [packageStatusFilter, setPackageStatusFilter] =
        useState<PackageStatusFilter>("all");
    const [staffModuleFilter, setStaffModuleFilter] =
        useState<StaffModuleFilter>("all");
    const [report, setReport] = useState<ReportData | null>(null);
    const [loading, setLoading] = useState(true);
    const [liveInventoryState, setLiveInventoryState] =
        useState<LiveInventoryLoadState>({
            ready: false,
            items: [],
        });
    const [liveBranchOptions, setLiveBranchOptions] = useState<
        LiveBranchOption[]
    >([]);
    const [liveSalesState, setLiveSalesState] =
        useState<LiveSalesLoadState>({
            ready: false,
            items: [],
        });
    const [liveBookingsState, setLiveBookingsState] =
        useState<LiveBookingsLoadState>({
            ready: false,
            items: [],
        });
    const [livePackagesState, setLivePackagesState] = useState<LivePackagesLoadState>({
        ready: false,
        items: [],
    });

    const storedAssignedBranchId = getStoredSessionValue([
        "branch_id",
        "stocknbook_branch_id",
        "manager_branch_id",
        "staff_branch_id",
    ]);

    const selectedOwnerBranchId = useMemo(() => {
        if (initialRole !== "owner" || isAllBranches(branch)) {
            return "";
        }

        const normalizedBranch = branch.trim().toLowerCase();

        return (
            liveBranchOptions.find(
                (item) => item.name.trim().toLowerCase() === normalizedBranch
            )?.id || ""
        );
    }, [branch, initialRole, liveBranchOptions]);

    const scopedSalesBranchId =
        initialRole === "owner"
            ? selectedOwnerBranchId
            : storedAssignedBranchId;

    const loadReport = useCallback(async () => {
        const query = new URLSearchParams({
            branch: isAllBranches(branch) ? "All branches" : branch,
            month: startDate.slice(0, 7),
            startDate,
            endDate,
            role,
            assignedBranch,
        });

        if (scopedSalesBranchId) {
            query.set("branch_id", scopedSalesBranchId);
        }

        const token = getStoredSessionValue(["token"]);

        if (!token) {
            setReport(null);
            setLoading(false);
            return;
        }

        try {
            setLoading(true);

            const response = await fetch(`/api/reports?${query.toString()}`, {
                headers: {
                    Authorization: `Bearer ${token}`,
                },
                cache: "no-store",
            });
            const payload = await response.json();

            setReport(response.ok && payload?.success ? payload.data : null);
        } catch (error) {
            console.warn("Reports API loading failed:", error);
            setReport(null);
        } finally {
            setLoading(false);
        }
    }, [
        assignedBranch,
        branch,
        endDate,
        role,
        scopedSalesBranchId,
        startDate,
    ]);

    const loadLiveBranches = useCallback(async () => {
        const token = getStoredSessionValue(["token"]);

        if (!token) {
            setLiveBranchOptions([]);
            return;
        }

        try {
            const response = await fetch("/api/branches", {
                method: "GET",
                headers: {
                    Authorization: `Bearer ${token}`,
                },
                cache: "no-store",
            });

            const payload = (await response.json()) as LiveBranchesResponse;

            if (!response.ok || !Array.isArray(payload.branches)) {
                throw new Error(payload.error || "Unable to load branches.");
            }

            const normalizedBranches = payload.branches
                .map((rawValue) => {
                    const raw = asLiveRecord(rawValue);
                    const id = asLiveText(
                        raw.id,
                        raw.branchId,
                        raw.branch_id
                    );
                    const name = asLiveText(
                        raw.branchName,
                        raw.branch_name,
                        raw.name
                    );

                    return id && name ? { id, name } : null;
                })
                .filter(
                    (item): item is LiveBranchOption => Boolean(item)
                )
                .filter(
                    (item, index, items) =>
                        items.findIndex(
                            (candidate) =>
                                candidate.name.trim().toLowerCase() ===
                                item.name.trim().toLowerCase()
                        ) === index
                );

            setLiveBranchOptions(normalizedBranches);
        } catch (error) {
            console.warn("Reports branch loading failed:", error);
            setLiveBranchOptions([]);
        }
    }, []);

    const loadLiveSales = useCallback(async () => {
        const token = getStoredSessionValue(["token"]);

        if (!token) {
            setLiveSalesState({
                ready: false,
                items: [],
            });
            return;
        }

        const storeId = getStoredSessionValue([
            "store_id",
            "stocknbook_store_id",
        ]);
        const request: Record<string, unknown> = {
            action: "get_orders",
            // Reports already has an explicit selected date range. Push it to
            // SQL instead of downloading historical POS rows and filtering in React.
            date_from: startDate,
            date_to: endDate,
        };
        const numericBranchId = Number(scopedSalesBranchId);

        if (Number.isFinite(numericBranchId) && numericBranchId > 0) {
            request.branch_id = numericBranchId;
        }

        if (storeId) {
            request.store_id = Number(storeId);
        }

        try {
            const response = await fetch("/api/pos", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${token}`,
                },
                body: JSON.stringify(request),
                cache: "no-store",
            });

            const payload = (await response.json()) as LiveSalesResponse;

            if (!response.ok || (payload as { success?: boolean }).success === false) {
                throw new Error(payload.error || "Unable to load POS orders.");
            }

            const fallbackBranch =
                initialRole === "owner" && isAllBranches(branch)
                    ? ALL_BRANCHES
                    : branch || assignedBranch || DEFAULT_BRANCH;

            const rawOrders = getLiveCollection(payload, [
                "orders",
                "sales",
                "transactions",
            ]);

            const normalizedOrders = rawOrders
                .map((order, index) =>
                    normalizeLivePosOrder(order, index, fallbackBranch)
                )
                .filter((order) =>
                    isDateInSelectedRange(order.date, startDate, endDate)
                );

            const ownerBranchScopedOrders =
                initialRole === "owner" &&
                !isAllBranches(branch) &&
                !scopedSalesBranchId
                    ? normalizedOrders.filter(
                        (order) =>
                            order.branch.trim().toLowerCase() ===
                            branch.trim().toLowerCase()
                    )
                    : normalizedOrders;

            setLiveSalesState({
                ready: true,
                items: ownerBranchScopedOrders,
            });
        } catch (error) {
            console.warn("Reports POS order loading failed:", error);
            setLiveSalesState({
                ready: false,
                items: [],
            });
        }
    }, [
        assignedBranch,
        branch,
        endDate,
        initialRole,
        scopedSalesBranchId,
        startDate,
    ]);

    const loadLiveBookings = useCallback(async () => {
        const token = getStoredSessionValue(["token"]);

        if (!token) {
            setLiveBookingsState({
                ready: false,
                items: [],
            });
            return;
        }

        const storeId = getStoredSessionValue([
            "store_id",
            "stocknbook_store_id",
        ]);
        const request: Record<string, unknown> = {
            action: "get_booking_page_bookings",
            role: initialRole,
            // Keep booking reports scalable by applying the selected period in
            // the backend query rather than filtering a full booking history.
            date_from: startDate,
            date_to: endDate,
        };
        const numericBranchId = Number(scopedSalesBranchId);

        if (Number.isFinite(numericBranchId) && numericBranchId > 0) {
            request.branch_id = numericBranchId;
        }

        if (storeId) {
            request.store_id = Number(storeId);
        }

        try {
            const response = await fetch("/api/bookings", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${token}`,
                },
                body: JSON.stringify(request),
                cache: "no-store",
            });

            const payload = (await response.json()) as LiveBookingsResponse;

            if (!response.ok || (payload as { success?: boolean }).success === false) {
                throw new Error(payload.error || "Unable to load bookings.");
            }

            const fallbackBranch =
                initialRole === "owner" && isAllBranches(branch)
                    ? ALL_BRANCHES
                    : branch || assignedBranch || DEFAULT_BRANCH;

            const rawBookings = getLiveCollection(payload, [
                "bookings",
                "records",
            ]);

            const normalizedBookings = rawBookings
                .map((booking, index) =>
                    normalizeLiveBooking(booking, index, fallbackBranch)
                )
                .filter((booking) =>
                    isDateInSelectedRange(booking.date, startDate, endDate)
                );

            const ownerBranchScopedBookings =
                initialRole === "owner" &&
                !isAllBranches(branch) &&
                !scopedSalesBranchId
                    ? normalizedBookings.filter(
                        (booking) =>
                            booking.branch.trim().toLowerCase() ===
                            branch.trim().toLowerCase()
                    )
                    : normalizedBookings;

            setLiveBookingsState({
                ready: true,
                items: ownerBranchScopedBookings,
            });
        } catch (error) {
            console.warn("Reports booking loading failed:", error);
            setLiveBookingsState({
                ready: false,
                items: [],
            });
        }
    }, [
        assignedBranch,
        branch,
        endDate,
        initialRole,
        scopedSalesBranchId,
        startDate,
    ]);

    const loadLivePackages = useCallback(async () => {
        const token = getStoredSessionValue(["token"]);

        if (!token) {
            setLivePackagesState({ ready: false, items: [] });
            return;
        }

        const storeId = getStoredSessionValue(["store_id", "stocknbook_store_id"]);
        const request: Record<string, unknown> = { action: "get_packages" };
        const numericBranchId = Number(scopedSalesBranchId);

        if (Number.isFinite(numericBranchId) && numericBranchId > 0) {
            request.branch_id = numericBranchId;
        }
        if (storeId) {
            request.store_id = Number(storeId);
        }

        try {
            const response = await fetch("/api/packages", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${token}`,
                },
                body: JSON.stringify(request),
                cache: "no-store",
            });

            const payload = (await response.json()) as LivePackagesResponse;

            if (!response.ok || (payload as { success?: boolean }).success === false) {
                throw new Error(payload.error || "Unable to load plans.");
            }

            const fallbackBranch = initialRole === "owner" && isAllBranches(branch)
                ? ALL_BRANCHES
                : branch || assignedBranch || DEFAULT_BRANCH;

            const rawPackages = getLiveCollection(payload, ["packages", "data", "records"]);

            const normalizedPackages = rawPackages.map((rawValue, index) => {
                const raw = asLiveRecord(rawValue);
                const id = asLiveText(raw.id, raw.packageId, raw.package_id);

                let rawInclusions: unknown[] = [];
                if (Array.isArray(raw.inclusions)) {
                    rawInclusions = raw.inclusions;
                } else if (typeof raw.inclusions === "string" && raw.inclusions.trim().startsWith("[")) {
                    try {
                        rawInclusions = JSON.parse(raw.inclusions) as unknown[];
                    } catch (e) {
                        rawInclusions = [];
                    }
                } else if (Array.isArray(raw.items)) {
                    rawInclusions = raw.items;
                } else if (typeof raw.items === "string" && raw.items.trim().startsWith("[")) {
                    try {
                        rawInclusions = JSON.parse(raw.items) as unknown[];
                    } catch (e) {
                        rawInclusions = [];
                    }
                }

                const normalizedInclusions = rawInclusions.map(inc => {
                    if (typeof inc === "string") return { name: inc, quantity: 1, price: 0 };

                    const incObj = asLiveRecord(inc);
                    return {
                        name: asLiveText(incObj.name, incObj.itemName, incObj.item_name, incObj.productName, incObj.product_name, incObj.item, incObj.title),
                        quantity: asLiveNumber(incObj.quantity ?? incObj.qty) || 1,
                        price: asLiveNumber(
                            incObj.price ?? incObj.unitPrice ?? incObj.unit_price ??
                            incObj.salesPrice ?? incObj.sales_price ?? incObj.itemPrice ??
                            incObj.item_price ?? incObj.lineTotal ?? incObj.line_total
                        ) || 0
                    };
                }).filter(inc => inc.name);

                const extractNumeric = (val: unknown) => {
                    if (typeof val === 'number') return val;
                    if (typeof val === 'string') return Number(val.replace(/[^0-9.-]/g, '')) || 0;
                    return 0;
                };

                const downPaymentVal = raw.downPayment ?? raw.down_payment ?? raw.downpayment ?? raw.downpaymentAmount ?? raw.down_payment_amount;
                const parsedDownPayment = extractNumeric(downPaymentVal);

                const discountVal = raw.discount ?? raw.discountValue ?? raw.discount_value ?? raw.discountAmount ?? raw.discount_amount ?? raw.discountPercentage ?? raw.discount_percentage;
                const parsedDiscount = extractNumeric(discountVal);

                let isDiscountPercentage = false;
                const discountType = String(raw.discountType ?? raw.discount_type ?? "").trim().toLowerCase();

                if (typeof discountVal === 'string' && discountVal.includes('%')) {
                    isDiscountPercentage = true;
                } else if (
                    discountType === 'percentage' ||
                    discountType === 'percent' ||
                    discountType === '%' ||
                    raw.isDiscountPercentage === true ||
                    raw.is_discount_percentage === true ||
                    raw.isPercentage === true
                ) {
                    isDiscountPercentage = true;
                } else if (discountType === 'peso' || discountType === 'fixed' || discountType === 'amount') {
                    isDiscountPercentage = false;
                } else {
                    const origPrice = asLiveNumber(raw.originalPrice ?? raw.original_price ?? raw.originalValue ?? raw.original_value);
                    const pkgPrice = asLiveNumber(raw.price ?? raw.packagePrice ?? raw.package_price);

                    if (origPrice > pkgPrice && pkgPrice > 0 && parsedDiscount > 0) {
                        const diff = origPrice - pkgPrice;
                        if (Math.abs(diff - parsedDiscount) < 1) {
                            isDiscountPercentage = false;
                        } else if (Math.abs((parsedDiscount / 100) * origPrice - diff) < 1) {
                            isDiscountPercentage = true;
                        } else {
                            isDiscountPercentage = parsedDiscount <= 100;
                        }
                    } else {
                        isDiscountPercentage = parsedDiscount > 0 && parsedDiscount <= 100;
                    }
                }

                let pkgBranch = asLiveText(
                    raw.branchName,
                    raw.branch_name,
                    raw.branch,
                    raw.storeBranch,
                    raw.store_branch,
                    raw.assignedBranch,
                    raw.assigned_branch,
                    raw.location
                );

                if (!pkgBranch && Array.isArray(raw.branches)) {
                    pkgBranch = raw.branches.map(b => typeof b === 'object' ? asLiveText((b as Record<string,unknown>).name, (b as Record<string,unknown>).branchName, (b as Record<string,unknown>).branch_name) : String(b)).filter(Boolean).join(", ");
                }
                if (!pkgBranch && Array.isArray(raw.branchNames)) {
                    pkgBranch = raw.branchNames.join(", ");
                }
                if (!pkgBranch && Array.isArray(raw.branch_names)) {
                    pkgBranch = raw.branch_names.join(", ");
                }

                return {
                    id: id.startsWith("PKG-") ? id : `PKG-${String(id || index + 1).padStart(3, "0")}`,
                    name: asLiveText(raw.name, raw.packageName, raw.package_name) || "Unnamed Package",
                    category: asLiveText(raw.category, raw.packageCategory, raw.package_category) || "Event Package",
                    branch: pkgBranch || fallbackBranch,
                    branchId: asLiveText(raw.branchId, raw.branch_id),
                    price: asLiveNumber(raw.price ?? raw.packagePrice ?? raw.package_price),

                    downPayment: parsedDownPayment,
                    discount: parsedDiscount,
                    isDiscountPercentage,

                    inclusions: normalizedInclusions,
                    status: asLiveText(raw.status, raw.packageStatus, raw.package_status) || "Active",

                    itemCount: asLiveNumber(raw.itemCount ?? raw.item_count) || normalizedInclusions.reduce((sum, inc) => sum + (inc.quantity || 1), 0),

                    updatedAt: asLiveText(raw.updatedAt, raw.updated_at),
                    updatedBy: asLiveText(raw.updatedBy, raw.updated_by),
                };
            });

            const ownerBranchScopedPackages =
                initialRole === "owner" &&
                !isAllBranches(branch) &&
                !scopedSalesBranchId
                    ? normalizedPackages.filter(
                        (pkg) =>
                            pkg.branch.toLowerCase().includes(branch.trim().toLowerCase())
                    )
                    : normalizedPackages;

            setLivePackagesState({ ready: true, items: ownerBranchScopedPackages });
        } catch (error) {
            console.warn("Reports plans loading failed:", error);
            setLivePackagesState({ ready: false, items: [] });
        }
    }, [assignedBranch, branch, initialRole, scopedSalesBranchId]);

    const loadLiveInventory = useCallback(async () => {
        const token = getStoredSessionValue(["token"]);

        if (!token) {
            setLiveInventoryState({
                ready: false,
                items: [],
            });
            return;
        }

        const storeId = getStoredSessionValue([
            "store_id",
            "stocknbook_store_id",
        ]);

        const assignedBranchId = getStoredSessionValue([
            "branch_id",
            "stocknbook_branch_id",
            "manager_branch_id",
            "staff_branch_id",
        ]);

        const productRequest: Record<string, unknown> = {
            action: "get_products",
            include_variants: true,
        };

        if (storeId) {
            productRequest.store_id = Number(storeId);
        }

        if (role !== "owner" && assignedBranchId) {
            productRequest.branch_id = Number(assignedBranchId);
        }

        try {
            const response = await fetch("/api/products", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${token}`,
                },
                body: JSON.stringify(productRequest),
                cache: "no-store",
            });

            const payload = (await response.json()) as LiveProductsResponse;

            if (!response.ok || !Array.isArray(payload.products)) {
                throw new Error(payload.error || "Unable to load live inventory.");
            }

            const normalizedInventory = payload.products.map((product, index) =>
                normalizeLiveInventoryProduct(product, index, assignedBranch)
            );

            const scopedInventory =
                role === "owner" &&
                !isAllBranches(branch) &&
                branch.trim()
                    ? normalizedInventory.filter(
                        (item) =>
                            item.branch.trim().toLowerCase() ===
                            branch.trim().toLowerCase()
                    )
                    : normalizedInventory;

            setLiveInventoryState({
                ready: true,
                items: scopedInventory,
            });
        } catch (error) {
            console.warn("Reports live inventory loading failed:", error);
            setLiveInventoryState({
                ready: false,
                items: [],
            });
        }
    }, [assignedBranch, branch, role]);

    const handleRefresh = useCallback(async () => {
        await Promise.all([
            loadReport(),
            loadLiveBranches(),
            loadLiveInventory(),
            loadLiveSales(),
            loadLiveBookings(),
            loadLivePackages(),
        ]);
    }, [
        loadLiveBookings,
        loadLiveBranches,
        loadLiveInventory,
        loadLiveSales,
        loadLivePackages,
        loadReport,
    ]);

    useEffect(() => {
        void loadReport();
        void loadLiveBranches();
        void loadLiveInventory();
        void loadLiveSales();
        void loadLiveBookings();
        void loadLivePackages();
    }, [
        loadLiveBookings,
        loadLiveBranches,
        loadLiveInventory,
        loadLiveSales,
        loadLivePackages,
        loadReport,
    ]);


    const activeBranch = isOwner
        ? branch
        : assignedBranch || report?.access?.assignedBranch || "Assigned Branch";

    const activeStoreName = useMemo(() => {
        const apiStoreName =
            report?.storeName ||
            report?.store_name ||
            report?.businessName ||
            report?.business_name ||
            "";

        return String(apiStoreName || storeName || "Store").trim() || "Store";
    }, [
        report?.businessName,
        report?.business_name,
        report?.storeName,
        report?.store_name,
        storeName,
    ]);

    const branchOptions = useMemo(() => {
        const apiBranches = liveBranchOptions.map((item) => item.name);
        const reportBranches = report?.branchOptions || [];

        const options = [...apiBranches, ...reportBranches];

        if (assignedBranch && initialRole !== "owner") {
            options.push(assignedBranch);
        }

        const uniqueBranches = options
            .map((item) => String(item || "").trim())
            .filter(Boolean)
            .filter((item) => !isAllBranches(item))
            .filter(
                (item, index, values) =>
                    values.findIndex(
                        (value) => value.toLowerCase() === item.toLowerCase()
                    ) === index
            );

        return [ALL_BRANCHES, ...uniqueBranches];
    }, [assignedBranch, initialRole, liveBranchOptions, report?.branchOptions]);

    const inventory = useMemo(() => {
        const baseItems = liveInventoryState.ready
            ? liveInventoryState.items
            : (report?.inventoryList ?? []);

        return baseItems.map(item => {
            let resolvedBranch = item.branch;
            if (resolvedBranch === ALL_BRANCHES || resolvedBranch === "Assigned Branch") {
                if (item.branchId) {
                    const matched = liveBranchOptions.find(b => String(b.id) === String(item.branchId));
                    if (matched) resolvedBranch = matched.name;
                }
                if (resolvedBranch === ALL_BRANCHES || resolvedBranch === "Assigned Branch") {
                    resolvedBranch = "—";
                }
            }
            return { ...item, branch: resolvedBranch };
        });
    }, [liveInventoryState.items, liveInventoryState.ready, report?.inventoryList, liveBranchOptions]);

    const restocks = useMemo(() => {
        return (report?.restockHistory ?? []).map(item => {
            let resolvedBranch = item.branch;
            if (resolvedBranch === ALL_BRANCHES || resolvedBranch === "Assigned Branch") {
                if (item.branchId) {
                    const matched = liveBranchOptions.find(b => String(b.id) === String(item.branchId));
                    if (matched) resolvedBranch = matched.name;
                }
                if (resolvedBranch === ALL_BRANCHES || resolvedBranch === "Assigned Branch") {
                    resolvedBranch = "—";
                }
            }
            return { ...item, branch: resolvedBranch };
        });
    }, [report?.restockHistory, liveBranchOptions]);

    const displayedRestocks = useMemo(() => {
        const query = searchQuery.trim().toLowerCase();

        if (!query) return restocks;

        return restocks.filter((item) =>
            [
                item.id,
                item.reference,
                item.product,
                item.variantName,
                item.branch,
                item.receivedBy,
                item.notes,
            ]
                .join(" ")
                .toLowerCase()
                .includes(query)
        );
    }, [restocks, searchQuery]);

    const bookings = useMemo(() => {
        let baseBookings = [];
        if (liveBookingsState.ready) {
            baseBookings = liveBookingsState.items;
        } else {
            baseBookings = (report?.bookingList ?? []).filter((booking) =>
                isDateInSelectedRange(toReportDateValue(booking.date), startDate, endDate)
            );
        }

        return baseBookings.map(item => {
            let resolvedBranch = item.branch;
            if (resolvedBranch === ALL_BRANCHES || resolvedBranch === "Assigned Branch") {
                if (item.branchId) {
                    const matched = liveBranchOptions.find(b => String(b.id) === String(item.branchId));
                    if (matched) resolvedBranch = matched.name;
                }
                if (resolvedBranch === ALL_BRANCHES || resolvedBranch === "Assigned Branch") {
                    resolvedBranch = "—";
                }
            }
            return { ...item, branch: resolvedBranch };
        });
    }, [endDate, liveBookingsState.items, liveBookingsState.ready, report?.bookingList, startDate, liveBranchOptions]);

    const orderRevenueRecords = useMemo(
        () =>
            liveSalesState.ready
                ? liveSalesState.items
                : report?.salesList ?? [],
        [liveSalesState.items, liveSalesState.ready, report?.salesList]
    );

    const sales = useMemo(
        () =>
            orderRevenueRecords.filter(
                (order) => order.revenueSource === "pos"
            ),
        [orderRevenueRecords]
    );


    const packages = useMemo<PackageRecord[]>(() => {
        let basePackages: PackageRecord[] = [];
        if (livePackagesState.ready && livePackagesState.items.length > 0) {
            basePackages = livePackagesState.items;
        } else if (report?.packageList?.length) {
            basePackages = report.packageList;
        } else {
            const packageMap = new Map<string, PackageRecord>();
            bookings.forEach((booking, index) => {
                const key = booking.packageName.trim().toLowerCase();
                if (!key || packageMap.has(key)) return;
                packageMap.set(key, {
                    id: `PKG-${String(index + 1).padStart(3, "0")}`,
                    name: booking.packageName,
                    category: "Event Package",
                    branch: booking.branch,
                    branchId: booking.branchId,
                    price: booking.amount,
                    itemCount: undefined,
                    status: "Active",
                    updatedAt: booking.date,
                    updatedBy: undefined,
                });
            });
            basePackages = Array.from(packageMap.values());
        }

        return basePackages.map(pkg => {
            let finalBranch = pkg.branch;
            if (!finalBranch || finalBranch === ALL_BRANCHES || finalBranch === "Assigned Branch") {
                if (pkg.branchId) {
                    const matched = liveBranchOptions.find(b => String(b.id) === String(pkg.branchId));
                    if (matched) finalBranch = matched.name;
                }
                if (!finalBranch || finalBranch === ALL_BRANCHES || finalBranch === "Assigned Branch") {
                    finalBranch = "—";
                }
            }
            return { ...pkg, branch: finalBranch };
        });
    }, [livePackagesState, report?.packageList, bookings, liveBranchOptions]);

    const forecasts = useMemo(
        () => report?.forecasting ?? [],
        [report?.forecasting]
    );

    const seasons = useMemo(
        () => report?.seasonalInsights ?? [],
        [report?.seasonalInsights]
    );

    const staffActivities = useMemo(() => {
        const loggedActivities = mapEmployeeActionsToStaffActivities(
            report?.employeeActions ?? []
        );

        return loggedActivities
            .map(item => {
                let resolvedBranch = item.branch;
                if (resolvedBranch === ALL_BRANCHES || resolvedBranch === "Assigned Branch") {
                    if (item.branchId) {
                        const matched = liveBranchOptions.find(b => String(b.id) === String(item.branchId));
                        if (matched) resolvedBranch = matched.name;
                    }
                    if (resolvedBranch === ALL_BRANCHES || resolvedBranch === "Assigned Branch") {
                        resolvedBranch = "—";
                    }
                }
                return { ...item, branch: resolvedBranch };
            })
            .sort((left, right) => {
                const dateDiff = right.date.localeCompare(left.date);
                return dateDiff || String(right.time || "").localeCompare(String(left.time || ""));
            });
    }, [report?.employeeActions, liveBranchOptions]);

    const bookingStaffActions = useMemo(
        () => staffActivities.filter((item) => item.module === "Bookings").length,
        [staffActivities]
    );

    const packageStaffActions = useMemo(
        () => staffActivities.filter((item) => item.module === "Packages").length,
        [staffActivities]
    );

    const inventoryStaffActions = useMemo(
        () => staffActivities.filter((item) => item.module === "Inventory").length,
        [staffActivities]
    );

    const salesPosStaffActions = useMemo(
        () =>
            staffActivities.filter((item) => item.module === "Sales / POS").length,
        [staffActivities]
    );


    const displayedStaffActivities = useMemo(() => {
        if (staffModuleFilter === "all") return staffActivities;

        return staffActivities.filter(
            (activity) => activity.module === staffModuleFilter
        );
    }, [staffActivities, staffModuleFilter]);

    const staffActionListTitle =
        staffModuleFilter === "all"
            ? "Current Employee Actions"
            : `${staffModuleFilter} Employee Actions`;

    const staffActionListSubtitle =
        staffModuleFilter === "all"
            ? "Track employee actions from Bookings, Inventory, Packages, and Sales / POS."
            : `Showing only employee actions from the ${staffModuleFilter} module.`;

    const lowStock = useMemo(() => {
        if (liveInventoryState.ready) {
            return inventory.filter((item) => item.status === "Low Stock");
        }

        return report?.lowStockItems?.length
            ? report.lowStockItems
            : inventory.filter((item) => item.status === "Low Stock");
    }, [
        inventory,
        liveInventoryState.ready,
        report?.lowStockItems,
    ]);

    const outOfStock = useMemo(() => {
        if (liveInventoryState.ready) {
            return inventory.filter((item) => item.status === "Out of Stock");
        }

        return report?.outOfStockItems?.length
            ? report.outOfStockItems
            : inventory.filter((item) => item.status === "Out of Stock");
    }, [
        inventory,
        liveInventoryState.ready,
        report?.outOfStockItems,
    ]);

    const inStock = useMemo(
        () => inventory.filter((item) => item.status === "In Stock"),
        [inventory]
    );

    const soonToExpire = useMemo(
        () =>
            inventory.filter(
                (item) => getExpirationStatus(item.expiryDate) === "Soon to Expire"
            ),
        [inventory]
    );

    const expiredItems = useMemo(
        () =>
            inventory.filter(
                (item) => getExpirationStatus(item.expiryDate) === "Expired"
            ),
        [inventory]
    );

    const goodExpirationItems = useMemo(
        () =>
            inventory.filter((item) => {
                const status = getExpirationStatus(item.expiryDate);
                return status === "Good" || status === "No Expiry";
            }),
        [inventory]
    );

    const inventoryCategories = useMemo(
        () =>
            Array.from(
                new Set(
                    inventory
                        .map((item) => item.category.trim())
                        .filter(Boolean)
                )
            ).sort((left, right) => left.localeCompare(right)),
        [inventory]
    );


    const displayedInventory = useMemo(() => {
        const normalizedSearch = searchQuery.trim().toLowerCase();

        return inventory.filter((item) => {
            const expirationStatus = getExpirationStatus(item.expiryDate);
            const updatedDate = toReportDateValue(item.lastUpdated);

            const matchesInventoryStatus =
                inventoryFilter === "all" ||
                (inventoryFilter === "in" && item.status === "In Stock") ||
                (inventoryFilter === "low" && item.status === "Low Stock") ||
                (inventoryFilter === "out" && item.status === "Out of Stock") ||
                (inventoryFilter === "soon" &&
                    expirationStatus === "Soon to Expire") ||
                (inventoryFilter === "expired" &&
                    expirationStatus === "Expired");

            const matchesSearch =
                !normalizedSearch ||
                [
                    item.product,
                    item.category,
                    item.branch,
                    ...getInventoryVariants(item).flatMap((variant) => [
                        variant.name,
                        variant.sku,
                    ]),
                ]
                    .join(" ")
                    .toLowerCase()
                    .includes(normalizedSearch);

            const matchesCategory =
                categoryFilter === "all" || item.category === categoryFilter;


            const matchesDate =
                !updatedDate ||
                isDateInSelectedRange(updatedDate, startDate, endDate);

            return (
                matchesInventoryStatus &&
                matchesSearch &&
                matchesCategory &&
                matchesDate
            );
        });
    }, [
        categoryFilter,
        endDate,
        inventory,
        inventoryFilter,
        searchQuery,
        startDate,
    ]);


    const inventoryCategorySummary = useMemo(() => {
        const counts = new Map<string, number>();

        inventory.forEach((item) => {
            const category = item.category || "Uncategorized";
            counts.set(category, (counts.get(category) || 0) + 1);
        });

        return Array.from(counts.entries())
            .map(([name, count]) => ({ name, count }))
            .sort((left, right) => {
                const countDifference = right.count - left.count;
                return countDifference || left.name.localeCompare(right.name);
            });
    }, [inventory]);

    const largestInventoryCategoryCount = Math.max(
        1,
        ...inventoryCategorySummary.map((category) => category.count)
    );

    const inventoryListTitle = "Inventory Report History";
    const inventoryListSubtitle =
        "Review current stock, prices, variants, and expiration status for every item.";

    const displayedBookings = useMemo(() => {
        if (bookingFilter === "all") return bookings;
        return bookings.filter((booking) => booking.status === bookingFilter);
    }, [bookingFilter, bookings]);

    const bookingListTitle =
        bookingFilter === "all"
            ? "All Booking Records"
            : `${bookingFilter.charAt(0).toUpperCase()}${bookingFilter.slice(1)} Booking Records`;

    const bookingListSubtitle =
        bookingFilter === "all"
            ? "Booking ID, reference number, customer, package, event date, and status."
            : `Showing only ${bookingFilter} booking records for the selected period.`;

    const bookingFilters: Array<{
        key: BookingFilter;
        label: string;
        count: number;
        helper: string;
    }> = [
        {
            key: "all",
            label: "ALL BOOKINGS",
            count: bookings.length,
            helper: "Show all booking records",
        },
        {
            key: "pending",
            label: "PENDING",
            count: bookings.filter((booking) => booking.status === "pending").length,
            helper: "Show pending bookings",
        },
        {
            key: "confirmed",
            label: "CONFIRMED",
            count: bookings.filter((booking) => booking.status === "confirmed").length,
            helper: "Show confirmed bookings",
        },
        {
            key: "preparing",
            label: "PREPARING",
            count: bookings.filter((booking) => booking.status === "preparing").length,
            helper: "Show bookings in preparation",
        },
        {
            key: "completed",
            label: "COMPLETED",
            count: bookings.filter((booking) => booking.status === "completed").length,
            helper: "Show completed bookings",
        },
        {
            key: "cancelled",
            label: "CANCELLED",
            count: bookings.filter((booking) => booking.status === "cancelled").length,
            helper: "Show cancelled bookings",
        },
    ];

    const posTransactions = useMemo(
        () =>
            [...sales].map(item => {
                let resolvedBranch = item.branch;
                if (resolvedBranch === ALL_BRANCHES || resolvedBranch === "Assigned Branch") {
                    if (item.branchId) {
                        const matched = liveBranchOptions.find(b => String(b.id) === String(item.branchId));
                        if (matched) resolvedBranch = matched.name;
                    }
                    if (resolvedBranch === ALL_BRANCHES || resolvedBranch === "Assigned Branch") {
                        resolvedBranch = "—";
                    }
                }
                return { ...item, branch: resolvedBranch };
            }).sort((a, b) => {
                const dateDifference = b.date.localeCompare(a.date);

                if (dateDifference !== 0) {
                    return dateDifference;
                }

                return (b.reference || b.id).localeCompare(a.reference || a.id);
            }),
        [sales, liveBranchOptions]
    );

    const displayedPosTransactions = useMemo(() => {
        const query = searchQuery.trim().toLowerCase();

        if (!query) return posTransactions;

        return posTransactions.filter((item) =>
            [
                item.id,
                item.reference,
                item.customer,
                item.product,
                item.itemsText,
                item.statusLabel,
            ]
                .join(" ")
                .toLowerCase()
                .includes(query)
        );
    }, [posTransactions, searchQuery]);

    const displayedPackages = useMemo(() => {
        const query = searchQuery.trim().toLowerCase();

        return packages.filter((item) => {
            const searchableText = [
                item.id,
                item.name,
                item.category,
                item.branch,
                item.status,
                item.updatedBy,
            ]
                .join(" ")
                .toLowerCase();
            const normalizedStatus = item.status.trim().toLowerCase();
            const matchesSearch = !query || searchableText.includes(query);
            const matchesStatus =
                packageStatusFilter === "all" ||
                (packageStatusFilter === "active" && normalizedStatus === "active") ||
                (packageStatusFilter === "inactive" && normalizedStatus !== "active");
            const matchesBranch = isAllBranches(branch) || item.branch.toLowerCase().includes(branch.toLowerCase());

            return matchesSearch && matchesStatus && matchesBranch;
        });
    }, [packageStatusFilter, packages, searchQuery, branch]);


    const totalSales = useMemo(() => sumBy(sales, (item) => item.amount), [sales]);

    const currentRange =
        report?.dateRange?.startDate && report?.dateRange?.endDate
            ? formatDateRange(report.dateRange.startDate, report.dateRange.endDate)
            : formatDateRange(startDate, endDate);

    const allowedCards = REPORT_CARDS;


    function getFilteredInventoryExportTable(): ExportTable {
        const headers = [
            "Product Name",
            ...(showBranchColumn ? ["Branch"] : []),
            "Category",
            "Type",
            "Current Stock",
            "Alert Level",
            "Unit Cost",
            "Selling Price",
            "Expiration Date",
            "Status",
        ];

        const rows = displayedInventory.flatMap((item) => {
            const variants = getInventoryVariants(item);
            const parentRow = [
                item.product,
                ...(showBranchColumn ? [item.branch] : []),
                item.category,
                variants.length > 0
                    ? `${variants.length} variant${variants.length === 1 ? "" : "s"}`
                    : "Regular",
                formatNumber(item.stock),
                formatNumber(item.reorderLevel),
                getPriceRange(item, "costPrice"),
                getPriceRange(item, "salesPrice"),
                item.expiryDate
                    ? `${formatDate(item.expiryDate)} (${getExpirationStatus(item.expiryDate)})`
                    : "No expiry",
                item.status,
            ];

            const variantRows = variants.map((variant) => [
                `↳ ${variant.name}`,
                ...(showBranchColumn ? ["—"] : []),
                "—",
                "Variant",
                formatNumber(variant.stock),
                formatNumber(variant.reorderLevel ?? 0),
                typeof variant.costPrice === "number"
                    ? formatPeso(variant.costPrice)
                    : "—",
                typeof variant.salesPrice === "number"
                    ? formatPeso(variant.salesPrice)
                    : "—",
                variant.expiryDate
                    ? `${formatDate(variant.expiryDate)} (${getExpirationStatus(variant.expiryDate)})`
                    : "No expiry",
                getVariantStatus(variant),
            ]);

            return [parentRow, ...variantRows];
        });

        return {
            title: "Filtered Inventory Report",
            headers,
            rows,
        };
    }

    function getFilteredRestockExportTable(): ExportTable {
        const headers = [
            "Date",
            "Reference",
            "Product",
            "Type",
            ...(showBranchColumn ? ["Branch"] : []),
            "Stock Before",
            "Qty Added",
            "Current Stock",
            "Received By",
        ];

        const rows = displayedRestocks.map((item) => {
            const stockBefore =
                typeof item.stockBefore === "number"
                    ? item.stockBefore
                    : Math.max(
                        Number(item.currentStock || 0) -
                        Number(item.quantityAdded || 0),
                        0
                    );

            return [
                formatDate(item.date),
                item.reference || item.id,
                item.variantName
                    ? `${item.product} - ${item.variantName}`
                    : item.product,
                item.variantName ? "Variant" : "Regular",
                ...(showBranchColumn ? [item.branch] : []),
                formatNumber(stockBefore),
                formatNumber(item.quantityAdded),
                formatNumber(item.currentStock),
                item.receivedBy || "Not recorded",
            ];
        });

        return {
            title: "Filtered Restock Report",
            headers,
            rows,
        };
    }

    function getFilteredPosExportTable(): ExportTable {
        const headers = [
            "Order ID",
            ...(showBranchColumn ? ["Branch"] : []),
            "Items",
            "Total",
            "Date",
        ];

        const rows = displayedPosTransactions.map((item) => [
            item.reference || item.id,
            ...(showBranchColumn ? [item.branch || "—"] : []),
            getSaleItemsLabel(item),
            formatPeso(item.amount),
            formatDate(item.date),
        ]);

        return {
            title: "Filtered POS Report",
            headers,
            rows,
        };
    }

    function getFilteredBookingExportTable(): ExportTable {
        const query = searchQuery.trim().toLowerCase();
        const filteredBookings = bookings.filter((item) => {
            const matchesSearch =
                !query ||
                [
                    item.id,
                    item.reference,
                    item.customer,
                    item.phone,
                    item.venue,
                    item.packageName,
                    item.statusLabel,
                    item.paymentStatus,
                    item.branch,
                ]
                    .join(" ")
                    .toLowerCase()
                    .includes(query);

            const matchesStatus =
                bookingFilter === "all" || item.status === bookingFilter;

            return matchesSearch && matchesStatus;
        });

        const headers = [
            "Booking ID",
            "Reference",
            "Client",
            "Phone",
            ...(showBranchColumn ? ["Branch"] : []),
            "Event Date",
            "Time",
            "Package",
            "Package Price",
            "Payment Status",
            "Amount Paid",
            "Balance",
            "Booking Status",
            "Venue",
        ];

        const rows = filteredBookings.map((item) => {
            const payment = getBookingPaymentDetails(item);

            return [
                item.id,
                item.reference || item.id,
                item.customer || "Not recorded",
                item.phone || "Not recorded",
                ...(showBranchColumn ? [item.branch || "—"] : []),
                formatDate(item.eventDate),
                item.scheduleTime || "Time not recorded",
                item.packageName || "Custom Booking",
                formatPeso(payment.packagePrice),
                payment.paymentStatus || "Not recorded",
                formatPeso(payment.amountPaid),
                formatPeso(payment.balance),
                getBookingStatusLabel(item),
                item.venue || "Venue not recorded",
            ];
        });

        return {
            title: "Filtered Booking Report",
            headers,
            rows,
        };
    }

    function getFilteredPackageExportTable(): ExportTable {
        const headers = [
            "Package ID",
            "Package Name",
            "Category",
            ...(showBranchColumn ? ["Branch"] : []),
            "Price",
            "Downpayment",
            "Discount",
            "Inclusions",
            "Status",
        ];

        const rows = displayedPackages.map((item) => [
            item.id,
            item.name,
            item.category || "Event Package",
            ...(showBranchColumn ? [item.branch || "—"] : []),
            formatPeso(item.price),
            item.downPayment ? formatPeso(item.downPayment) : "₱0.00",
            item.discount
                ? (item.isDiscountPercentage ? `${item.discount}%` : formatPeso(item.discount))
                : "0%",
            item.inclusions && item.inclusions.length > 0
                ? item.inclusions.map((i) => `• ${i.name}${i.quantity && i.quantity > 1 ? ` × ${i.quantity}` : ""}`).join("\n")
                : "—",
            item.status,
        ]);

        return {
            title: "Filtered Packages Report",
            headers,
            rows,
        };
    }

    function getFilteredEmployeeActionsExportTable(): ExportTable {
        const query = searchQuery.trim().toLowerCase();
        const searchedActivities = displayedStaffActivities.filter((item) =>
            !query ||
            [
                item.id,
                item.staffName,
                item.role,
                item.action,
                item.module,
                item.reference,
                item.details,
                item.branch,
            ]
                .join(" ")
                .toLowerCase()
                .includes(query)
        );

        const headers = [
            "Date",
            "Time",
            "Employee",
            "Role",
            "Action",
            "Module",
            "Reference",
            ...(showBranchColumn ? ["Branch"] : []),
            "Details",
        ];

        const rows = searchedActivities.map((item) => [
            formatDate(item.date),
            item.time || "—",
            item.staffName,
            item.role,
            item.action,
            item.module,
            item.reference || "—",
            ...(showBranchColumn ? [item.branch || "—"] : []),
            item.details || "—",
        ]);

        return {
            title: "Employee Actions History",
            headers,
            rows,
        };
    }

    function exportDoc(
        table: ExportTable,
        filenamePrefix = "stocknbook-full-inventory"
    ) {
        const rows = table.rows
            .map(
                (row) =>
                    `<tr>${row.map((cell) => `<td>${escapeHtml(cell)}</td>`).join("")}</tr>`
            )
            .join("");

        const documentHtml = `
      <html>
        <head>
          <meta charset="UTF-8" />
          <style>
            body { font-family: Arial, sans-serif; color: #1A1220; }
            h1 { color: #2B174C; }
            table { width: 100%; border-collapse: collapse; margin-top: 18px; }
            th { background: #2B174C; color: white; }
            th, td { border: 1px solid #DED3E8; padding: 8px; text-align: left; }
          </style>
        </head>
        <body>
          <h1>${escapeHtml(table.title)}</h1>
          <p><strong>Store:</strong> ${escapeHtml(activeStoreName)}</p>
          <p><strong>Branch:</strong> ${escapeHtml(activeBranch || "Assigned Branch")}</p>
          <p><strong>Date range:</strong> ${escapeHtml(currentRange)}</p>
          <table>
            <thead><tr>${table.headers
            .map((header) => `<th>${escapeHtml(header)}</th>`)
            .join("")}</tr></thead>
            <tbody>${rows}</tbody>
          </table>
        </body>
      </html>
    `;

        downloadFile(
            `${filenamePrefix}-${startDate}.doc`,
            "application/msword;charset=utf-8",
            documentHtml
        );
    }

    async function exportExcel(
        table: ExportTable,
        filenamePrefix = "stocknbook-full-inventory",
        sheetName = "Inventory Report"
    ) {
        // Spreadsheet generation is an export-only feature. Lazy-load XLSX so
        // normal report viewing does not pay the bundle/parse cost on startup.
        const XLSX = await import("xlsx");
        const worksheet = XLSX.utils.aoa_to_sheet([
            [table.title],
            [`Store: ${activeStoreName}`],
            [`Branch: ${activeBranch || "Assigned Branch"}`],
            [`Date range: ${currentRange}`],
            [],
            table.headers,
            ...table.rows,
        ]);

        worksheet["!cols"] = table.headers.map((header, columnIndex) => {
            const longestValue = Math.max(
                header.length,
                ...table.rows.map((row) => String(row[columnIndex] ?? "").length)
            );

            return { wch: Math.min(Math.max(longestValue + 2, 12), 36) };
        });

        const workbook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(workbook, worksheet, sheetName);
        XLSX.writeFile(workbook, `${filenamePrefix}-${startDate}.xlsx`);
    }

    function exportPdf(
        table: ExportTable,
        filenamePrefix = "stocknbook-full-inventory"
    ) {
        const pdf = createTablePdf({
            title: table.title,
            storeName: activeStoreName,
            branch: activeBranch || "Assigned Branch",
            dateRange: currentRange,
            headers: table.headers,
            rows: table.rows,
        });

        downloadFile(
            `${filenamePrefix}-${startDate}.pdf`,
            "application/pdf",
            pdf
        );
    }

    return (
        <div className="min-h-screen min-w-0 overflow-x-hidden bg-[#FFFDF8] font-sans">
            <div className="px-4 py-5 sm:px-5 lg:px-6">
                <header className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
                    <div>
                        <h1 className="text-[27px] font-bold leading-none text-[#1A1220]">
                            Reports
                        </h1>
                        <p className="mt-2 text-sm text-[#7F7188]">
                            View and export business reports and activity history.
                        </p>
                    </div>

                    <div className="flex items-center gap-2">
                        <button
                            type="button"
                            onClick={() => void handleRefresh()}
                            disabled={loading}
                            className="inline-flex h-10 items-center gap-2 rounded-xl bg-[#2B174C] px-4 text-sm font-semibold text-white shadow-sm transition-all duration-200 hover:-translate-y-0.5 hover:bg-[#1B0D31] hover:shadow-md disabled:cursor-not-allowed disabled:opacity-60"
                        >
                            <RefreshCw
                                size={15}
                                className={loading ? "animate-spin" : ""}
                            />
                            Refresh
                        </button>
                    </div>
                </header>

                <nav
                    aria-label="Report types"
                    className="mt-5 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6"
                >
                    {allowedCards.map((card) => {
                        const Icon = card.icon;
                        const active = selectedReport === card.key;

                        return (
                            <button
                                key={card.key}
                                type="button"
                                aria-pressed={active}
                                onClick={() => {
                                    setSelectedReport(card.key);
                                    setSearchQuery("");
                                    setExpandedInventoryId(null);

                                    if (card.key === "inventory") {
                                        setInventoryFilter("all");
                                        setCategoryFilter("all");
                                    }

                                    if (card.key === "bookings") {
                                        setBookingFilter("all");
                                    }

                                    if (card.key === "packages") {
                                        setPackageStatusFilter("all");
                                    }

                                    if (card.key === "staff") {
                                        setStaffModuleFilter("all");
                                    }
                                }}
                                className={`group flex min-h-[132px] min-w-0 flex-col rounded-[16px] border p-4 text-left transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-[#7C4DFF]/20 ${
                                    active
                                        ? "border-[#9B6CF3] bg-[#FCF9FF] shadow-[0_0_0_2px_rgba(124,77,255,0.12),0_10px_24px_rgba(62,32,100,0.12)]"
                                        : "border-[#E7DFED] bg-white shadow-sm hover:-translate-y-0.5 hover:border-[#C5A9E8] hover:shadow-[0_10px_24px_rgba(62,32,100,0.12)]"
                                }`}
                            >
                                <span className="flex min-w-0 items-start justify-between gap-2">
                                    <span
                                        className={`min-w-0 break-words pr-1 text-[13px] font-bold leading-5 transition-colors ${
                                            active ? "text-[#5727C8]" : "text-[#20152A]"
                                        }`}
                                    >
                                        {card.title}
                                    </span>

                                    <span
                                        className={`flex h-10 shrink-0 items-center justify-end overflow-hidden rounded-full transition-all duration-200 ${card.iconClassName} ${
                                            active
                                                ? "w-[76px]"
                                                : "w-10 group-hover:w-[76px]"
                                        }`}
                                    >
                                        <span
                                            className={`overflow-hidden whitespace-nowrap text-[11px] font-semibold transition-all duration-200 ${
                                                active
                                                    ? "ml-3 max-w-[34px] opacity-100"
                                                    : "ml-0 max-w-0 opacity-0 group-hover:ml-3 group-hover:max-w-[34px] group-hover:opacity-100"
                                            }`}
                                        >
                                            View
                                        </span>
                                        <Icon
                                            size={19}
                                            strokeWidth={2}
                                            className="mx-2.5 shrink-0"
                                        />
                                    </span>
                                </span>

                                <span className="mt-4 block break-words text-[11px] leading-[1.45] text-[#7F7188]">
                                    {card.subtitle}
                                </span>
                            </button>
                        );
                    })}
                </nav>

                <ReportFilterBar
                    selectedReport={selectedReport}
                    searchQuery={searchQuery}
                    onSearchChange={(value) => {
                        setSearchQuery(value);
                    }}
                    startDate={startDate}
                    endDate={endDate}
                    onStartDateChange={(value) => {
                        setStartDate(value);
                    }}
                    onEndDateChange={(value) => {
                        setEndDate(value);
                    }}
                    categoryFilter={categoryFilter}
                    inventoryCategories={inventoryCategories}
                    onCategoryChange={(value) => {
                        setCategoryFilter(value);
                    }}
                    bookingStatusFilter={bookingFilter}
                    onBookingStatusChange={setBookingFilter}
                    packageStatusFilter={packageStatusFilter}
                    onPackageStatusChange={setPackageStatusFilter}
                    staffModuleFilter={staffModuleFilter}
                    onStaffModuleChange={setStaffModuleFilter}
                    showBranchFilter={showBranchFilter}
                    branch={branch}
                    branchOptions={branchOptions}
                    onBranchChange={setBranch}
                    onClear={() => {
                        setSearchQuery("");
                        setStartDate(getMonthStart(getToday()));
                        setEndDate(getToday());
                        setCategoryFilter("all");
                        setInventoryFilter("all");
                        setBookingFilter("all");
                        setPackageStatusFilter("all");
                        setStaffModuleFilter("all");
                        setBranch(initialRole === "owner" ? ALL_BRANCHES : assignedBranch || DEFAULT_BRANCH);
                        setExpandedInventoryId(null);
                    }}
                />

                <div className="mt-4 pb-12">
                    {loading && !report && !liveSalesState.ready ? (
                        <ModuleSkeleton variant="reports" />
                    ) : (
                        <>
                            {selectedReport === "inventory" && (
                                <InventoryReportView
                                    items={displayedInventory}
                                    showBranchColumn={showBranchColumn}
                                    expandedInventoryId={expandedInventoryId}
                                    onToggleExpanded={(id) => setExpandedInventoryId(current => current === id ? null : id)}
                                    inStockCount={inStock.length}
                                    lowStockCount={lowStock.length}
                                    outOfStockCount={outOfStock.length}
                                    soonToExpireCount={soonToExpire.length}
                                    expiredCount={expiredItems.length}
                                    goodExpirationCount={goodExpirationItems.length}
                                    categorySummary={inventoryCategorySummary}
                                    onExportPdf={() => exportPdf(getFilteredInventoryExportTable(), "inventory-report")}
                                    onExportXlsx={() => exportExcel(getFilteredInventoryExportTable(), "inventory-report")}
                                    onExportDoc={() => exportDoc(getFilteredInventoryExportTable(), "inventory-report")}
                                />
                            )}

                            {selectedReport === "restock" && (
                                <RestockReportView
                                    records={displayedRestocks}
                                    showBranchColumn={showBranchColumn}
                                    onExportPdf={() => exportPdf(getFilteredRestockExportTable(), "restock-report")}
                                    onExportXlsx={() => exportExcel(getFilteredRestockExportTable(), "restock-report")}
                                    onExportDoc={() => exportDoc(getFilteredRestockExportTable(), "restock-report")}
                                />
                            )}

                            {selectedReport === "sales" && (
                                <PosReportView
                                    records={displayedPosTransactions}
                                    showBranchColumn={showBranchColumn}
                                    onExportPdf={() => exportPdf(getFilteredPosExportTable(), "pos-report")}
                                    onExportXlsx={() => exportExcel(getFilteredPosExportTable(), "pos-report")}
                                    onExportDoc={() => exportDoc(getFilteredPosExportTable(), "pos-report")}
                                />
                            )}

                            {selectedReport === "bookings" && (
                                <BookingReportView
                                    records={displayedBookings}
                                    searchQuery={searchQuery}
                                    activeFilter={bookingFilter}
                                    onFilterChange={setBookingFilter}
                                    showBranchColumn={showBranchColumn}
                                    onExportPdf={() => exportPdf(getFilteredBookingExportTable(), "booking-report")}
                                    onExportXlsx={() => exportExcel(getFilteredBookingExportTable(), "booking-report")}
                                    onExportDoc={() => exportDoc(getFilteredBookingExportTable(), "booking-report")}
                                />
                            )}

                            {selectedReport === "packages" && (
                                <PackagesReportView
                                    records={displayedPackages}
                                    showBranchColumn={showBranchColumn}
                                    onExportPdf={() => exportPdf(getFilteredPackageExportTable(), "plans-report")}
                                    onExportXlsx={() => exportExcel(getFilteredPackageExportTable(), "plans-report")}
                                    onExportDoc={() => exportDoc(getFilteredPackageExportTable(), "plans-report")}
                                />
                            )}

                            {selectedReport === "staff" && (
                                <EmployeeActionsReportView
                                    records={displayedStaffActivities}
                                    searchQuery={searchQuery}
                                    activeFilter={staffModuleFilter}
                                    onFilterChange={setStaffModuleFilter}
                                    showBranchColumn={showBranchColumn}
                                    onExportPdf={() => exportPdf(getFilteredEmployeeActionsExportTable(), "employee-actions-report")}
                                    onExportXlsx={() => exportExcel(getFilteredEmployeeActionsExportTable(), "employee-actions-report")}
                                    onExportDoc={() => exportDoc(getFilteredEmployeeActionsExportTable(), "employee-actions-report")}
                                />
                            )}
                        </>
                    )}
                </div>
            </div>
        </div>
    );
}
// Format audit timestamps for display and exports; preserve the stored time.
function formatAuditClockTime(value: string): string {
    const raw = String(value || "").trim();
    if (!raw) return "—";
    const match = /^(\d{1,2}):(\d{2})(?::(\d{2}))?$/.exec(raw);
    if (!match) return raw; // Already 12-hour format, or an unknown format.
    const hour = Number(match[1]);
    if (hour < 0 || hour > 23) return raw;
    const hour12 = hour % 12 || 12;
    const seconds = match[3] ? `:${match[3]}` : "";
    return `${hour12}:${match[2]}${seconds} ${hour < 12 ? "AM" : "PM"}`;
}

function auditModuleBadgeClass(module: string): string {
    switch (String(module || "").trim().toLowerCase()) {
        case "bookings": return "bg-[#EAF2FF] text-[#1D4ED8]";
        case "inventory": return "bg-[#FFF1E6] text-[#B45309]";
        case "sales / pos":
        case "pos":
        case "sales": return "bg-[#E8F7EE] text-[#15803D]";
        case "packages": return "bg-[#F1EAFE] text-[#6D28D9]";
        default: return "bg-[#F2EDF6] text-[#594767]";
    }
}

// Audit Logs retains the existing Reports route and role-scoped API.
// The table follows the original column order used by Employee Actions History.
type AuditLogRow = {
    id: string;
    date: string;
    time: string;
    employeeName: string;
    employeeRole: string;
    action: string;
    details: string;
    module: string;
    reference: string;
    branch: string;
};

type AuditLogResponse = {
    success?: boolean;
    error?: string;
    data?: {
        logs: AuditLogRow[];
        total: number;
        page: number;
        pageSize: number;
        totalPages: number;
        modules: string[];
        branches: Array<{ id: number; name: string }>;
    };
};

export function AuditLogsWorkspace({
                                       initialRole,
                                       assignedBranch,
                                       storeName,
                                       viewConfig,
                                   }: ReportsWorkspaceProps) {
    const owner = initialRole === "owner";
    const manager = initialRole === "manager";
    const [search, setSearch] = useState("");
    const [startDate, setStartDate] = useState(() => getMonthStart(getToday()));
    const [endDate, setEndDate] = useState(getToday);
    const [moduleName, setModuleName] = useState("");
    const [branchId, setBranchId] = useState("");
    const [branches, setBranches] = useState<Array<{ id: number; name: string }>>([]);
    const [rows, setRows] = useState<AuditLogRow[]>([]);
    const [total, setTotal] = useState(0);
    const [page, setPage] = useState(1);
    const [totalPages, setTotalPages] = useState(1);
    const [loading, setLoading] = useState(true);
    const scrollLoadPending = useRef(false);
    const [exporting, setExporting] = useState(false);
    const [error, setError] = useState("");

    const buildAuditQuery = useCallback((requestedPage: number) => {
        const query = new URLSearchParams({
            scope: "audit_logs",
            startDate,
            endDate,
            page: String(requestedPage),
        });
        if (search.trim()) query.set("search", search.trim());
        if (moduleName) query.set("module", moduleName);
        // Branch restrictions for managers and staff remain enforced by /api/reports.
        if (owner && branchId) query.set("branch_id", branchId);
        return query;
    }, [owner, search, startDate, endDate, moduleName, branchId]);

    const requestAuditPage = useCallback(async (requestedPage: number, signal?: AbortSignal) => {
        const token = getStoredSessionValue(["token"]);
        if (!token) throw new Error("Your session has expired. Please sign in again.");
        const response = await fetch(`/api/reports?${buildAuditQuery(requestedPage)}`, {
            headers: { Authorization: `Bearer ${token}` },
            cache: "no-store",
            signal,
        });
        const result = (await response.json()) as AuditLogResponse;
        if (!response.ok || !result.success || !result.data) {
            throw new Error(result.error || "Unable to load audit logs.");
        }
        return result.data;
    }, [buildAuditQuery]);

    useEffect(() => {
        const controller = new AbortController();
        const timeout = window.setTimeout(() => {
            const load = async () => {
                setLoading(true);
                setError("");
                try {
                    const data = await requestAuditPage(page, controller.signal);
                    if (controller.signal.aborted) return;
                    // Keep previous rows visible when the user scrolls to load more.
                    setRows((previous) => page === 1
                        ? (Array.isArray(data.logs) ? data.logs : [])
                        : [...previous, ...(Array.isArray(data.logs) ? data.logs : [])]);
                    setTotal(Number(data.total) || 0);
                    setTotalPages(Math.max(1, Number(data.totalPages) || 1));
                    // Prevent an invalid API page from producing "0–NaN" in pagination.
                    const validPage = Number(data.page);
                    if (Number.isSafeInteger(validPage) && validPage > 0 && validPage !== page) {
                        setPage(validPage);
                    }
                    if (owner) setBranches(Array.isArray(data.branches) ? data.branches : []);
                } catch (caught) {
                    if (controller.signal.aborted) return;
                    setRows([]);
                    setTotal(0);
                    setError(caught instanceof Error ? caught.message : "Unable to load audit logs.");
                } finally {
                    if (!controller.signal.aborted) {
                        scrollLoadPending.current = false;
                        setLoading(false);
                    }
                }
            };
            void load();
        }, search.trim() ? 250 : 0);
        return () => { window.clearTimeout(timeout); controller.abort(); };
    }, [owner, page, requestAuditPage]);

    const downloadAuditLogs = async () => {
        if (exporting || loading || total === 0) return;
        setExporting(true);
        setError("");
        try {
            // Get a fresh first page, then download every remaining page using
            // the SAME filters. Never export only the currently visible page.
            // This endpoint applies the role/branch restrictions to every request.
            const firstPage = await requestAuditPage(1);
            const allLogs: AuditLogRow[] = [...(firstPage.logs || [])];
            const numberOfPages = Math.max(1, Number(firstPage.totalPages) || 1);
            for (let first = 2; first <= numberOfPages; first += 6) {
                const last = Math.min(first + 5, numberOfPages);
                const batch = await Promise.all(
                    Array.from({ length: last - first + 1 }, (_, index) =>
                        requestAuditPage(first + index)
                    )
                );
                batch.forEach((result) => allLogs.push(...(result.logs || [])));
            }
            if (allLogs.length === 0) {
                setError("No matching audit logs to download.");
                return;
            }

            const scopeLabel = owner
                ? (branchId ? branches.find((branch) => String(branch.id) === branchId)?.name || "Selected Branch" : "All Branches")
                : assignedBranch || "Assigned Branch";
            const pdf = createTablePdf({
                title: "Audit Logs / Employee Actions",
                storeName: storeName || "StockNBook",
                branch: scopeLabel,
                dateRange: `${startDate} to ${endDate}`,
                // Preserve longer action descriptions without changing other report exports.
                maxCellLines: 10,
                headers: viewConfig.showBranchColumn
                    ? ["Date / Time", "Employee", "Action", "Module", "Reference", "Branch"]
                    : ["Date / Time", "Employee", "Action", "Module", "Reference"],
                rows: allLogs.map((log) => {
                    const cells = [
                        `${log.date || "-"} ${formatAuditClockTime(log.time)}`.trim(),
                        `${log.employeeName || "Unknown"} (${log.employeeRole || "Staff"})`,
                        log.details ? `${log.action || "-"} - ${log.details}` : log.action || "-",
                        log.module || "-",
                        log.reference || "-",
                    ];
                    if (viewConfig.showBranchColumn) cells.push(log.branch || "-");
                    return cells;
                }),
            });
            downloadFile(`stocknbook-audit-logs-${startDate}-to-${endDate}.pdf`, "application/pdf", pdf);
        } catch (caught) {
            setError(caught instanceof Error ? caught.message : "Failed to download audit logs.");
        } finally {
            setExporting(false);
        }
    };

    const inputStyle = "h-[42px] min-w-0 w-full rounded-xl border border-[#E3D8EA] bg-white px-3 text-sm text-[#1A1220] outline-none shadow-sm transition focus:border-[#2B174C] focus:ring-4 focus:ring-[#2B174C]/10";

    return (
        <div className="min-h-screen bg-[#FFFDF8] font-sans text-[#1A1220]">
            <header className="sticky top-0 z-20 flex min-h-[72px] flex-wrap items-center justify-between gap-3 border-b border-[#E9E0EF] bg-[#FFFDF8]/95 px-6 py-3 backdrop-blur">
                <div>
                    <h1 className="text-[25px] font-bold text-[#1A1220]">Audit Logs</h1>
                    <p className="mt-1 text-xs text-[#806A8C]">
                        {owner ? "Manager and staff actions across your branches."
                            : manager ? `Staff actions in ${assignedBranch || "your assigned branch"}.`
                                : "Your recorded employee actions."}
                    </p>
                </div>
            </header>

            <section className="px-6 py-4">
                <div className="overflow-hidden rounded-[18px] border border-[#E6DDF0] bg-white shadow-sm">
                    <div className="flex flex-wrap items-center justify-between gap-3 px-5 pb-3 pt-5">
                        <div>
                            <h2 className="text-[16px] font-bold text-[#1A1220]">Employee Action History</h2>
                            <p className="mt-1 text-xs text-[#806A8C]">Who performed the action, what changed, where it happened, and when.</p>
                        </div>
                        <button type="button" onClick={() => void downloadAuditLogs()}
                                disabled={loading || exporting || total === 0}
                                aria-label="Download filtered audit logs as PDF"
                                title="Download filtered audit logs as PDF"
                                className="inline-flex h-[42px] w-[42px] shrink-0 items-center justify-center rounded-xl border border-[#DFCFEF] bg-white text-[#5A35A5] shadow-sm transition hover:bg-[#F7F1FF] disabled:cursor-not-allowed disabled:opacity-40">
                            <Download size={18} className={exporting ? "animate-pulse" : ""} />
                        </button>
                    </div>

                    <div className={`grid gap-3 px-5 pb-4 sm:grid-cols-2 ${owner && viewConfig.showBranchFilter ? "xl:grid-cols-[minmax(220px,1fr)_175px_175px_185px_195px]" : "xl:grid-cols-[minmax(220px,1fr)_185px_185px_210px]"}`}>
                        <label className="relative block min-w-0">
                            <span className="sr-only">Search employee actions</span>
                            <Search size={16} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-[#9B8AAA]" />
                            <input value={search} onChange={(event) => { setSearch(event.target.value); setPage(1); }}
                                   placeholder="Search employee, action or reference..."
                                   className={`${inputStyle} pl-10 placeholder:text-[#9B8AAA]`} />
                        </label>
                        <label className="relative block min-w-0">
                            <span className="sr-only">From date</span>
                            <span className="pointer-events-none absolute top-1/2 left-3 -translate-y-1/2 text-[10px] font-semibold text-[#806A8C]">FROM</span>
                            <input type="date" value={startDate} max={endDate} onChange={(event) => { setStartDate(event.target.value); setPage(1); }}
                                   className={`${inputStyle} pl-14`} />
                        </label>
                        <label className="relative block min-w-0">
                            <span className="sr-only">To date</span>
                            <span className="pointer-events-none absolute top-1/2 left-3 -translate-y-1/2 text-[10px] font-semibold text-[#806A8C]">TO</span>
                            <input type="date" value={endDate} min={startDate} onChange={(event) => { setEndDate(event.target.value); setPage(1); }}
                                   className={`${inputStyle} pl-9`} />
                        </label>
                        <select aria-label="Filter audit logs by module" value={moduleName}
                                onChange={(event) => { setModuleName(event.target.value); setPage(1); }} className={inputStyle}>
                            <option value="">All Modules</option>
                            {["Bookings", "Inventory", "Sales / POS", "Packages"].map((name) => (
                                <option key={name} value={name}>{name}</option>
                            ))}
                        </select>
                        {owner && viewConfig.showBranchFilter && (
                            <select aria-label="Filter audit logs by branch" value={branchId}
                                    onChange={(event) => { setBranchId(event.target.value); setPage(1); }} className={inputStyle}>
                                <option value="">All Branches</option>
                                {branches.map((branch) => <option key={branch.id} value={branch.id}>{branch.name}</option>)}
                            </select>
                        )}
                    </div>

                    {error && <div role="alert" className="mx-5 mb-4 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">{error}</div>}
                    <div
                        className="max-h-[580px] overflow-x-auto overflow-y-auto border-t border-[#EAE1EF]"
                        onScroll={(event) => {
                            const element = event.currentTarget;
                            const nearBottom = element.scrollTop + element.clientHeight >= element.scrollHeight - 120;
                            if (nearBottom && !loading && !scrollLoadPending.current && page < totalPages) {
                                scrollLoadPending.current = true;
                                setPage((current) => current + 1);
                            }
                        }}
                    >
                        <table className={`w-full border-collapse text-left text-[12px] ${viewConfig.showBranchColumn ? "min-w-[880px]" : "min-w-[740px]"}`}>
                            <thead className="sticky top-0 z-10 bg-[#F8F4FC] text-[11px] font-medium uppercase tracking-wide text-[#705B81]">
                            <tr className="border-b border-[#E6DDF0]">
                                <th className="px-4 py-3">Date / Time</th>
                                <th className="px-4 py-3">Employee</th>
                                <th className="px-4 py-3">Action</th>
                                <th className="px-4 py-3">Module</th>
                                <th className="px-4 py-3">Reference</th>
                                {viewConfig.showBranchColumn && <th className="px-4 py-3">Branch</th>}
                            </tr>
                            </thead>
                            <tbody className="divide-y divide-[#EEE7F3]">
                            {loading && rows.length === 0 ? (
                                <tr><td colSpan={viewConfig.showBranchColumn ? 6 : 5} className="px-4 py-12 text-center text-sm text-[#806A8C]">Loading employee actions...</td></tr>
                            ) : rows.length === 0 ? (
                                <tr><td colSpan={viewConfig.showBranchColumn ? 6 : 5} className="px-4 py-12 text-center text-sm text-[#806A8C]">No employee actions match the selected filters.</td></tr>
                            ) : rows.map((log) => (
                                <tr key={log.id} className="align-top transition-colors hover:bg-[#FCFAFF]">
                                    <td className="whitespace-nowrap px-4 py-4">
                                        <p className="font-semibold text-[#2B174C]">{formatDate(log.date)}</p>
                                        <p className="mt-1 text-[11px] text-[#806A8C]">{formatAuditClockTime(log.time)}</p>
                                    </td>
                                    <td className="px-4 py-4">
                                        <p className="font-semibold text-[#1A1220]">{log.employeeName}</p>
                                        <p className="mt-1 text-[11px] text-[#806A8C]">{log.employeeRole}</p>
                                    </td>
                                    <td className="max-w-[410px] px-4 py-4">
                                        <p className="font-semibold text-[#1A1220]">{log.action}</p>
                                        {log.details && <p className="mt-1 break-words text-[11px] leading-5 text-[#806A8C]">{log.details}</p>}
                                    </td>
                                    <td className="px-4 py-4">
                                        <span className={`inline-block rounded-full px-2.5 py-1 text-[11px] font-semibold ${auditModuleBadgeClass(log.module)}`}>{log.module}</span>
                                    </td>
                                    <td className="max-w-[155px] break-all px-4 py-4 font-medium text-[#594767]">{log.reference || "—"}</td>
                                    {viewConfig.showBranchColumn && <td className="px-4 py-4 text-[#594767]">{log.branch}</td>}
                                </tr>
                            ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            </section>
        </div>
    );
}
