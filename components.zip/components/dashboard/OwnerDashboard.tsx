"use client";

/**
 * Owner Dashboard — strategic, store-wide view.
 *
 * Redesign notes (per adviser feedback):
 * - This dashboard is now DIFFERENT from Manager/Staff. It intentionally drops
 *   the operational widgets (upcoming bookings table, inventory/expiration
 *   alerts) that used to be duplicated across all three role dashboards.
 *   Those belong on the Manager dashboard (day-to-day reports: inventory,
 *   bookings, restock, staff activity) and the Staff dashboard (today's
 *   queue). The Owner only sees sales, profit, and trend-level insight.
 * - 4 KPI cards: Total Sales, Cost of Sales, Gross Profit, and Forecasted Sales
 *   (next month).
 * - The lower summary area intentionally focuses on Top Products / Packages
 *   and Sales Forecast. Revenue by Channel was removed to keep the layout
 *   compact, focused, and visually balanced.
 * - Cost of Sales is calculated from live inventory/product cost data for POS
 *   items and from the inventory cost of standard package inclusions for
 *   realized bookings. Recorded POS totalCost remains the preferred historical
 *   source when it is present. No artificial margin fallback is used.
 * - Gross Profit uses the same sales population as Total Sales: realized POS
 *   sales plus realized booking revenue, less the corresponding inventory cost.
 *   If any realized revenue cannot be reliably costed from the available live
 *   inventory/package data, the dashboard shows a dash instead of fabricating
 *   a profit figure. Operating expenses are separate and are not deducted from
 *   Gross Profit; they would be used later to calculate Net Profit.
 * - The "Forecasted Sales" KPI badge and the "Sales Forecast" panel below
 *   both read from the SAME predictedNextMonthSales/forecastGrowthPct values,
 *   so they can never drift out of sync with each other.
 * - "Sales Forecast" is a lightweight linear-trend projection over the
 *   last completed months of real sales data (not a hosted ML model). It's honest
 *   about being a trend projection in the UI copy ("Trend-based projection")
 *   and keeps the Forecast Basis / Method disclosure — that transparency is
 *   what the adviser's "should have science" requirement is asking for.
 */

import { useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { useCurrentUser } from "@/hooks/useCurrentUser";
import {
    BarChart3,
    Building2,
    Info,
    Lightbulb,
    RefreshCw,
    Sparkles,
    TrendingDown,
    TrendingUp,
    Trophy,
    Wallet,
} from "lucide-react";

/* ----------------------------------------------------------------------- */
/* Types                                                                    */
/* ----------------------------------------------------------------------- */

type Branch = {
    id: number;
    branchName: string;
};

type Booking = {
    id: number;
    packageId?: number | null;
    branchId?: number | null;
    date?: string;
    status?: string;
    packageName?: string;
    bookingType?: string;
    booking_type?: string;
    customOrder?: string;
    custom_order?: string;
    agreed_price?: number | string | null;
    agreedPrice?: number | string | null;
    package_price?: number | string | null;
    packagePrice?: number | string | null;
    total?: number;
    costOfSales?: number | null;
};

type OrderItem = {
    name?: string;
    quantity?: number;
    price?: number;
    unitPrice?: number;
    unit_price?: number;
    lineTotal?: number;
    line_total?: number;
    sellingPrice?: number;
    selling_price?: number;
    salesPrice?: number;
    sales_price?: number;
    costPrice?: number;
    cost_price?: number;
    originalPrice?: number;
    original_price?: number;
};

type InventoryVariant = {
    id?: number;
    name?: string;
    costPrice?: number;
    salesPrice?: number;
    sales_price?: number;
    cost_price?: number;
    variantValues?: Record<string, string>;
    variant_values?: Record<string, string>;
};

type InventoryProduct = {
    id: number;
    branchId?: number | null;
    branch_id?: number | null;
    name: string;
    costPrice?: number;
    salesPrice?: number;
    sales_price?: number;
    cost_price?: number;
    variants?: InventoryVariant[];
};

type PackageInclusion = {
    name: string;
    productId?: number | null;
    product_id?: number | null;
    variantId?: number | null;
    variant_id?: number | null;
    quantity: number;
    costPrice?: number;
    cost_price?: number;
};

type PackageRecord = {
    id?: string | number;
    name: string;
    branchId?: number | null;
    branch_id?: number | null;
    inclusions: PackageInclusion[];
};

type Order = {
    branchId?: number | null;
    total?: number;
    totalCost?: number | null;
    profit?: number | null;
    date?: string;
    createdAt?: string;
    items?: OrderItem[];
    status?: string;
    orderType?: string;
};

type PeriodOption = "month" | "quarter" | "year";
type TrendRange = 6 | 12;

type OwnerPosDailyMetric = {
    date: string;
    sales: number;
    cost: number;
};

type OwnerPosBranchRow = {
    key: string;
    name: string;
    amount: number;
};

type OwnerPosTopProduct = {
    key: string;
    name: string;
    sales: number;
    units: number;
};

type OwnerPosSummary = {
    daily: OwnerPosDailyMetric[];
    branchPerformance: Record<PeriodOption, OwnerPosBranchRow[]>;
    topProducts: Record<PeriodOption, OwnerPosTopProduct[]>;
};

const EMPTY_OWNER_POS_SUMMARY: OwnerPosSummary = {
    daily: [],
    branchPerformance: { month: [], quarter: [], year: [] },
    topProducts: { month: [], quarter: [], year: [] },
};

/* ----------------------------------------------------------------------- */
/* Generic parsing helpers (kept consistent with the rest of the app)      */
/* ----------------------------------------------------------------------- */

function getSavedItem(key: string) {
    if (typeof window === "undefined") return "";
    return sessionStorage.getItem(key) || localStorage.getItem(key) || "";
}

function getUserValue(user: unknown, key: string) {
    if (!user || typeof user !== "object") return "";
    return String((user as Record<string, unknown>)[key] ?? "");
}

function peso(value: number) {
    return `₱${Number(value || 0).toLocaleString("en-PH", {
        minimumFractionDigits: 0,
        maximumFractionDigits: 0,
    })}`;
}

function pesoCompact(value: number) {
    const abs = Math.abs(value);
    if (abs >= 1_000_000) {
        return `₱${(value / 1_000_000).toFixed(abs >= 10_000_000 ? 0 : 1)}M`;
    }
    if (abs >= 1_000) {
        return `₱${(value / 1_000).toFixed(0)}K`;
    }
    return `₱${Math.round(value)}`;
}

function formatCurrentDashboardDateTime(value: Date) {
    const dateLabel = value.toLocaleDateString("en-US", {
        month: "long",
        day: "numeric",
        year: "numeric",
    });

    const timeLabel = value
        .toLocaleTimeString("en-US", {
            hour: "numeric",
            minute: "2-digit",
            hour12: true,
        })
        .toLowerCase();

    return `${dateLabel} | ${timeLabel}`;
}

function formatDashboardIsoDate(value: Date) {
    const year = value.getFullYear();
    const month = String(value.getMonth() + 1).padStart(2, "0");
    const day = String(value.getDate()).padStart(2, "0");
    return `${year}-${month}-${day}`;
}

type ApiRecord = Record<string, unknown>;

function toRecord(value: unknown): ApiRecord {
    return value && typeof value === "object" && !Array.isArray(value)
        ? (value as ApiRecord)
        : {};
}

function firstDefined(record: ApiRecord, keys: string[]) {
    for (const key of keys) {
        const value = record[key];
        if (value !== null && value !== undefined) return value;
    }
    return undefined;
}

function readText(record: ApiRecord, keys: string[], fallback = "") {
    const value = firstDefined(record, keys);
    if (typeof value === "string") return value;
    if (typeof value === "number") return String(value);
    return fallback;
}

function readNumber(record: ApiRecord, keys: string[], fallback = 0) {
    const value = firstDefined(record, keys);
    const parsed = Number(value);
    return Number.isFinite(parsed) ? parsed : fallback;
}

function readNullableNumber(record: ApiRecord, keys: string[]) {
    const value = firstDefined(record, keys);
    if (value === null || value === undefined || value === "") return null;
    const parsed = Number(value);
    return Number.isFinite(parsed) ? parsed : null;
}

/* ----------------------------------------------------------------------- */
/* Normalizers (trimmed to sales/profit-relevant fields only)              */
/* ----------------------------------------------------------------------- */

function normalizeBranch(value: unknown): Branch {
    const raw = toRecord(value);
    return {
        id: readNumber(raw, ["id", "branch_id", "branchId"]),
        branchName: readText(
            raw,
            ["branchName", "branch_name", "name", "branch"],
            "Unnamed Branch",
        ),
    };
}

function normalizeDashboardBookingStatus(value?: string | null) {
    const raw = String(value || "").trim().toLowerCase();
    if (!raw || raw === "pending") return "Pending";
    if (
        raw === "awaiting down payment" ||
        raw === "waiting down payment" ||
        raw === "awaiting payment" ||
        raw === "down payment required"
    ) {
        return "Awaiting Down Payment";
    }
    if (raw === "confirmed") return "Confirmed";
    if (raw === "preparing") return "Preparing";
    if (raw === "completed") return "Completed";
    if (raw === "cancelled" || raw === "canceled") return "Cancelled";
    return value || "Pending";
}

function normalizeBooking(value: unknown): Booking {
    const raw = toRecord(value);
    return {
        id: readNumber(raw, ["id", "booking_id"]),
        packageId: readNullableNumber(raw, ["packageId", "package_id"]),
        branchId: readNullableNumber(raw, ["branchId", "branch_id"]),
        date: readText(raw, [
            "date",
            "event_date",
            "eventDate",
            "booking_date",
            "bookingDate",
            "scheduled_at",
            "scheduledAt",
            "start_at",
            "startAt",
            "created_at",
            "createdAt",
        ]),
        status: normalizeDashboardBookingStatus(readText(raw, ["status"])),
        packageName: readText(raw, [
            "packageName",
            "package_name",
            "package",
            "package_title",
            "service_name",
        ]),
        bookingType: readText(raw, ["bookingType", "booking_type"]),
        booking_type: readText(raw, ["booking_type", "bookingType"]),
        customOrder: readText(raw, ["customOrder", "custom_order"]),
        custom_order: readText(raw, ["custom_order", "customOrder"]),
        agreed_price: firstDefined(raw, ["agreed_price", "agreedPrice"]) as
            | number
            | string
            | null
            | undefined,
        agreedPrice: firstDefined(raw, ["agreedPrice", "agreed_price"]) as
            | number
            | string
            | null
            | undefined,
        package_price: firstDefined(raw, ["package_price", "packagePrice"]) as
            | number
            | string
            | null
            | undefined,
        packagePrice: firstDefined(raw, ["packagePrice", "package_price"]) as
            | number
            | string
            | null
            | undefined,
        total: readNumber(raw, [
            "total",
            "total_amount",
            "booking_total",
            "amount",
            "grand_total",
        ]),
        costOfSales: readNullableNumber(raw, [
            "costOfSales",
            "cost_of_sales",
            "bookingCost",
            "booking_cost",
        ]),
    };
}

function isCustomDashboardBooking(booking: Booking) {
    const type = String(booking.bookingType || booking.booking_type || "")
        .trim()
        .toLowerCase();
    const packageLabel = String(booking.packageName || "").trim().toLowerCase();
    const customText = String(booking.customOrder || booking.custom_order || "").trim();
    return type.includes("custom") || packageLabel.includes("custom") || Boolean(customText);
}

function getDashboardBookingTotalPrice(booking: Booking) {
    // agreed_price is the transaction-level selling price and can include
    // package discounts plus additional/custom items. Fall back to package
    // price for older records where agreed_price is missing or zero.
    const candidates = [
        booking.agreed_price,
        booking.agreedPrice,
        booking.package_price,
        booking.packagePrice,
        booking.total,
    ];

    for (const candidate of candidates) {
        const value = Number(candidate);
        if (Number.isFinite(value) && value > 0) return value;
    }

    return 0;
}

function normalizeOrderItem(value: unknown): OrderItem {
    const raw = toRecord(value);
    return {
        name: readText(raw, ["name", "productName", "product_name"]),
        quantity: readNumber(raw, ["quantity", "qty"]),
        price: readNumber(raw, ["price", "unitPrice", "unit_price"]),
        unitPrice: readNumber(raw, ["unitPrice", "unit_price", "price"]),
        unit_price: readNumber(raw, ["unit_price", "unitPrice", "price"]),
        lineTotal: readNumber(raw, ["lineTotal", "line_total"]),
        line_total: readNumber(raw, ["line_total", "lineTotal"]),
        sellingPrice: readNumber(raw, ["sellingPrice", "selling_price"]),
        selling_price: readNumber(raw, ["selling_price", "sellingPrice"]),
        salesPrice: readNumber(raw, ["salesPrice", "sales_price"]),
        sales_price: readNumber(raw, ["sales_price", "salesPrice"]),
        costPrice: readNumber(raw, ["costPrice", "cost_price"]),
        cost_price: readNumber(raw, ["cost_price", "costPrice"]),
        originalPrice: readNumber(raw, ["originalPrice", "original_price"]),
        original_price: readNumber(raw, ["original_price", "originalPrice"]),
    };
}

function parseOrderItems(itemText?: string): OrderItem[] {
    if (!itemText) return [];
    return itemText
        .split(",")
        .map((item) => {
            const [name, qty] = item.split(" x");
            return { name: name?.trim() || "", quantity: Number(qty || 0) };
        })
        .filter((item) => item.name);
}

function normalizeOrder(value: unknown): Order {
    const raw = toRecord(value);
    const itemText = readText(raw, ["item"]);
    const rawItems = firstDefined(raw, ["items", "orderItems", "order_items"]);
    const items = Array.isArray(rawItems)
        ? rawItems.map(normalizeOrderItem).filter((item) => item.name)
        : parseOrderItems(itemText);

    return {
        branchId: readNullableNumber(raw, ["branchId", "branch_id"]),
        total: readNumber(raw, ["total"]),
        totalCost: readNullableNumber(raw, ["totalCost", "total_cost"]),
        profit: readNullableNumber(raw, ["profit"]),
        date: readText(raw, [
            "date",
            "orderDate",
            "order_date",
            "createdAt",
            "created_at",
        ]),
        createdAt: readText(raw, ["createdAt", "created_at"]),
        items,
        status: readText(raw, ["status", "order_status"]),
        orderType: readText(raw, ["orderType", "order_type", "type", "source"]),
    };
}

function normalizeInventoryProduct(value: unknown): InventoryProduct {
    const raw = toRecord(value);
    const rawVariants = firstDefined(raw, ["variants", "productVariants", "product_variants"]);

    const variants: InventoryVariant[] = Array.isArray(rawVariants)
        ? rawVariants.map((value) => {
            const variant = toRecord(value);
            const variantValues = firstDefined(variant, ["variantValues", "variant_values", "values"]);
            let parsedValues: Record<string, string> = {};
            if (variantValues && typeof variantValues === "object" && !Array.isArray(variantValues)) {
                parsedValues = variantValues as Record<string, string>;
            } else if (typeof variantValues === "string") {
                try {
                    const parsed = JSON.parse(variantValues);
                    if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
                        parsedValues = parsed as Record<string, string>;
                    }
                } catch {
                    parsedValues = {};
                }
            }

            return {
                id: readNumber(variant, ["id"]),
                name: readText(variant, ["name", "variantName", "variant_name"]),
                costPrice: readNullableNumber(variant, ["costPrice", "cost_price", "unitCost", "unit_cost"]) ?? undefined,
                cost_price: readNullableNumber(variant, ["cost_price", "costPrice", "unit_cost", "unitCost"]) ?? undefined,
                salesPrice: readNullableNumber(variant, ["salesPrice", "sales_price", "price"]) ?? undefined,
                sales_price: readNullableNumber(variant, ["sales_price", "salesPrice", "price"]) ?? undefined,
                variantValues: parsedValues,
                variant_values: parsedValues,
            };
        })
        : [];

    return {
        id: readNumber(raw, ["id", "product_id"]),
        branchId: readNullableNumber(raw, ["branchId", "branch_id"]),
        branch_id: readNullableNumber(raw, ["branch_id", "branchId"]),
        name: readText(raw, ["name", "productName", "product_name"]),
        costPrice: readNullableNumber(raw, ["costPrice", "cost_price", "unitCost", "unit_cost"]) ?? undefined,
        cost_price: readNullableNumber(raw, ["cost_price", "costPrice", "unit_cost", "unitCost"]) ?? undefined,
        salesPrice: readNullableNumber(raw, ["salesPrice", "sales_price", "price"]) ?? undefined,
        sales_price: readNullableNumber(raw, ["sales_price", "salesPrice", "price"]) ?? undefined,
        variants,
    };
}

function normalizePackageRecord(value: unknown): PackageRecord {
    const raw = toRecord(value);
    let rawInclusions: unknown[] = [];
    const source = firstDefined(raw, ["inclusions", "items", "packageItems", "package_items"]);

    if (Array.isArray(source)) {
        rawInclusions = source;
    } else if (typeof source === "string" && source.trim().startsWith("[")) {
        try { rawInclusions = JSON.parse(source) as unknown[]; } catch { rawInclusions = []; }
    }

    const inclusions = rawInclusions.map((item) => {
        if (typeof item === "string") return { name: item.trim(), quantity: 1 };
        const inc = toRecord(item);
        const productId = readNullableNumber(inc, ["productId", "product_id"]);
        const variantId = readNullableNumber(inc, ["variantId", "variant_id"]);
        return {
            name: readText(inc, ["name", "itemName", "item_name", "productName", "product_name", "item", "title"]),
            productId,
            product_id: productId,
            variantId,
            variant_id: variantId,
            quantity: Math.max(1, readNumber(inc, ["quantity", "qty", "itemQuantity", "item_quantity"], 1)),
            costPrice: readNullableNumber(inc, ["costPrice", "cost_price", "unitCost", "unit_cost"]) ?? undefined,
            cost_price: readNullableNumber(inc, ["cost_price", "costPrice", "unit_cost", "unitCost"]) ?? undefined,
        };
    }).filter((item) => item.name);

    return {
        id: firstDefined(raw, ["id", "packageId", "package_id"]) as string | number | undefined,
        name: readText(raw, ["name", "packageName", "package_name"]),
        branchId: readNullableNumber(raw, ["branchId", "branch_id"]),
        branch_id: readNullableNumber(raw, ["branch_id", "branchId"]),
        inclusions,
    };
}

function normalizeOwnerPosSummary(value: unknown): OwnerPosSummary {
    const raw = toRecord(value);

    const normalizeDaily = (source: unknown): OwnerPosDailyMetric[] =>
        Array.isArray(source)
            ? source.map((item) => {
                const row = toRecord(item);
                return {
                    date: readText(row, ["date"]),
                    sales: readNumber(row, ["sales"]),
                    cost: readNumber(row, ["cost"]),
                };
            }).filter((row) => row.date)
            : [];

    const normalizeBranchRows = (source: unknown): OwnerPosBranchRow[] =>
        Array.isArray(source)
            ? source.map((item) => {
                const row = toRecord(item);
                return {
                    key: readText(row, ["key"], "unassigned"),
                    name: readText(row, ["name"], "Unassigned"),
                    amount: readNumber(row, ["amount"]),
                };
            })
            : [];

    const normalizeTopRows = (source: unknown): OwnerPosTopProduct[] =>
        Array.isArray(source)
            ? source.map((item) => {
                const row = toRecord(item);
                return {
                    key: readText(row, ["key"]),
                    name: readText(row, ["name"], "Unnamed Product"),
                    sales: readNumber(row, ["sales"]),
                    units: readNumber(row, ["units"]),
                };
            }).filter((row) => row.name)
            : [];

    const branchPerformance = toRecord(raw.branchPerformance);
    const topProducts = toRecord(raw.topProducts);

    return {
        daily: normalizeDaily(raw.daily),
        branchPerformance: {
            month: normalizeBranchRows(branchPerformance.month),
            quarter: normalizeBranchRows(branchPerformance.quarter),
            year: normalizeBranchRows(branchPerformance.year),
        },
        topProducts: {
            month: normalizeTopRows(topProducts.month),
            quarter: normalizeTopRows(topProducts.quarter),
            year: normalizeTopRows(topProducts.year),
        },
    };
}

function normalizeName(value: string) {
    return String(value || "").trim().toLowerCase().replace(/\s+/g, " ");
}

function getInventoryCostForItem(
    itemName: string,
    branchId: number | null | undefined,
    products: InventoryProduct[],
) {
    const target = normalizeName(itemName);
    if (!target) return null;

    const candidates = products.filter((product) => {
        const sameName = normalizeName(product.name) === target;
        if (!sameName) return false;
        if (branchId === null || branchId === undefined) return true;
        const productBranchId = product.branchId ?? product.branch_id;
        return productBranchId === null || productBranchId === undefined || String(productBranchId) === String(branchId);
    });

    for (const product of candidates) {
        const directCost = Number(product.costPrice ?? product.cost_price);
        if (Number.isFinite(directCost) && directCost > 0) return directCost;

        const variantCosts = (product.variants || [])
            .map((variant) => Number(variant.costPrice ?? variant.cost_price))
            .filter((value) => Number.isFinite(value) && value > 0);
        if (variantCosts.length > 0) {
            return variantCosts.reduce((sum, value) => sum + value, 0) / variantCosts.length;
        }
    }

    return null;
}

function getPackageCost(
    booking: Booking,
    packages: PackageRecord[],
    products: InventoryProduct[],
) {
    // Preferred source: backend-calculated cost from the actual booking_items
    // rows. This supports package and custom bookings and uses product/variant
    // IDs instead of fragile product-name matching.
    if (booking.costOfSales !== null && booking.costOfSales !== undefined) {
        const directCost = Number(booking.costOfSales);
        if (Number.isFinite(directCost) && directCost >= 0) return directCost;
    }

    const packageName = normalizeName(booking.packageName || "");
    if (!packageName || isCustomDashboardBooking(booking)) return null;

    const matchingPackages = packages.filter((pkg) => {
        if (normalizeName(pkg.name) !== packageName) return false;
        const packageBranchId = pkg.branchId ?? pkg.branch_id;
        const bookingBranchId = booking.branchId;
        if (bookingBranchId === null || bookingBranchId === undefined || packageBranchId === null || packageBranchId === undefined) {
            return true;
        }
        return String(packageBranchId) === String(bookingBranchId);
    });

    const pkg = matchingPackages[0];
    if (!pkg || pkg.inclusions.length === 0) return null;

    let total = 0;
    for (const inclusion of pkg.inclusions) {
        const explicitCost = Number(inclusion.costPrice ?? inclusion.cost_price);
        let unitCost = Number.isFinite(explicitCost) && explicitCost > 0
            ? explicitCost
            : null;

        if (unitCost === null && inclusion.productId) {
            const product = products.find((candidate) =>
                Number(candidate.id) === Number(inclusion.productId) &&
                (candidate.branchId === null ||
                    candidate.branchId === undefined ||
                    booking.branchId === null ||
                    booking.branchId === undefined ||
                    String(candidate.branchId) === String(booking.branchId))
            );

            if (product) {
                const variantId = inclusion.variantId ?? inclusion.variant_id;
                const variant = variantId
                    ? (product.variants || []).find((candidate) => Number(candidate.id) === Number(variantId))
                    : undefined;
                unitCost = Number(variant?.costPrice ?? variant?.cost_price ?? product.costPrice ?? product.cost_price);
                if (!Number.isFinite(unitCost) || unitCost < 0) unitCost = null;
            }
        }

        if (unitCost === null) {
            unitCost = getInventoryCostForItem(inclusion.name, booking.branchId, products);
        }

        if (unitCost === null) return null;
        total += unitCost * Math.max(1, inclusion.quantity);
    }

    return total;
}

/* ----------------------------------------------------------------------- */
/* Date / period helpers                                                   */
/* ----------------------------------------------------------------------- */

function parseFlexibleDate(value?: string | null): Date | null {
    const raw = String(value || "").trim();
    if (!raw) return null;
    const parsed = new Date(raw);
    return Number.isNaN(parsed.getTime()) ? null : parsed;
}

function getOrderDate(order: Order) {
    return parseFlexibleDate(order.date) || parseFlexibleDate(order.createdAt);
}

function monthKey(date: Date) {
    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
}

function monthLabelWithYear(date: Date) {
    return date.toLocaleDateString("en-US", { month: "short", year: "numeric" });
}

function getLastNMonthBuckets(reference: Date, n: number) {
    const buckets: { key: string; date: Date; label: string }[] = [];
    for (let i = n - 1; i >= 0; i--) {
        const d = new Date(reference.getFullYear(), reference.getMonth() - i, 1);
        buckets.push({ key: monthKey(d), date: d, label: monthLabelWithYear(d) });
    }
    return buckets;
}

function getPeriodStart(period: PeriodOption, reference: Date) {
    if (period === "month") {
        return new Date(reference.getFullYear(), reference.getMonth(), 1);
    }
    if (period === "quarter") {
        const quarterStartMonth = Math.floor(reference.getMonth() / 3) * 3;
        return new Date(reference.getFullYear(), quarterStartMonth, 1);
    }
    return new Date(reference.getFullYear(), 0, 1);
}

function formatPeriodLabel(period: PeriodOption, reference: Date) {
    if (period === "month") {
        return reference.toLocaleDateString("en-US", { month: "long", year: "numeric" });
    }
    if (period === "quarter") {
        const quarter = Math.floor(reference.getMonth() / 3) + 1;
        return `Q${quarter} ${reference.getFullYear()}`;
    }
    return String(reference.getFullYear());
}

/* ----------------------------------------------------------------------- */
/* Core business logic                                                     */
/* ----------------------------------------------------------------------- */

const SCHEDULED_ORDER_TYPES = [
    "scheduled",
    "schedule",
    "scheduled-order",
    "future",
    "future-order",
    "advance-order",
    "pre-order",
    "preorder",
];

const EXCLUDED_ORDER_STATUSES = [
    "pending",
    "pending payment",
    "unpaid",
    "cancelled",
    "canceled",
    "refunded",
    "void",
    "draft",
    "failed",
];

function isPosSaleOrder(order: Order) {
    const type = String(order.orderType || "").trim().toLowerCase().replace(/_/g, "-");
    const status = String(order.status || "").trim().toLowerCase();
    return !SCHEDULED_ORDER_TYPES.includes(type) && !EXCLUDED_ORDER_STATUSES.includes(status);
}

function isRealizedBooking(booking: Booking) {
    const status = normalizeDashboardBookingStatus(booking.status);
    // Owner financial KPIs use realized/fulfilled revenue only. Confirmed
    // bookings remain pipeline, not completed sales.
    return status === "Completed";
}

type MonthlyPoint = {
    key: string;
    label: string;
    posSales: number;
    posCost: number;
    bookingSales: number;
    bookingCost: number;
    sales: number;
    cost: number;
    profit: number | null;
    uncostedSales: number;
    costCoveragePct: number;
};

function getOrderCost(order: Order): number | null {
    const backendCost = order.totalCost;
    if (backendCost !== null && backendCost !== undefined && Number.isFinite(backendCost)) {
        return Math.max(0, backendCost);
    }

    const itemCost = (order.items || []).reduce((sum, item) => {
        const quantity = Number(item.quantity || 0);
        const costPrice = Number(item.costPrice ?? item.cost_price ?? NaN);
        if (!Number.isFinite(quantity) || !Number.isFinite(costPrice)) return sum;
        return sum + Math.max(0, quantity) * Math.max(0, costPrice);
    }, 0);

    if (itemCost > 0) return itemCost;

    const revenue = Number(order.total || 0);
    const backendProfit = order.profit;
    if (backendProfit !== null && backendProfit !== undefined && Number.isFinite(backendProfit)) {
        return Math.max(0, revenue - backendProfit);
    }

    return null;
}

function getInventoryPortfolioCostRatio(products: InventoryProduct[]) {
    let weightedCost = 0;
    let weightedSales = 0;

    for (const product of products) {
        const variants = product.variants || [];
        if (variants.length > 0) {
            for (const variant of variants) {
                const cost = Number(variant.costPrice ?? variant.cost_price);
                const sales = Number(variant.salesPrice ?? variant.sales_price);
                if (Number.isFinite(cost) && cost >= 0 && Number.isFinite(sales) && sales > 0) {
                    weightedCost += cost;
                    weightedSales += sales;
                }
            }
            continue;
        }

        const cost = Number(product.costPrice ?? product.cost_price);
        const sales = Number(product.salesPrice ?? product.sales_price);
        if (Number.isFinite(cost) && cost >= 0 && Number.isFinite(sales) && sales > 0) {
            weightedCost += cost;
            weightedSales += sales;
        }
    }

    if (weightedSales <= 0) return 0.5;
    return Math.max(0.05, Math.min(0.95, weightedCost / weightedSales));
}

function buildOwnerAnalytics(
    posSummary: OwnerPosSummary,
    bookings: Booking[],
    packages: PackageRecord[],
    products: InventoryProduct[],
    monthsBack: number,
    reference: Date,
) {
    const buckets = getLastNMonthBuckets(reference, monthsBack).map((bucket) => ({
        ...bucket,
        posSales: 0,
        posCost: 0,
        bookingSales: 0,
        bookingCost: 0,
        uncostedSales: 0,
    }));
    const bucketByKey = new Map(buckets.map((bucket) => [bucket.key, bucket]));

    // POS data is already aggregated server-side. This keeps the browser from
    // downloading and reducing thousands of historical order/order-item rows.
    posSummary.daily.forEach((point) => {
        const date = parseFlexibleDate(point.date);
        if (!date) return;
        const bucket = bucketByKey.get(monthKey(date));
        if (!bucket) return;

        bucket.posSales += Math.max(0, Number(point.sales || 0));
        bucket.posCost += Math.max(0, Number(point.cost || 0));
    });

    bookings.filter(isRealizedBooking).forEach((booking) => {
        const date = parseFlexibleDate(booking.date);
        if (!date) return;
        const bucket = bucketByKey.get(monthKey(date));
        if (!bucket) return;

        const revenue = getDashboardBookingTotalPrice(booking);
        bucket.bookingSales += revenue;

        const cost = getPackageCost(booking, packages, products);
        if (cost !== null) bucket.bookingCost += cost;
        else bucket.uncostedSales += Math.max(0, revenue);
    });

    const costedSalesTotal = buckets.reduce(
        (sum, bucket) => sum + Math.max(0, bucket.posSales + bucket.bookingSales - bucket.uncostedSales),
        0,
    );
    const costedCostTotal = buckets.reduce(
        (sum, bucket) => sum + Math.max(0, bucket.posCost + bucket.bookingCost),
        0,
    );
    const portfolioCostRatio = costedSalesTotal > 0
        ? Math.max(0.05, Math.min(0.95, costedCostTotal / costedSalesTotal))
        : getInventoryPortfolioCostRatio(products);

    const monthly: MonthlyPoint[] = buckets.map((bucket) => {
        const sales = bucket.posSales + bucket.bookingSales;
        const cost = bucket.posCost + bucket.bookingCost;
        const costCoveragePct = sales > 0
            ? Math.max(0, Math.min(100, ((sales - bucket.uncostedSales) / sales) * 100))
            : 100;

        // Legacy booking rows without an item-level cost use the portfolio's
        // observed COGS ratio from costed sales. POS cost is already aggregated
        // from the same order-item/product cost sources used by the prior API.
        const fallbackCost = bucket.uncostedSales > 0
            ? bucket.uncostedSales * portfolioCostRatio
            : 0;
        const reportedCost = cost + fallbackCost;

        return {
            key: bucket.key,
            label: bucket.label,
            posSales: bucket.posSales,
            posCost: bucket.posCost,
            bookingSales: bucket.bookingSales,
            bookingCost: bucket.bookingCost,
            sales,
            cost: reportedCost,
            profit: sales - reportedCost,
            uncostedSales: bucket.uncostedSales,
            costCoveragePct,
        };
    });

    return { monthly, portfolioCostRatio };
}

function getMonthToDateMetrics(
    posSummary: OwnerPosSummary,
    bookings: Booking[],
    packages: PackageRecord[],
    products: InventoryProduct[],
    reference: Date,
    monthOffset: number,
    fallbackCostRatio = 0.5,
) {
    const targetMonth = new Date(reference.getFullYear(), reference.getMonth() - monthOffset, 1);
    const daysElapsed = reference.getDate();
    const monthStart = targetMonth;
    const monthEnd = new Date(
        targetMonth.getFullYear(),
        targetMonth.getMonth(),
        Math.min(daysElapsed, new Date(targetMonth.getFullYear(), targetMonth.getMonth() + 1, 0).getDate()) + 1,
    );

    let sales = 0;
    let cost = 0;
    let uncostedSales = 0;

    posSummary.daily.forEach((point) => {
        const date = parseFlexibleDate(point.date);
        if (!date || date < monthStart || date >= monthEnd) return;
        sales += Math.max(0, Number(point.sales || 0));
        cost += Math.max(0, Number(point.cost || 0));
    });

    bookings.filter(isRealizedBooking).forEach((booking) => {
        const date = parseFlexibleDate(booking.date);
        if (!date || date < monthStart || date >= monthEnd) return;
        const revenue = Math.max(0, getDashboardBookingTotalPrice(booking));
        sales += revenue;
        const bookingCost = getPackageCost(booking, packages, products);
        if (bookingCost === null) uncostedSales += revenue;
        else cost += bookingCost;
    });

    const costRatio = sales > 0 && uncostedSales < sales
        ? Math.max(0.05, Math.min(0.95, cost / Math.max(0.01, sales - uncostedSales)))
        : Math.max(0.05, Math.min(0.95, fallbackCostRatio));
    const reportedCost = cost + uncostedSales * costRatio;

    return {
        sales,
        cost: reportedCost,
        profit: sales - reportedCost,
        uncostedSales,
    };
}

function aggregateBranchPerformance(
    posSummary: OwnerPosSummary,
    bookings: Booking[],
    branches: Branch[],
    period: PeriodOption,
    reference: Date,
) {
    const start = getPeriodStart(period, reference);
    const end = new Date(reference.getFullYear(), reference.getMonth(), reference.getDate() + 1);
    const nameById = new Map(branches.map((branch) => [String(branch.id), branch.branchName]));
    const totals = new Map<string, number>();

    posSummary.branchPerformance[period].forEach((row) => {
        totals.set(row.key, (totals.get(row.key) || 0) + Number(row.amount || 0));
    });

    bookings.filter(isRealizedBooking).forEach((booking) => {
        const date = parseFlexibleDate(booking.date);
        if (!date || date < start || date >= end) return;
        const key = booking.branchId !== null && booking.branchId !== undefined ? String(booking.branchId) : "unassigned";
        totals.set(key, (totals.get(key) || 0) + getDashboardBookingTotalPrice(booking));
    });

    const backendNames = new Map(
        posSummary.branchPerformance[period].map((row) => [row.key, row.name]),
    );

    return Array.from(totals.entries())
        .map(([key, amount]) => ({
            key,
            name:
                key === "unassigned"
                    ? "Unassigned"
                    : backendNames.get(key) || nameById.get(key) || `Branch #${key}`,
            amount,
        }))
        .sort((a, b) => b.amount - a.amount);
}

type TopItemRow = { key: string; name: string; sales: number; units: number };

function aggregateTopItems(
    posSummary: OwnerPosSummary,
    bookings: Booking[],
    period: PeriodOption,
    reference: Date,
): TopItemRow[] {
    const start = getPeriodStart(period, reference);
    const end = new Date(reference.getFullYear(), reference.getMonth(), reference.getDate() + 1);
    const map = new Map<string, TopItemRow>();

    posSummary.topProducts[period].forEach((row) => {
        map.set(row.key, {
            key: row.key,
            name: row.name,
            sales: Number(row.sales || 0),
            units: Number(row.units || 0),
        });
    });

    bookings.filter(isRealizedBooking).forEach((booking) => {
        const date = parseFlexibleDate(booking.date);
        if (!date || date < start || date >= end) return;

        const name = (booking.packageName || (isCustomDashboardBooking(booking) ? "Custom Order" : "")).trim();
        if (!name) return;

        const key = `package:${name.toLowerCase()}`;
        const existing = map.get(key) || { key, name, sales: 0, units: 0 };
        existing.sales += getDashboardBookingTotalPrice(booking);
        existing.units += 1;
        map.set(key, existing);
    });

    return Array.from(map.values()).sort((a, b) => b.sales - a.sales);
}

function pctDelta(current: number, previous: number): number | null {
    if (!Number.isFinite(previous) || previous === 0) return null;
    return ((current - previous) / Math.abs(previous)) * 100;
}

function linearForecastNext(values: number[], stepsAhead = 1) {
    const n = values.length;
    if (n === 0) return 0;
    if (n === 1) return values[0];

    const meanX = (n - 1) / 2;
    const meanY = values.reduce((sum, v) => sum + v, 0) / n;

    let numerator = 0;
    let denominator = 0;
    values.forEach((value, index) => {
        numerator += (index - meanX) * (value - meanY);
        denominator += (index - meanX) ** 2;
    });

    const slope = denominator !== 0 ? numerator / denominator : 0;
    const intercept = meanY - slope * meanX;
    const targetIndex = n - 1 + Math.max(1, stepsAhead);
    return Math.max(0, slope * targetIndex + intercept);
}

function niceStep(value: number) {
    if (value <= 0) return 1;
    const exponent = Math.floor(Math.log10(value));
    const base = Math.pow(10, exponent);
    const fraction = value / base;
    let niceFraction = 10;
    if (fraction <= 1) niceFraction = 1;
    else if (fraction <= 2) niceFraction = 2;
    else if (fraction <= 5) niceFraction = 5;
    return niceFraction * base;
}

/* ----------------------------------------------------------------------- */
/* Main component                                                          */
/* ----------------------------------------------------------------------- */



/* ----------------------------------------------------------------------- */
/* Initial dashboard skeleton                                               */
/* ----------------------------------------------------------------------- */

function OwnerSkeletonBar({ className = "" }: { className?: string }) {
    return <div className={`rounded-full bg-[#ECE7F0] ${className}`} />;
}

function OwnerMetricSkeleton() {
    return (
        <div className="flex min-h-[126px] items-center gap-4 rounded-2xl border border-[#E9E0EF] bg-white px-5 py-4 shadow-sm">
            <div className="h-14 w-14 shrink-0 rounded-full bg-[#EEE9F4]" />
            <div className="min-w-0 flex-1">
                <OwnerSkeletonBar className="h-3 w-24" />
                <OwnerSkeletonBar className="mt-3 h-7 w-28" />
                <OwnerSkeletonBar className="mt-3 h-2.5 w-36 max-w-full" />
            </div>
        </div>
    );
}

function OwnerTrendSkeleton() {
    return (
        <div className="min-h-[330px] rounded-2xl border border-[#E9E0EF] bg-white p-4 shadow-sm">
            <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-2.5">
                    <div className="h-9 w-9 rounded-lg bg-[#EEE9F4]" />
                    <div>
                        <OwnerSkeletonBar className="h-3.5 w-44" />
                        <OwnerSkeletonBar className="mt-2 h-2.5 w-72 max-w-full" />
                    </div>
                </div>
                <div className="h-8 w-28 rounded-lg bg-[#F1EDF4]" />
            </div>
            <div className="relative mt-5 h-[215px] overflow-hidden rounded-xl">
                {[25, 70, 115, 160].map((top) => (
                    <div key={top} className="absolute left-10 right-3 h-px bg-[#F0EBF3]" style={{ top }} />
                ))}
                <svg viewBox="0 0 760 210" className="absolute inset-0 h-full w-full" aria-hidden="true">
                    <path d="M40 122 L105 102 L170 135 L235 145 L300 118 L365 120 L430 90 L495 122 L560 122 L625 130 L700 126" fill="none" stroke="#E2DCE8" strokeWidth="8" strokeLinecap="round" strokeLinejoin="round" />
                    <path d="M40 150 L105 136 L170 158 L235 163 L300 145 L365 146 L430 125 L495 145 L560 145 L625 151 L700 149" fill="none" stroke="#ECE6F0" strokeWidth="6" strokeLinecap="round" strokeLinejoin="round" />
                    <path d="M40 172 L105 158 L170 175 L235 179 L300 165 L365 166 L430 148 L495 164 L560 164 L625 168 L700 167" fill="none" stroke="#F1ECF4" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
                <div className="absolute bottom-1 left-10 right-3 flex justify-between">
                    {[0, 1, 2, 3, 4, 5, 6].map((item) => (
                        <div key={item} className="h-2 w-9 rounded-full bg-[#EEE9F2]" />
                    ))}
                </div>
            </div>
            <div className="mt-2 flex justify-center gap-6">
                {[0, 1, 2].map((item) => (
                    <div key={item} className="flex items-center gap-2">
                        <div className="h-2.5 w-2.5 rounded-full bg-[#E5DFEA]" />
                        <OwnerSkeletonBar className="h-2.5 w-16" />
                    </div>
                ))}
            </div>
        </div>
    );
}

function OwnerBranchSkeleton() {
    return (
        <div className="min-h-[330px] rounded-2xl border border-[#E9E0EF] bg-white p-4 shadow-sm">
            <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-2.5">
                    <div className="h-9 w-9 rounded-lg bg-[#EEE9F4]" />
                    <div>
                        <OwnerSkeletonBar className="h-3.5 w-32" />
                        <OwnerSkeletonBar className="mt-2 h-2.5 w-40" />
                    </div>
                </div>
                <div className="h-8 w-20 rounded-lg bg-[#F1EDF4]" />
            </div>
            <div className="mt-7 space-y-5">
                {[0, 1, 2, 3].map((item) => (
                    <div key={item}>
                        <div className="flex items-center justify-between gap-3">
                            <OwnerSkeletonBar className="h-2.5 w-28" />
                            <OwnerSkeletonBar className="h-3 w-16" />
                        </div>
                        <div className="mt-2 h-2 rounded-full bg-[#F2EEF5]">
                            <div className="h-full rounded-full bg-[#E3DCE9]" style={{ width: `${78 - item * 13}%` }} />
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
}

function OwnerTopItemsSkeleton() {
    return (
        <div className="min-h-[290px] rounded-2xl border border-[#E9E0EF] bg-white p-4 shadow-sm">
            <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-2.5">
                    <div className="h-9 w-9 rounded-lg bg-[#EEE9F4]" />
                    <div>
                        <OwnerSkeletonBar className="h-3.5 w-36" />
                        <OwnerSkeletonBar className="mt-2 h-2.5 w-44" />
                    </div>
                </div>
                <div className="h-8 w-20 rounded-lg bg-[#F1EDF4]" />
            </div>
            <div className="mt-5 divide-y divide-[#F2EDF4]">
                {[0, 1, 2, 3].map((item) => (
                    <div key={item} className="grid grid-cols-[32px_1fr_auto] items-center gap-3 py-3.5">
                        <div className="h-7 w-7 rounded-full bg-[#EEE9F4]" />
                        <div>
                            <OwnerSkeletonBar className="h-2.5 w-48 max-w-full" />
                            <OwnerSkeletonBar className="mt-2 h-2 w-24" />
                        </div>
                        <OwnerSkeletonBar className="h-3 w-16" />
                    </div>
                ))}
            </div>
        </div>
    );
}

function OwnerForecastSkeleton() {
    return (
        <div className="min-h-[290px] rounded-2xl border border-[#E9E0EF] bg-white p-4 shadow-sm">
            <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-2.5">
                    <div className="h-9 w-9 rounded-lg bg-[#EEE9F4]" />
                    <div>
                        <OwnerSkeletonBar className="h-3.5 w-28" />
                        <OwnerSkeletonBar className="mt-2 h-2.5 w-44" />
                    </div>
                </div>
                <OwnerSkeletonBar className="h-2.5 w-20" />
            </div>
            <div className="mt-7 rounded-xl border border-[#EFE8F3] bg-[#FBF9FC] p-4">
                <div className="flex items-start justify-between gap-4">
                    <div>
                        <OwnerSkeletonBar className="h-2.5 w-36" />
                        <OwnerSkeletonBar className="mt-3 h-7 w-32" />
                        <OwnerSkeletonBar className="mt-3 h-2.5 w-44" />
                    </div>
                    <div className="h-12 w-12 rounded-full bg-[#EEE9F4]" />
                </div>
            </div>
            <div className="mt-5 grid grid-cols-2 gap-3">
                {[0, 1].map((item) => (
                    <div key={item} className="rounded-xl bg-[#FAF8FC] p-3">
                        <OwnerSkeletonBar className="h-2.5 w-20" />
                        <OwnerSkeletonBar className="mt-3 h-4 w-24" />
                        <OwnerSkeletonBar className="mt-2 h-2 w-16" />
                    </div>
                ))}
            </div>
        </div>
    );
}

function OwnerDashboardSkeleton() {
    return (
        <div className="mx-auto max-w-none space-y-4 animate-pulse" role="status" aria-label="Loading owner dashboard">
            <span className="sr-only">Loading owner dashboard data</span>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4" aria-hidden="true">
                {[0, 1, 2, 3].map((item) => <OwnerMetricSkeleton key={item} />)}
            </div>
            <div className="grid grid-cols-1 gap-3 xl:grid-cols-3" aria-hidden="true">
                <div className="xl:col-span-2"><OwnerTrendSkeleton /></div>
                <OwnerBranchSkeleton />
            </div>
            <div className="grid grid-cols-1 gap-4 xl:grid-cols-[1.45fr_1fr]" aria-hidden="true">
                <OwnerTopItemsSkeleton />
                <OwnerForecastSkeleton />
            </div>
        </div>
    );
}

export default function OwnerDashboard() {
    const router = useRouter();
    const { user } = useCurrentUser();

    const [branches, setBranches] = useState<Branch[]>([]);
    const [bookings, setBookings] = useState<Booking[]>([]);
    const [posSummary, setPosSummary] = useState<OwnerPosSummary>(EMPTY_OWNER_POS_SUMMARY);
    const [inventoryProducts, setInventoryProducts] = useState<InventoryProduct[]>([]);
    const [packages, setPackages] = useState<PackageRecord[]>([]);
    const [loadError, setLoadError] = useState("");
    const [currentDateTime, setCurrentDateTime] = useState(() => new Date());
    const [isRefreshing, setIsRefreshing] = useState(false);
    const [hasLoadedDashboard, setHasLoadedDashboard] = useState(false);
    const loadInFlightRef = useRef(false);
    const posRefreshInFlightRef = useRef(false);

    const [trendRange, setTrendRange] = useState<TrendRange>(12);
    const [branchPeriod, setBranchPeriod] = useState<PeriodOption>("month");
    const [topPeriod, setTopPeriod] = useState<PeriodOption>("month");


    useEffect(() => {
        const timer = window.setInterval(() => {
            setCurrentDateTime(new Date());
        }, 30_000);

        return () => window.clearInterval(timer);
    }, []);

    async function loadOwnerDashboard({ silent = false }: { silent?: boolean } = {}) {
        const token = getSavedItem("token");
        const storeId =
            getUserValue(user, "store_id") ||
            getUserValue(user, "storeId") ||
            getSavedItem("store_id") ||
            getSavedItem("stocknbook_store_id");

        if (!token) {
            setLoadError("Unable to load the owner dashboard because no login token was found.");
            setHasLoadedDashboard(true);
            return;
        }

        // Prevent React Strict Mode/Fast Refresh from starting a duplicate copy
        // of the owner dashboard requests while one is in flight.
        if (loadInFlightRef.current) return;
        loadInFlightRef.current = true;

        if (!silent) setIsRefreshing(true);
        setLoadError("");

        try {
            /*
             * Load the independent dashboard sources at the same time. POS uses
             * a dashboard-specific aggregate action instead of downloading full
             * historical orders and order items into the browser. This preserves
             * the same KPI/chart behavior while drastically reducing server work,
             * JSON size, transfer time, and client-side aggregation.
             */
            const ordersDateFrom = formatDashboardIsoDate(
                new Date(
                    currentDateTime.getFullYear(),
                    currentDateTime.getMonth() - 12,
                    1,
                ),
            );
            const ordersDateTo = formatDashboardIsoDate(currentDateTime);

            const [branchesResult, bookingsResult, bookingCostsResult, posSummaryResult, productsResult, packagesResult] =
                await Promise.allSettled([
                    fetch("/api/branches", {
                        method: "GET",
                        headers: { Authorization: `Bearer ${token}` },
                        cache: "no-store",
                    }),
                    fetch("/api/bookings", {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json",
                            Authorization: `Bearer ${token}`,
                        },
                        body: JSON.stringify({
                            action: "get_booking_page_bookings",
                            role: "owner",
                            store_id: storeId ? Number(storeId) : undefined,
                            date_from: ordersDateFrom,
                            date_to: ordersDateTo,
                        }),
                        cache: "no-store",
                    }),
                    fetch("/api/bookings", {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json",
                            Authorization: `Bearer ${token}`,
                        },
                        body: JSON.stringify({
                            action: "get_booking_costs",
                            role: "owner",
                            store_id: storeId ? Number(storeId) : undefined,
                            date_from: ordersDateFrom,
                            date_to: ordersDateTo,
                        }),
                        cache: "no-store",
                    }),
                    fetch("/api/pos", {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json",
                            Authorization: `Bearer ${token}`,
                        },
                        body: JSON.stringify({
                            action: "get_owner_dashboard_summary",
                            date_from: ordersDateFrom,
                            date_to: ordersDateTo,
                        }),
                        cache: "no-store",
                    }),
                    fetch("/api/products", {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json",
                            Authorization: `Bearer ${token}`,
                        },
                        body: JSON.stringify({
                            action: "get_products",
                            include_variants: true,
                            store_id: storeId ? Number(storeId) : undefined,
                        }),
                        cache: "no-store",
                    }),
                    fetch("/api/packages", {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json",
                            Authorization: `Bearer ${token}`,
                        },
                        body: JSON.stringify({
                            action: "get_packages",
                            store_id: storeId ? Number(storeId) : undefined,
                        }),
                        cache: "no-store",
                    }),
                ]);

            // Start from the currently displayed data. If one endpoint fails,
            // keep its previous value instead of clearing the dashboard and
            // producing another misleading intermediate state.
            let nextBranches = branches;
            let nextBookings = bookings;
            let nextPosSummary = posSummary;
            let nextInventoryProducts = inventoryProducts;
            let nextPackages = packages;
            const errors: string[] = [];

            if (branchesResult.status === "fulfilled") {
                try {
                    const response = branchesResult.value;
                    const data = await response.json().catch(() => ({}));
                    if (response.ok && Array.isArray(data.branches)) {
                        nextBranches = (data.branches as unknown[]).map(normalizeBranch);
                    } else if (!response.ok) {
                        errors.push("Unable to load branch data.");
                    }
                } catch {
                    errors.push("Unable to parse branch data.");
                }
            } else {
                console.warn("Owner dashboard branches fetch failed:", branchesResult.reason);
                errors.push("Unable to load branch data.");
            }

            if (bookingsResult.status === "fulfilled") {
                try {
                    const response = bookingsResult.value;
                    const text = await response.text();
                    const data: { bookings?: unknown[]; error?: unknown; message?: unknown } =
                        text ? JSON.parse(text) : {};

                    if (response.ok && Array.isArray(data.bookings)) {
                        nextBookings = data.bookings.map(normalizeBooking);
                    } else if (!response.ok) {
                        errors.push(
                            String(data.error || data.message || "Unable to load booking data."),
                        );
                    }
                } catch (error) {
                    console.error("Owner dashboard bookings parse failed:", error);
                    errors.push("Unable to parse booking data.");
                }
            } else {
                console.error("Owner dashboard bookings fetch failed:", bookingsResult.reason);
                errors.push("Unable to load booking data.");
            }

            if (bookingCostsResult.status === "fulfilled") {
                try {
                    const response = bookingCostsResult.value;
                    const data = await response.json().catch(() => ({}));
                    if (response.ok && data.costs && typeof data.costs === "object") {
                        const costs = data.costs as Record<string, unknown>;
                        nextBookings = nextBookings.map((booking) => ({
                            ...booking,
                            costOfSales: Number.isFinite(Number(costs[String(booking.id)]))
                                ? Number(costs[String(booking.id)])
                                : booking.costOfSales ?? null,
                        }));
                    } else if (!response.ok) {
                        errors.push("Unable to load booking inventory cost data.");
                    }
                } catch {
                    errors.push("Unable to parse booking inventory cost data.");
                }
            } else {
                console.warn("Owner dashboard booking costs fetch failed:", bookingCostsResult.reason);
                errors.push("Unable to load booking inventory cost data.");
            }

            if (posSummaryResult.status === "fulfilled") {
                try {
                    const response = posSummaryResult.value;
                    const data = await response.json().catch(() => ({}));

                    if (response.ok && data?.summary && typeof data.summary === "object") {
                        nextPosSummary = normalizeOwnerPosSummary(data.summary);

                        if (data?.meta?.queryTimingsMs) {
                            console.info(
                                "Owner dashboard POS summary timings:",
                                data.meta.queryTimingsMs,
                            );
                        }
                    } else {
                        const backendMessage = String(
                            data?.error ||
                            data?.message ||
                            `POS dashboard summary returned HTTP ${response.status}.`,
                        );

                        console.error("Owner dashboard POS summary request failed:", {
                            status: response.status,
                            response: data,
                        });

                        errors.push(`Unable to load POS dashboard summary: ${backendMessage}`);
                    }
                } catch (error) {
                    console.error("Owner dashboard POS summary processing failed:", error);
                    errors.push(
                        error instanceof Error
                            ? `Unable to load POS dashboard summary: ${error.message}`
                            : "Unable to load POS dashboard summary.",
                    );
                }
            } else {
                console.warn("Owner dashboard POS summary fetch failed:", posSummaryResult.reason);
                errors.push(
                    posSummaryResult.reason instanceof Error
                        ? `Unable to load POS dashboard summary: ${posSummaryResult.reason.message}`
                        : "Unable to load POS dashboard summary.",
                );
            }

            if (productsResult.status === "fulfilled") {
                try {
                    const response = productsResult.value;
                    const data = await response.json().catch(() => ({}));
                    if (response.ok && Array.isArray(data.products)) {
                        nextInventoryProducts = (data.products as unknown[]).map(normalizeInventoryProduct);
                    } else if (!response.ok) {
                        errors.push("Unable to load live inventory cost data.");
                    }
                } catch {
                    errors.push("Unable to parse live inventory cost data.");
                }
            } else {
                console.warn("Owner dashboard products fetch failed:", productsResult.reason);
                errors.push("Unable to load live inventory cost data.");
            }

            if (packagesResult.status === "fulfilled") {
                try {
                    const response = packagesResult.value;
                    const data = await response.json().catch(() => ({}));
                    const rawPackages = Array.isArray(data.packages)
                        ? data.packages
                        : Array.isArray(data.data)
                            ? data.data
                            : Array.isArray(data.records)
                                ? data.records
                                : [];
                    if (response.ok && Array.isArray(rawPackages)) {
                        nextPackages = rawPackages.map(normalizePackageRecord);
                    } else if (!response.ok) {
                        errors.push("Unable to load package cost data.");
                    }
                } catch {
                    errors.push("Unable to parse package cost data.");
                }
            } else {
                console.warn("Owner dashboard packages fetch failed:", packagesResult.reason);
                errors.push("Unable to load package cost data.");
            }

            // React 18 batches these updates, so the UI changes from the old
            // complete snapshot to the new complete snapshot in one render.
            setBranches(nextBranches);
            setBookings(nextBookings);
            setPosSummary(nextPosSummary);
            setInventoryProducts(nextInventoryProducts);
            setPackages(nextPackages);
            setLoadError(errors.join(" "));
        } finally {
            loadInFlightRef.current = false;
            if (!silent) setIsRefreshing(false);
            setHasLoadedDashboard(true);
        }
    }

    async function refreshOwnerPosSummary() {
        if (posRefreshInFlightRef.current) return;

        const token = getSavedItem("token");
        if (!token) return;

        posRefreshInFlightRef.current = true;

        try {
            const now = new Date();
            const dateFrom = formatDashboardIsoDate(
                new Date(now.getFullYear(), now.getMonth() - 12, 1),
            );
            const dateTo = formatDashboardIsoDate(now);

            const response = await fetch("/api/pos", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${token}`,
                },
                body: JSON.stringify({
                    action: "get_owner_dashboard_summary",
                    date_from: dateFrom,
                    date_to: dateTo,
                }),
                cache: "no-store",
            });

            const data = await response.json().catch(() => ({}));

            if (response.ok && data?.summary && typeof data.summary === "object") {
                setPosSummary(normalizeOwnerPosSummary(data.summary));

                if (data?.meta?.queryTimingsMs) {
                    console.info(
                        "Owner POS near-real-time refresh timings:",
                        data.meta.queryTimingsMs,
                    );
                }
            }
        } catch (error) {
            // Keep the last successful POS snapshot. A transient background
            // refresh failure should never blank or interrupt the dashboard.
            console.warn("Owner POS background refresh failed:", error);
        } finally {
            posRefreshInFlightRef.current = false;
        }
    }

    useEffect(() => {
        // Initial load. The Refresh button still works exactly as before.
        void loadOwnerDashboard();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    useEffect(() => {
        /*
         * POS is the most time-sensitive Owner metric. Refresh only the compact
         * POS summary every 15 seconds instead of re-downloading bookings,
         * products, packages and branches at the same rate. Pause while the tab
         * is hidden and refresh once when the user comes back.
         */
        const refreshIfVisible = () => {
            if (document.visibilityState === "visible") {
                void refreshOwnerPosSummary();
            }
        };

        const posTimer = window.setInterval(refreshIfVisible, 15_000);
        document.addEventListener("visibilitychange", refreshIfVisible);

        return () => {
            window.clearInterval(posTimer);
            document.removeEventListener("visibilitychange", refreshIfVisible);
        };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    useEffect(() => {
        /*
         * Near-real-time dashboard refresh:
         * re-check the same authoritative APIs every 60 seconds while this page
         * remains open. This keeps KPI values, their data-aware tooltips, charts,
         * and the forecast current without adding WebSockets or changing the
         * existing backend/API contract.
         */
        const autoRefreshTimer = window.setInterval(() => {
            void loadOwnerDashboard({ silent: true });
        }, 60_000);

        return () => window.clearInterval(autoRefreshTimer);
        // Keep the timer closure aligned with the latest successfully displayed
        // snapshot so a partial API failure can still preserve existing data.
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [branches, bookings, user]);

    const referenceDateKey = currentDateTime.toDateString();

    const analytics = useMemo(
        () => buildOwnerAnalytics(posSummary, bookings, packages, inventoryProducts, 13, currentDateTime),
        // eslint-disable-next-line react-hooks/exhaustive-deps
        [posSummary, bookings, packages, inventoryProducts, referenceDateKey],
    );

    const branchRows = useMemo(
        () => aggregateBranchPerformance(posSummary, bookings, branches, branchPeriod, currentDateTime),
        // eslint-disable-next-line react-hooks/exhaustive-deps
        [posSummary, bookings, branches, branchPeriod, referenceDateKey],
    );

    const topItems = useMemo(
        () => aggregateTopItems(posSummary, bookings, topPeriod, currentDateTime),
        // eslint-disable-next-line react-hooks/exhaustive-deps
        [posSummary, bookings, topPeriod, referenceDateKey],
    );

    const monthly = analytics.monthly;
    const current = monthly[monthly.length - 1] || { sales: 0, posCost: 0, bookingSales: 0, bookingCost: 0, cost: 0, profit: null, posSales: 0, uncostedSales: 0, costCoveragePct: 100 };
    const previous = monthly[monthly.length - 2] || { sales: 0, posCost: 0, bookingSales: 0, bookingCost: 0, cost: 0, profit: null, posSales: 0, uncostedSales: 0, costCoveragePct: 100 };

    // Growth badges compare the same elapsed number of days against the prior month,
    // rather than comparing a partial current month with the previous full month.
    const currentMtd = getMonthToDateMetrics(
        posSummary,
        bookings,
        packages,
        inventoryProducts,
        currentDateTime,
        0,
        analytics.portfolioCostRatio,
    );
    const previousMtd = getMonthToDateMetrics(
        posSummary,
        bookings,
        packages,
        inventoryProducts,
        currentDateTime,
        1,
        analytics.portfolioCostRatio,
    );
    const deltaSales = pctDelta(currentMtd.sales, previousMtd.sales);
    const deltaCost = pctDelta(currentMtd.cost, previousMtd.cost);
    const deltaProfit = currentMtd.profit !== null && previousMtd.profit !== null
        ? pctDelta(currentMtd.profit, previousMtd.profit)
        : null;
    const trendChartData = monthly.slice(-trendRange).map((point) => ({
        label: point.label,
        sales: point.sales,
        cost: point.cost,
        profit: point.profit ?? 0,
    }));

    /*
     * Forecast stability:
     * Use only COMPLETED months so an in-progress month (for example, September 9)
     * does not look artificially weak simply because the month is not finished yet.
     * The 6-month history window is rolling, so when the calendar month changes,
     * the forecast basis and displayed month range move forward automatically.
     *
     * Because the newest completed month is one month behind the current month,
     * forecasting the NEXT calendar month is two monthly steps ahead of that
     * completed-history endpoint.
     */
    const completedMonthly = monthly.slice(0, -1);
    const recentCompletedMonthsForForecast = completedMonthly.slice(-6);
    const recentSalesForForecast = recentCompletedMonthsForForecast.map((point) => point.sales);

    const forecastHistoryStartLabel =
        recentCompletedMonthsForForecast[0]?.label || "";
    const forecastHistoryEndLabel =
        recentCompletedMonthsForForecast[recentCompletedMonthsForForecast.length - 1]?.label || "";
    const forecastHistoryRangeLabel =
        forecastHistoryStartLabel && forecastHistoryEndLabel
            ? `${forecastHistoryStartLabel} – ${forecastHistoryEndLabel}`
            : "Completed-month history";

    const predictedNextMonthSales = linearForecastNext(recentSalesForForecast, 2);

    const forecastBaseline =
        recentCompletedMonthsForForecast[recentCompletedMonthsForForecast.length - 1] ||
        previous;
    const forecastGrowthPct = pctDelta(predictedNextMonthSales, forecastBaseline.sales);

    const nextMonthDate = new Date(currentDateTime.getFullYear(), currentDateTime.getMonth() + 1, 1);
    const nextMonthFullLabel = nextMonthDate.toLocaleDateString("en-US", {
        month: "long",
        year: "numeric",
    });
    const forecastBaselineDate = new Date(
        currentDateTime.getFullYear(),
        currentDateTime.getMonth() - 1,
        1,
    );
    const forecastBaselineLabel = forecastBaselineDate.toLocaleDateString("en-US", {
        month: "long",
        year: "numeric",
    });

    const currentMonthLabel = currentDateTime.toLocaleDateString("en-US", {
        month: "long",
        year: "numeric",
    });

    const forecastInsight =
        forecastGrowthPct === null
            ? `Forecast basis: ${forecastHistoryRangeLabel}. Partial ${currentMonthLabel} is excluded because it is still in progress.`
            : `Using completed months ${forecastHistoryRangeLabel} and excluding partial ${currentMonthLabel}, ${nextMonthFullLabel} sales are projected at ${peso(
                Math.round(predictedNextMonthSales),
            )}, ${Math.abs(forecastGrowthPct).toFixed(1)}% ${
                forecastGrowthPct >= 0 ? "higher" : "lower"
            } than ${forecastBaselineLabel}.`;

    return (
        <>
            <header className="sticky top-0 z-20 border-b border-[#E9E0EF] bg-[#FFFDF8]/95 font-sans backdrop-blur">
                <div className="flex min-h-[88px] flex-wrap items-center justify-between gap-4 px-6 py-3">
                    <div className="min-w-0">
                        <h1 className="truncate text-[25px] font-bold tracking-[-0.02em] text-[#1A1220]">
                            Owner Dashboard
                        </h1>
                        <p className="mt-1 truncate text-[12px] text-[#7A6A84]">
                            Strategic business overview across all branches for {currentMonthLabel}.
                        </p>
                    </div>

                    <div className="flex shrink-0 items-center gap-2.5">
                        <span className="inline-flex h-[42px] items-center rounded-xl border border-[#E6DDF0] bg-white px-3.5 text-sm font-semibold text-[#2B174C] shadow-sm">
                            {formatCurrentDashboardDateTime(currentDateTime)}
                        </span>

                        <button
                            type="button"
                            onClick={() => void loadOwnerDashboard()}
                            disabled={isRefreshing}
                            aria-label="Refresh dashboard details"
                            title="Refresh dashboard details"
                            className="inline-flex h-[42px] items-center gap-2 rounded-xl bg-[#2B174C] px-4 text-sm font-semibold text-white shadow-sm transition hover:bg-[#1B0D31] disabled:cursor-not-allowed disabled:opacity-60"
                        >
                            <RefreshCw size={16} className={isRefreshing ? "animate-spin" : ""} />
                            {isRefreshing ? "Refreshing..." : "Refresh"}
                        </button>
                    </div>
                </div>
            </header>

            <section
                aria-busy={!hasLoadedDashboard || isRefreshing}
                className="px-6 py-5 font-sans"
            >
                {!hasLoadedDashboard ? <OwnerDashboardSkeleton /> : null}

                <div className={`mx-auto max-w-none space-y-4 ${!hasLoadedDashboard ? "hidden" : ""}`}>
                    {loadError && (
                        <div className="rounded-xl border border-[#F2C4C4] bg-[#FFF0F0] px-4 py-3 text-xs font-medium text-[#C32F2F]">
                            {loadError}
                        </div>
                    )}

                    {/* Owner KPI cards — same visual system as the existing dashboard reference */}
                    <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4">
                        <KpiCard
                            title="Total Sales"
                            value={peso(current.sales)}
                            delta={deltaSales}
                            info={`Current ${currentMonthLabel} realized sales: ${peso(current.sales)} = ${peso(current.posSales)} POS sales + ${peso(current.bookingSales)} completed booking revenue. ${
                                deltaSales === null
                                    ? "No prior-month comparison is available yet."
                                    : `${Math.abs(deltaSales).toFixed(1)}% ${deltaSales >= 0 ? "higher" : "lower"} than the same period last month.`
                            } Auto-updates every 60 seconds while this dashboard is open.`}
                            icon={<BarChart3 size={25} />}
                            iconBg="bg-[#F1EBFF]"
                            iconColor="text-[#6D35D4]"
                        />
                        <KpiCard
                            title="Cost of Sales"
                            value={peso(current.cost)}
                            delta={deltaCost}
                            inverseDelta
                            info={`Current ${currentMonthLabel} Cost of Sales is calculated from live inventory/product costs for POS items and the inventory costs of standard package inclusions used in realized bookings. ${
                                current.uncostedSales > 0
                                    ? `${peso(current.uncostedSales)} of realized sales still has no resolvable inventory cost, so the dashboard does not fabricate a cost value.`
                                    : `${peso(current.cost)} is the total recorded product cost supporting this month's realized sales.`
                            }`}
                            icon={<Wallet size={25} />}
                            iconBg="bg-[#FFF0E5]"
                            iconColor="text-[#E66B20]"
                        />
                        <KpiCard
                            title="Gross Profit"
                            value={peso(current.profit ?? 0)}
                            delta={deltaProfit}
                            info={`Gross Profit = Total Sales − Cost of Sales. Current cost coverage is ${current.costCoveragePct.toFixed(1)}%. ${
                                `This month: ${peso(current.sales)} Total Sales − ${peso(current.cost)} Cost of Sales = ${peso(current.profit ?? 0)} Gross Profit.`
                            } Operating expenses are not deducted from Gross Profit.`}
                            icon={<TrendingUp size={25} />}
                            iconBg="bg-[#E6F7EE]"
                            iconColor="text-[#159455]"
                        />
                        <KpiCard
                            title="Forecasted Sales"
                            value={peso(Math.round(predictedNextMonthSales))}
                            delta={forecastGrowthPct}
                            comparisonText="vs last completed month"
                            info={`Projected ${nextMonthFullLabel} sales: ${peso(Math.round(predictedNextMonthSales))}. ${
                                forecastGrowthPct === null
                                    ? "No percentage comparison is available yet."
                                    : `${Math.abs(forecastGrowthPct).toFixed(1)}% ${forecastGrowthPct >= 0 ? "above" : "below"} ${forecastBaselineLabel} sales (${peso(forecastBaseline.sales)}).`
                            } Forecast basis: ${forecastHistoryRangeLabel}. Partial ${currentMonthLabel} is excluded to avoid incomplete-month bias. Linear-trend projection only; data updates every 60 seconds and the month range rolls forward automatically.`}
                            infoAlign="right"
                            icon={<BarChart3 size={25} />}
                            iconBg="bg-[#E6F7EE]"
                            iconColor="text-[#159455]"
                        />
                    </div>

                    {/* Trend chart + branch performance */}
                    <div className="grid grid-cols-1 gap-3 xl:grid-cols-3">
                        <div className="rounded-2xl border border-[#E9E0EF] bg-white p-4 shadow-sm xl:col-span-2">
                            <div className="flex flex-wrap items-center justify-between gap-3">
                                <div className="flex items-center gap-2.5">
                                    <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-[#F1EBFF] text-[#6D35D4]">
                                        <BarChart3 size={18} />
                                    </span>
                                    <div>
                                        <h3 className="text-[15px] font-bold text-[#1A1220]">Sales, Cost &amp; Gross Profit Trend</h3>
                                        <p className="text-[11px] text-[#9A8DA8]">
                                            Monthly realized sales, inventory cost of sales, and gross profit across all branches
                                        </p>
                                    </div>
                                </div>

                                <select
                                    value={trendRange}
                                    onChange={(event) => setTrendRange(Number(event.target.value) as TrendRange)}
                                    className="h-8 rounded-lg border border-[#E6DDF0] bg-white px-2.5 text-xs font-semibold text-[#5F4E75] shadow-sm focus:outline-none focus:ring-2 focus:ring-[#D9C6F5]"
                                >
                                    <option value={6}>Last 6 Months</option>
                                    <option value={12}>Last 12 Months</option>
                                </select>
                            </div>

                            <div className="mt-2">
                                <SalesTrendChart data={trendChartData} />
                            </div>

                            <div className="mt-1 flex flex-wrap items-center justify-center gap-6 text-[10px] font-semibold text-[#5F4E75]">
                                <span className="inline-flex items-center gap-1.5">
                                    <span className="h-2.5 w-2.5 rounded-full bg-[#6D35D4]" />
                                    Total Sales
                                </span>
                                <span className="inline-flex items-center gap-1.5">
                                    <span className="h-2.5 w-2.5 rounded-full bg-[#E66B20]" />
                                    Cost of Sales
                                </span>
                                <span className="inline-flex items-center gap-1.5">
                                    <span className="h-2.5 w-2.5 rounded-full bg-[#159455]" />
                                    Gross Profit
                                </span>
                            </div>
                        </div>

                        <BranchPerformancePanel
                            rows={branchRows}
                            period={branchPeriod}
                            onPeriodChange={setBranchPeriod}
                            periodLabel={formatPeriodLabel(branchPeriod, currentDateTime)}
                        />
                    </div>

                    {/* Clean summary area — top products + forecast */}
                    <div className="grid grid-cols-[1.45fr_1fr] items-stretch gap-4">
                        <TopProductsPanel
                            rows={topItems}
                            period={topPeriod}
                            onPeriodChange={setTopPeriod}
                            onViewAll={() => router.push("/reports")}
                        />

                        <DemandForecastPanel
                            nextMonthLabel={nextMonthFullLabel}
                            currentMonthLabel={currentMonthLabel}
                            comparisonMonthLabel={forecastBaselineLabel}
                            predicted={predictedNextMonthSales}
                            comparisonSales={forecastBaseline.sales}
                            growthPct={forecastGrowthPct}
                            historyMonths={recentSalesForForecast.length}
                            historyRangeLabel={forecastHistoryRangeLabel}
                            insight={forecastInsight}
                        />
                    </div>
                </div>
            </section>
        </>
    );
}


/* ----------------------------------------------------------------------- */
/* Presentational components                                               */
/* ----------------------------------------------------------------------- */

function KpiCard({
                     title,
                     value,
                     delta,
                     deltaSuffix = "%",
                     comparisonText = "vs last month",
                     info,
                     infoAlign = "center",
                     inverseDelta = false,
                     icon,
                     iconBg,
                     iconColor,
                 }: {
    title: string;
    value: string;
    delta: number | null;
    deltaSuffix?: string;
    comparisonText?: string;
    info?: string;
    infoAlign?: "center" | "right";
    inverseDelta?: boolean;
    icon: React.ReactNode;
    iconBg: string;
    iconColor: string;
}) {
    const isUp = delta !== null && (inverseDelta ? delta <= 0 : delta >= 0);
    const tooltipPositionClass =
        infoAlign === "right"
            ? "right-0"
            : "left-1/2 -translate-x-1/2";
    const tooltipArrowClass =
        infoAlign === "right"
            ? "right-[5px]"
            : "left-1/2 -translate-x-1/2";

    return (
        <div className="flex min-h-[116px] items-center gap-4 rounded-[16px] border border-[#E6DDF0] bg-white px-5 py-4 shadow-sm">
            <span
                className={`flex h-14 w-14 shrink-0 items-center justify-center rounded-full ${iconBg} ${iconColor}`}
            >
                {icon}
            </span>

            <div className="min-w-0 flex-1">
                <div className="flex items-center gap-1.5">
                    <p className="text-[14px] font-semibold leading-5 text-[#4B3E55]">
                        {title}
                    </p>

                    {info && (
                        <span className="group relative inline-flex shrink-0">
                            <button
                                type="button"
                                aria-label={`${title} information`}
                                className="inline-flex h-[18px] w-[18px] items-center justify-center rounded-full border border-[#D9CDE7] bg-[#FAF7FF] text-[#6D35D4] transition hover:border-[#BCA7DB] hover:bg-[#F1EBFF] focus:outline-none focus:ring-2 focus:ring-[#D9C6F5]"
                            >
                                <Info size={11} strokeWidth={2.2} />
                            </button>

                            <span
                                role="tooltip"
                                className={`pointer-events-none absolute top-full z-40 mt-2 hidden w-[280px] max-w-[calc(100vw-2rem)] rounded-lg border border-[#E5DAEE] bg-[#2B174C] px-3 py-2 text-[11px] font-medium leading-4 text-white shadow-lg group-hover:block group-focus-within:block ${tooltipPositionClass}`}
                            >
                                {info}
                                <span
                                    className={`absolute bottom-full h-0 w-0 border-x-[5px] border-b-[5px] border-x-transparent border-b-[#2B174C] ${tooltipArrowClass}`}
                                />
                            </span>
                        </span>
                    )}
                </div>

                <p className="mt-2 truncate text-[25px] font-bold leading-none tracking-[-0.03em] text-[#1A1220]">
                    {value}
                </p>

                {delta === null ? (
                    <p className="mt-2 text-[12px] font-medium leading-4 text-[#8A7D92]">
                        No prior month to compare
                    </p>
                ) : (
                    <p
                        className={`mt-2 flex items-center gap-1 text-[12px] font-semibold leading-4 ${
                            isUp ? "text-[#159455]" : "text-[#D92D20]"
                        }`}
                    >
                        {isUp ? <TrendingUp size={13} /> : <TrendingDown size={13} />}
                        {isUp ? "+" : ""}
                        {delta.toFixed(1)}
                        {deltaSuffix} {comparisonText}
                    </p>
                )}
            </div>
        </div>
    );
}

function SalesTrendChart({ data }: { data: { label: string; sales: number; cost: number; profit: number }[] }) {
    const width = 960;
    const height = 245;
    const margin = { top: 14, right: 16, bottom: 32, left: 58 };
    const innerW = width - margin.left - margin.right;
    const innerH = height - margin.top - margin.bottom;

    if (data.length === 0) {
        return (
            <div className="flex h-[205px] items-center justify-center text-sm text-[#9A8DA8]">
                No sales history yet. Once orders and bookings come in, this trend will populate automatically.
            </div>
        );
    }

    const maxRaw = Math.max(1, ...data.map((d) => d.sales), ...data.map((d) => d.cost), ...data.map((d) => d.profit));
    const step = niceStep(maxRaw / 5);
    const axisMax = step * 5;
    const ticks = [0, 1, 2, 3, 4, 5].map((i) => step * i);

    const xFor = (index: number) =>
        margin.left + (data.length > 1 ? (index / (data.length - 1)) * innerW : innerW / 2);
    const yFor = (value: number) => margin.top + innerH - (axisMax > 0 ? (value / axisMax) * innerH : 0);

    const salesPoints = data.map((d, index) => ({ x: xFor(index), y: yFor(d.sales) }));
    const costPoints = data.map((d, index) => ({ x: xFor(index), y: yFor(d.cost) }));
    const profitPoints = data.map((d, index) => ({ x: xFor(index), y: yFor(d.profit) }));

    const linePath = (points: { x: number; y: number }[]) =>
        points.map((p, i) => `${i === 0 ? "M" : "L"}${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(" ");

    const areaPath = (points: { x: number; y: number }[]) => {
        const baseline = margin.top + innerH;
        return `${linePath(points)} L${points[points.length - 1].x.toFixed(1)},${baseline.toFixed(
            1,
        )} L${points[0].x.toFixed(1)},${baseline.toFixed(1)} Z`;
    };

    return (
        <svg viewBox={`0 0 ${width} ${height}`} className="w-full" role="img" aria-label="Total sales, cost of sales, and gross profit trend chart">
            <defs>
                <linearGradient id="ownerSalesFill" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#6D35D4" stopOpacity="0.16" />
                    <stop offset="100%" stopColor="#6D35D4" stopOpacity="0" />
                </linearGradient>
                <linearGradient id="ownerProfitFill" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#159455" stopOpacity="0.12" />
                    <stop offset="100%" stopColor="#159455" stopOpacity="0" />
                </linearGradient>
            </defs>

            {ticks.map((tick) => (
                <g key={tick}>
                    <line
                        x1={margin.left}
                        x2={width - margin.right}
                        y1={yFor(tick)}
                        y2={yFor(tick)}
                        stroke="#EEE7F5"
                        strokeWidth={1}
                    />
                    <text x={margin.left - 10} y={yFor(tick) + 4} textAnchor="end" fontSize="10" fill="#9A8DA8">
                        {pesoCompact(tick)}
                    </text>
                </g>
            ))}

            <path d={areaPath(salesPoints)} fill="url(#ownerSalesFill)" stroke="none" />
            <path d={areaPath(profitPoints)} fill="url(#ownerProfitFill)" stroke="none" />
            <path
                d={linePath(salesPoints)}
                fill="none"
                stroke="#6D35D4"
                strokeWidth={2.5}
                strokeLinecap="round"
                strokeLinejoin="round"
            />
            <path
                d={linePath(costPoints)}
                fill="none"
                stroke="#E66B20"
                strokeWidth={2.2}
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeDasharray="5 4"
            />
            <path
                d={linePath(profitPoints)}
                fill="none"
                stroke="#159455"
                strokeWidth={2.5}
                strokeLinecap="round"
                strokeLinejoin="round"
            />

            {salesPoints.map((p, i) => (
                <circle key={`sales-${i}`} cx={p.x} cy={p.y} r={3} fill="#6D35D4" />
            ))}
            {costPoints.map((p, i) => (
                <circle key={`cost-${i}`} cx={p.x} cy={p.y} r={2.5} fill="#E66B20" />
            ))}
            {profitPoints.map((p, i) => (
                <circle key={`profit-${i}`} cx={p.x} cy={p.y} r={3} fill="#159455" />
            ))}

            {data.map((point, index) => (
                <text
                    key={point.label + index}
                    x={xFor(index)}
                    y={height - 12}
                    textAnchor="middle"
                    fontSize="9.5"
                    fill="#9A8DA8"
                >
                    {point.label}
                </text>
            ))}
        </svg>
    );
}

function BranchPerformancePanel({
                                    rows,
                                    period,
                                    onPeriodChange,
                                    periodLabel,
                                }: {
    rows: { key: string; name: string; amount: number }[];
    period: PeriodOption;
    onPeriodChange: (period: PeriodOption) => void;
    periodLabel: string;
}) {
    const visible = rows.slice(0, 6);
    const width = 440;
    const height = 260;
    const margin = { top: 30, right: 20, bottom: 78, left: 54 };

    const chartBranchLabel = (name: string) => {
        const compact = String(name || "")
            .trim()
            .replace(/\s+Retail\s+Branch$/i, "")
            .replace(/\s+Retail$/i, "")
            .trim();

        return compact || name;
    };
    const innerW = width - margin.left - margin.right;
    const innerH = height - margin.top - margin.bottom;
    const maxRaw = Math.max(1, ...visible.map((row) => row.amount));
    const step = niceStep(maxRaw / 4);
    const axisMax = step * 4;
    const ticks = [0, 1, 2, 3, 4].map((index) => step * index);
    const slotWidth = visible.length > 0 ? innerW / visible.length : innerW;
    const barWidth = Math.min(56, Math.max(28, slotWidth * 0.52));
    const yFor = (value: number) =>
        margin.top + innerH - (axisMax > 0 ? (Math.max(0, value) / axisMax) * innerH : 0);

    return (
        <div className="h-full rounded-2xl border border-[#E9E0EF] bg-white p-4 shadow-sm">
            <div className="flex items-center justify-between gap-3">
                <div className="flex min-w-0 items-center gap-2.5">
                    <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-[#EAF1FF] text-[#2563EB]">
                        <Building2 size={18} />
                    </span>
                    <div className="min-w-0">
                        <h3 className="truncate text-[15px] font-bold text-[#1A1220]">Branch Performance</h3>
                        <p className="truncate text-[11px] text-[#9A8DA8]">Total sales per branch for {periodLabel}</p>
                    </div>
                </div>

                <select
                    value={period}
                    onChange={(event) => onPeriodChange(event.target.value as PeriodOption)}
                    className="h-8 shrink-0 rounded-lg border border-[#E6DDF0] bg-white px-2.5 text-xs font-semibold text-[#5F4E75] shadow-sm focus:outline-none focus:ring-2 focus:ring-[#D9C6F5]"
                >
                    <option value="month">This Month</option>
                    <option value="quarter">This Quarter</option>
                    <option value="year">This Year</option>
                </select>
            </div>

            {visible.length === 0 ? (
                <div className="flex min-h-[245px] items-center justify-center text-sm text-[#9A8DA8]">
                    No branch sales recorded for this period yet.
                </div>
            ) : (
                <div className="mt-3">
                    <svg
                        viewBox={`0 0 ${width} ${height}`}
                        className="w-full"
                        role="img"
                        aria-label={`Branch sales bar chart for ${periodLabel}`}
                    >
                        <defs>
                            <linearGradient id="branchBarFill" x1="0" y1="0" x2="0" y2="1">
                                <stop offset="0%" stopColor="#7C45E8" />
                                <stop offset="100%" stopColor="#5C2BC5" />
                            </linearGradient>
                            <filter id="branchBarShadow" x="-20%" y="-20%" width="140%" height="160%">
                                <feDropShadow dx="0" dy="3" stdDeviation="3" floodColor="#6D35D4" floodOpacity="0.16" />
                            </filter>
                        </defs>

                        {ticks.map((tick) => (
                            <g key={tick}>
                                <line
                                    x1={margin.left}
                                    x2={width - margin.right}
                                    y1={yFor(tick)}
                                    y2={yFor(tick)}
                                    stroke="#EEE7F5"
                                    strokeWidth={1}
                                />
                                <text
                                    x={margin.left - 9}
                                    y={yFor(tick) + 4}
                                    textAnchor="end"
                                    fontSize="9.5"
                                    fill="#9A8DA8"
                                >
                                    {pesoCompact(tick)}
                                </text>
                            </g>
                        ))}

                        {visible.map((row, index) => {
                            const x = margin.left + index * slotWidth + (slotWidth - barWidth) / 2;
                            const y = yFor(row.amount);
                            const barHeight = margin.top + innerH - y;

                            return (
                                <g key={row.key}>
                                    <title>{`${row.name}: ${peso(row.amount)}`}</title>
                                    <rect
                                        x={x}
                                        y={y}
                                        width={barWidth}
                                        height={Math.max(2, barHeight)}
                                        rx={7}
                                        fill="url(#branchBarFill)"
                                        filter="url(#branchBarShadow)"
                                    />
                                    <text
                                        x={x + barWidth / 2}
                                        y={Math.max(14, y - 7)}
                                        textAnchor="middle"
                                        fontSize="9.5"
                                        fontWeight="700"
                                        fill="#1A1220"
                                    >
                                        {pesoCompact(row.amount)}
                                    </text>
                                    <text
                                        x={x + barWidth / 2}
                                        y={height - 48}
                                        textAnchor="middle"
                                        fontSize="10"
                                        fontWeight="700"
                                        fill="#5F4E75"
                                        stroke="#FFFFFF"
                                        strokeWidth="1.6"
                                        paintOrder="stroke"
                                        transform={`rotate(-30 ${x + barWidth / 2} ${height - 48})`}
                                    >
                                        {chartBranchLabel(row.name)}
                                    </text>
                                </g>
                            );
                        })}
                    </svg>
                </div>
            )}
        </div>
    );
}

function TopProductsPanel({
                              rows,
                              period,
                              onPeriodChange,
                              onViewAll,
                          }: {
    rows: TopItemRow[];
    period: PeriodOption;
    onPeriodChange: (period: PeriodOption) => void;
    onViewAll: () => void;
}) {
    const top = rows.slice(0, 5);
    const hasMore = rows.length > 5;
    const chartColors = ["#6D35D4", "#2563EB", "#159455", "#F59E0B", "#EC4899"];
    const total = top.reduce((sum, row) => sum + Math.max(0, row.sales), 0);

    const radius = 48;
    const center = 60;
    let accumulated = 0;

    const polar = (angle: number) => {
        const radians = ((angle - 90) * Math.PI) / 180;
        return {
            x: center + radius * Math.cos(radians),
            y: center + radius * Math.sin(radians),
        };
    };

    const piePath = (value: number, offset: number) => {
        if (total <= 0 || value <= 0) return "";
        const startAngle = (offset / total) * 360;
        const endAngle = ((offset + value) / total) * 360;
        const startPoint = polar(startAngle);
        const endPoint = polar(endAngle);
        const largeArc = endAngle - startAngle > 180 ? 1 : 0;

        return [
            `M ${center} ${center}`,
            `L ${startPoint.x} ${startPoint.y}`,
            `A ${radius} ${radius} 0 ${largeArc} 1 ${endPoint.x} ${endPoint.y}`,
            "Z",
        ].join(" ");
    };

    return (
        <div className="flex h-full min-w-0 flex-col rounded-2xl border border-[#E9E0EF] bg-white p-4 shadow-sm">
            <div className="flex items-center justify-between gap-3">
                <div className="flex min-w-0 items-center gap-3">
                    <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-[#F1EBFF] text-[#6D35D4]">
                        <Trophy size={17} />
                    </span>
                    <div className="min-w-0">
                        <h3 className="truncate text-[14px] font-bold leading-5 text-[#1A1220]">
                            Top Products / Packages
                        </h3>
                        <p className="truncate text-[10px] leading-4 text-[#9A8DA8]">
                            Best-performing items by sales amount
                        </p>
                    </div>
                </div>

                <select
                    value={period}
                    onChange={(event) => onPeriodChange(event.target.value as PeriodOption)}
                    className="h-8 shrink-0 rounded-lg border border-[#E6DDF0] bg-white px-2.5 text-xs font-semibold text-[#5F4E75] shadow-sm focus:outline-none focus:ring-2 focus:ring-[#D9C6F5]"
                >
                    <option value="month">This Month</option>
                    <option value="quarter">This Quarter</option>
                    <option value="year">This Year</option>
                </select>
            </div>

            {top.length === 0 ? (
                <div className="flex flex-1 min-h-[220px] items-center justify-center text-[11px] font-medium text-[#9A8DA8]">
                    No sales recorded for this period yet.
                </div>
            ) : (
                <div className="mt-4 flex flex-1 items-center gap-6">
                    <div className="relative h-[190px] w-[190px] shrink-0">
                        <svg viewBox="0 0 120 120" className="h-full w-full" role="img" aria-label="Top products by sales">
                            {top.map((row, index) => {
                                const value = Math.max(0, row.sales);
                                const path = piePath(value, accumulated);
                                accumulated += value;

                                return (
                                    <path
                                        key={row.key}
                                        d={path}
                                        fill={chartColors[index]}
                                        stroke="#FFFFFF"
                                        strokeWidth="1.5"
                                    />
                                );
                            })}
                        </svg>

                        <div className="absolute inset-[25%] flex flex-col items-center justify-center rounded-full bg-white text-center">
                            <span className="text-[19px] font-bold leading-none tracking-[-0.04em] text-[#1A1220]">
                                {pesoCompact(total)}
                            </span>
                            <span className="mt-1 text-[9px] font-medium text-[#8A7D92]">
                                Top 5 sales
                            </span>
                        </div>
                    </div>

                    <div className="min-w-0 flex-1 space-y-3">
                        {top.map((row, index) => {
                            const share = total > 0 ? (Math.max(0, row.sales) / total) * 100 : 0;

                            return (
                                <div key={row.key} className="min-w-0">
                                    <div className="flex items-center gap-2.5">
                                        <span
                                            className="h-2.5 w-2.5 shrink-0 rounded-full"
                                            style={{ backgroundColor: chartColors[index] }}
                                        />
                                        <div className="min-w-0 flex-1">
                                            <div className="flex items-center justify-between gap-2">
                                                <span
                                                    className="truncate text-[10px] font-semibold text-[#2A1B33]"
                                                    title={row.name}
                                                >
                                                    {index + 1}. {row.name}
                                                </span>
                                                <span className="shrink-0 text-[10px] font-bold text-[#1A1220]">
                                                    {peso(row.sales)}
                                                </span>
                                            </div>
                                            <div className="mt-1 h-1 rounded-full bg-[#F1ECF6]">
                                                <div
                                                    className="h-full rounded-full"
                                                    style={{
                                                        width: `${Math.max(2, Math.min(100, share))}%`,
                                                        backgroundColor: chartColors[index],
                                                    }}
                                                />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                </div>
            )}

            {(top.length > 0 || hasMore) && (
                <button
                    type="button"
                    onClick={onViewAll}
                    className="mt-3 text-[10px] font-semibold text-[#6D35D4] transition hover:text-[#4E24A8]"
                >
                    View full sales report →
                </button>
            )}
        </div>
    );
}

function DemandForecastPanel({
                                 nextMonthLabel,
                                 currentMonthLabel,
                                 comparisonMonthLabel,
                                 predicted,
                                 comparisonSales,
                                 growthPct,
                                 historyMonths,
                                 historyRangeLabel,
                                 insight,
                             }: {
    nextMonthLabel: string;
    currentMonthLabel: string;
    comparisonMonthLabel: string;
    predicted: number;
    comparisonSales: number;
    growthPct: number | null;
    historyMonths: number;
    historyRangeLabel: string;
    insight: string;
}) {
    const hasComparison = growthPct !== null;
    const isUp = hasComparison && growthPct >= 0;

    const forecastTone = !hasComparison
        ? {
            container: "border border-[#DDE5F2] bg-[#F5F8FC]",
            icon: "bg-white text-[#64748B]",
            amount: "text-[#334155]",
            direction: "text-[#64748B]",
            label: "Trend projection",
        }
        : isUp
            ? {
                container: "border border-[#CFEBDD] bg-[#EAF8F1]",
                icon: "bg-[#D8F2E5] text-[#159455]",
                amount: "text-[#0E7B47]",
                direction: "text-[#159455]",
                label: "Higher sales projected",
            }
            : {
                container: "border border-[#F4D2D2] bg-[#FFF2F2]",
                icon: "bg-[#FDE2E2] text-[#D92D20]",
                amount: "text-[#B42318]",
                direction: "text-[#D92D20]",
                label: "Lower sales projected",
            };

    return (
        <div className="flex h-full min-w-0 flex-col rounded-2xl border border-[#E9E0EF] bg-white p-4 shadow-sm">
            <div className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-2.5">
                    <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-[#EAF1FF] text-[#2563EB]">
                        <Sparkles size={17} />
                    </span>
                    <div className="min-w-0">
                        <h3 className="text-[14px] font-bold leading-5 text-[#1A1220]">Sales Forecast</h3>
                        <p className="text-[10px] leading-4 text-[#9A8DA8]">
                            Next-month sales projection for {nextMonthLabel}
                        </p>
                    </div>
                </div>

                <span className={`shrink-0 rounded-full px-2 py-1 text-[8.5px] font-bold ${forecastTone.direction} bg-white`}>
                    {forecastTone.label}
                </span>
            </div>

            <div className="mt-3 flex flex-1 flex-col justify-center gap-3">
                <div className={`rounded-xl px-3 py-2.5 ${forecastTone.container}`}>
                    <div className="flex items-center gap-2.5">
                        <span className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-full ${forecastTone.icon}`}>
                            <BarChart3 size={16} />
                        </span>

                        <div className="min-w-0 flex-1">
                            <div className="flex items-center justify-between gap-2">
                                <p className="text-[9px] font-semibold text-[#5F4E75]">
                                    Forecasted Sales ({nextMonthLabel})
                                </p>

                                {growthPct !== null && (
                                    <span className={`inline-flex shrink-0 items-center gap-1 text-[9.5px] font-bold ${forecastTone.direction}`}>
                                        {isUp ? <TrendingUp size={11} /> : <TrendingDown size={11} />}
                                        {isUp ? "+" : ""}
                                        {growthPct.toFixed(1)}%
                                    </span>
                                )}
                            </div>

                            <p className={`mt-0.5 text-[20px] font-bold leading-none tracking-[-0.03em] ${forecastTone.amount}`}>
                                {peso(Math.round(predicted))}
                            </p>

                            <p className="mt-1 text-[8px] font-medium text-[#7F7289]">
                                Compared with last completed month ({comparisonMonthLabel}): {peso(comparisonSales)}
                            </p>
                        </div>
                    </div>
                </div>

                <div className="rounded-xl bg-[#F4F8FE] px-3.5 py-3">
                    <div className="flex items-start gap-2.5">
                        <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-white text-[#2563EB] shadow-sm">
                            <Lightbulb size={14} />
                        </span>

                        <div className="min-w-0">
                            <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5">
                                <p className="text-[9px] font-bold text-[#2563EB]">Key Insight</p>
                                <span className="text-[8px] font-medium text-[#7A86A0]">
                                    {historyRangeLabel} • {historyMonths} completed months • Linear trend • Auto-refresh 60s
                                </span>
                            </div>

                            <p
                                className="mt-1 overflow-hidden text-[9px] font-medium leading-3.5 text-[#50617C]"
                                style={{
                                    display: "-webkit-box",
                                    WebkitLineClamp: 3,
                                    WebkitBoxOrient: "vertical",
                                }}
                            >
                                {insight}
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}