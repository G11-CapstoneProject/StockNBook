"use client";

import * as React from "react";
import Link from "next/link";
import {
    AlertTriangle, ArrowLeftRight, CalendarDays, ClipboardList, Clock3, Eye,
    FileText, Package, PackagePlus, RefreshCw, Search, ShoppingCart, X,
} from "lucide-react";
import { useInventoryController } from "@/hooks/useInventory";
import { ModuleSkeleton } from "@/components/loading/ModuleSkeletons";
import type { Product } from "./_shared";
import StaffRentalInventory from "./StaffRentalInventory";

/* Staff inventory only: the existing product hook remains the authoritative
   sales-stock source. No manager catalog editor or financial controls are mounted. */

type StockLine = {
    key: string;
    product: Product;
    reference: string;
    name: string;
    category: string;
    stock: number;
    reorder: number;
    status: "In Stock" | "Low Stock" | "Out of Stock";
};
type ActivityRow = {
    id: string;
    at: string;
    item: string;
    kind: string;
    quantity: number | null;
    reference: string;
};
type EmployeeEvent = {
    id?: string | number;
    action?: string;
    module?: string;
    details?: string;
    referenceNumber?: string;
    referenceId?: string;
    date?: string;
    time?: string;
};
type PosOrder = {
    id?: number | string;
    orderId?: string;
    order_id?: string;
    orderNumber?: string;
    order_number?: string;
    orderDate?: string;
    order_date?: string;
    createdAt?: string;
    created_at?: string;
    completedAt?: string;
    completed_at?: string;
    status?: string;
    item?: string;
    orderItems?: PosItem[];
    order_items?: PosItem[];
};
type PosItem = { productName?: string; product_name?: string; name?: string; quantity?: number | string; qty?: number | string };

const card = "overflow-hidden rounded-2xl border border-[#E6DDF0] bg-white shadow-sm";
const outline = "inline-flex h-[42px] items-center justify-center gap-2 rounded-xl border border-[#E6DDF0] bg-white px-4 text-sm font-semibold text-[#2B174C] shadow-sm transition hover:bg-[#F7F1FF]";
const primary = "inline-flex h-[42px] items-center justify-center gap-2 rounded-xl bg-[#2B174C] px-4 text-sm font-semibold text-white shadow-sm transition hover:bg-[#1B0D31]";
const filterClass = "h-[40px] rounded-xl border border-[#E6DDF0] bg-white px-3 text-xs text-[#2B174C] outline-none focus:border-[#2B174C]";
const headClass = "px-3 py-3 text-left text-[10px] font-semibold uppercase tracking-wide text-[#806A8C]";

function dateInManila(value = new Date()) {
    const parts = new Intl.DateTimeFormat("en-US", {
        timeZone: "Asia/Manila", year: "numeric", month: "2-digit", day: "2-digit",
    }).formatToParts(value);
    const part = (type: string) => parts.find(p => p.type === type)?.value || "";
    return `${part("year")}-${part("month")}-${part("day")}`;
}
function formatClock(value: Date) {
    return value.toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric", timeZone: "Asia/Manila" }) + " | " +
        value.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit", hour12: true, timeZone: "Asia/Manila" }).toLowerCase();
}
function safeDate(value: string) {
    if (!value) return "—";
    const normalized = value.includes(" ") ? value.replace(" ", "T") : value;
    const parsed = new Date(normalized);
    return Number.isNaN(parsed.getTime()) ? value : parsed.toLocaleString("en-PH", {
        month: "short", day: "numeric", hour: "numeric", minute: "2-digit", timeZone: "Asia/Manila",
    });
}
function toStockLines(products: Product[]): StockLine[] {
    return products.flatMap(product => {
        const from = (stockValue: number, reorderValue: number, name: string, reference: string, key: string): StockLine => {
            const stock = Math.max(0, Number(stockValue || 0));
            const reorder = Math.max(0, Number(reorderValue || 0));
            return {
                key, product, reference: reference || "—", name, category: product.category || "Uncategorized", stock, reorder,
                status: stock <= 0 ? "Out of Stock" : stock <= reorder ? "Low Stock" : "In Stock",
            };
        };
        if (product.hasVariants && product.variants?.length) {
            return product.variants.map(variant => {
                const label = Object.values(variant.variantValues || {}).filter(Boolean).join(", ") || "Variant";
                return from(variant.stock, variant.alertLevel, `${product.name} – ${label}`,
                    variant.variantNumber || product.productNumber || "", `${product.id}:${variant.id}`);
            });
        }
        return [from(product.stock, product.alertLevel, product.name, product.productNumber || "", `${product.id}:regular`)];
    });
}
function stockBadge(status: StockLine["status"]) {
    return status === "Out of Stock" ? "bg-[#FFE7EA] text-[#BF2438]" :
        status === "Low Stock" ? "bg-[#FFF3D8] text-[#B07408]" : "bg-[#E5F7ED] text-[#218246]";
}
function activityKind(action: string) {
    if (/restock|received|stock in|added inventory/i.test(action)) return "Stock In";
    if (/stock out|sold|dispatched|released/i.test(action)) return "Stock Out";
    return "Inventory Action";
}
function fromAudit(events: EmployeeEvent[], lines: StockLine[]): ActivityRow[] {
    const byReference = new Map(lines.filter(line => line.reference !== "—").map(line => [line.reference, line.name]));
    return events.filter(event => /inventory|stock/i.test(`${event.module || ""} ${event.action || ""}`))
        .map((event, index) => ({
            id: `audit-${event.id || index}`, at: `${event.date || ""}${event.time ? `T${event.time}` : ""}`,
            // Staff should not see raw audit details containing possible supplier/cost information.
            item: byReference.get(event.referenceNumber || "") || event.action || "Inventory updated", kind: activityKind(event.action || ""),
            quantity: null, reference: event.referenceNumber || event.referenceId || "—",
        }));
}
function fromOrders(orders: PosOrder[], businessDay: string): ActivityRow[] {
    return orders.flatMap<ActivityRow>((order, idx): ActivityRow[] => {
        const status = String(order.status || "completed").toLowerCase();
        if (/cancel|void|refund|fail|pending|unpaid|draft/.test(status)) return [];
        const stamp = String(order.completedAt || order.completed_at || order.createdAt || order.created_at || order.orderDate || order.order_date || "");
        if (!stamp || stamp.slice(0, 10) !== businessDay) return [];
        const items = Array.isArray(order.orderItems) ? order.orderItems : Array.isArray(order.order_items) ? order.order_items : [];
        const reference = String(order.orderNumber || order.order_number || order.orderId || order.order_id || "—");
        if (items.length) {
            return items.filter(item => Number(item.quantity ?? item.qty) > 0).map((item, j) => ({
                id: `pos-${order.id || order.orderId || idx}-${j}`, at: stamp,
                item: String(item.productName || item.product_name || item.name || "POS product"),
                kind: "POS Sale", quantity: -Number(item.quantity ?? item.qty), reference,
            }));
        }
        // Existing StockNBook POS returns the combined item text, not structured
        // lines. Show the transaction without guessing quantities or variants.
        return order.item?.trim() ? [{
            id: `pos-${order.id || order.orderId || idx}`, at: stamp,
            item: order.item.trim(), kind: "POS Sale", quantity: null, reference,
        }] : [];

    });
}
function SectionHead({ icon, title, subtitle, children }: {icon: React.ReactNode; title: string; subtitle: string; children?: React.ReactNode}) {
    return <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#E9E1EE] px-4 py-3.5">
        <div className="flex items-center gap-3">
            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-[10px] bg-[#F1EBFF] text-[#5A35A5]">{icon}</span>
            <div><h3 className="text-[15px] font-bold text-[#21132E]">{title}</h3><p className="mt-0.5 text-[11px] text-[#86778F]">{subtitle}</p></div>
        </div>{children}
    </div>;
}
function Stat({label,value,helper,icon,color}: {label:string;value:number|null;helper:string;icon:React.ReactNode;color:string}) {
    return <div className="flex h-[132px] flex-col rounded-[18px] border border-[#E6DDF0] bg-white p-3 shadow-sm">
        <div className="flex items-start justify-between gap-2"><p className="pt-1 text-sm font-semibold text-[#1A1220]">{label}</p>
            <span className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-full ${color}`}>{icon}</span></div>
        <p className="mt-3 text-[23px] font-bold leading-tight text-[#2B174C]">{value == null ? "—" : value.toLocaleString("en-PH")}</p>
        <p className="mt-1 text-[11px] leading-4 text-[#8A7D90]">{helper}</p>
    </div>;
}

export default function StaffInventory() {
    const inv = useInventoryController();
    const [now, setNow] = React.useState<Date | null>(null);
    const [tab, setTab] = React.useState<"sales" | "rental">("sales");
    const [search, setSearch] = React.useState("");
    const [category, setCategory] = React.useState("all");
    const [status, setStatus] = React.useState("all");
    const [taskFilter, setTaskFilter] = React.useState("all");
    const [page, setPage] = React.useState(1);
    const [details, setDetails] = React.useState<StockLine | null>(null);
    const [showReceivingInfo, setShowReceivingInfo] = React.useState(false);
    const [isRefreshing, setIsRefreshing] = React.useState(false);
    const [activityKey, setActivityKey] = React.useState(0);
    const [rentalKey, setRentalKey] = React.useState(0);
    const [activities, setActivities] = React.useState<ActivityRow[]>([]);
    const [activityError, setActivityError] = React.useState<string | null>(null);
    const [activityLoading, setActivityLoading] = React.useState(true);
    const isRental = tab === "rental";
    const today = dateInManila(now || new Date());
    const lines = React.useMemo(() => toStockLines(inv.baseProducts), [inv.baseProducts]);
    const low = lines.filter(line => line.status === "Low Stock");
    const out = lines.filter(line => line.status === "Out of Stock");
    const attention = [...out, ...low];
    const categories = React.useMemo(() => [...new Set(lines.map(item => item.category))].sort(), [lines]);
    const visible = React.useMemo(() => lines.filter(line =>
            [line.name, line.reference, line.category].join(" ").toLowerCase().includes(search.toLowerCase()) &&
            (category === "all" || line.category === category) && (status === "all" || line.status === status)),
        [lines, search, category, status]);
    const tasks = attention.filter(line => taskFilter === "all" || line.status === taskFilter);
    const pageSize = 25;
    const pages = Math.max(1, Math.ceil(visible.length / pageSize));
    const visiblePage = visible.slice((Math.min(page, pages) - 1) * pageSize, Math.min(page, pages) * pageSize);
    React.useEffect(() => { setPage(1); }, [search, category, status]);
    const branch = inv.assignedBranchName || "Assigned Branch";

    React.useEffect(() => {
        setNow(new Date());
        const interval = window.setInterval(() => setNow(new Date()), 30000);
        return () => window.clearInterval(interval);
    }, []);

    // Two small, authorized, branch-scoped read requests. Product quantities are
    // loaded once by useInventoryController, not duplicated in this component.
    React.useEffect(() => {
        if (isRental) return;
        const controller = new AbortController();
        const load = async () => {
            setActivityLoading(true);
            setActivityError(null);
            const token = sessionStorage.getItem("token");
            if (!token) { setActivityError("Session expired."); setActivityLoading(false); return; }
            const headers = { Authorization: `Bearer ${token}` };
            const posHeaders = { ...headers, "Content-Type": "application/json" };
            const [audit, pos] = await Promise.allSettled([
                fetch(`/api/reports?scope=employee_actions&startDate=${today}&endDate=${today}`, { headers, cache: "no-store", signal: controller.signal }),
                fetch("/api/pos", { method: "POST", headers: posHeaders, body: JSON.stringify({ action: "get_orders", date_from: today, date_to: today }), cache: "no-store", signal: controller.signal }),
            ]);
            if (controller.signal.aborted) return;
            const errors: string[] = [];
            const rows: ActivityRow[] = [];
            if (audit.status === "fulfilled" && audit.value.ok) {
                const data = await audit.value.json().catch(() => ({}));
                rows.push(...fromAudit(Array.isArray(data?.data?.employeeActions) ? data.data.employeeActions : [], lines));
            } else errors.push("inventory audit events");
            if (pos.status === "fulfilled" && pos.value.ok) {
                const data = await pos.value.json().catch(() => ({}));
                rows.push(...fromOrders(Array.isArray(data.orders) ? data.orders : [], today));
            } else errors.push("POS movements");
            if (controller.signal.aborted) return;
            setActivities(rows.sort((a,b) => b.at.localeCompare(a.at)).slice(0,50));
            setActivityError(errors.length ? `Unable to load ${errors.join(" and ")}. Available activity is shown.` : null);
            setActivityLoading(false);
        };
        void load().catch(() => { if (!controller.signal.aborted) { setActivityError("Unable to load activity."); setActivityLoading(false); } });
        return () => controller.abort();
    }, [today, activityKey, isRental, lines]);

    const refresh = async () => {
        if (isRefreshing) return;
        setIsRefreshing(true);
        try {
            if (isRental) setRentalKey(k=>k+1);
            else { await inv.refreshAll(); setActivityKey(k=>k+1); }
        } finally { setIsRefreshing(false); }
    };
    const reportText = (line: StockLine) => `StockNBook - Stock shortage review\nBranch: ${branch}\nProduct: ${line.name}\nProduct No.: ${line.reference}\nCurrent stock: ${line.stock}\nReorder point: ${line.reorder}\nStatus: ${line.status}\nPlease review and authorize stock replenishment.`;

    return <>
        <header className="sticky top-0 z-20 border-b border-[#E9E0EF] bg-[#FFFDF8]/95 font-sans backdrop-blur">
            <div className="flex flex-wrap items-center justify-between gap-3 px-6 py-3">
                <div className="flex items-center gap-3"><h1 className="text-[25px] font-bold text-[#1A1220]">Inventory</h1>
                    <span className="rounded-lg bg-[#EFE8F8] px-3.5 py-1.5 text-sm font-medium text-[#4E2C66]">{branch}</span></div>
                <div className="flex items-center gap-2.5">
                    <span className="inline-flex h-[42px] items-center rounded-xl border border-[#E6DDF0] bg-white px-3.5 text-sm font-semibold text-[#2B174C] shadow-sm">{now ? formatClock(now) : "Loading date..."}</span>
                    <button type="button" onClick={() => void refresh()} disabled={isRefreshing} className={primary}>
                        <RefreshCw size={16} className={isRefreshing ? "animate-spin" : ""}/> {isRefreshing ? "Refreshing..." : "Refresh"}
                    </button>
                </div>
            </div>
        </header>
        <main className="space-y-4 px-5 py-5 font-sans">
            <section className="flex flex-col gap-3 rounded-2xl bg-gradient-to-r from-[#F1F3FF] to-[#F7F5FF] px-4 py-3 shadow-sm sm:flex-row sm:items-center sm:justify-between">
                <div className="flex items-center gap-3">
                    <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-[#F1EBFF] text-[#5A35A5]">{isRental ? <CalendarDays size={22}/> : <ShoppingCart size={22}/>}</span>
                    <div><h2 className="text-[25px] font-bold text-[#1A1220]">{isRental ? "Rental Inventory" : "Sales Inventory"}</h2>
                        <p className="mt-0.5 text-xs text-[#766983]">{isRental ? "Daily equipment preparation, releases, returns and inspections." : "Daily stock handling for products sold to customers."}</p></div>
                </div>
                <div className="grid grid-cols-2 gap-3" aria-label="Select inventory view">
                    <button type="button" aria-pressed={!isRental} onClick={()=>setTab("sales")} className={`${!isRental ? primary : outline} min-w-[145px]`}><ShoppingCart size={17}/> Sales Inventory</button>
                    <button type="button" aria-pressed={isRental} onClick={()=>setTab("rental")} className={`${isRental ? primary : outline} min-w-[145px]`}><CalendarDays size={17}/> Rental Inventory</button>
                </div>
            </section>
            {isRental ? <StaffRentalInventory key={rentalKey} branchName={branch}/> : inv.productsLoading ?
                <ModuleSkeleton variant="inventory"/> : inv.productsError ?
                    <section role="alert" className={`${card} space-y-2 p-6`}><p className="font-semibold text-[#B92727]">Inventory could not be loaded.</p><p className="text-sm text-[#806A8C]">{inv.productsError}</p>
                        <button type="button" className={outline} onClick={()=>void refresh()}>Try Again</button></section> :
                    <div className="space-y-4">
                        <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
                            <Stat label="Items to Restock" value={attention.length} helper="Products at or below their reorder point" color="bg-[#FFF3DE] text-[#E68A00]" icon={<PackagePlus size={19}/>}/>
                            <Stat label="Low Stock Alerts" value={low.length} helper="Product variants approaching shortage" color="bg-[#FFF3DE] text-[#E68A00]" icon={<AlertTriangle size={19}/>}/>
                            <Stat label="Out of Stock" value={out.length} helper="Product variants with no available stock" color="bg-[#FFE7EB] text-[#CF3348]" icon={<Package size={19}/>}/>
                            <Stat label="Today's Stock Movements" value={activityLoading || activityError ? null : activities.length} helper="Recorded POS entries and inventory actions today" color="bg-[#E9F2FF] text-[#1E6FE8]" icon={<ArrowLeftRight size={19}/>}/>
                        </div>
                        <div className="grid gap-4 xl:grid-cols-[1.15fr_1fr]">
                            <section className={card}>
                                <SectionHead icon={<ClipboardList size={18}/>} title="Today's Sales Tasks" subtitle="Stock shortages to check or escalate, based on current quantities.">
                                    <select aria-label="Filter sales tasks" value={taskFilter} onChange={e=>setTaskFilter(e.target.value)} className={filterClass}>
                                        <option value="all">All Tasks</option><option value="Low Stock">Low Stock</option><option value="Out of Stock">Out of Stock</option>
                                    </select>
                                </SectionHead>
                                <div className="max-h-[330px] overflow-auto"><table className="w-full min-w-[580px] text-left text-xs">
                                    <thead className="sticky top-0 bg-[#FFFDF8]"><tr><th className={headClass}>Product</th><th className={`${headClass} text-center`}>Stock</th><th className={`${headClass} text-center`}>Reorder</th><th className={headClass}>Task</th><th className={headClass}>Action</th></tr></thead>
                                    <tbody>{tasks.slice(0,30).map(item=><tr key={item.key} className="border-t border-[#F0EAF4] text-[#2B174C]">
                                        <td className="px-3 py-3 font-medium">{item.name}</td><td className="px-3 py-3 text-center">{item.stock}</td><td className="px-3 py-3 text-center">{item.reorder}</td>
                                        <td className="px-3 py-3"><span className={`rounded-lg px-2 py-1 ${stockBadge(item.status)}`}>{item.status === "Out of Stock" ? "Report Shortage" : "Check / Replenish"}</span></td>
                                        <td className="px-3 py-3"><button type="button" onClick={()=>setDetails(item)} className="rounded-lg border border-[#DCCBF2] bg-[#F8F5FF] px-3 py-1.5 font-semibold text-[#5932D8] hover:bg-[#EDE4FF]">Review</button></td>
                                    </tr>)}</tbody></table>
                                    {tasks.length===0 && <p className="py-10 text-center text-sm text-[#806A8C]">No stock tasks match this filter.</p>}
                                    {tasks.length>30 && <p className="border-t border-[#F0EAF4] px-4 py-2 text-xs text-[#806A8C]">Showing first 30 of {tasks.length} stock alerts. Use the branch inventory list to find more.</p>}
                                </div>
                            </section>
                            <section className={card}>
                                <SectionHead icon={<Clock3 size={18}/>} title="Recent Stock Activity" subtitle="Today's recorded stock-related transactions and audit events."/>
                                {activityError && <p role="status" className="px-4 pt-3 text-xs text-[#A56607]">{activityError}</p>}
                                {activityLoading ? <div className="space-y-3 p-4" aria-busy="true" aria-label="Loading today's stock activity">{[1,2,3,4].map(x=><div key={x} className="h-8 animate-pulse rounded-lg bg-[#F2EDF8]"/>)}</div> :
                                    <div className="max-h-[330px] overflow-auto"><table className="w-full min-w-[440px] text-left text-xs">
                                        <thead className="sticky top-0 bg-[#FFFDF8]"><tr><th className={headClass}>Time</th><th className={headClass}>Product / Activity</th><th className={headClass}>Type</th><th className={headClass}>Qty</th><th className={headClass}>Reference</th></tr></thead>
                                        <tbody>{activities.slice(0,12).map(item=><tr key={item.id} className="border-t border-[#F0EAF4] text-[#2B174C]">
                                            <td className="px-3 py-3 text-[#806A8C]">{safeDate(item.at)}</td><td className="max-w-[200px] truncate px-3 py-3" title={item.item}>{item.item}</td>
                                            <td className="px-3 py-3"><span className={`rounded-lg px-2 py-1 ${item.kind === "POS Sale" ? "bg-[#FFE7EA] text-[#BF2438]" : "bg-[#E5F7ED] text-[#218246]"}`}>{item.kind}</span></td>
                                            <td className="px-3 py-3">{item.quantity == null ? "—" : item.quantity}</td><td className="px-3 py-3">{item.reference}</td>
                                        </tr>)}</tbody></table>{activities.length===0&&<p className="py-10 text-center text-sm text-[#806A8C]">No recorded stock movements available for today.</p>}</div>}
                            </section>
                        </div>
                        <div className="flex flex-wrap items-center gap-2">
                            <label className="relative min-w-[200px] flex-1"><span className="sr-only">Search sales inventory</span>
                                <Search size={17} className="absolute left-4 top-1/2 -translate-y-1/2 text-[#9B8AAA]"/>
                                <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search product no., name, category or variant..." className="h-[42px] w-full rounded-xl border border-[#E6DDF0] bg-white pl-10 pr-4 text-sm text-[#2B174C] shadow-sm outline-none focus:border-[#2B174C]"/></label>
                            <button type="button" className={outline} onClick={()=>{setStatus("Low Stock");document.getElementById("staff-sales-list")?.scrollIntoView({behavior:"smooth"});}}><Eye size={16}/> View Low Stock</button>
                            <button type="button" className={primary} onClick={()=>setShowReceivingInfo(true)}><PackagePlus size={16}/> Record Stock In</button>
                        </div>
                        <section id="staff-sales-list" className={card}>
                            <SectionHead icon={<Package size={18}/>} title="Branch Sales Inventory List" subtitle={`Products available for daily stock operations · ${branch}`}>
                                <div className="flex flex-wrap gap-2"><select aria-label="Filter categories" className={filterClass} value={category} onChange={e=>setCategory(e.target.value)}><option value="all">All Categories</option>
                                    {categories.map(cat=><option key={cat} value={cat}>{cat}</option>)}</select>
                                    <select aria-label="Filter stock statuses" className={filterClass} value={status} onChange={e=>setStatus(e.target.value)}><option value="all">All Status</option><option value="In Stock">In Stock</option><option value="Low Stock">Low Stock</option><option value="Out of Stock">Out of Stock</option></select></div>
                            </SectionHead>
                            <div className="max-h-[460px] overflow-auto"><table className="w-full min-w-[850px] text-left text-xs"><thead className="sticky top-0 bg-[#FFFDF8]"><tr>
                                {['Product No.','Product','Category','Available Stock','Reorder Point','Status','Action'].map(label=><th key={label} className={headClass}>{label}</th>)}</tr></thead>
                                <tbody>{visiblePage.map(item=><tr key={item.key} className="border-t border-[#F0EAF4] text-[#2B174C]">
                                    <td className="px-3 py-3 text-[#806A8C]">{item.reference}</td><td className="px-3 py-3 font-semibold">{item.name}</td><td className="px-3 py-3">{item.category}</td>
                                    <td className="px-3 py-3 text-center">{item.stock}</td><td className="px-3 py-3 text-center">{item.reorder}</td>
                                    <td className="px-3 py-3"><span className={`inline-flex min-w-[85px] justify-center rounded-lg px-2 py-1 ${stockBadge(item.status)}`}>{item.status}</span></td>
                                    <td className="px-3 py-3"><button type="button" className="rounded-lg border border-[#DCCBF2] bg-[#F8F5FF] px-3 py-1.5 font-semibold text-[#5932D8]" onClick={()=>setDetails(item)}>View</button></td>
                                </tr>)}</tbody></table>
                                {visible.length===0 && <p className="py-10 text-center text-sm text-[#806A8C]">No products match your search or filters.</p>}</div>
                            <div className="flex flex-wrap items-center justify-between gap-3 border-t border-[#E9E1EE] px-4 py-3">
                                <p className="text-[11px] text-[#806A8C]">{visible.length} of {lines.length} product / variant records</p>
                                <div className="flex items-center gap-2 text-xs text-[#5A476A]">
                                    <button type="button" disabled={page<=1} className={`${outline} h-8 disabled:opacity-40`} onClick={()=>setPage(p=>Math.max(1,p-1))}>Previous</button>
                                    <span>Page {Math.min(page,pages)} of {pages}</span>
                                    <button type="button" disabled={page>=pages} className={`${outline} h-8 disabled:opacity-40`} onClick={()=>setPage(p=>Math.min(pages,p+1))}>Next</button>
                                </div>
                            </div>
                        </section>
                    </div>}
        </main>
        {(details || showReceivingInfo) && <div className="fixed inset-0 z-[90] flex items-center justify-center bg-[#21132E]/50 p-4" onMouseDown={event=>{if(event.target===event.currentTarget){setDetails(null);setShowReceivingInfo(false);}}}>
            <section role="dialog" aria-modal="true" aria-label={details ? "Stock review" : "Stock receiving"} className="w-full max-w-lg rounded-2xl border border-[#E6DDF0] bg-white p-5 shadow-xl">
                <div className="flex items-start justify-between gap-4"><h3 className="text-lg font-bold text-[#21132E]">{details ? "Stock Review" : "Record Stock In"}</h3>
                    <button aria-label="Close" type="button" onClick={()=>{setDetails(null);setShowReceivingInfo(false);}} className="rounded-lg p-1 text-[#6A5D6F] hover:bg-[#F7F1FF]"><X size={20}/></button></div>
                {details ? <div className="mt-4 space-y-3 text-sm"><p className="font-semibold">{details.name}</p><p className="text-[#806A8C]">{details.reference} · {details.category}</p>
                    <div className="grid grid-cols-2 gap-2"><p>Available: <strong>{details.stock}</strong></p><p>Reorder point: <strong>{details.reorder}</strong></p></div>
                    <p>Status: <span className={`rounded-lg px-2 py-1 ${stockBadge(details.status)}`}>{details.status}</span></p>
                    <p className="rounded-xl bg-[#F7F3FC] p-3 text-xs leading-5 text-[#6A5D6F]">Staff can check and report shortages. Inventory corrections, purchasing and supplier payments require Manager or Owner authorization.</p>
                    {details.status!=="In Stock" && <button type="button" className={outline} onClick={()=>void navigator.clipboard.writeText(reportText(details))}><FileText size={16}/> Copy Shortage Report</button>}
                </div> : <div className="mt-4 space-y-3"><p className="text-sm text-[#5F4E75]">Your current backend restricts supplier stock receiving to Owners and Managers. Staff cannot submit stock-in transactions through this role until an authorized, audited receiving workflow is available.</p>
                    <p className="rounded-xl bg-[#F7F3FC] p-3 text-xs text-[#806A8C]">For now, coordinate supplier deliveries with the Manager. No stock was changed.</p><Link href="/bookings" className={outline}>View Today&apos;s Bookings</Link></div>}
            </section>
        </div>}
    </>;
}
