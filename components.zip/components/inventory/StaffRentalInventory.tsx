"use client";

import * as React from "react";
import Link from "next/link";
import {
    CalendarClock,
    ClipboardCheck,
    ClipboardList,
    Clock3,
    Eye,
    PackageCheck,
    PackageSearch,
    RotateCcw,
    Search,
    Sparkles,
    Truck,
    X,
} from "lucide-react";
import {
    useRentalInventory,
    type RentalInventoryAction,
    type RentalInventoryEquipment,
    type RentalInventoryActivity,
} from "@/hooks/useRentalInventory";

/*
 * Staff-facing rental operations view.
 * Reuses the existing shared rental hook; does not change its API or the Manager view.
 * Until the rental backend is connected, metrics are unavailable (—), not zero.
 * Staff may inspect transactions here, but may not mutate inventory from this UI.
 */

type TaskKind = "prepare" | "release" | "return" | "inspect" | "clean" | "review";
type StaffTask = RentalInventoryAction & {
    bookingReference?: string | null;
    referenceNumber?: string | null;
    equipmentName?: string | null;
    taskType?: string | null;
    quantity?: number | null;
    dueAt?: string | null;
    status?: string | null;
};
type StaffEquipment = RentalInventoryEquipment & {
    variant?: string | null;
    reservedUnits?: number | null;
};
type StaffActivity = RentalInventoryActivity & {
    quantity?: number | null;
    equipmentName?: string | null;
};

const card = "overflow-hidden rounded-2xl border border-[#E6DDF0] bg-white shadow-sm";
const outline = "inline-flex h-[42px] items-center justify-center gap-2 rounded-xl border border-[#E6DDF0] bg-white px-4 text-sm font-semibold text-[#2B174C] shadow-sm transition hover:bg-[#F7F1FF]";
const filterStyle = "h-[40px] rounded-xl border border-[#E6DDF0] bg-white px-3 text-xs text-[#2B174C] outline-none focus:border-[#2B174C]";
const tableHeader = "px-3 py-3 text-left text-[10px] font-semibold uppercase tracking-wide text-[#806A8C]";

const taskNames: Record<TaskKind, string> = {
    prepare: "Prepare", release: "Release", return: "Receive Return",
    inspect: "Inspect", clean: "Clean", review: "Review",
};

function taskKind(task: StaffTask): TaskKind {
    const value = String(task.taskType || task.description || "").toLowerCase();
    if (/inspect|condition check/.test(value)) return "inspect";
    if (/clean|sanitize/.test(value)) return "clean";
    if (/return|check-in|check in|receive/.test(value)) return "return";
    if (/release|dispatch|check-out|check out/.test(value)) return "release";
    if (/prepare|pack|pick/.test(value)) return "prepare";
    return "review";
}

function readableDate(value?: string | null) {
    if (!value) return "—";
    const parsed = new Date(value);
    return Number.isNaN(parsed.getTime()) ? String(value) : parsed.toLocaleString("en-PH", {
        month: "short", day: "numeric", year: "numeric", hour: "numeric", minute: "2-digit",
        timeZone: "Asia/Manila",
    });
}

function manilaDay(value: string) {
    const parsed = new Date(value);
    if (Number.isNaN(parsed.getTime())) return "";
    const parts = new Intl.DateTimeFormat("en-US", {
        year: "numeric", month: "2-digit", day: "2-digit", timeZone: "Asia/Manila",
    }).formatToParts(parsed);
    const part = (kind: string) => parts.find(item => item.type === kind)?.value || "";
    return `${part("year")}-${part("month")}-${part("day")}`;
}

function Stat({ label, value, helper, icon, iconStyle }: {
    label: string; value: number | null; helper: string; icon: React.ReactNode; iconStyle: string;
}) {
    return (
        <div className="flex h-[132px] flex-col rounded-[18px] border border-[#E6DDF0] bg-white p-3 shadow-sm">
            <div className="flex items-start justify-between gap-2">
                <p className="pt-1 text-sm font-semibold text-[#1A1220]">{label}</p>
                <span className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-full ${iconStyle}`}>{icon}</span>
            </div>
            <p className="mt-3 text-[23px] font-bold leading-tight text-[#2B174C]">
                {value == null ? "—" : value.toLocaleString("en-PH")}
            </p>
            <p className="mt-1 text-[11px] leading-4 text-[#8A7D90]">{helper}</p>
        </div>
    );
}

function EmptyState({ title, detail }: { title: string; detail: string }) {
    return (
        <div className="flex min-h-[170px] flex-col items-center justify-center gap-2 px-4 py-8 text-center">
            <PackageSearch size={27} className="text-[#A091B0]" />
            <p className="text-sm font-semibold text-[#4E2C66]">{title}</p>
            <p className="max-w-sm text-xs leading-5 text-[#806A8C]">{detail}</p>
        </div>
    );
}

function SectionTitle({ icon, title, subtitle, right }: {
    icon: React.ReactNode; title: string; subtitle: string; right?: React.ReactNode;
}) {
    return (
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#E9E1EE] px-4 py-3.5">
            <div className="flex items-center gap-3">
                <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-[10px] bg-[#F1EBFF] text-[#5A35A5]">{icon}</span>
                <div>
                    <h3 className="text-[15px] font-bold text-[#21132E]">{title}</h3>
                    <p className="mt-0.5 text-[11px] text-[#86778F]">{subtitle}</p>
                </div>
            </div>
            {right}
        </div>
    );
}

export default function StaffRentalInventory({ branchName }: { branchName: string }) {
    const rental = useRentalInventory();
    const [search, setSearch] = React.useState("");
    const [taskFilter, setTaskFilter] = React.useState<TaskKind | "all">("all");
    const [categoryFilter, setCategoryFilter] = React.useState("all");
    const [statusFilter, setStatusFilter] = React.useState("all");
    const [selectedTask, setSelectedTask] = React.useState<StaffTask | null>(null);
    const [selectedEquipment, setSelectedEquipment] = React.useState<StaffEquipment | null>(null);

    const tasks = rental.requiredActions as readonly StaffTask[];
    const equipment = rental.equipment as readonly StaffEquipment[];
    const activities = React.useMemo(() =>
        [...(rental.recentActivity as readonly StaffActivity[])].sort((a, b) =>
            String(b.date).localeCompare(String(a.date))), [rental.recentActivity]);
    const byId = React.useMemo(() => new Map(equipment.map(item => [String(item.id), item])), [equipment]);
    const matching = search.trim().toLowerCase();
    const categories = [...new Set(equipment.map(item => item.category).filter(Boolean))].sort();
    const statuses = [...new Set(equipment.map(item => item.status).filter(Boolean))].sort();
    const allKinds = tasks.map(taskKind);
    const hasTypedTasks = allKinds.some(kind => kind !== "review");
    const count = (kind: TaskKind) => rental.connected && hasTypedTasks
        ? allKinds.filter(value => value === kind).length : null;
    const today = manilaDay(new Date().toISOString());
    const hasDatedReturns = tasks.some(task => taskKind(task) === "return" && task.dueAt);
    const returnsDueToday = rental.connected && hasDatedReturns
        ? tasks.filter(task => taskKind(task) === "return" && task.dueAt && manilaDay(task.dueAt) === today).length
        : null;
    const readyForRelease = rental.connected && hasTypedTasks
        ? tasks.filter(task => taskKind(task) === "release" && /ready/i.test(String(task.status || task.description))).length
        : null;

    const visibleTasks = tasks.filter(task => {
        const item = byId.get(String(task.equipmentId));
        const searchable = [task.equipmentName, item?.name, item?.equipmentNumber,
            task.bookingReference, task.referenceNumber, task.description].join(" ").toLowerCase();
        // A daily Staff queue includes today's and overdue work, not future tasks.
        const dueDay = task.dueAt ? manilaDay(task.dueAt) : "";
        return searchable.includes(matching) && (!dueDay || dueDay <= today) &&
            (taskFilter === "all" || taskKind(task) === taskFilter);
    });
    const visibleEquipment = equipment.filter(item =>
        [item.equipmentNumber, item.name, item.variant, item.category].join(" ").toLowerCase().includes(matching)
        && (categoryFilter === "all" || item.category === categoryFilter)
        && (statusFilter === "all" || item.status === statusFilter)
    );
    const emptyDetail = rental.connected
        ? "No records match this selection."
        : "The rental database and booking transaction API have not been connected yet.";

    return (
        <div className="space-y-4" aria-label="Staff Rental Inventory">
            <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
                <Stat label="Ready for Release" value={readyForRelease}
                      helper="Prepared release tasks, not total owned units"
                      icon={<Truck size={19} />} iconStyle="bg-[#E5F8EC] text-[#23834A]" />
                <Stat label="For Return Today" value={returnsDueToday}
                      helper="Rental return tasks due today"
                      icon={<CalendarClock size={19} />} iconStyle="bg-[#E9F2FF] text-[#1E6FE8]" />
                <Stat label="Pending Inspection" value={count("inspect")}
                      helper="Returns that need condition checks"
                      icon={<ClipboardCheck size={19} />} iconStyle="bg-[#FFF3DE] text-[#E68A00]" />
                <Stat label="Needs Cleaning" value={count("clean")}
                      helper="Equipment waiting to be cleaned"
                      icon={<Sparkles size={19} />} iconStyle="bg-[#F1ECFF] text-[#5F35D8]" />
            </div>

            {!rental.connected && (
                <div className="rounded-xl border border-[#DED5EC] bg-[#F7F3FC] px-4 py-3 text-xs leading-5 text-[#5F4E75]">
                    Rental tasks require branch-scoped equipment, booking allocations and return records. The
                    shared rental hook is not yet connected; “—” means information is unavailable, not zero stock.
                </div>
            )}

            <div className="grid gap-4 xl:grid-cols-[1.15fr_1fr]">
                <section id="staff-rental-tasks" className={card}>
                    <SectionTitle icon={<ClipboardList size={18} />} title="Today's Rental Tasks"
                                  subtitle="Booking-related equipment to prepare, release, receive, inspect or clean."
                                  right={<select aria-label="Filter rental tasks" value={taskFilter}
                                                 onChange={event => setTaskFilter(event.target.value as TaskKind | "all")}
                                                 className={filterStyle}>
                                      <option value="all">All Tasks</option>
                                      <option value="prepare">Prepare</option><option value="release">Release</option>
                                      <option value="return">Returns</option><option value="inspect">Inspections</option>
                                      <option value="clean">Cleaning</option><option value="review">Other</option>
                                  </select>} />
                    <div className="overflow-x-auto">
                        <table className="w-full min-w-[610px] text-left text-xs">
                            <thead className="bg-[#FFFDF8]"><tr>
                                <th className={tableHeader}>Booking Ref.</th>
                                <th className={tableHeader}>Equipment</th>
                                <th className={`${tableHeader} text-center`}>Qty</th>
                                <th className={tableHeader}>Task</th>
                                <th className={tableHeader}>Action</th>
                            </tr></thead>
                            <tbody>{visibleTasks.map(task => {
                                const item = byId.get(String(task.equipmentId));
                                return <tr key={task.id} className="border-t border-[#F0EAF4] text-[#2B174C]">
                                    <td className="px-3 py-3">{task.bookingReference || task.referenceNumber || "—"}</td>
                                    <td className="px-3 py-3 font-medium">{task.equipmentName || item?.name || "—"}</td>
                                    <td className="px-3 py-3 text-center">{task.quantity ?? "—"}</td>
                                    <td className="px-3 py-3"><span className="rounded-lg bg-[#F1EBFF] px-2 py-1 text-[#5A35A5]">{taskNames[taskKind(task)]}</span></td>
                                    <td className="px-3 py-3"><button type="button" onClick={() => setSelectedTask(task)} className="rounded-lg border border-[#DCCBF2] px-3 py-1.5 font-semibold text-[#5932D8] hover:bg-[#F7F1FF]">View</button></td>
                                </tr>;
                            })}</tbody>
                        </table>
                    </div>
                    {visibleTasks.length === 0 && <EmptyState title={rental.connected ? "No rental tasks found" : "Rental tasks not yet connected"} detail={emptyDetail} />}
                </section>

                <section className={card}>
                    <SectionTitle icon={<Clock3 size={18} />} title="Recent Rental Activity"
                                  subtitle="Latest equipment releases, returns and inspection records." />
                    <div className="overflow-x-auto"><table className="w-full min-w-[510px] text-left text-xs">
                        <thead className="bg-[#FFFDF8]"><tr>
                            <th className={tableHeader}>Date &amp; Time</th>
                            <th className={tableHeader}>Equipment</th>
                            <th className={tableHeader}>Type</th>
                            <th className={tableHeader}>Reference</th>
                        </tr></thead>
                        <tbody>{activities.slice(0, 8).map(activity => <tr key={activity.id} className="border-t border-[#F0EAF4] text-[#2B174C]">
                            <td className="px-3 py-3 text-[#806A8C]">{readableDate(activity.date)}</td>
                            <td className="px-3 py-3 font-medium">{activity.equipmentName || byId.get(String(activity.equipmentId))?.name || "—"}</td>
                            <td className="px-3 py-3">{activity.activityType || "—"}</td>
                            <td className="px-3 py-3">{activity.referenceNumber || "—"}</td>
                        </tr>)}</tbody>
                    </table></div>
                    {activities.length === 0 && <EmptyState title={rental.connected ? "No recent rental activity" : "Rental activity not yet connected"} detail={emptyDetail} />}
                </section>
            </div>

            <div className="flex flex-wrap items-center gap-2">
                <label className="relative min-w-[190px] flex-1">
                    <span className="sr-only">Search rental equipment and tasks</span>
                    <Search size={17} className="absolute left-4 top-1/2 -translate-y-1/2 text-[#9B8AAA]" />
                    <input type="search" value={search} onChange={event => setSearch(event.target.value)}
                           placeholder="Search equipment no., equipment name or booking..."
                           className="h-[42px] w-full rounded-xl border border-[#E6DDF0] bg-white pl-10 pr-4 text-sm text-[#2B174C] shadow-sm outline-none focus:border-[#2B174C]" />
                </label>
                <button type="button" onClick={() => { setTaskFilter("return"); document.getElementById("staff-rental-tasks")?.scrollIntoView({ behavior: "smooth", block: "center" }); }} className={outline}>
                    <RotateCcw size={16} /> View Returns
                </button>
                <button type="button" onClick={() => { setTaskFilter("all"); document.getElementById("staff-rental-tasks")?.scrollIntoView({ behavior: "smooth", block: "center" }); }} className={outline}>
                    <ClipboardCheck size={16} /> View Tasks
                </button>
                <Link href="/bookings" className="inline-flex h-[42px] items-center justify-center gap-2 rounded-xl bg-[#2B174C] px-4 text-sm font-semibold text-white shadow-sm hover:bg-[#1B0D31]">
                    <CalendarClock size={16} /> Open Bookings
                </Link>
            </div>

            <section className={card}>
                <SectionTitle icon={<PackageCheck size={18} />} title="Branch Rental Inventory List"
                              subtitle={`Rental equipment for daily operations · ${branchName}`}
                              right={<div className="flex flex-wrap gap-2">
                                  <select aria-label="Filter equipment category" value={categoryFilter} onChange={event => setCategoryFilter(event.target.value)} className={filterStyle}>
                                      <option value="all">All Categories</option>
                                      {categories.map(category => <option key={category} value={category}>{category}</option>)}
                                  </select>
                                  <select aria-label="Filter equipment status" value={statusFilter} onChange={event => setStatusFilter(event.target.value)} className={filterStyle}>
                                      <option value="all">All Status</option>
                                      {statuses.map(status => <option key={status} value={status}>{status}</option>)}
                                  </select>
                              </div>} />
                <div className="overflow-x-auto">
                    <table className="w-full min-w-[790px] text-left text-xs">
                        <thead className="bg-[#FFFDF8]"><tr>
                            <th className={tableHeader}>Equipment No.</th>
                            <th className={tableHeader}>Equipment</th>
                            <th className={tableHeader}>Category</th>
                            <th className={`${tableHeader} text-center`}>Available</th>
                            <th className={`${tableHeader} text-center`}>Reserved</th>
                            <th className={`${tableHeader} text-center`}>Out</th>
                            <th className={tableHeader}>Status</th>
                            <th className={tableHeader}>Action</th>
                        </tr></thead>
                        <tbody>{visibleEquipment.map(item => <tr key={item.id} className="border-t border-[#F0EAF4] text-[#2B174C]">
                            <td className="px-3 py-3 font-medium">{item.equipmentNumber || "—"}</td>
                            <td className="px-3 py-3">{item.name}{item.variant ? ` – ${item.variant}` : ""}</td>
                            <td className="px-3 py-3">{item.category || "—"}</td>
                            <td className="px-3 py-3 text-center">{item.availableUnits}</td>
                            <td className="px-3 py-3 text-center">{item.reservedUnits ?? "—"}</td>
                            <td className="px-3 py-3 text-center">{item.rentedOutUnits}</td>
                            <td className="px-3 py-3"><span className="rounded-lg bg-[#F1EBFF] px-2 py-1 text-[#5A35A5]">{item.status || "—"}</span></td>
                            <td className="px-3 py-3"><button type="button" onClick={() => setSelectedEquipment(item)} className="inline-flex items-center gap-1 rounded-lg border border-[#DCCBF2] bg-[#F8F5FF] px-3 py-1.5 font-semibold text-[#5932D8] hover:bg-[#EDE4FF]"><Eye size={13} /> View</button></td>
                        </tr>)}</tbody>
                    </table>
                </div>
                {visibleEquipment.length === 0 && <EmptyState title={rental.connected ? "No rental equipment found" : "Rental equipment not yet connected"} detail={emptyDetail} />}
            </section>

            {(selectedTask || selectedEquipment) && <div role="presentation" onMouseDown={event => {
                if (event.target === event.currentTarget) { setSelectedTask(null); setSelectedEquipment(null); }
            }} className="fixed inset-0 z-[90] flex items-center justify-center bg-[#21132E]/50 p-4">
                <section role="dialog" aria-modal="true" aria-label={selectedTask ? "Rental task details" : "Rental equipment details"}
                         className="w-full max-w-lg rounded-2xl border border-[#E6DDF0] bg-white p-5 shadow-2xl">
                    <div className="flex items-start justify-between gap-4">
                        <div>
                            <h3 className="text-lg font-bold text-[#21132E]">{selectedTask ? "Rental Task Details" : selectedEquipment?.name}</h3>
                            <p className="mt-1 text-xs text-[#806A8C]">{selectedTask ? selectedTask.bookingReference || selectedTask.referenceNumber || "Booking reference unavailable" : selectedEquipment?.equipmentNumber}</p>
                        </div>
                        <button type="button" aria-label="Close details" onClick={() => { setSelectedTask(null); setSelectedEquipment(null); }} className="rounded-lg p-1 text-[#6A5D6F] hover:bg-[#F7F1FF]"><X size={20}/></button>
                    </div>
                    {selectedTask ? <dl className="mt-4 space-y-2 text-sm">
                        <div className="flex justify-between gap-3"><dt className="text-[#806A8C]">Task</dt><dd className="font-semibold">{taskNames[taskKind(selectedTask)]}</dd></div>
                        <div className="flex justify-between gap-3"><dt className="text-[#806A8C]">Equipment</dt><dd className="text-right font-medium">{selectedTask.equipmentName || byId.get(String(selectedTask.equipmentId))?.name || "—"}</dd></div>
                        <div className="flex justify-between gap-3"><dt className="text-[#806A8C]">Quantity</dt><dd>{selectedTask.quantity ?? "—"}</dd></div>
                        <div className="flex justify-between gap-3"><dt className="text-[#806A8C]">Due</dt><dd>{readableDate(selectedTask.dueAt)}</dd></div>
                        <div className="rounded-xl bg-[#F8F5FF] p-3 text-xs leading-5 text-[#5A476A]">{selectedTask.description}</div>
                    </dl> : selectedEquipment && <dl className="mt-4 space-y-2 text-sm">
                        <div className="flex justify-between gap-3"><dt className="text-[#806A8C]">Total Owned</dt><dd>{selectedEquipment.totalUnits}</dd></div>
                        <div className="flex justify-between gap-3"><dt className="text-[#806A8C]">Available</dt><dd>{selectedEquipment.availableUnits}</dd></div>
                        <div className="flex justify-between gap-3"><dt className="text-[#806A8C]">Reserved</dt><dd>{selectedEquipment.reservedUnits ?? "—"}</dd></div>
                        <div className="flex justify-between gap-3"><dt className="text-[#806A8C]">Out on Rental</dt><dd>{selectedEquipment.rentedOutUnits}</dd></div>
                        <div className="flex justify-between gap-3"><dt className="text-[#806A8C]">Status</dt><dd>{selectedEquipment.status || "—"}</dd></div>
                    </dl>}
                    <p className="mt-4 rounded-xl bg-[#F7F3FC] px-3 py-2.5 text-xs text-[#5A476A]">Read-only until authorized rental transaction endpoints are available. Equipment catalog changes belong to the Manager.</p>
                    <button type="button" className={`${outline} mt-4 w-full`} onClick={() => { setSelectedTask(null); setSelectedEquipment(null); }}>Close</button>
                </section>
            </div>}
        </div>
    );
}
