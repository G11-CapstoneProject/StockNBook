/* eslint-disable @typescript-eslint/no-explicit-any */
"use client";

import * as XLSX from "xlsx";
import { useCallback, useEffect, useMemo, useState } from "react";
import {
    type Branch,
    type Category,
    type InventoryRole,
    type PendingProductSave,
    type Product,
    type ProductSaveData,
    type ProductVariantSave,
    getApiErrorMessage,
    getTokenOrAlert,
    normalizeCat,
    normalizeProduct,
    safeParseResponse,
} from "@/components/inventory/_shared";

type CategoryApiResponse = {
    success?: boolean;
    category?: Category;
    categories?: Category[];
    id?: number;
    categoryName?: string;
    error?: string;
};

type ProductsApiResponse = {
    success?: boolean;
    product?: Product;
    products?: Product[];
    error?: string;
};

type BranchesApiResponse = {
    branches?: any[];
    error?: string;
};

type FormSubmitEvent = { preventDefault: () => void };

type ProductPricingMethod = "manual" | "markup";

// Additional fields used only by the Add/Edit Product dialog. Keep the
// existing shared ProductSaveData type and other inventory flows unchanged.
type ProductSaveWithPurchase = Omit<ProductSaveData, "variants"> & {
    pricingMethod?: ProductPricingMethod;
    markupPercentage?: number | null;
    initialPurchase?: {
        supplier: string;
        supplierInvoiceNumber?: string | null;
        purchaseDate: string;
        paymentMethod: "cash" | "credit";
        amountPaid: number;
        paymentDueDate: string | null;
    };
    variants?: Array<ProductVariantSave & {
        pricingMethod?: ProductPricingMethod;
        markupPercentage?: number | null;
    }>;
};


export type ProductFormVariant = {
    id?: number;
    variantNumber?: string | null;
    variantValues: Record<string, string>;
    stock: string;
    alertLevel: string;
    originalPrice: string;
    salesPrice: string;
    expirationDate?: string | null;
};

export type ImportPurchaseSummary = {
    purchaseRef: string;
    supplierInvoiceNumber?: string | null;
    supplier: string;
    purchaseDate: string;
    paymentMethod: "cash" | "credit";
    amountPaid: number;
    paymentDueDate: string | null;
    purchaseTotal: number;
    outstandingBalance: number;
};

export type ImportPreviewProduct = ProductSaveData & {
    tempId: string;
    pricingMethod?: "manual" | "markup";
    markupPercentage?: number | null;
    purchaseRef?: string;
    purchase?: ImportPurchaseSummary | null;
    importTemplateVersion?: "complete";
};

type PricedImportVariant = ProductVariantSave & {
    pricingMethod?: "manual" | "markup";
    markupPercentage?: number | null;
};

function cleanImportCell(value: unknown) {
    return String(value ?? "").trim();
}

function parseImportNumber(value: unknown) {
    const text = String(value ?? "")
        .replace(/[₱,\s]/g, "")
        .replace(/pesos/gi, "")
        .trim();

    const match = text.match(/-?\d+(\.\d+)?/);
    return match ? Number(match[0]) : 0;
}

function normalizeImportHeader(value: unknown) {
    const key = cleanImportCell(value).toLowerCase().replace(/[^a-z0-9]/g, "");

    if (["product", "products", "name", "productname"].includes(key)) return "product";
    if (["category", "categories"].includes(key)) return "category";
    if (["hasvariants", "hasvariant", "withvariants"].includes(key)) return "hasVariants";
    if (["variantfields", "variantfield", "variantsfields", "variantsfield", "variationfields", "variationfield"].includes(key)) {
        return "variantFields";
    }
    if (["variantvalues", "variantvalue", "variationvalues", "variationvalue"].includes(key)) {
        return "variantValues";
    }
    if (["variant", "variants", "variation", "variations"].includes(key)) {
        return "legacyVariants";
    }
    if (["stock", "stocks", "quantity", "qty"].includes(key)) return "stock";
    if (["alert", "alertlevel", "reorderlevel"].includes(key)) return "alert";
    if (["original", "cost", "originalprice", "costprice"].includes(key)) return "original";
    if (["sales", "price", "salesprice", "sellingprice"].includes(key)) return "sales";
    if (
        [
            "expiration",
            "expirationdate",
            "expirationdateoptional",
            "expiry",
            "expirydate",
            "expirydateoptional",
        ].includes(key)
    ) {
        return "expiration";
    }

    return "";
}

function isImportYes(value: unknown) {
    const text = cleanImportCell(value).toLowerCase();
    return ["yes", "y", "true", "1"].includes(text);
}

function splitImportList(value: unknown) {
    return cleanImportCell(value)
        .split(",")
        .map((part) => part.trim())
        .filter(Boolean);
}

function variantFieldsAndValuesToObject(
    fieldsValue: unknown,
    valuesValue: unknown
): Record<string, string> {
    const fields = splitImportList(fieldsValue).map((field) =>
        field.toLowerCase()
    );
    const values = splitImportList(valuesValue);

    if (fields.length === 0 && values.length === 0) return {};

    if (fields.length !== values.length) {
        throw new Error(
            "Variant Fields and Variant Values must have the same number of comma-separated entries."
        );
    }

    return Object.fromEntries(
        fields
            .map((field, index) => [field, values[index] || ""])
            .filter(([field, value]) => Boolean(field && value))
    );
}

function legacyVariantTextToValues(value: unknown): Record<string, string> {
    const parts = cleanImportCell(value)
        .split(/[,/|]/g)
        .map((part) => part.trim())
        .filter(Boolean);

    return Object.fromEntries(
        parts.map((part, index) => [`option${index + 1}`, part])
    );
}

function formatImportDateParts(year: number, month: number, day: number) {
    const candidate = new Date(year, month - 1, day);

    if (
        candidate.getFullYear() !== year ||
        candidate.getMonth() !== month - 1 ||
        candidate.getDate() !== day
    ) {
        return "";
    }

    return `${String(year).padStart(4, "0")}-${String(month).padStart(
        2,
        "0"
    )}-${String(day).padStart(2, "0")}`;
}

function parseImportDate(value: unknown) {
    if (value instanceof Date && !Number.isNaN(value.getTime())) {
        return formatImportDateParts(
            value.getFullYear(),
            value.getMonth() + 1,
            value.getDate()
        );
    }

    if (typeof value === "number" && Number.isFinite(value)) {
        const parsed = XLSX.SSF.parse_date_code(value);

        if (parsed) {
            return formatImportDateParts(parsed.y, parsed.m, parsed.d);
        }
    }

    const text = cleanImportCell(value);

    if (!text) return "";

    const isoMatch = text.match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);

    if (isoMatch) {
        return formatImportDateParts(
            Number(isoMatch[1]),
            Number(isoMatch[2]),
            Number(isoMatch[3])
        );
    }

    const dayFirstMatch = text.match(/^(\d{1,2})[/-](\d{1,2})[/-](\d{4})$/);

    if (dayFirstMatch) {
        return formatImportDateParts(
            Number(dayFirstMatch[3]),
            Number(dayFirstMatch[2]),
            Number(dayFirstMatch[1])
        );
    }

    const parsedDate = new Date(text);

    if (Number.isNaN(parsedDate.getTime())) {
        throw new Error(
            `Invalid expiration date "${text}". Use YYYY-MM-DD or DD/MM/YYYY.`
        );
    }

    return formatImportDateParts(
        parsedDate.getFullYear(),
        parsedDate.getMonth() + 1,
        parsedDate.getDate()
    );
}

function recalculateImportProduct(product: ImportPreviewProduct): ImportPreviewProduct {
    const variants = product.variants || [];

    if (!product.hasVariants || variants.length === 0) {
        return {
            ...product,
            stock: Number(product.stock || 0),
            alertLevel: Number(product.alertLevel || 0),
            originalPrice: Number(product.originalPrice || 0),
            salesPrice: Number(product.salesPrice || 0),
            expirationDate: product.expirationDate || null,
            variants: [],
        };
    }

    const stock = variants.reduce(
        (sum, variant) => sum + Number(variant.stock || 0),
        0
    );

    const alertLevel = variants.reduce(
        (sum, variant) => sum + Number(variant.alertLevel || 0),
        0
    );

    const originalPrices = variants.map((variant) =>
        Number(variant.originalPrice || 0)
    );

    const salesPrices = variants.map((variant) =>
        Number(variant.salesPrice || 0)
    );

    return {
        ...product,
        stock,
        alertLevel,
        originalPrice: originalPrices.length ? Math.min(...originalPrices) : 0,
        salesPrice: salesPrices.length ? Math.min(...salesPrices) : 0,
        expirationDate: null,
        variants,
    };
}

/* COMPLETE THREE-SHEET TEMPLATE: legacy import parsing remains unchanged below. */
function importColumnKey(value: unknown) {
    return cleanImportCell(value).toLowerCase().replace(/[^a-z0-9]/g, "");
}

function requiredImportNumber(value: unknown, field: string, row: number, integer = false) {
    if (value === "" || value === null || value === undefined) {
        throw new Error(`Row ${row}: ${field} is required.`);
    }
    const raw = String(value).replace(/[₱,\s]/g, "").trim();
    if (!/^(?:\d+)(?:\.\d+)?$/.test(raw)) {
        throw new Error(`Row ${row}: ${field} must be a nonnegative number.`);
    }
    const parsed = Number(raw);
    if (!Number.isFinite(parsed) || parsed < 0 || (integer && !Number.isInteger(parsed))) {
        throw new Error(`Row ${row}: ${field} must be ${integer ? "a whole nonnegative number" : "nonnegative"}.`);
    }
    return parsed;
}

function importMoney(value: number) {
    return Math.round((value + Number.EPSILON) * 100) / 100;
}

function newImportSheetReader(sheet: XLSX.WorkSheet, sheetName: string, required: string[]) {
    const rows = XLSX.utils.sheet_to_json<unknown[]>(sheet, { header: 1, raw: true, defval: "" });
    const headerRowIndex = rows.findIndex(row => {
        const keys = row.map(importColumnKey);
        return required.every(key => keys.includes(key));
    });
    if (headerRowIndex < 0) {
        throw new Error(`${sheetName}: missing required columns: ${required.join(", ")}.`);
    }
    const headerLookup = new Map<string, number>();
    rows[headerRowIndex].forEach((value, index) => headerLookup.set(importColumnKey(value), index));
    const get = (row: unknown[], header: string) => {
        const index = headerLookup.get(importColumnKey(header));
        return index === undefined ? "" : row[index];
    };
    return { rows, headerRowIndex, get };
}

function parseNewVariantDetails(value: unknown, rowNumber: number) {
    const text = cleanImportCell(value);
    const location = `PRODUCTS AND VARIANTS · D${rowNumber} (Variant Details)`;
    const example = 'Color: Blue; Size: Small';
    if (!text) throw new Error(`${location}: Required when Has Variants is Yes. Example: ${example}`);
    // A semicolon separates attributes; a colon separates each attribute name/value.
    // Reject commas mistakenly used to separate attributes rather than importing a wrong variant.
    if (/,\s*[^,;:]+\s*:/.test(text)) {
        throw new Error(`${location}: Use a semicolon (;) between attributes, NOT a comma (,). Example: ${example}`);
    }
    const parsed: Record<string, string> = {};
    for (const pair of text.split(';')) {
        if (!pair.trim()) continue;
        const colon = pair.indexOf(':');
        if (colon < 1 || pair.indexOf(':', colon + 1) !== -1) {
            throw new Error(`${location}: Write each attribute as Name: Value and separate with ; Example: ${example}`);
        }
        const key = pair.slice(0, colon).trim().toLowerCase();
        const val = pair.slice(colon + 1).trim();
        if (!key || !val) throw new Error(`${location}: Attribute name and value cannot be blank. Example: ${example}`);
        if (parsed[key]) throw new Error(`${location}: '${key}' was entered twice. Enter each attribute name only once.`);
        parsed[key] = val;
    }
    if (!Object.keys(parsed).length) throw new Error(`${location}: No variant attributes entered. Example: ${example}`);
    return parsed;
}

function importVariantSignature(value: Record<string, string>) {
    return Object.entries(value)
        .map(([key, val]) => [key.toLowerCase().trim(), val.toLowerCase().trim()])
        .sort(([a], [b]) => a.localeCompare(b))
        .map(([key, val]) => `${key}:${val}`)
        .join("|");
}

function importPricingDetails(get: (row: unknown[], header: string) => unknown, row: unknown[], rowNumber: number, cost: number) {
    const methodName = cleanImportCell(get(row, "Pricing Method")).toLowerCase();
    if (methodName !== "markup" && methodName !== "manual") {
        throw new Error(`Row ${rowNumber}: Pricing Method must be Markup or Manual.`);
    }
    const markupRaw = get(row, "Markup (%)");
    const manualRaw = get(row, "Manual Selling Price (₱)");
    const displayedAuto = get(row, "Selling Price (Auto)");
    if (methodName === "markup") {
        const pct = requiredImportNumber(markupRaw, "Markup (%)", rowNumber);
        const price = importMoney(cost * (1 + pct / 100));
        if (displayedAuto !== "" && importMoney(parseImportNumber(displayedAuto)) !== price) {
            throw new Error(`Row ${rowNumber}: the automatic selling price does not match the markup calculation.`);
        }
        return { pricingMethod: "markup" as const, markupPercentage: pct, salesPrice: price };
    }
    const price = requiredImportNumber(manualRaw, "Manual Selling Price (₱)", rowNumber);
    if (displayedAuto !== "" && importMoney(parseImportNumber(displayedAuto)) !== importMoney(price)) {
        throw new Error(`Row ${rowNumber}: the automatic selling price does not match the manual selling price.`);
    }
    return { pricingMethod: "manual" as const, markupPercentage: null, salesPrice: importMoney(price) };
}

async function parseCompleteImportFile(
    workbook: XLSX.WorkBook, storeId: string, branchId: string, branchName: string | null
): Promise<ImportPreviewProduct[]> {
    const productsSheet = workbook.Sheets["PRODUCTS AND VARIANTS"];
    const purchasesSheet = workbook.Sheets["PURCHASE DETAILS"];
    if (!productsSheet || !purchasesSheet) {
        throw new Error('The workbook must have "PRODUCTS AND VARIANTS" and "PURCHASE DETAILS" sheets.');
    }
    // Product rows no longer require user-entered Purchase Ref values.
    // Older three-sheet files with that column remain supported.
    const p = newImportSheetReader(productsSheet, "PRODUCTS AND VARIANTS", ["productname", "category", "hasvariants", "variantdetails", "stock", "reorderpoint", "costprice", "pricingmethod"]);
    const byName = new Map<string, ImportPreviewProduct>();
    const variantSignatures = new Map<string, Set<string>>();
    const rows = p.rows.slice(p.headerRowIndex + 1);
    rows.forEach((row, idx) => {
        const rowNumber = p.headerRowIndex + idx + 2;
        const name = cleanImportCell(p.get(row, "Product Name"));
        const category = cleanImportCell(p.get(row, "Category"));
        // Ignore empty template rows even when Excel has cached formula results.
        const enteredFields = ["Product Name", "Category", "Has Variants", "Variant Details",
            "Stock", "Reorder Point", "Cost Price (₱)", "Pricing Method", "Markup (%)",
            "Manual Selling Price (₱)", "Expiration Date"];
        if (!enteredFields.some(header => cleanImportCell(p.get(row, header)) !== "")) return;
        if (!name || !category) throw new Error(`Row ${rowNumber}: Product Name and Category are required.`);
        const hasVariantValue = cleanImportCell(p.get(row, "Has Variants")).toLowerCase();
        if (!["yes", "no"].includes(hasVariantValue)) throw new Error(`Row ${rowNumber}: Has Variants must be Yes or No.`);
        const hasVariants = hasVariantValue === "yes";
        const stock = requiredImportNumber(p.get(row, "Stock"), "Stock", rowNumber, true);
        if (stock <= 0) {
            throw new Error(`PRODUCTS AND VARIANTS · E${rowNumber}: Stock must be greater than zero for a supplier-purchase import.`);
        }
        const alertLevel = requiredImportNumber(p.get(row, "Reorder Point"), "Reorder Point", rowNumber, true);
        const originalPrice = requiredImportNumber(p.get(row, "Cost Price (₱)"), "Cost Price", rowNumber);
        const price = importPricingDetails(p.get, row, rowNumber, originalPrice);
        const rawExpiration = p.get(row, "Expiration Date");
        const normalizedExpiration = parseImportDate(rawExpiration);
        if (cleanImportCell(rawExpiration) && !normalizedExpiration) {
            throw new Error(`PRODUCTS AND VARIANTS · L${rowNumber} (Expiration Date): Invalid date. Use YYYY-MM-DD, for example 2027-04-30.`);
        }
        const expirationDate = normalizedExpiration || null;
        const purchaseRef = cleanImportCell(p.get(row, "Purchase Ref"));
        const key = name.toLowerCase().replace(/\s+/g, " ");
        let product = byName.get(key);
        if (product && (product.category.toLowerCase() !== category.toLowerCase() ||
            product.hasVariants !== hasVariants || String(product.purchaseRef || "").toLowerCase() !== purchaseRef.toLowerCase())) {
            throw new Error(`Row ${rowNumber}: All rows for "${name}" must have the same category, variant setting, and Purchase Ref.`);
        }
        if (!product) {
            product = {
                tempId: `import-complete-${rowNumber}`, storeId: Number(storeId), branchId: Number(branchId), branchName,
                name, category, stock: 0, alertLevel: 0, originalPrice: 0, salesPrice: 0,
                hasVariants, variants: [], expirationDate: null, pricingMethod: "manual",
                markupPercentage: null, purchaseRef, purchase: null, importTemplateVersion: "complete",
            };
            byName.set(key, product);
        }
        if (!hasVariants) {
            if (cleanImportCell(p.get(row, "Variant Details"))) {
                throw new Error(`PRODUCTS AND VARIANTS · D${rowNumber}: Leave Variant Details empty when Has Variants is No.`);
            }
            if (product.stock || product.variants?.length || (product as any).__regularSeen) {
                throw new Error(`Row ${rowNumber}: Regular product "${name}" must appear only once.`);
            }
            (product as any).__regularSeen = true;
            Object.assign(product, { stock, alertLevel, originalPrice, salesPrice: price.salesPrice,
                expirationDate, pricingMethod: price.pricingMethod, markupPercentage: price.markupPercentage });
        } else {
            const variantValues = parseNewVariantDetails(p.get(row, "Variant Details"), rowNumber);
            const signature = importVariantSignature(variantValues);
            const seen = variantSignatures.get(key) ?? new Set<string>();
            if (seen.has(signature)) throw new Error(`Row ${rowNumber}: Duplicate variant combination in "${name}".`);
            seen.add(signature); variantSignatures.set(key, seen);
            (product.variants as PricedImportVariant[]).push({ variantValues, stock, alertLevel,
                originalPrice, salesPrice: price.salesPrice, expirationDate,
                pricingMethod: price.pricingMethod, markupPercentage: price.markupPercentage });
        }
    });
    const products = [...byName.values()].map(recalculateImportProduct);
    if (!products.length) throw new Error("PRODUCTS AND VARIANTS contains no products.");

    // One complete workbook represents ONE supplier purchase, with all products
    // and variants included automatically. No purchase reference or product-name
    // mapping is entered by the user.
    const pr = newImportSheetReader(purchasesSheet, "PURCHASE DETAILS",
        ["supplier", "purchasedate", "paymentmethod", "amountpaid"]);
    const purchaseHeaders = new Set(pr.rows[pr.headerRowIndex].map(importColumnKey));
    if (!purchaseHeaders.has("paymentduedate") && !purchaseHeaders.has("duedate")) {
        throw new Error('PURCHASE DETAILS must include "Payment Due Date".');
    }
    const inputHeaders = ["Supplier", "Supplier Invoice Number (Optional)", "Purchase Date",
        "Payment Method", "Amount Paid (₱)", "Payment Due Date", "Due Date",
        "Products Included", "Purchase Ref"];
    const filledRows = pr.rows.slice(pr.headerRowIndex + 1)
        .map((row, index) => ({ row, rowNumber: pr.headerRowIndex + index + 2 }))
        .filter(({row}) => inputHeaders.some(header => cleanImportCell(pr.get(row, header)) !== ""));
    if (filledRows.length !== 1) {
        const filledLocations = filledRows.map(item => item.rowNumber).join(', ') || 'none';
        throw new Error(`PURCHASE DETAILS: Exactly ONE purchase row is allowed (row 7). Found ${filledRows.length} filled purchase rows: ${filledLocations}. Clear any other purchase cells below row 7; use another Excel file for another purchase.`);
    }
    const {row, rowNumber} = filledRows[0];
    const supplier = cleanImportCell(pr.get(row, "Supplier"));
    const supplierInvoiceNumber = cleanImportCell(pr.get(row, "Supplier Invoice Number (Optional)")) || null;
    const purchaseDate = parseImportDate(pr.get(row, "Purchase Date"));
    const paymentMethod = cleanImportCell(pr.get(row, "Payment Method")).toLowerCase();
    const paymentDueDate = parseImportDate(pr.get(row,
        purchaseHeaders.has("paymentduedate") ? "Payment Due Date" : "Due Date")) || null;
    if (!supplier) throw new Error(`PURCHASE DETAILS · A${rowNumber}: Enter the Supplier name.`);
    if (!purchaseDate) throw new Error(`PURCHASE DETAILS · C${rowNumber}: Enter a valid Purchase Date (YYYY-MM-DD, e.g. 2026-10-09).`);
    if (!["cash", "credit"].includes(paymentMethod)) {
        throw new Error(`PURCHASE DETAILS · D${rowNumber}: Payment Method must be Cash or Credit.`);
    }
    const paidInput = pr.get(row, "Amount Paid (₱)");
    const amountPaid = paidInput === "" || paidInput === undefined || paidInput === null
        ? 0 : requiredImportNumber(paidInput, "Amount Paid", rowNumber);
    // Older templates can be imported only when all rows refer to one purchase;
    // legacy multi-purchase workbooks are rejected rather than silently merged.
    const productRefs = new Set(products.map(p => String(p.purchaseRef || "").trim().toLowerCase()).filter(Boolean));
    if (productRefs.size > 1) {
        throw new Error("This workbook contains multiple Purchase Refs. Import each supplier purchase in a separate Excel file.");
    }
    const oldSheetRef = cleanImportCell(pr.get(row, "Purchase Ref")).toLowerCase();
    if (productRefs.size === 1 && oldSheetRef && !productRefs.has(oldSheetRef)) {
        throw new Error("The old template's Purchase Ref does not match its product rows.");
    }
    const purchaseTotal = importMoney(products.reduce((sum, product) => sum + (
        product.hasVariants
            ? (product.variants || []).reduce((n, variant) => n + Number(variant.stock) * Number(variant.originalPrice), 0)
            : Number(product.stock) * Number(product.originalPrice)
    ), 0));
    if (products.some(product => Number(product.stock) <= 0)) {
        throw new Error("Each product in a supplier purchase must have initial stock greater than zero. Add zero-stock catalogue products through Add Product.");
    }
    let effectivePaid = importMoney(amountPaid);
    if (paymentMethod === "cash") {
        if (effectivePaid !== 0 && effectivePaid !== purchaseTotal) {
            throw new Error("For Cash, Amount Paid must equal the combined purchase total (or be left blank for automatic full payment).");
        }
        effectivePaid = purchaseTotal;
    } else {
        if (effectivePaid > purchaseTotal) throw new Error("Amount Paid cannot exceed the combined purchase total.");
        if (effectivePaid < purchaseTotal && !paymentDueDate) {
            throw new Error(`PURCHASE DETAILS · F${rowNumber}: Payment Due Date is required for unpaid Credit. Use YYYY-MM-DD.`);
        }
        if (paymentDueDate && paymentDueDate < purchaseDate) {
            throw new Error(`PURCHASE DETAILS · F${rowNumber}: Payment Due Date must be on or after Purchase Date.`);
        }
    }
    // The marker is only used for the per-product confirmation preview. The
    // server creates the actual PUR-###### purchase number after saving.
    const purchase: ImportPurchaseSummary = {
        purchaseRef: "SINGLE_FILE_PURCHASE", supplier, supplierInvoiceNumber,
        purchaseDate, paymentMethod: paymentMethod as "cash" | "credit",
        amountPaid: effectivePaid, paymentDueDate: paymentMethod === "cash" ? null : paymentDueDate,
        purchaseTotal, outstandingBalance: importMoney(Math.max(0, purchaseTotal - effectivePaid)),
    };
    products.forEach(product => { product.purchaseRef = purchase.purchaseRef; product.purchase = purchase; });
    return products;
}

async function parseImportFileToPreviewProducts({
                                                    file,
                                                    storeId,
                                                    branchId,
                                                    branchName,
                                                }: {
    file: File;
    storeId: string;
    branchId: string;
    branchName: string | null;
}): Promise<ImportPreviewProduct[]> {
    const buffer = await file.arrayBuffer();
    const workbook = XLSX.read(buffer, {
        type: "array",
        cellDates: true,
    });
    if (workbook.SheetNames.includes("PRODUCTS AND VARIANTS") ||
        workbook.SheetNames.includes("PURCHASE DETAILS")) {
        return parseCompleteImportFile(workbook, storeId, branchId, branchName);
    }

    const firstSheetName = workbook.SheetNames[0];

    if (!firstSheetName) {
        throw new Error("The uploaded file has no worksheet.");
    }

    const worksheet = workbook.Sheets[firstSheetName];

    const rows = XLSX.utils.sheet_to_json<unknown[]>(worksheet, {
        header: 1,
        raw: true,
        ["def" + "val"]: "",
    });

    const headerIndex = rows.findIndex((row) => {
        const headers = row.map(normalizeImportHeader);
        return headers.includes("product") && headers.includes("category");
    });

    if (headerIndex < 0) {
        throw new Error("Cannot find Product and Category headers in the file.");
    }

    const headerRow = rows[headerIndex];
    const headerMap: Partial<Record<string, number>> = {};

    headerRow.forEach((cell, index) => {
        const key = normalizeImportHeader(cell);
        if (key) headerMap[key] = index;
    });

    const getValue = (row: unknown[], key: string) => {
        const index = headerMap[key];
        return index === undefined ? "" : row[index];
    };

    const products: ImportPreviewProduct[] = [];
    const variantProducts = new Map<string, ImportPreviewProduct>();

    rows.slice(headerIndex + 1).forEach((row, rowIndex) => {
        const excelRowNumber = headerIndex + rowIndex + 2;
        const productName = cleanImportCell(getValue(row, "product"));
        const category = cleanImportCell(getValue(row, "category"));
        const variantFields = cleanImportCell(getValue(row, "variantFields"));
        const variantValuesText = cleanImportCell(getValue(row, "variantValues"));
        const legacyVariants = cleanImportCell(getValue(row, "legacyVariants"));

        const stock = parseImportNumber(getValue(row, "stock"));
        const alertLevel = parseImportNumber(getValue(row, "alert"));
        const originalPrice = parseImportNumber(getValue(row, "original"));
        const salesPrice = parseImportNumber(getValue(row, "sales"));
        const expirationDate = parseImportDate(getValue(row, "expiration"));

        const rowIsBlank =
            !productName &&
            !category &&
            !variantFields &&
            !variantValuesText &&
            !legacyVariants &&
            stock === 0 &&
            alertLevel === 0 &&
            originalPrice === 0 &&
            salesPrice === 0 &&
            !expirationDate;

        if (rowIsBlank) return;

        if (!productName || !category) {
            throw new Error(
                `Row ${excelRowNumber}: Product and Category are required.`
            );
        }

        const hasVariants =
            isImportYes(getValue(row, "hasVariants")) ||
            Boolean(variantFields || variantValuesText || legacyVariants);

        if (!hasVariants) {
            products.push({
                tempId: `import-${Date.now()}-${rowIndex}`,
                storeId: storeId ? Number(storeId) : null,
                branchId: Number(branchId),
                branchName,
                name: productName,
                category,
                stock,
                alertLevel,
                originalPrice,
                salesPrice,
                expirationDate: expirationDate || null,
                hasVariants: false,
                variants: [],
            });
            return;
        }

        let variantValues: Record<string, string>;

        try {
            variantValues =
                variantFields || variantValuesText
                    ? variantFieldsAndValuesToObject(
                        variantFields,
                        variantValuesText
                    )
                    : legacyVariantTextToValues(legacyVariants);
        } catch (error) {
            throw new Error(
                `Row ${excelRowNumber}: ${
                    error instanceof Error
                        ? error.message
                        : "Invalid variant information."
                }`
            );
        }

        if (Object.keys(variantValues).length === 0) {
            throw new Error(
                `Row ${excelRowNumber}: Variant Fields and Variant Values are required for variant products.`
            );
        }

        const groupKey = `${productName
            .toLowerCase()
            .replace(/\s+/g, " ")}|${category
            .toLowerCase()
            .replace(/\s+/g, " ")}`;

        let product = variantProducts.get(groupKey);

        if (!product) {
            product = {
                tempId: `import-${Date.now()}-${rowIndex}`,
                storeId: storeId ? Number(storeId) : null,
                branchId: Number(branchId),
                branchName,
                name: productName,
                category,
                stock: 0,
                alertLevel: 0,
                originalPrice: 0,
                salesPrice: 0,
                expirationDate: null,
                hasVariants: true,
                variants: [],
            };

            variantProducts.set(groupKey, product);
            products.push(product);
        }

        product.variants = [
            ...(product.variants || []),
            {
                variantValues,
                stock,
                alertLevel,
                originalPrice,
                salesPrice,
                expirationDate: expirationDate || null,
            },
        ];
    });

    return products
        .map(recalculateImportProduct)
        .filter((product) => product.name.trim() && product.category.trim());
}

function getSessionSnapshot() {
    if (typeof window === "undefined") {
        return {
            role: "" as InventoryRole,
            storeId: "",
            branchId: "",
            branchName: "",
            storeName: "Store Name",
        };
    }

    const role = (sessionStorage.getItem("role") || "").toLowerCase() as InventoryRole;

    const storeId =
        sessionStorage.getItem("store_id") ||
        sessionStorage.getItem("stocknbook_store_id") ||
        "";

    const branchId =
        sessionStorage.getItem("branch_id") ||
        sessionStorage.getItem("stocknbook_branch_id") ||
        "";

    const branchName =
        sessionStorage.getItem("branch_name") ||
        sessionStorage.getItem("stocknbook_branch_name") ||
        "";

    const storeName =
        sessionStorage.getItem("store_name") ||
        sessionStorage.getItem("stocknbook_store_name") ||
        "Store Name";

    return { role, storeId, branchId, branchName, storeName };
}

const LEGACY_VARIANT_KEY_MAP: Record<string, string> = {
    option1: "size",
    option2: "packaging",
    option3: "color",
    option4: "material",
    option5: "type",
};

function isLegacyVariantKey(key: string) {
    return /^option\d+$/i.test(String(key || "").trim());
}

function normalizeVariantKey(key: string) {
    const cleanKey = String(key || "").trim();
    const lowerKey = cleanKey.toLowerCase();

    return LEGACY_VARIANT_KEY_MAP[lowerKey] || lowerKey;
}

function normalizeVariantValuesForEdit(
    values: Record<string, string> | undefined
): Record<string, string> {
    const normalized: Record<string, string> = {};

    const entries = Object.entries(values || {}).sort(([keyA], [keyB]) => {
        const aIsLegacy = isLegacyVariantKey(keyA);
        const bIsLegacy = isLegacyVariantKey(keyB);

        if (aIsLegacy && !bIsLegacy) return 1;
        if (!aIsLegacy && bIsLegacy) return -1;

        return 0;
    });

    entries.forEach(([rawKey, rawValue]) => {
        const key = normalizeVariantKey(rawKey);
        const value = String(rawValue || "").trim();

        if (!key || !value) return;

        if (!normalized[key]) {
            normalized[key] = value;
        }
    });

    return normalized;
}

function normalizeVariantForSave(v: ProductFormVariant): ProductVariantSave {
    const normalizedValues = normalizeVariantValuesForEdit(v.variantValues);

    const variantValues = Object.fromEntries(
        Object.entries(normalizedValues)
            .map(([key, value]) => [key, String(value || "").trim()])
            .filter(([, value]) => value.length > 0)
    );

    return {
        ...(v.id ? { id: v.id } : {}),
        variantValues,
        stock: Number(v.stock || 0),
        alertLevel: Number(v.alertLevel || 0),
        originalPrice: Number(v.originalPrice || 0),
        salesPrice: Number(v.salesPrice || 0),
        expirationDate: v.expirationDate || null,
    };
}

function normalizeDuplicateText(value: unknown) {
    return String(value ?? "")
        .trim()
        .replace(/\s+/g, " ")
        .toLowerCase();
}

function getProductBranchId(value: unknown) {
    const parsed = Number(value);
    return Number.isFinite(parsed) ? parsed : 0;
}

function findExistingProductByName(
    productList: Product[],
    productName: string,
    branchId: string | number | null,
    excludeProductId?: number | null
) {
    const cleanName = normalizeDuplicateText(productName);
    const cleanBranchId = getProductBranchId(branchId);

    if (!cleanName || !cleanBranchId) return undefined;

    return productList.find((product) => {
        const sameName = normalizeDuplicateText(product.name) === cleanName;
        const sameBranch =
            getProductBranchId(product.branchId) === cleanBranchId;
        const notCurrentProduct =
            !excludeProductId || Number(product.id) !== Number(excludeProductId);

        return sameName && sameBranch && notCurrentProduct;
    });
}

function getVariantSignature(values: Record<string, string> | undefined) {
    const normalizedValues = normalizeVariantValuesForEdit(values);

    const entries = Object.entries(normalizedValues)
        .map(([key, value]) => [
            normalizeDuplicateText(key),
            normalizeDuplicateText(value),
        ])
        .filter(([, value]) => value.length > 0)
        .sort(([keyA, valueA], [keyB, valueB]) => {
            const keyCompare = keyA.localeCompare(keyB);
            return keyCompare !== 0 ? keyCompare : valueA.localeCompare(valueB);
        });

    if (entries.length === 0) return "";

    return entries.map(([key, value]) => `${key}:${value}`).join("|");
}

function getVariantDisplayName(values: Record<string, string> | undefined) {
    return (
        Object.values(normalizeVariantValuesForEdit(values))
            .map((value) => String(value || "").trim())
            .filter(Boolean)
            .join(", ") || "Unnamed variant"
    );
}

function getDuplicateVariantError(
    productName: string,
    variantList: ProductVariantSave[]
) {
    const seen = new Map<string, string>();

    for (const variant of variantList) {
        const signature = getVariantSignature(variant.variantValues);
        if (!signature) continue;

        const displayName = getVariantDisplayName(variant.variantValues);

        if (seen.has(signature)) {
            return `❌ Variant "${displayName}" already exists in ${productName}.`;
        }

        seen.set(signature, displayName);
    }

    return "";
}

function getImportDuplicateError(
    importProducts: ImportPreviewProduct[],
    existingProducts: Product[]
) {
    const seenImportProducts = new Map<string, string>();

    for (const product of importProducts) {
        const productData = recalculateImportProduct(product);
        const cleanName = productData.name.trim();
        const branchId = getProductBranchId(productData.branchId);
        const importKey = `${branchId}|${normalizeDuplicateText(cleanName)}`;

        const existingProduct = findExistingProductByName(
            existingProducts,
            cleanName,
            branchId
        );

        if (existingProduct) {
            return `❌ Product "${cleanName}" already exists in this branch.`;
        }

        if (seenImportProducts.has(importKey)) {
            return `❌ Product "${cleanName}" is duplicated in the Excel file.`;
        }

        seenImportProducts.set(importKey, cleanName);

        if (productData.hasVariants) {
            const duplicateVariantError = getDuplicateVariantError(
                cleanName,
                productData.variants || []
            );

            if (duplicateVariantError) return duplicateVariantError;
        }
    }

    return "";
}

export function useInventoryController() {
    const session = getSessionSnapshot();

    const [formMode, setFormMode] = useState<"product" | "category">("product");

    const [products, setProducts] = useState<Product[]>([]);
    // Staff sales view needs a real product-loading and error state.
    const [productsLoading, setProductsLoading] = useState(true);
    const [productsError, setProductsError] = useState<string | null>(null);
    const [manualCategories, setManualCategories] = useState<Category[]>([]);
    const [branches, setBranches] = useState<Branch[]>([]);
    const [packages, setPackages] = useState<any[]>([]);

    const [storeName] = useState(session.storeName);
    const [storeId] = useState(session.storeId);
    const [role] = useState<InventoryRole>(session.role);
    const [assignedBranchId] = useState(session.branchId);
    const [assignedBranchName] = useState(session.branchName);

    const [search, setSearch] = useState("");
    const [selectedCategory, setSelectedCategory] = useState("All");
    const [selectedBranchId, setSelectedBranchId] = useState("");

    const [showForm, setShowForm] = useState(false);
    const [editingId, setEditingId] = useState<number | null>(null);

    const [name, setName] = useState("");
    const [category, setCategory] = useState("");
    const [stock, setStock] = useState("");
    const [alertLevel, setAlertLevel] = useState("");
    const [originalPrice, setOriginalPrice] = useState("");
    const [salesPrice, setSalesPrice] = useState("");

    const [hasVariants, setHasVariants] = useState(false);
    const [variants, setVariants] = useState<ProductFormVariant[]>([]);

    const [productBranchId, setProductBranchId] = useState(
        session.role === "manager" || session.role === "staff" ? session.branchId : ""
    );

    const [editingCategory, setEditingCategory] = useState<string | null>(null);
    const [editCategoryValue, setEditCategoryValue] = useState("");

    const [showDeleteProductDialog, setShowDeleteProductDialog] = useState(false);
    const [productToDelete, setProductToDelete] = useState<Product | null>(null);

    const [showConfirmProductSaveDialog, setShowConfirmProductSaveDialog] =
        useState(false);
    const [pendingProductSave, setPendingProductSave] =
        useState<PendingProductSave | null>(null);

    const [showImportDialog, setShowImportDialog] = useState(false);
    const [showImportConfirmDialog, setShowImportConfirmDialog] = useState(false);
    const [selectedImportFile, setSelectedImportFile] = useState<File | null>(null);
    const [importPreviewProducts, setImportPreviewProducts] = useState<ImportPreviewProduct[]>([]);
    const [isImporting, setIsImporting] = useState(false);

    const isOwner = role === "owner";
    const isBranchUser = role === "manager" || role === "staff";

    const loadProducts = useCallback(async () => {
        const token = sessionStorage.getItem("token");

        if (!token) {
            setProducts([]);
            setProductsError("Session expired. Please sign in again.");
            setProductsLoading(false);
            return;
        }

        const payload: Record<string, unknown> = {
            action: "get_products",
            include_variants: true,
        };

        if (storeId) payload.store_id = Number(storeId);
        if (isBranchUser && assignedBranchId) payload.branch_id = Number(assignedBranchId);

        try {
            const res = await fetch("/api/products", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${token}`,
                },
                body: JSON.stringify(payload),
            });

            const { data } = await safeParseResponse<ProductsApiResponse>(res);
            if (!res.ok || data.success === false || !Array.isArray(data.products)) {
                setProducts([]);
                setProductsError(getApiErrorMessage(data, "Failed to load inventory products."));
                return;
            }
            setProducts(data.products.map(normalizeProduct));
            setProductsError(null);
        } catch (error) {
            setProducts([]);
            setProductsError(error instanceof Error ? error.message : "Failed to load inventory products.");
        } finally {
            // Initial fetch drives Staff Inventory skeleton; later refreshes keep
            // the existing UI visible instead of flashing a full-page skeleton.
            setProductsLoading(false);
        }
    }, [assignedBranchId, isBranchUser, storeId]);

    const loadCategories = useCallback(async () => {
        const token = sessionStorage.getItem("token");

        if (!token) {
            setManualCategories([]);
            return;
        }

        try {
            const res = await fetch("/api/categories", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${token}`,
                },
                body: JSON.stringify({
                    action: "get_categories",
                    ...(storeId ? { store_id: Number(storeId) } : {}),
                }),
            });

            const { data } = await safeParseResponse<CategoryApiResponse>(res);

            if (!res.ok) {
                console.warn(
                    "Categories fetch failed:",
                    getApiErrorMessage(data, "Failed to fetch categories")
                );
                setManualCategories([]);
                return;
            }

            setManualCategories(Array.isArray(data.categories) ? data.categories : []);
        } catch {
            setManualCategories([]);
        }
    }, [storeId]);

    const loadBranches = useCallback(async () => {
        const token = sessionStorage.getItem("token");

        if (!token) {
            setBranches([]);
            return;
        }

        try {
            const res = await fetch("/api/branches", {
                method: "GET",
                headers: { Authorization: `Bearer ${token}` },
            });

            const { data } = await safeParseResponse<BranchesApiResponse>(res);

            if (!res.ok || !Array.isArray(data.branches)) {
                setBranches([]);
                return;
            }

            const mapped = data.branches.map((b: any) => ({
                id: Number(b.id ?? b.branch_id ?? b.branchId),
                branchName: b.branchName ?? b.branch_name ?? b.name ?? "Unnamed Branch",
            }));

            setBranches(mapped.filter((b) => b.id));
        } catch {
            setBranches([]);
        }
    }, []);

    const loadPackages = useCallback(async () => {
        const token = sessionStorage.getItem("token");

        if (!token) {
            setPackages([]);
            return;
        }

        try {
            const res = await fetch("/api/packages", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${token}`,
                },
                body: JSON.stringify({
                    action: "get_packages",
                    ...(storeId ? { store_id: Number(storeId) } : {}),
                    ...(isBranchUser && assignedBranchId
                        ? { branch_id: Number(assignedBranchId) }
                        : {}),
                }),
            });

            const { data } = await safeParseResponse<any>(res);

            if (!res.ok || !Array.isArray(data.packages)) {
                setPackages([]);
                return;
            }

            setPackages(data.packages);
        } catch {
            setPackages([]);
        }
    }, [assignedBranchId, isBranchUser, storeId]);

    const refreshAll = useCallback(async () => {
        await Promise.all([
            loadProducts(),
            loadCategories(),
            loadBranches(),
            loadPackages(),
        ]);
    }, [loadBranches, loadCategories, loadProducts, loadPackages]);

    useEffect(() => {
        void refreshAll();
    }, [refreshAll]);

    const branchGroups = useMemo(() => {
        const groups: Record<string, Product[]> = {};

        products.forEach((product) => {
            const key = product.branchId ? String(product.branchId) : "unassigned";
            if (!groups[key]) groups[key] = [];
            groups[key].push(product);
        });

        return groups;
    }, [products]);

    const categories = useMemo(() => {
        const productCats = products.map((p) => p.category.trim());
        const manualCats = manualCategories.map((c) => c.categoryName.trim());

        return [...new Set([...productCats, ...manualCats])]
            .filter(Boolean)
            .sort((a, b) => a.localeCompare(b));
    }, [products, manualCategories]);

    const selectedBranch = useMemo(
        () => branches.find((b) => String(b.id) === selectedBranchId) || null,
        [branches, selectedBranchId]
    );

    const baseProducts = useMemo(() => {
        const sourceProducts = isOwner
            ? branchGroups[selectedBranchId] || []
            : products;

        return sourceProducts.map((p) => {
            const productPackageId =
                (p as any).packageId ?? (p as any).package_id ?? null;

            const matchedPackage = packages.find((pkg) => {
                const pkgId = pkg.id ?? pkg.package_id ?? pkg.packageId;
                return Number(pkgId) === Number(productPackageId);
            });

            return {
                ...p,
                packageId: productPackageId,
                packageName:
                    matchedPackage?.name ||
                    matchedPackage?.package_name ||
                    matchedPackage?.packageName ||
                    (p as any).packageName ||
                    (p as any).package_name ||
                    "",
            };
        });
    }, [branchGroups, isOwner, packages, products, selectedBranchId]);

    const filteredProducts = useMemo(() => {
        const q = search.trim().toLowerCase();

        return baseProducts.filter((p) => {
            const variantText =
                p.variants
                    ?.map((v) => Object.values(v.variantValues || {}).join(" "))
                    .join(" ")
                    .toLowerCase() || "";

            const matchesCategory = selectedCategory === "All" || p.category === selectedCategory;

            const matchesSearch =
                q.length === 0 ||
                p.name.toLowerCase().includes(q) ||
                p.category.toLowerCase().includes(q) ||
                (p.branchName || "").toLowerCase().includes(q) ||
                variantText.includes(q);

            return matchesCategory && matchesSearch;
        });
    }, [baseProducts, selectedCategory, search]);

    const filteredCategoriesForManage = useMemo(() => {
        const q = category.trim().toLowerCase();
        if (!q) return categories;
        return categories.filter((c) => c.toLowerCase().includes(q));
    }, [categories, category]);

    function clearProductForm() {
        setName("");
        setCategory("");
        setStock("");
        setAlertLevel("");
        setOriginalPrice("");
        setSalesPrice("");
        setHasVariants(false);
        setVariants([]);
        setProductBranchId(isBranchUser ? assignedBranchId : selectedBranchId || "");
    }

    function clearCategoryForm() {
        setCategory("");
        setEditingCategory(null);
        setEditCategoryValue("");
    }

    function openManageCategories() {
        clearCategoryForm();
        setFormMode("category");
        setShowForm(true);
    }

    function openAddProduct() {
        clearProductForm();
        setEditingId(null);
        setFormMode("product");
        setShowForm(true);
    }

    function openImportDialog() {
        setSelectedImportFile(null);
        setShowImportDialog(true);
    }

    function closeImportDialog() {
        setSelectedImportFile(null);
        setShowImportDialog(false);
        setShowImportConfirmDialog(false);
        setImportPreviewProducts([]);
    }

    async function ensureCategoriesExist(categoryNames: Array<string | null | undefined>) {
        const token = getTokenOrAlert();
        if (!token) return false;

        const uniqueCategories = Array.from(
            new Map(
                categoryNames
                    .map((value) => normalizeCat(value || ""))
                    .filter(Boolean)
                    .map((value) => [value.toLowerCase(), value])
            ).values()
        );

        if (uniqueCategories.length === 0) return true;

        const existingCategoryKeys = new Set(
            manualCategories.map((cat) =>
                normalizeCat(cat.categoryName).toLowerCase()
            )
        );

        const missingCategories = uniqueCategories.filter(
            (catName) => !existingCategoryKeys.has(catName.toLowerCase())
        );

        if (missingCategories.length === 0) return true;

        const createdCategories: Category[] = [];

        for (const catName of missingCategories) {
            try {
                const res = await fetch("/api/categories", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${token}`,
                    },
                    body: JSON.stringify({
                        action: "create_category",
                        categoryName: catName,
                        description: "",
                        ...(storeId ? { store_id: Number(storeId) } : {}),
                    }),
                });

                const { data } = await safeParseResponse<CategoryApiResponse>(res);

                if (!res.ok) {
                    const message = data?.error || "";

                    // If backend says it already exists, just continue.
                    if (/exist|duplicate/i.test(message)) {
                        continue;
                    }

                    alert(`❌ Failed to save category "${catName}".`);
                    return false;
                }

                const created = data.category ?? {
                    id: data.id ?? Date.now() + createdCategories.length,
                    categoryName: data.categoryName ?? catName,
                    description: "",
                };

                createdCategories.push(created);
            } catch {
                alert(`❌ Failed to save category "${catName}".`);
                return false;
            }
        }

        if (createdCategories.length > 0) {
            setManualCategories((prev) => {
                const existingKeys = new Set(
                    prev.map((cat) =>
                        normalizeCat(cat.categoryName).toLowerCase()
                    )
                );

                const nextCategories = createdCategories.filter(
                    (cat) =>
                        !existingKeys.has(
                            normalizeCat(cat.categoryName).toLowerCase()
                        )
                );

                return [...prev, ...nextCategories];
            });
        }

        await loadCategories();

        return true;
    }

    function getImportTargetBranch() {
        const targetBranchId = isBranchUser ? assignedBranchId : selectedBranchId;
        const branchLabel =
            branches.find((b) => String(b.id) === String(targetBranchId))?.branchName ||
            assignedBranchName ||
            null;

        return { targetBranchId, branchLabel };
    }

    async function importProductsFromExcel() {
        if (!selectedImportFile) {
            alert("❌ Please select an Excel file.");
            return;
        }

        const { targetBranchId, branchLabel } = getImportTargetBranch();

        if (!targetBranchId) {
            alert("❌ Please select a branch before importing.");
            return;
        }

        if (!storeId) {
            alert("❌ Missing store ID.");
            return;
        }

        try {
            setIsImporting(true);

            const previewProducts = await parseImportFileToPreviewProducts({
                file: selectedImportFile,
                storeId,
                branchId: targetBranchId,
                branchName: branchLabel,
            });

            // Excel bulk purchase imports must include supplier/payment details.
            // Leave the older CSV-only product import path unchanged.
            if (/\.(xlsx|xls)$/i.test(selectedImportFile.name) &&
                previewProducts.some(product => product.importTemplateVersion !== "complete")) {
                throw new Error("Use the new One Supplier / One Purchase Excel template with a PURCHASE DETAILS sheet. Each Excel file must contain exactly one supplier purchase.");
            }

            if (previewProducts.length === 0) {
                alert("❌ No valid products found in the file.");
                return;
            }

            const duplicateError = getImportDuplicateError(previewProducts, products);

            if (duplicateError) {
                alert(duplicateError);
                return;
            }

            setImportPreviewProducts(previewProducts);
            setShowImportDialog(false);
            setShowImportConfirmDialog(true);
        } catch (error) {
            console.error("Import preview failed:", error);
            alert(
                error instanceof Error
                    ? `❌ ${error.message}`
                    : "❌ Failed to preview import file."
            );
        } finally {
            setIsImporting(false);
        }
    }

    async function confirmImportProducts() {
        if (importPreviewProducts.length === 0) {
            alert("❌ No products to import.");
            return;
        }

        const duplicateError = getImportDuplicateError(importPreviewProducts, products);

        if (duplicateError) {
            alert(duplicateError);
            return;
        }

        const token = getTokenOrAlert();
        if (!token) return;

        const importCategoriesOk = await ensureCategoriesExist(
            importPreviewProducts.map((product) =>
                recalculateImportProduct(product).category
            )
        );

        if (!importCategoriesOk) return;

        try {
            setIsImporting(true);

            if (importPreviewProducts.some(product => product.importTemplateVersion === "complete")) {
                // Exactly one supplier purchase per file. The server saves all
                // products/variants, the purchase, and its payment atomically.
                const purchase = importPreviewProducts[0].purchase;
                if (!purchase || importPreviewProducts.some(product => product.purchase !== purchase)) {
                    alert("❌ Only one supplier purchase is allowed per Excel file.");
                    return;
                }
                const productsPayload = importPreviewProducts.map(product => {
                    const data = recalculateImportProduct(product);
                    return { ...data, purchaseRef: undefined, purchase: undefined,
                        importTemplateVersion: undefined };
                });
                const response = await fetch("/api/products", {
                    method: "POST",
                    headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
                    body: JSON.stringify({ action: "import_products_bulk", importMode: "single_purchase",
                        branch_id: Number(importPreviewProducts[0].branchId),
                        products: productsPayload,
                        purchase: { supplier: purchase.supplier, supplierInvoiceNumber: purchase.supplierInvoiceNumber,
                            purchaseDate: purchase.purchaseDate, paymentMethod: purchase.paymentMethod,
                            amountPaid: purchase.amountPaid, paymentDueDate: purchase.paymentDueDate } }),
                });
                const { data } = await safeParseResponse<ProductsApiResponse>(response);
                if (!response.ok || data?.success === false) {
                    alert(`❌ ${data?.error || `Bulk import failed (HTTP ${response.status})`}`);
                    return;
                }
                // Update the product number lookup immediately, as with Add Product.
                if (Array.isArray(data?.products)) {
                    const numbers = data.products
                        .map((product) => ({
                            id: Number(product.id),
                            productNumber: String((product as Product & { productNumber?: string | null; product_number?: string | null }).productNumber ?? (product as Product & { product_number?: string | null }).product_number ?? "").trim(),
                        }))
                        .filter((item) => Number.isInteger(item.id) && item.id > 0 && item.productNumber);
                    if (numbers.length > 0) {
                        window.dispatchEvent(new CustomEvent("stocknbook:created-product-numbers", { detail: numbers }));
                    }
                }
                await refreshAll();
                alert("✅ Products imported successfully.");
                closeImportDialog();
                return;
            }

            for (const product of importPreviewProducts) {
                const productData = recalculateImportProduct(product);

                if (!productData.name.trim() || !productData.category.trim()) {
                    alert("❌ Product name and category are required.");
                    return;
                }

                if (
                    productData.hasVariants &&
                    (!productData.variants || productData.variants.length === 0)
                ) {
                    alert(
                        `❌ ${productData.name} is marked as variant product but has no variants.`
                    );
                    return;
                }

                const serializedVariants = (productData.variants || []).map((variant) => ({
                    variantValues: variant.variantValues || {},
                    variant_values: variant.variantValues || {},
                    stock: Number(variant.stock || 0),
                    alertLevel: Number(variant.alertLevel || 0),
                    alert_level: Number(variant.alertLevel || 0),
                    originalPrice: Number(variant.originalPrice || 0),
                    original_price: Number(variant.originalPrice || 0),
                    salesPrice: Number(variant.salesPrice || 0),
                    sales_price: Number(variant.salesPrice || 0),
                    expirationDate: variant.expirationDate || null,
                    expiration_date: variant.expirationDate || null,
                }));

                const res = await fetch("/api/products", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${token}`,
                    },
                    body: JSON.stringify({
                        action: "create_product",
                        openingStock:true, // Legacy single-sheet imports have no supplier purchase details.
                        store_id: productData.storeId,
                        storeId: productData.storeId,
                        branch_id: Number(productData.branchId),
                        branchId: Number(productData.branchId),
                        name: productData.name,
                        category: productData.category,
                        stock: Number(productData.stock || 0),
                        alertLevel: Number(productData.alertLevel || 0),
                        alert_level: Number(productData.alertLevel || 0),
                        originalPrice: Number(productData.originalPrice || 0),
                        original_price: Number(productData.originalPrice || 0),
                        salesPrice: Number(productData.salesPrice || 0),
                        sales_price: Number(productData.salesPrice || 0),
                        expirationDate: productData.hasVariants
                            ? null
                            : productData.expirationDate || null,
                        expiration_date: productData.hasVariants
                            ? null
                            : productData.expirationDate || null,
                        hasVariants: productData.hasVariants,
                        has_variants: productData.hasVariants ? 1 : 0,
                        variants: productData.hasVariants ? serializedVariants : [],
                    }),
                });

                const { data } = await safeParseResponse<ProductsApiResponse>(res);

                if (!res.ok) {
                    alert(`❌ ${data?.error || `Failed to import ${productData.name}`}`);
                    return;
                }
            }

            await refreshAll();

            alert("✅ Products imported successfully.");
            closeImportDialog();
        } catch (error) {
            console.error("Import failed:", error);
            alert("❌ Failed to import products.");
        } finally {
            setIsImporting(false);
        }
    }

    function addVariantRow() {
        setVariants((prev) => [
            ...prev,
            {
                variantValues: {},
                stock: "",
                alertLevel: "",
                originalPrice: "",
                salesPrice: "",
                expirationDate: null,
            },
        ]);
    }

    function removeVariantRow(index: number) {
        setVariants((prev) => prev.filter((_, i) => i !== index));
    }

    function updateVariantValue(index: number, key: string, value: string) {
        setVariants((prev) =>
            prev.map((variant, i) =>
                i === index
                    ? {
                        ...variant,
                        variantValues: {
                            ...variant.variantValues,
                            [key]: value,
                        },
                    }
                    : variant
            )
        );
    }

    function updateVariantField(
        index: number,
        field: "stock" | "alertLevel" | "originalPrice" | "salesPrice",
        value: string
    ) {
        setVariants((prev) =>
            prev.map((variant, i) => (i === index ? { ...variant, [field]: value } : variant))
        );
    }

    function handleSubmitProduct(e: FormSubmitEvent) {
        e.preventDefault();

        const cleanName = name.trim();
        const cleanCategory = category.trim();

        if (!cleanName) {
            alert("❌ Please enter a product name.");
            return;
        }

        if (!cleanCategory) {
            alert("❌ Please select a category first.");
            return;
        }

        const targetBranchId = isBranchUser ? assignedBranchId : productBranchId;

        if (!targetBranchId) {
            alert("❌ Please select a branch for this product.");
            return;
        }

        const existingProduct = findExistingProductByName(
            products,
            cleanName,
            targetBranchId,
            editingId
        );

        if (existingProduct) {
            alert(`❌ Product "${cleanName}" already exists in this branch.`);
            return;
        }

        if (hasVariants && variants.length === 0) {
            alert("❌ Please add at least one variant.");
            return;
        }

        const cleanedVariants = variants.map(normalizeVariantForSave);

        if (hasVariants) {
            const hasInvalidVariant = cleanedVariants.some((variant) => {
                const values = Object.values(variant.variantValues || {})
                    .map((value) => String(value || "").trim())
                    .filter(Boolean);

                return values.length === 0;
            });

            if (hasInvalidVariant) {
                alert("❌ Each variant must have at least one value, like size or color.");
                return;
            }

            const duplicateVariantError = getDuplicateVariantError(
                cleanName,
                cleanedVariants
            );

            if (duplicateVariantError) {
                alert(duplicateVariantError);
                return;
            }
        }

        const variantStock = cleanedVariants.reduce((sum, v) => sum + Number(v.stock || 0), 0);
        const variantAlert = cleanedVariants.reduce((sum, v) => sum + Number(v.alertLevel || 0), 0);
        const firstVariant = cleanedVariants[0];

        const branchLabel =
            branches.find((b) => String(b.id) === String(targetBranchId))?.branchName ||
            assignedBranchName ||
            null;

        const after = {
            storeId: storeId ? Number(storeId) : null,
            branchId: Number(targetBranchId),
            branchName: branchLabel,
            name: cleanName,
            category: cleanCategory,
            stock: hasVariants ? variantStock : Number(stock || 0),
            alertLevel: hasVariants ? variantAlert : Number(alertLevel || 0),
            originalPrice: hasVariants ? Number(firstVariant?.originalPrice || 0) : Number(originalPrice || 0),
            salesPrice: hasVariants ? Number(firstVariant?.salesPrice || 0) : Number(salesPrice || 0),
            hasVariants,
            variants: hasVariants ? cleanedVariants : [],
        };

        if (editingId) {
            const before = products.find((p) => p.id === editingId);
            if (!before) return;
            setPendingProductSave({ mode: "edit", editingId, before, after });
        } else {
            setPendingProductSave({ mode: "add", data: after });
        }

        setShowConfirmProductSaveDialog(true);
    }

    async function confirmSaveProduct(
        productDataOverride?: ProductSaveWithPurchase
    ) {
        if (!pendingProductSave) return false;

        const token = getTokenOrAlert();
        if (!token) return false;

        const productData: ProductSaveWithPurchase =
            productDataOverride ??
            (pendingProductSave.mode === "edit"
                ? pendingProductSave.after
                : pendingProductSave.data);

        if (!productData.branchId) {
            alert("❌ Missing branch for product.");
            return false;
        }

        const categoriesOk = await ensureCategoriesExist([
            productData.category,
            ...(pendingProductSave.mode === "edit"
                ? [pendingProductSave.before.category]
                : []),
        ]);

        if (!categoriesOk) return false;

        const serializedVariants = (productData.variants || []).map((variant) => ({
            ...(variant.id ? { id: Number(variant.id) } : {}),
            variantValues: variant.variantValues || {},
            variant_values: variant.variantValues || {},
            stock: Number(variant.stock || 0),
            alertLevel: Number(variant.alertLevel || 0),
            alert_level: Number(variant.alertLevel || 0),
            originalPrice: Number(variant.originalPrice || 0),
            original_price: Number(variant.originalPrice || 0),
            salesPrice: Number(variant.salesPrice || 0),
            sales_price: Number(variant.salesPrice || 0),
            // Keep each variant's chosen pricing method when saving.
            ...(variant.pricingMethod !== undefined
                ? { pricingMethod: variant.pricingMethod }
                : {}),
            ...(variant.markupPercentage !== undefined
                ? { markupPercentage: variant.markupPercentage }
                : {}),
            expirationDate: variant.expirationDate || null,
            expiration_date: variant.expirationDate || null,
        }));

        const payload = {
            action: pendingProductSave.mode === "edit" ? "update_product" : "create_product",
            ...(pendingProductSave.mode === "edit" ? { id: pendingProductSave.editingId } : {}),
            store_id: productData.storeId,
            storeId: productData.storeId,
            branch_id: Number(productData.branchId),
            branchId: Number(productData.branchId),
            name: productData.name,
            category: productData.category,
            stock: productData.stock,
            alertLevel: productData.alertLevel,
            alert_level: productData.alertLevel,
            originalPrice: productData.originalPrice,
            original_price: productData.originalPrice,
            salesPrice: productData.salesPrice,
            sales_price: productData.salesPrice,
            // Forward the pricing selections and supplier purchase details from
            // ManagerInventory's Add/Edit dialog to the existing product API.
            ...(productData.pricingMethod !== undefined
                ? { pricingMethod: productData.pricingMethod }
                : {}),
            ...(productData.markupPercentage !== undefined
                ? { markupPercentage: productData.markupPercentage }
                : {}),
            ...(productData.initialPurchase !== undefined
                ? { initialPurchase: productData.initialPurchase }
                : {}),
            expirationDate: productData.hasVariants
                ? null
                : productData.expirationDate || null,
            expiration_date: productData.hasVariants
                ? null
                : productData.expirationDate || null,
            hasVariants: productData.hasVariants,
            has_variants: productData.hasVariants ? 1 : 0,
            variants: productData.hasVariants ? serializedVariants : [],
        };

        try {
            const res = await fetch("/api/products", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${token}`,
                },
                body: JSON.stringify(payload),
            });

            // The proxy may return an empty or non-JSON body on upstream errors.
            // Read a clone so safeParseResponse() still processes the real response.
            const errorBody = !res.ok
                ? await res.clone().text().catch(() => "")
                : "";
            const { data } = await safeParseResponse<ProductsApiResponse>(res);

            if (!res.ok || data?.success === false) {
                const detail = data?.error ||
                    (errorBody.trim() && !errorBody.trim().startsWith("<")
                        ? errorBody.trim().slice(0, 250)
                        : "");
                const message = detail ||
                    `Product API returned HTTP ${res.status}${res.statusText ? ` (${res.statusText})` : ""}. Check the Next.js server/Lambda logs.`;
                console.error("Save product failed:", {
                    httpStatus: res.status,
                    statusText: res.statusText,
                    serverMessage: detail || "(empty or non-JSON response)",
                });
                alert(`❌ ${message}`);
                return false;
            }

            // The create_product response already includes the actual Product No.
            // assigned and committed by the backend. Notify the manager inventory
            // lookup immediately so the new row never needs a browser refresh.
            if (pendingProductSave.mode === "add" && data?.product) {
                const persistedProduct = data.product as Product & {
                    productNumber?: string | null;
                    product_number?: string | null;
                };
                const createdId = Number(persistedProduct.id);
                const createdProductNumber = String(
                    persistedProduct.productNumber ??
                    persistedProduct.product_number ??
                    ""
                ).trim();

                if (Number.isInteger(createdId) && createdId > 0 && createdProductNumber) {
                    window.dispatchEvent(
                        new CustomEvent("stocknbook:created-product-numbers", {
                            detail: [{ id: createdId, productNumber: createdProductNumber }],
                        })
                    );
                }
            }

            await refreshAll();
            setSelectedCategory(productData.category);
            setPendingProductSave(null);
            setShowConfirmProductSaveDialog(false);
            clearProductForm();
            setEditingId(null);
            setShowForm(false);
            return true;
        } catch (error) {
            console.error("Save product request crashed:", error);
            alert(error instanceof Error ? `❌ ${error.message}` : "❌ Failed to save product");
            return false;
        }
    }

    function closeConfirmProductSaveDialog() {
        setPendingProductSave(null);
        setShowConfirmProductSaveDialog(false);
    }

    function handleEditProduct(p: Product) {
        setEditingId(p.id);
        setName(p.name);
        setCategory(p.category);
        setStock(String(p.stock));
        setAlertLevel(String(p.alertLevel));
        setOriginalPrice(String(p.originalPrice));
        setSalesPrice(String(p.salesPrice));
        setHasVariants(Boolean(p.hasVariants) || (Array.isArray(p.variants) && p.variants.length > 0));
        setProductBranchId(String(p.branchId || assignedBranchId || ""));

        setVariants(
            Array.isArray(p.variants)
                ? p.variants.map((v) => ({
                    id: v.id,
                    variantNumber: (v as any).variantNumber ?? null,
                    variantValues: normalizeVariantValuesForEdit(v.variantValues || {}),
                    stock: String(v.stock),
                    alertLevel: String(v.alertLevel),
                    originalPrice: String(v.originalPrice),
                    salesPrice: String(v.salesPrice),
                    expirationDate: v.expirationDate || null,
                }))
                : []
        );

        setFormMode("product");
        setShowForm(true);
    }

    function requestDeleteProduct(p: Product) {
        setProductToDelete(p);
        setShowDeleteProductDialog(true);
    }

    async function confirmDeleteProduct() {
        if (!productToDelete) return;

        const token = getTokenOrAlert();
        if (!token) return;

        try {
            const res = await fetch("/api/products", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${token}`,
                },
                body: JSON.stringify({
                    action: "delete_product",
                    id: productToDelete.id,
                    ...(productToDelete.branchId ? { branch_id: Number(productToDelete.branchId) } : {}),
                }),
            });

            const { data } = await safeParseResponse<ProductsApiResponse>(res);

            if (!res.ok) {
                alert(`❌ ${data?.error || "Failed to delete product"}`);
                return;
            }

            setProducts((prev) => prev.filter((p) => p.id !== productToDelete.id));
            setShowDeleteProductDialog(false);
            setProductToDelete(null);
        } catch {
            alert("❌ Failed to delete product");
        }
    }

    function closeDeleteProductDialog() {
        setShowDeleteProductDialog(false);
        setProductToDelete(null);
    }

    async function addCategoryNow(nextValue: string) {
        const token = getTokenOrAlert();
        if (!token) return;

        const next = normalizeCat(nextValue);
        if (!next) return;

        try {
            const res = await fetch("/api/categories", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${token}`,
                },
                body: JSON.stringify({
                    action: "create_category",
                    categoryName: next,
                    description: "",
                    ...(storeId ? { store_id: Number(storeId) } : {}),
                }),
            });

            const { data } = await safeParseResponse<CategoryApiResponse>(res);

            if (!res.ok) {
                alert(`❌ ${data?.error || "Failed to save category"}`);
                return;
            }

            const created = data.category ?? {
                id: data.id ?? Date.now(),
                categoryName: data.categoryName ?? next,
                description: "",
            };

            setManualCategories((prev) => {
                const exists = prev.some(
                    (c) =>
                        c.categoryName.trim().toLowerCase() ===
                        created.categoryName.trim().toLowerCase()
                );

                return exists ? prev : [...prev, created];
            });

            setSelectedCategory(created.categoryName);
            setCategory("");
        } catch {
            alert("❌ Failed to save category");
        }
    }

    async function updateCategoryNow(oldCat: string, nextValue: string) {
        const token = getTokenOrAlert();
        if (!token) return;

        const next = normalizeCat(nextValue);
        if (!next) return;

        const target = manualCategories.find((c) => c.categoryName === oldCat);

        if (!target) {
            alert("❌ Category ID not found");
            return;
        }

        try {
            const res = await fetch("/api/categories", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${token}`,
                },
                body: JSON.stringify({
                    action: "update_category",
                    category_id: target.id,
                    categoryName: next,
                    description: "",
                }),
            });

            const { data } = await safeParseResponse<CategoryApiResponse>(res);

            if (!res.ok) {
                alert(`❌ ${data?.error || "Failed to update category"}`);
                return;
            }

            setManualCategories((prev) =>
                prev.map((c) => (c.id === target.id ? { ...c, categoryName: next } : c))
            );

            setProducts((prev) =>
                prev.map((p) => (p.category === oldCat ? { ...p, category: next } : p))
            );

            if (selectedCategory === oldCat) setSelectedCategory(next);

            setEditingCategory(null);
            setEditCategoryValue("");
        } catch {
            alert("❌ Failed to update category");
        }
    }

    async function deleteCategoryNow(cat: string) {
        const stillHasProducts = products.some((p) => p.category === cat);

        if (stillHasProducts) {
            alert("❌ Cannot delete category with products.");
            return;
        }

        const token = getTokenOrAlert();
        if (!token) return;

        const target = manualCategories.find((c) => c.categoryName === cat);

        if (!target) {
            alert("❌ Category ID not found");
            return;
        }

        try {
            const res = await fetch("/api/categories", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${token}`,
                },
                body: JSON.stringify({
                    action: "delete_category",
                    category_id: target.id,
                }),
            });

            const { data } = await safeParseResponse<CategoryApiResponse>(res);

            if (!res.ok) {
                alert(`❌ ${data?.error || "Failed to delete category"}`);
                return;
            }

            setManualCategories((prev) => prev.filter((x) => x.id !== target.id));

            if (selectedCategory === cat) setSelectedCategory("All");
        } catch {
            alert("❌ Failed to delete category");
        }
    }

    return {
        formMode,
        setFormMode,
        productsLoading,
        productsError,

        products,
        setProducts,
        manualCategories,
        setManualCategories,
        branches,

        storeName,
        storeId,
        role,
        assignedBranchId,
        assignedBranchName,

        search,
        setSearch,
        selectedCategory,
        setSelectedCategory,
        selectedBranchId,
        setSelectedBranchId,

        showForm,
        setShowForm,
        editingId,

        name,
        setName,
        category,
        setCategory,
        stock,
        setStock,
        alertLevel,
        setAlertLevel,
        originalPrice,
        setOriginalPrice,
        salesPrice,
        setSalesPrice,

        hasVariants,
        setHasVariants,
        variants,
        setVariants,
        addVariantRow,
        removeVariantRow,
        updateVariantValue,
        updateVariantField,

        productBranchId,
        setProductBranchId,

        editingCategory,
        editCategoryValue,
        setEditCategoryValue,

        showDeleteProductDialog,
        productToDelete,
        showConfirmProductSaveDialog,
        pendingProductSave,

        showImportDialog,
        setShowImportDialog,
        selectedImportFile,
        setSelectedImportFile,
        isImporting,
        openImportDialog,
        closeImportDialog,
        importProductsFromExcel,
        showImportConfirmDialog,
        setShowImportConfirmDialog,
        importPreviewProducts,
        confirmImportProducts,

        isOwner,
        isBranchUser,

        branchGroups,
        categories,
        selectedBranch,
        baseProducts,
        filteredProducts,
        filteredCategoriesForManage,

        openManageCategories,
        openAddProduct,

        handleSubmitProduct,
        confirmSaveProduct,
        closeConfirmProductSaveDialog,

        handleEditProduct,
        requestDeleteProduct,
        confirmDeleteProduct,
        closeDeleteProductDialog,

        addCategoryNow,
        updateCategoryNow,
        deleteCategoryNow,

        refreshAll,
    };
}

export type InventoryController = ReturnType<typeof useInventoryController>;
