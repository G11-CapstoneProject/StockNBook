/* eslint-disable @typescript-eslint/no-require-imports */

const mysql = require("mysql2/promise");
const jwt = require("jsonwebtoken");
const fs = require("fs");
const JWT_SECRET = "stocknbook-secret-key";

const dbConfig = {
    host: "127.0.0.1",
    user: "root",
    password: "BTA5EYVWLfWcebF",
    database: "stocknbook",
    ssl: { rejectUnauthorized: false },
};

// Reuse database connections across warm requests. This avoids paying the
// TCP/TLS/database handshake cost for every dashboard API call.
const dbPool = mysql.createPool({
    ...dbConfig,
    waitForConnections: true,
    connectionLimit: 5,
    queueLimit: 0,
});


let bookingItemsCostSchemaCache = null;

async function getBookingItemsCostSchema(connection) {
    if (bookingItemsCostSchemaCache) {
        return bookingItemsCostSchemaCache;
    }

    const [columnRows] = await connection.query(`SHOW COLUMNS FROM booking_items`);
    const availableColumns = new Set(
        columnRows.map((row) => String(row.Field || row.field || "").toLowerCase())
    );

    bookingItemsCostSchemaCache = {
        quantityColumn: [
            "used_quantity",
            "booked_quantity",
            "quantity",
            "reserved_quantity",
        ].find((column) => availableColumns.has(column)) || null,
        hasUnitCost: availableColumns.has("unit_cost"),
    };

    return bookingItemsCostSchemaCache;
}

const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Content-Type": "application/json",
};

function response(statusCode, payload) {
    return {
        statusCode,
        headers,
        body: JSON.stringify(payload),
    };
}

function parseBody(event) {
    if (!event.body) return {};

    if (typeof event.body === "object") {
        return event.body;
    }

    try {
        return JSON.parse(event.body || "{}");
    } catch {
        return {};
    }
}

function toNumber(value, fallback = 0) {
    const num = Number(value ?? fallback);
    return Number.isFinite(num) ? num : fallback;
}

function normalizeDateFilter(value) {
    const text = String(value ?? "").trim();
    if (!text) return null;
    return /^\d{4}-\d{2}-\d{2}$/.test(text) ? text : null;
}

function safeParseJSON(value) {
    if (!value) return null;

    if (typeof value === "object") {
        return value;
    }

    try {
        return JSON.parse(value);
    } catch {
        return null;
    }
}

function cleanPackageName(value) {
    if (!value) return "";

    return String(value)
        .replace(/\s*-\s*₱?\s*[\d,]+(\.\d+)?\s*$/i, "")
        .trim();
}

function normalizeText(value) {
    return cleanPackageName(value).toLowerCase().trim();
}

function getPackageInput(body) {
    return (
        body.selectedPackage ||
        body.packageData ||
        body.package_json ||
        body.packageJSON ||
        body.package ||
        null
    );
}

function getPackageIdFromInput(packageInput, body) {
    if (body.package_id) return Number(body.package_id);
    if (body.packageId) return Number(body.packageId);

    if (packageInput && typeof packageInput === "object") {
        return Number(
            packageInput.id ||
            packageInput.package_id ||
            packageInput.packageId ||
            0
        );
    }

    return 0;
}

function getPackageNameFromInput(packageInput, body) {
    if (body.packageName) return cleanPackageName(body.packageName);
    if (body.package_name) return cleanPackageName(body.package_name);

    if (typeof body.package === "string") {
        return cleanPackageName(body.package);
    }

    if (packageInput && typeof packageInput === "object") {
        return cleanPackageName(
            packageInput.name ||
            packageInput.package_name ||
            packageInput.packageName ||
            packageInput.title ||
            ""
        );
    }

    return "";
}

function snapshotFromPackagePayload(packageInput) {
    const parsed = safeParseJSON(packageInput);

    if (!parsed || typeof parsed !== "object") return null;

    const name = cleanPackageName(
        parsed.name ||
        parsed.package_name ||
        parsed.packageName ||
        parsed.title ||
        ""
    );

    const packagePrice = toNumber(
        parsed.package_price ??
        parsed.packagePrice ??
        parsed.price ??
        parsed.package_price_amount ??
        0
    );

    const downPaymentAmount = toNumber(
        parsed.down_payment_amount ??
        parsed.downPaymentAmount ??
        parsed.required_down_payment ??
        parsed.requiredDownPayment ??
        0
    );

    if (!name && packagePrice <= 0) return null;

    return {
        id: parsed.id || parsed.package_id || parsed.packageId || null,
        name,
        price: packagePrice,
        package_price: packagePrice,
        down_payment_amount: downPaymentAmount,
        required_down_payment: downPaymentAmount,
        duration: parsed.duration || null,
        status: parsed.status || null,
        inclusions: parsed.inclusions || [],
    };
}

function packageSnapshotFromRow(row) {
    return {
        id: row.id,
        name: row.name,
        price: toNumber(row.package_price),
        package_price: toNumber(row.package_price),
        down_payment_amount: toNumber(row.down_payment_amount),
        required_down_payment: toNumber(row.down_payment_amount),
        duration: row.duration || null,
        status: row.status || null,
        inclusions: safeParseJSON(row.inclusions) || [],
    };
}

async function findPackageSnapshot(connection, options) {
    const {
        storeId,
        branchId,
        packageId,
        packageName,
        packageInput,
    } = options;

    if (packageId) {
        const [rows] = await connection.execute(
            `
                SELECT
                    id,
                    name,
                    package_price,
                    down_payment_amount,
                    duration,
                    status,
                    inclusions
                FROM packages
                WHERE id = ?
                  AND store_id = ?
                  AND (? IS NULL OR branch_id = ?)
                    LIMIT 1
            `,
            [
                Number(packageId),
                Number(storeId),
                branchId ? Number(branchId) : null,
                branchId ? Number(branchId) : null,
            ]
        );

        if (rows.length > 0) {
            return packageSnapshotFromRow(rows[0]);
        }
    }

    const cleanedName = normalizeText(packageName);

    if (cleanedName) {
        const [rows] = await connection.execute(
            `
                SELECT
                    id,
                    name,
                    package_price,
                    down_payment_amount,
                    duration,
                    status,
                    inclusions
                FROM packages
                WHERE store_id = ?
                  AND (? IS NULL OR branch_id = ?)
                ORDER BY created_at DESC
            `,
            [
                Number(storeId),
                branchId ? Number(branchId) : null,
                branchId ? Number(branchId) : null,
            ]
        );

        const matched = rows.find((row) => {
            return normalizeText(row.name) === cleanedName;
        });

        if (matched) {
            return packageSnapshotFromRow(matched);
        }
    }

    return snapshotFromPackagePayload(packageInput);
}

// Rental equipment is stored separately from consumable Sales booking_items.
// Quotes come from the database (never client-supplied prices). They are NOT revenue
// until Staff completes the physical rental and the allocation is returned.
function rentalDate(value, label) {
    const text = String(value ?? "").trim();
    if (!/^\d{4}-\d{2}-\d{2}$/.test(text) ||
        new Date(`${text}T00:00:00Z`).toISOString().slice(0, 10) !== text) {
        throw new Error(`${label} must be a valid YYYY-MM-DD date.`);
    }
    return text;
}
function rentalDays(from, to) {
    const days = Math.round((Date.parse(`${to}T00:00:00Z`) - Date.parse(`${from}T00:00:00Z`)) / 86400000) + 1;
    if (days < 1 || days > 30) throw new Error("Rental period must be from 1 to 30 calendar days.");
    return days;
}
function rentalMoneyCents(value) {
    const n = Number(value);
    if (!Number.isFinite(n) || n < 0 || !Number.isSafeInteger(Math.round(n * 100)))
        throw new Error("Invalid rental price in catalog.");
    return Math.round(n * 100);
}
function parseRentalSelection(raw) {
    if (raw == null) return [];
    if (!Array.isArray(raw) || raw.length > 30) throw new Error("Select at most 30 rental equipment types.");
    const seen = new Set();
    return raw.map(line => {
        const equipmentId = Number(line?.equipmentId);
        const quantity = Number(line?.quantity);
        if (!Number.isSafeInteger(equipmentId) || equipmentId <= 0 ||
            !Number.isSafeInteger(quantity) || quantity < 1 || quantity > 100000 || seen.has(equipmentId))
            throw new Error("Rental equipment selections must have unique IDs and valid quantities.");
        seen.add(equipmentId);
        return {equipmentId, quantity};
    });
}
async function saveRentalRequestLines(connection,{bookingId,storeId,branchId,reference,startDate,endDate,lines}) {
    if (!lines.length) return {amount:0,count:0};
    const days = rentalDays(startDate,endDate);
    let totalCents=0;
    // Read active catalog entries server-side; do not trust client-supplied amounts.
    for (const line of [...lines].sort((a,b)=>a.equipmentId-b.equipmentId)) {
        const [equipment] = await connection.execute(`SELECT id,name,rental_rate_per_day,total_units,maintenance_units,missing_units
            FROM rental_equipment WHERE id=? AND store_id=? AND branch_id=? AND archived_at IS NULL LIMIT 1`,
            [line.equipmentId,storeId,branchId]);
        if (!equipment.length) throw new Error("Selected rental equipment is unavailable in this branch.");
        const e=equipment[0];
        if (Number(e.total_units)-Number(e.maintenance_units)-Number(e.missing_units)<line.quantity)
            throw new Error(`${e.name}: selected quantity exceeds physical rental stock.`);
        const cents=rentalMoneyCents(e.rental_rate_per_day);
        if (cents<=0) throw new Error(`${e.name}: daily rental price has not been set.`);
        const lineCents=cents*line.quantity*days;
        if (!Number.isSafeInteger(lineCents)) throw new Error("Rental quotation is too large.");
        totalCents+=lineCents;
        await connection.execute(`INSERT INTO booking_rental_items
            (booking_id,store_id,branch_id,booking_reference,equipment_id,equipment_name,quantity,start_date,end_date,
             billable_days,daily_rate_snapshot,agreed_line_total)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`,
            [bookingId,storeId,branchId,reference,line.equipmentId,e.name,line.quantity,startDate,endDate,days,cents/100,lineCents/100]);
    }
    if (!Number.isSafeInteger(totalCents)) throw new Error("Rental quotation total is too large.");
    return {amount:totalCents/100,count:lines.length};
}
async function rentalQuoteTotal(connection,bookingId,storeId,branchId) {
    const [rows]=await connection.execute(`SELECT COALESCE(SUM(agreed_line_total),0) AS rentalTotal,COUNT(*) AS lineCount
      FROM booking_rental_items WHERE booking_id=? AND store_id=? AND branch_id=?`,[bookingId,storeId,branchId]);
    return {total:Number(rows[0].rentalTotal),count:Number(rows[0].lineCount)};
}
function rentalError(message) {const e=new Error(message);e.rentalValidation=true;return e;}
// The equipment row lock serializes reservations of one equipment type, including
// overlapping dates and different booking references. Everything runs in the
// same transaction as the booking's Confirmed/Cancelled status transition.
async function confirmRentalAllocations(connection,{bookingId,storeId,branchId,price}) {
    const [lines]=await connection.execute(`SELECT equipment_id AS equipmentId,quantity,
        DATE_FORMAT(start_date,'%Y-%m-%d') AS startDate,
        DATE_FORMAT(end_date,'%Y-%m-%d') AS endDate,
        booking_reference AS bookingReference,agreed_line_total AS lineTotal
        FROM booking_rental_items WHERE booking_id=? AND store_id=? AND branch_id=? ORDER BY equipment_id FOR UPDATE`,
        [bookingId,storeId,branchId]);
    if(!lines.length)return;
    const agreed=Number(price);
    const minimum=lines.reduce((sum,l)=>sum+Math.round(Number(l.lineTotal)*100),0)/100;
    if(!Number.isFinite(agreed)||agreed<minimum-0.005)
        throw rentalError(`Set an agreed booking price of at least ₱${minimum.toFixed(2)} before confirming this rental.`);
    for(const line of lines) {
        const [eq]=await connection.execute(`SELECT id,total_units,maintenance_units,missing_units FROM rental_equipment
            WHERE id=? AND store_id=? AND branch_id=? AND archived_at IS NULL FOR UPDATE`,
            [line.equipmentId,storeId,branchId]);
        if(!eq.length)throw rentalError("Rental equipment was archived. Update the request before confirming.");
        const from=String(line.startDate).slice(0,10),to=String(line.endDate).slice(0,10);
        const [existing]=await connection.execute(`SELECT quantity,
          DATE_FORMAT(start_date,'%Y-%m-%d') AS startDate,DATE_FORMAT(end_date,'%Y-%m-%d') AS endDate,status
          FROM rental_booking_allocations WHERE store_id=? AND branch_id=? AND equipment_id=?
          AND status IN ('reserved','checked_out') AND start_date<=? AND (end_date>=? OR status='checked_out')`,
            [storeId,branchId,line.equipmentId,to,from]);
        const dayParts=new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Manila',year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(new Date());
        const part=type=>dayParts.find(x=>x.type===type)?.value||'';
        const today=`${part('year')}-${part('month')}-${part('day')}`;
        const events=new Map();
        for(const a of existing){
            const first=String(a.startDate)>from?String(a.startDate):from;
            const lastDate=a.status==='checked_out'&&String(a.endDate)<today?today:String(a.endDate);
            const last=lastDate<to?lastDate:to;
            if(first>last)continue;
            events.set(first,(events.get(first)||0)+Number(a.quantity));
            const following=new Date(Date.parse(`${last}T00:00:00Z`)+86400000).toISOString().slice(0,10);
            events.set(following,(events.get(following)||0)-Number(a.quantity));
        }
        let active=0,peak=0;
        for(const [,change] of [...events].sort(([a],[b])=>a.localeCompare(b))) {active+=change;peak=Math.max(peak,active);}
        const physical=Number(eq[0].total_units)-Number(eq[0].maintenance_units)-Number(eq[0].missing_units);
        if(physical-peak<Number(line.quantity))throw rentalError(`Not enough rental equipment for ${from} to ${to}. Choose another date or reduce quantity.`);
        await connection.execute(`INSERT INTO rental_booking_allocations
            (store_id,branch_id,booking_reference,equipment_id,quantity,start_date,end_date,status,rental_charge_total)
            VALUES (?,?,?,?,?,?,?,'reserved',?)`,
            [storeId,branchId,line.bookingReference,line.equipmentId,line.quantity,from,to,line.lineTotal]);
    }
}
async function cancelRentalAllocations(connection,{bookingId,storeId,branchId}) {
    const [rows]=await connection.execute(`SELECT a.id,a.status FROM rental_booking_allocations a
      JOIN booking_rental_items r ON r.booking_reference=a.booking_reference AND r.equipment_id=a.equipment_id
          AND r.store_id=a.store_id AND r.branch_id=a.branch_id
      WHERE r.booking_id=? AND a.store_id=? AND a.branch_id=? FOR UPDATE`,[bookingId,storeId,branchId]);
    if(rows.some(r=>r.status==='checked_out'))
        throw rentalError("Receive the checked-out rental equipment before cancelling this booking.");
    if(rows.some(r=>r.status==='returned'))
        throw rentalError("Returned rentals already contain fulfilled charges; contact an administrator for refund adjustments.");
    for(const row of rows)if(row.status==='reserved')
        await connection.execute("UPDATE rental_booking_allocations SET status='cancelled' WHERE id=?",[row.id]);
}
async function requireRentalReturnBeforeCompletion(connection,{bookingId,storeId,branchId}) {
    const [rows]=await connection.execute(`SELECT a.status FROM rental_booking_allocations a
      JOIN booking_rental_items r ON r.booking_reference=a.booking_reference AND r.equipment_id=a.equipment_id
          AND r.store_id=a.store_id AND r.branch_id=a.branch_id
      WHERE r.booking_id=? AND a.store_id=? AND a.branch_id=?`,[bookingId,storeId,branchId]);
    if(rows.some(x=>x.status!=='returned'))throw rentalError("Receive and account for rented equipment before completing the booking.");
    const [requests]=await connection.execute(`SELECT COUNT(*) AS total FROM booking_rental_items
        WHERE booking_id=? AND store_id=? AND branch_id=?`,[bookingId,storeId,branchId]);
    if(Number(requests[0].total)>rows.length)throw rentalError("Rental allocation is missing. Confirm the booking correctly before completion.");
}

function getBookingItemsInput(body) {
    const rawItems =
        body.bookingItems ||
        body.booking_items ||
        body.selectedCustomItems ||
        body.customItems ||
        [];

    const parsed = safeParseJSON(rawItems);

    return Array.isArray(parsed) ? parsed : [];
}

function normalizeBookingItemsForSave(rawItems, options) {
    const {
        bookingId,
        storeId,
        branchId,
        sourceType,
        packageId = null,
    } = options;

    if (!Array.isArray(rawItems)) return [];

    return rawItems
        .map((item) => {
            const productId = Number(
                item.productId ||
                item.product_id ||
                item.id ||
                0
            );

            if (!Number.isInteger(productId) || productId <= 0) {
                return null;
            }

            const rawVariantId = item.variantId ?? item.variant_id ?? null;
            const variantId = rawVariantId ? Number(rawVariantId) : null;

            const displayName = String(
                item.displayName ||
                item.productName ||
                item.product_name ||
                item.item ||
                item.name ||
                ""
            ).trim();

            const productName = String(
                item.productName ||
                item.product_name ||
                item.item ||
                item.name ||
                displayName.split("—")[0] ||
                displayName
            ).trim();

            const variantName = String(
                item.variantName ||
                item.variant_name ||
                ""
            ).trim();

            const category = String(item.category || "").trim();

            const bookedQuantity = Math.max(
                1,
                Math.floor(
                    toNumber(
                        item.quantity ??
                        item.qty ??
                        item.bookedQuantity ??
                        item.booked_quantity ??
                        1,
                        1
                    )
                )
            );

            const unitPrice = toNumber(
                item.salesPrice ??
                item.sales_price ??
                item.unitPrice ??
                item.unit_price ??
                item.unitSalesPrice ??
                item.unit_sales_price ??
                0,
                0
            );

            return {
                bookingId,
                storeId,
                branchId,
                sourceType,
                packageId,
                productId,
                variantId,
                productName,
                variantName,
                category,
                bookedQuantity,
                unitPrice,
                estimatedSubtotal: unitPrice * bookedQuantity,
            };
        })
        .filter(Boolean);
}

async function insertBookingItems(connection, items) {
    if (!Array.isArray(items) || items.length === 0) return;

    const placeholders = items
        .map(() => "(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")
        .join(", ");

    const params = items.flatMap((item) => [
        item.bookingId,
        item.storeId,
        item.branchId,
        item.sourceType,
        item.packageId,

        item.productId,
        item.variantId,

        item.productName,
        item.variantName || null,
        item.category || null,

        item.bookedQuantity,
        0,
        0,
        0,

        item.unitPrice,
        item.estimatedSubtotal,
        0,

        "pending",
        null,
    ]);

    await connection.execute(
        `
            INSERT INTO booking_items
            (
                booking_id,
                store_id,
                branch_id,
                source_type,
                package_id,

                product_id,
                variant_id,

                product_name,
                variant_name,
                category,

                booked_quantity,
                reserved_quantity,
                used_quantity,
                restored_quantity,

                unit_price,
                estimated_subtotal,
                used_subtotal,

                inventory_status,
                notes
            )
            VALUES ${placeholders}
        `,
        params
    );
}


async function getBookingV2InventoryForUpdate(connection, storeId, branchId, productId, variantId) {
    const [rows] = await connection.execute(
        `SELECT id, store_id, branch_id, product_id, variant_id,
                quantity_on_hand, cost_price
         FROM branch_inventory
         WHERE store_id = ?
           AND branch_id = ?
           AND product_id = ?
           AND variant_id <=> ?
           AND status = 'active'
         LIMIT 1
         FOR UPDATE`,
        [storeId, branchId, productId, variantId || null]
    );
    return rows[0] || null;
}

async function consumeBookingV2Batches(connection, inventoryId, quantity) {
    let remaining = Math.max(0, Number(quantity || 0));
    if (remaining <= 0) return;

    const [batches] = await connection.execute(
        `SELECT id, remaining_quantity
         FROM inventory_batches
         WHERE branch_inventory_id = ? AND remaining_quantity > 0
         ORDER BY (expiration_date IS NULL) ASC,
                  expiration_date ASC,
                  received_at ASC,
                  id ASC
             FOR UPDATE`,
        [inventoryId]
    );

    for (const batch of batches) {
        if (remaining <= 0) break;
        const available = Math.max(0, Number(batch.remaining_quantity || 0));
        const take = Math.min(available, remaining);
        if (take <= 0) continue;

        await connection.execute(
            `UPDATE inventory_batches
             SET remaining_quantity = remaining_quantity - ?,
                 status = CASE WHEN remaining_quantity - ? <= 0 THEN 'depleted' ELSE status END,
                 updated_at = CURRENT_TIMESTAMP
             WHERE id = ?`,
            [take, take, batch.id]
        );
        remaining -= take;
    }

    if (remaining > 0) {
        throw new Error(
            `Database V2 batch balance is short by ${remaining} unit(s) for inventory #${inventoryId}. ` +
            `Run the V2 verification/backfill before changing booking inventory.`
        );
    }
}

async function addBookingReturnBatch(connection, inventoryRow, quantity, bookingId, bookingItemId) {
    const qty = Math.max(0, Number(quantity || 0));
    if (qty <= 0) return;

    const batchCode = `V2-BKG-RETURN-${bookingId}-${bookingItemId}-${inventoryRow.id}`.slice(0, 100);
    await connection.execute(
        `INSERT INTO inventory_batches
         (store_id, branch_id, branch_inventory_id, batch_code,
          received_quantity, remaining_quantity, unit_cost, received_at,
          expiration_date, status)
         VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, NULL, 'active')`,
        [
            inventoryRow.store_id,
            inventoryRow.branch_id,
            inventoryRow.id,
            batchCode,
            qty,
            qty,
            Number(inventoryRow.cost_price || 0),
        ]
    );
}

async function adjustBookingV2Inventory(connection, options) {
    const row = await getBookingV2InventoryForUpdate(
        connection,
        options.storeId,
        options.branchId,
        options.productId,
        options.variantId
    );

    if (!row) {
        throw new Error(
            `Database V2 inventory row is missing for product ${options.productId}` +
            `${options.variantId ? ` variant ${options.variantId}` : ""}. Run the V2 backfill/verification.`
        );
    }

    const delta = Number(options.quantityDelta || 0);
    const before = Number(row.quantity_on_hand || 0);
    const after = before + delta;

    if (after < 0) {
        throw new Error(
            `Database V2 stock mismatch for product ${options.productId}. Available: ${before}, needed: ${Math.abs(delta)}.`
        );
    }

    if (delta < 0) {
        await consumeBookingV2Batches(connection, row.id, Math.abs(delta));
    } else if (delta > 0) {
        await addBookingReturnBatch(
            connection,
            row,
            delta,
            options.bookingId,
            options.bookingItemId
        );
    }

    await connection.execute(
        `UPDATE branch_inventory
         SET quantity_on_hand = ?, updated_at = CURRENT_TIMESTAMP
         WHERE id = ?`,
        [after, row.id]
    );

    const actor = options.actor || { id: null, role: "SYSTEM", name: "StockNBook" };
    await connection.execute(
        `INSERT INTO inventory_movements
         (store_id, branch_id, branch_inventory_id, movement_type,
          quantity_delta, quantity_before, quantity_after,
          reference_type, reference_id, actor_id, actor_role, actor_name, notes)
         VALUES (?, ?, ?, ?, ?, ?, ?, 'BOOKING', ?, ?, ?, ?, ?)`,
        [
            options.storeId,
            options.branchId,
            row.id,
            options.movementType,
            delta,
            before,
            after,
            String(options.bookingId),
            actor.id ?? null,
            actor.role || null,
            actor.name || null,
            options.notes || null,
        ]
    );
}

async function reserveBookingInventory(connection, options) {
    const { bookingId, storeId, branchId, actor = null } = options;

    const params = [Number(bookingId), Number(storeId)];
    let branchFilter = "";

    if (branchId) {
        branchFilter = " AND branch_id = ?";
        params.push(Number(branchId));
    }

    const [items] = await connection.execute(
        `
            SELECT
                id,
                product_id,
                variant_id,
                product_name,
                variant_name,
                booked_quantity,
                reserved_quantity,
                inventory_status
            FROM booking_items
            WHERE booking_id = ?
              AND store_id = ?
                ${branchFilter}
          AND inventory_status = 'pending'
        FOR UPDATE
        `,
        params
    );

    let reservedCount = 0;

    for (const item of items) {
        const bookingItemId = Number(item.id);
        const productId = Number(item.product_id);
        const variantId = item.variant_id ? Number(item.variant_id) : null;
        const bookedQty = Number(item.booked_quantity || 0);
        const alreadyReserved = Number(item.reserved_quantity || 0);
        const qtyToReserve = bookedQty - alreadyReserved;

        if (!productId || qtyToReserve <= 0) continue;

        const itemLabel = item.variant_name
            ? `${item.product_name} — ${item.variant_name}`
            : item.product_name;

        if (variantId) {
            const [variantRows] = await connection.execute(
                `
                    SELECT stock
                    FROM product_variants
                    WHERE id = ?
                      AND product_id = ?
                        FOR UPDATE
                `,
                [variantId, productId]
            );

            if (!variantRows.length) {
                return {
                    ok: false,
                    error: `Variant stock record not found for ${itemLabel}.`,
                };
            }

            const currentStock = Number(variantRows[0].stock || 0);

            if (currentStock < qtyToReserve) {
                return {
                    ok: false,
                    error: `Not enough stock for ${itemLabel}. Available: ${currentStock}, needed: ${qtyToReserve}.`,
                };
            }

            await connection.execute(
                `
                    UPDATE product_variants
                    SET stock = stock - ?
                    WHERE id = ?
                      AND product_id = ?
                `,
                [qtyToReserve, variantId, productId]
            );

            await connection.execute(
                `
                    UPDATE products
                    SET stock = GREATEST(stock - ?, 0)
                    WHERE id = ?
                      AND store_id = ?
                `,
                [qtyToReserve, productId, storeId]
            );
        } else {
            const productParams = [productId, storeId];
            let productBranchFilter = "";

            if (branchId) {
                productBranchFilter = " AND branch_id = ?";
                productParams.push(Number(branchId));
            }

            const [productRows] = await connection.execute(
                `
                    SELECT stock
                    FROM products
                    WHERE id = ?
                      AND store_id = ?
                        ${productBranchFilter}
                FOR UPDATE
                `,
                productParams
            );

            if (!productRows.length) {
                return {
                    ok: false,
                    error: `Product stock record not found for ${itemLabel}.`,
                };
            }

            const currentStock = Number(productRows[0].stock || 0);

            if (currentStock < qtyToReserve) {
                return {
                    ok: false,
                    error: `Not enough stock for ${itemLabel}. Available: ${currentStock}, needed: ${qtyToReserve}.`,
                };
            }

            const updateParams = [qtyToReserve, productId, storeId];

            let updateBranchFilter = "";

            if (branchId) {
                updateBranchFilter = " AND branch_id = ?";
                updateParams.push(Number(branchId));
            }

            await connection.execute(
                `
                    UPDATE products
                    SET stock = stock - ?
                    WHERE id = ?
                      AND store_id = ?
                        ${updateBranchFilter}
                `,
                updateParams
            );
        }

        await adjustBookingV2Inventory(connection, {
            storeId,
            branchId,
            productId,
            variantId,
            quantityDelta: -qtyToReserve,
            movementType: "BOOKING_RESERVE",
            bookingId,
            bookingItemId,
            actor,
            notes: `Reserved ${qtyToReserve} unit(s) for ${itemLabel}.`,
        });

        await connection.execute(
            `
                UPDATE booking_items
                SET
                    reserved_quantity = booked_quantity,
                    inventory_status = 'reserved',
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
            `,
            [bookingItemId]
        );

        reservedCount += 1;
    }

    return {
        ok: true,
        reservedCount,
    };
}

function getUsedItemsInput(body) {
    const rawItems =
        body.usedItems ||
        body.used_items ||
        body.cancelItems ||
        body.cancel_items ||
        [];

    const parsed = safeParseJSON(rawItems);

    return Array.isArray(parsed) ? parsed : [];
}

function getUsedQuantityForItem(item, usedItems) {
    const matched = usedItems.find((usedItem) => {
        const usedBookingItemId = Number(
            usedItem.booking_item_id ||
            usedItem.bookingItemId ||
            usedItem.id ||
            0
        );

        return usedBookingItemId === Number(item.id);
    });

    if (!matched) return 0;

    return Math.max(
        0,
        Math.floor(
            toNumber(
                matched.used_quantity ??
                matched.usedQuantity ??
                matched.quantityUsed ??
                matched.qtyUsed ??
                0,
                0
            )
        )
    );
}

async function restoreBookingInventoryOnCancel(connection, options) {
    const { bookingId, storeId, branchId, usedItems = [], actor = null } = options;

    const params = [Number(bookingId), Number(storeId)];
    let branchFilter = "";

    if (branchId) {
        branchFilter = " AND branch_id = ?";
        params.push(Number(branchId));
    }

    const [items] = await connection.execute(
        `
            SELECT
                id,
                product_id,
                variant_id,
                product_name,
                variant_name,
                reserved_quantity,
                used_quantity,
                restored_quantity,
                unit_price,
                inventory_status
            FROM booking_items
            WHERE booking_id = ?
              AND store_id = ?
                ${branchFilter}
          AND inventory_status = 'reserved'
        FOR UPDATE
        `,
        params
    );

    let restoredCount = 0;
    let restoredQuantity = 0;
    let usedQuantity = 0;

    for (const item of items) {
        const bookingItemId = Number(item.id);
        const productId = Number(item.product_id);
        const variantId = item.variant_id ? Number(item.variant_id) : null;
        const reservedQty = Number(item.reserved_quantity || 0);
        const unitPrice = toNumber(item.unit_price, 0);

        if (!productId || reservedQty <= 0) continue;

        const usedQty = getUsedQuantityForItem(item, usedItems);

        const itemLabel = item.variant_name
            ? `${item.product_name} — ${item.variant_name}`
            : item.product_name;

        if (usedQty > reservedQty) {
            return {
                ok: false,
                error: `Used quantity for ${itemLabel} cannot exceed reserved quantity. Reserved: ${reservedQty}, used: ${usedQty}.`,
            };
        }

        const qtyToRestore = reservedQty - usedQty;

        if (qtyToRestore > 0) {
            if (variantId) {
                await connection.execute(
                    `
                        UPDATE product_variants
                        SET stock = stock + ?
                        WHERE id = ?
                          AND product_id = ?
                    `,
                    [qtyToRestore, variantId, productId]
                );

                await connection.execute(
                    `
                        UPDATE products
                        SET stock = stock + ?
                        WHERE id = ?
                          AND store_id = ?
                    `,
                    [qtyToRestore, productId, storeId]
                );
            } else {
                const updateParams = [qtyToRestore, productId, storeId];
                let updateBranchFilter = "";

                if (branchId) {
                    updateBranchFilter = " AND branch_id = ?";
                    updateParams.push(Number(branchId));
                }

                await connection.execute(
                    `
                        UPDATE products
                        SET stock = stock + ?
                        WHERE id = ?
                          AND store_id = ?
                            ${updateBranchFilter}
                    `,
                    updateParams
                );
            }
        }

        if (qtyToRestore > 0) {
            await adjustBookingV2Inventory(connection, {
                storeId,
                branchId,
                productId,
                variantId,
                quantityDelta: qtyToRestore,
                movementType: "BOOKING_RELEASE",
                bookingId,
                bookingItemId,
                actor,
                notes: `Released ${qtyToRestore} unused reserved unit(s) for ${itemLabel}.`,
            });
        }

        const nextInventoryStatus =
            usedQty <= 0
                ? "cancelled_restored"
                : qtyToRestore <= 0
                    ? "cancelled_used"
                    : "cancelled_partial_used";

        await connection.execute(
            `
                UPDATE booking_items
                SET
                    used_quantity = ?,
                    restored_quantity = ?,
                    used_subtotal = ?,
                    inventory_status = ?,
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
            `,
            [
                usedQty,
                qtyToRestore,
                unitPrice * usedQty,
                nextInventoryStatus,
                bookingItemId,
            ]
        );

        restoredCount += 1;
        restoredQuantity += qtyToRestore;
        usedQuantity += usedQty;
    }

    return {
        ok: true,
        restoredCount,
        restoredQuantity,
        usedQuantity,
    };
}

function getAuthHeader(event) {
    return event.headers?.Authorization || event.headers?.authorization || "";
}

// Resolve operational access from the current database row, not a cached browser permission.
// Keep legacy access keys compatible with existing Manager/Staff records.
function normalizeOperationalAccess(permissions, moduleName, role) {
    let values = permissions;
    if (typeof values === "string") {
        try { values = JSON.parse(values); } catch { values = {}; }
    }
    if (!values || typeof values !== "object" || Array.isArray(values)) values = {};

    const keys = moduleName === "bookings"
        ? ["bookings", "booking_access", "bookings_access"]
        : ["pos", "pos_access", "sales_access"];
    const selected = keys.find((key) => Object.prototype.hasOwnProperty.call(values, key));
    if (!selected) return role === "manager" ? "full" : "none";
    const access = values[selected];
    // The legacy Staff Bookings screen treated boolean true as view-only.
    if (moduleName === "bookings" && role === "staff" && access === true) return "view";
    if (access === true || access === 1 || access === "1" || access === "true" || access === "full") return "full";
    if (access === "view" || access === "view_only" || access === "viewOnly") return "view";
    return "none";
}

async function getOperationalAccess(connection, decoded, moduleName) {
    const role = String(decoded?.role || "").trim().toLowerCase();
    if (role === "owner") return "full";
    if (role !== "manager" && role !== "staff") return "none";

    const storeId = Number(decoded?.store_id);
    const branchId = Number(decoded?.branch_id);
    const employeeId = Number(role === "manager" ? decoded?.manager_id : decoded?.staff_id);
    if (![storeId, branchId, employeeId].every((id) => Number.isSafeInteger(id) && id > 0)) return "none";

    const table = role === "manager" ? "managers" : "staff";
    const [rows] = await connection.execute(
        `SELECT permissions FROM ${table} WHERE id = ? AND store_id = ? AND branch_id = ? AND LOWER(status) = 'active' LIMIT 1`,
        [employeeId, storeId, branchId]
    );
    if (!rows.length) return "none";
    return normalizeOperationalAccess(rows[0].permissions, moduleName, role);
}

function verifyProtectedStore(event) {
    const authHeader = getAuthHeader(event);

    if (!authHeader) {
        throw new Error("No token");
    }

    const token = authHeader.replace("Bearer ", "");
    const decoded = jwt.verify(token, JWT_SECRET);

    return {
        storeId: Number(decoded.store_id || decoded.storeId || 0),
        tokenRole: String(decoded.role || "").toLowerCase(),
        tokenBranchId: decoded.branch_id ? Number(decoded.branch_id) : null,
        decoded,
    };
}

function toSafeString(value, max = 255) {
    return String(value ?? "").trim().slice(0, max);
}

/*
 * The JWT issued at login only carries ids (store_id / manager_id /
 * staff_id) and an email — never a display name. To log a real,
 * human-readable employee_actions row we look the acting user's name up
 * from their own table using the id that's already in the token.
 */
async function getActingEmployee(connection, decoded, tokenRole, storeId) {
    const role = String(tokenRole || "").toLowerCase();

    if (role === "manager" && decoded?.manager_id) {
        const [rows] = await connection.execute(
            `SELECT manager_name FROM managers WHERE id = ? AND store_id = ? LIMIT 1`,
            [Number(decoded.manager_id), storeId]
        );

        return {
            id: Number(decoded.manager_id),
            name: toSafeString(rows[0]?.manager_name, 255) || "Manager",
            role: "Manager",
        };
    }

    if (role === "staff" && decoded?.staff_id) {
        const [rows] = await connection.execute(
            `SELECT staff_name FROM staff WHERE id = ? AND store_id = ? LIMIT 1`,
            [Number(decoded.staff_id), storeId]
        );

        return {
            id: Number(decoded.staff_id),
            name: toSafeString(rows[0]?.staff_name, 255) || "Staff",
            role: "Staff",
        };
    }

    if (role === "owner") {
        const [rows] = await connection.execute(
            `SELECT owner_name FROM stores WHERE id = ? LIMIT 1`,
            [storeId]
        );

        return {
            id: null,
            name: toSafeString(rows[0]?.owner_name, 255) || "Owner",
            role: "Owner",
        };
    }

    return { id: null, name: "Unknown", role: "Staff" };
}

/*
 * Writes one row to employee_actions. Called from inside the same DB
 * transaction as the booking action it's logging, so the log and the
 * action succeed or fail together.
 */
async function logEmployeeAction(connection, entry) {
    await connection.execute(
        `INSERT INTO employee_actions
         (store_id, branch_id, employee_id, employee_name, employee_role,
          module, reference_number, action, reference_id, details)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
            entry.storeId,
            entry.branchId ?? null,
            entry.employee.id,
            entry.employee.name,
            entry.employee.role,
            entry.module,
            entry.referenceNumber ?? null,
            entry.action,
            entry.referenceId ?? null,
            entry.details ?? null,
        ]
    );
}

function buildBookingReference(row, id) {
    return row?.booking_reference || `BKG-${String(id).padStart(6, "0")}`;
}

// Canonical booking statuses. Any casing/spacing variant coming from the
// frontend or already sitting in the DB gets mapped to one of these, so
// status-transition checks never fail due to a stray "confirmed" vs
// "Confirmed" mismatch.
const CANONICAL_BOOKING_STATUSES = [
    "Pending Review",
    "Confirmed",
    "Preparing",
    "Completed",
    "Cancelled",
];

function normalizeBookingStatus(value) {
    const clean = String(value ?? "").trim().toLowerCase();

    const match = CANONICAL_BOOKING_STATUSES.find(
        (canonical) => canonical.toLowerCase() === clean
    );

    if (match) return match;

    // Accept the common "canceled" (one L) spelling too.
    if (clean === "canceled") return "Cancelled";

    return null;
}

const packagePriceExpr = `
    COALESCE(
        NULLIF(bookings.package_price, 0),
        CAST(NULLIF(JSON_UNQUOTE(JSON_EXTRACT(bookings.package_json, '$.package_price')), '') AS DECIMAL(10,2)),
        CAST(NULLIF(JSON_UNQUOTE(JSON_EXTRACT(bookings.package_json, '$.price')), '') AS DECIMAL(10,2)),
        0
    )
`;

const requiredDownPaymentExpr = `
    COALESCE(
        NULLIF(bookings.required_down_payment, 0),
        CAST(NULLIF(JSON_UNQUOTE(JSON_EXTRACT(bookings.package_json, '$.down_payment_amount')), '') AS DECIMAL(10,2)),
        CAST(NULLIF(JSON_UNQUOTE(JSON_EXTRACT(bookings.package_json, '$.required_down_payment')), '') AS DECIMAL(10,2)),
        0
    )
`;

const totalPriceExpr = `
    CASE
        WHEN LOWER(COALESCE(bookings.booking_type, '')) LIKE '%custom%'
             OR COALESCE(bookings.custom_order, '') <> ''
        THEN COALESCE(NULLIF(bookings.agreed_price, 0), 0)
        ELSE ${packagePriceExpr}
    END
`;

const computedBalanceExpr = `
    CASE
        WHEN COALESCE(bookings.balance, 0) = 0
             AND COALESCE(bookings.amount_paid, 0) = 0
             AND ${totalPriceExpr} > 0
        THEN ${totalPriceExpr}
        ELSE COALESCE(bookings.balance, 0)
    END
`;

function bookingSelectFields() {
    return `
        bookings.id,
        bookings.branch_id              AS branchId,
        branches.branch_name            AS branchName,
        bookings.booking_reference      AS bookingReference,
        bookings.booking_type           AS bookingType,
        bookings.name,
        bookings.facebook_name          AS facebookName,
        bookings.phone,
        bookings.email,
        bookings.event_date             AS date,
        bookings.event_time             AS eventTime,
        bookings.event_type             AS eventType,
        bookings.package_name           AS package,
        bookings.custom_order           AS customOrder,
        bookings.theme,
        bookings.venue,
        bookings.notes,
        bookings.status,
        bookings.agreed_price,
        bookings.agreed_price           AS agreedPrice,
        ${packagePriceExpr}             AS package_price,
        ${packagePriceExpr}             AS packagePrice,
        ${requiredDownPaymentExpr}      AS required_down_payment,
        ${requiredDownPaymentExpr}      AS requiredDownPayment,
        COALESCE(bookings.amount_paid, 0) AS amount_paid,
        COALESCE(bookings.amount_paid, 0) AS amountPaid,
        ${computedBalanceExpr}          AS balance,
        COALESCE(bookings.payment_status, 'Unpaid') AS payment_status,
        COALESCE(bookings.payment_status, 'Unpaid') AS paymentStatus,
        bookings.package_json,
        bookings.created_at             AS createdAt
    `;
}

// Lightweight fields used by owner, manager, and staff dashboards.
// Do not include package JSON/payment calculations here because dashboards
// only need counts, package names, schedules, statuses, and branch details.
function dashboardBookingSelectFields() {
    return `
        bookings.id,
        bookings.branch_id         AS branchId,
        branches.branch_name       AS branchName,
        bookings.name,
        bookings.event_date        AS date,
        bookings.status,
        bookings.package_name      AS packageName,
        bookings.event_type        AS eventName,
        bookings.created_at        AS createdAt
    `;
}

// Fields used by the full Bookings screens. This avoids the very large
// package JSON expressions used by get_bookings while still returning the
// customer, schedule, branch, package, status, and payment values needed by
// owner, manager, and staff booking pages.
function bookingPageSelectFields() {
    return `
        bookings.id,
        bookings.branch_id                      AS branchId,
        branches.branch_name                    AS branchName,
        bookings.booking_reference              AS bookingReference,
        bookings.booking_type                   AS bookingType,
        bookings.name,
        bookings.facebook_name                  AS facebookName,
        bookings.phone,
        bookings.email,
        bookings.event_date                     AS date,
        bookings.event_time                     AS eventTime,
        bookings.event_type                     AS eventType,
        bookings.event_type                     AS eventName,
        bookings.package_name                   AS package,
        bookings.package_name                   AS packageName,
        bookings.custom_order                   AS customOrder,
        bookings.theme,
        bookings.venue,
        bookings.notes,
        bookings.status,
        COALESCE(bookings.agreed_price, 0)       AS agreed_price,
        COALESCE(bookings.agreed_price, 0)       AS agreedPrice,
        COALESCE(bookings.package_price, 0)      AS package_price,
        COALESCE(bookings.package_price, 0)      AS packagePrice,
        COALESCE(bookings.required_down_payment, 0) AS required_down_payment,
        COALESCE(bookings.required_down_payment, 0) AS requiredDownPayment,
        COALESCE(bookings.amount_paid, 0)        AS amount_paid,
        COALESCE(bookings.amount_paid, 0)        AS amountPaid,
        COALESCE(bookings.balance, 0)            AS balance,
        COALESCE(bookings.payment_status, 'Unpaid') AS payment_status,
        COALESCE(bookings.payment_status, 'Unpaid') AS paymentStatus,
        bookings.created_at                     AS createdAt
    `;
}


// Limit enforcement when paid access ends; existing records remain accessible.
// This duplicates the read-only eligibility rule from lambda-auth so a
// direct Lambda request cannot bypass the owner dashboard's plan limits.
async function effectiveSubscriptionLimit(connection, storeId, resourceColumn) {
    const allowed = new Set(['max_inventory', 'max_bookings']);
    if (!allowed.has(resourceColumn)) throw new Error('Unsupported plan limit');
    const [subRows] = await connection.execute(
        `SELECT p.max_inventory, p.max_bookings, p.price, sub.expires_at,
                LOWER(sub.status) AS status,
                CASE WHEN sub.expires_at IS NULL OR DATE(sub.expires_at) >= CURDATE()
             THEN 1 ELSE 0 END AS not_expired
         FROM subscriptions sub JOIN plans p ON p.id = sub.plan_id
         WHERE sub.store_id = ? ORDER BY sub.id DESC LIMIT 1`, [storeId]);
    const paid = subRows[0];
    let eligible = !!paid && ['active', 'expiring'].includes(paid.status) &&
        Number(paid.not_expired) === 1;
    if (paid && !eligible && ['active', 'expiring'].includes(paid.status) && Number(paid.price) > 0) {
        const [columns] = await connection.query('SHOW COLUMNS FROM payments');
        const available = new Set(columns.map((c) => c.Field));
        const dateColumn = ['created_at', 'submitted_at', 'payment_date'].find((name) => available.has(name));
        if (dateColumn) {
            const [graceRows] = await connection.execute(
                `SELECT id FROM payments WHERE store_id = ? AND UPPER(status) = 'PENDING'
                                           AND DATE(${dateColumn}) <= DATE(?)
                                           AND CURDATE() <= DATE_ADD(DATE(?), INTERVAL 2 DAY)
                    LIMIT 1`, [storeId, paid.expires_at, paid.expires_at]);
            eligible = graceRows.length > 0;
        }
    }
    let plan = eligible ? paid : null;
    if (!plan) {
        const [starter] = await connection.execute(
            `SELECT max_inventory, max_bookings FROM plans
             WHERE is_archived = 0 AND (LOWER(name) = 'starter' OR price = 0)
             ORDER BY price ASC, id ASC LIMIT 1`);
        plan = starter[0] || null;
    }
    if (!plan) throw new Error('No effective subscription plan is configured.');
    const limit = Number(plan[resourceColumn] || 0);
    return limit > 0 ? limit : null;
}

exports.handler = async (event) => {
    const method = event.httpMethod || event.requestContext?.http?.method;

    if (method === "OPTIONS") {
        return { statusCode: 200, headers, body: "" };
    }

    let connection;

    try {
        const body = parseBody(event);
        const action = body.action;

        connection = await dbPool.getConnection();

        // PUBLIC: limited rental catalog for the selected storefront/branch.
        // Read-only; prices are reloaded from the DB on submit.
        if (action === "get_public_rental_catalog") {
            const targetStoreId=Number(body.storeId ?? body.store_id);
            const requestedBranch=Number(body.branchId ?? body.branch_id ?? 0);
            if(!Number.isSafeInteger(targetStoreId)||targetStoreId<=0||
                (requestedBranch && (!Number.isSafeInteger(requestedBranch)||requestedBranch<=0)))
                return response(400,{error:"Valid store and branch IDs are required."});
            const [branches]=await connection.execute(`SELECT id,branch_name AS branchName FROM branches
                WHERE store_id=? ${requestedBranch?'AND id=?':''} ORDER BY id LIMIT 50`,
                [targetStoreId,...(requestedBranch?[requestedBranch]:[])]);
            if(!branches.length)return response(404,{error:"Store branch not found."});
            const chosen=Number(requestedBranch||branches[0].id);
            const [items]=await connection.execute(`SELECT id,name,rental_rate_per_day AS dailyRate,
                total_units AS totalUnits,maintenance_units AS maintenanceUnits,missing_units AS missingUnits
                FROM rental_equipment WHERE store_id=? AND branch_id=? AND archived_at IS NULL
                AND rental_rate_per_day>0 AND total_units>maintenance_units+missing_units ORDER BY name LIMIT 200`,
                [targetStoreId,chosen]);
            return response(200,{branchId:chosen,branchName:branches[0].branchName,
                equipment:items.map(e=>({id:Number(e.id),name:e.name,dailyRate:Number(e.dailyRate),
                    physicallyAvailable:Number(e.totalUnits)-Number(e.maintenanceUnits)-Number(e.missingUnits)}))});
        }

        // ── PUBLIC: create_booking ────────────────────────────────────────────
        if (action === "create_booking") {
            const {
                storeId,
                store_id,
                branchId,
                branch_id,
                bookingReference,
                booking_reference,
                bookingType,
                booking_type,
                name,
                facebookName,
                facebook_name,
                phone,
                email,
                date,
                event_date,
                eventTime,
                event_time,
                eventType,
                event_type,
                customOrder,
                custom_order,
                theme,
                venue,
                notes,
                status,
            } = body;

            const targetStoreId = Number(storeId || store_id);
            const targetBranchId = branchId || branch_id ? Number(branchId || branch_id) : null;

            let rentalSelections;
            try {rentalSelections=parseRentalSelection(body.rentalItems);}
            catch(error) {return response(400,{error:error.message});}
            if(rentalSelections.length && (!targetBranchId || !Number.isSafeInteger(targetBranchId) || targetBranchId<=0))
                return response(400,{error:"Select a valid rental branch before booking equipment."});
            if(rentalSelections.length && !(String(bookingType||booking_type||'').toLowerCase().includes('custom')))
                return response(400,{error:"Rental equipment selection currently supports Custom Bookings only."});
            let rentalStartDate=null,rentalEndDate=null;
            if(rentalSelections.length){
                try {rentalStartDate=rentalDate(date||event_date,'Event date');
                    rentalEndDate=rentalDate(body.rentalEndDate||rentalStartDate,'Rental return date');
                    rentalDays(rentalStartDate,rentalEndDate);
                    const nowParts=new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Manila',year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(new Date());
                    const datePart=type=>nowParts.find(x=>x.type===type)?.value||'';
                    const today=`${datePart('year')}-${datePart('month')}-${datePart('day')}`;
                    if(rentalStartDate<today)throw new Error('Rental start date cannot be in the past.');
                } catch(error){return response(400,{error:error.message});}
            }
            const finalBookingReference = bookingReference || booking_reference || null;
            const finalBookingType = bookingType || booking_type || "";
            const finalDate = date || event_date;
            const finalEventTime = eventTime || event_time || null;
            const finalEventType = eventType || event_type || "Based on selected package";
            const finalCustomOrder = customOrder || custom_order || "";

            if (!targetStoreId || !finalBookingType || !name || !phone || !finalDate) {
                return response(400, {
                    error: "Missing required booking fields",
                });
            }

            // Enforce monthly new-booking capacity without touching existing
            // bookings, including those already promised to customers.
            const bookingLimit = await effectiveSubscriptionLimit(connection, targetStoreId, 'max_bookings');
            if (bookingLimit !== null) {
                const [monthlyCount] = await connection.execute(
                    `SELECT COUNT(*) AS total FROM bookings
                     WHERE store_id = ? AND created_at >= DATE_FORMAT(CURDATE(), '%Y-%m-01')
                       AND created_at < DATE_FORMAT(DATE_ADD(CURDATE(), INTERVAL 1 MONTH), '%Y-%m-01')`,
                    [targetStoreId]
                );
                if (Number(monthlyCount[0]?.total || 0) >= bookingLimit) {
                    return response(409, {
                        error: `This store has reached its ${bookingLimit} new bookings for this month. Existing reservations remain available.`,
                        code: 'SUBSCRIPTION_BOOKING_LIMIT',
                    });
                }
            }

            const packageInput = getPackageInput(body);
            const packageId = getPackageIdFromInput(packageInput, body);
            const rawPackageName = getPackageNameFromInput(packageInput, body);

            const isCustom =
                String(finalBookingType).toLowerCase().includes("custom") ||
                Boolean(finalCustomOrder);

            let packageSnapshot = null;

            if (!isCustom) {
                packageSnapshot = await findPackageSnapshot(connection, {
                    storeId: targetStoreId,
                    branchId: targetBranchId,
                    packageId,
                    packageName: rawPackageName,
                    packageInput,
                });

                if (!packageSnapshot) {
                    return response(400, {
                        error: "Selected package was not found",
                    });
                }

                if (packageId && Number(packageSnapshot.id) !== Number(packageId)) {
                    return response(400, {
                        error: "Package mismatch: selected package ID does not match package snapshot",
                        selectedPackageId: Number(packageId),
                        snapshotPackageId: Number(packageSnapshot.id),
                        snapshotPackageName: packageSnapshot.name,
                    });
                }
            }

            if (
                rawPackageName &&
                normalizeText(packageSnapshot.name) !== normalizeText(rawPackageName)
            ) {
                return response(400, {
                    error: "Package mismatch: selected package name does not match package snapshot",
                    selectedPackageName: rawPackageName,
                    snapshotPackageName: packageSnapshot.name,
                });
            }

            const packagePrice = isCustom
                ? 0
                : toNumber(packageSnapshot?.package_price ?? packageSnapshot?.price ?? 0);

            const requiredDownPayment = isCustom
                ? 0
                : toNumber(
                    packageSnapshot?.down_payment_amount ??
                    packageSnapshot?.required_down_payment ??
                    0
                );

            const packageNameForSave = isCustom
                ? ""
                : packageSnapshot?.name || rawPackageName || "";

            const packageJsonForSave = packageSnapshot
                ? JSON.stringify(packageSnapshot)
                : packageInput && typeof packageInput === "object"
                    ? JSON.stringify(packageInput)
                    : null;

            const amountPaid = 0;
            const balance = isCustom ? 0 : packagePrice;
            const paymentStatus = "Unpaid";

            await connection.beginTransaction();
            try {
                const [result] = await connection.execute(
                    `
                    INSERT INTO bookings
                    (
                        store_id,
                        branch_id,
                        booking_reference,
                        booking_type,
                        name,
                        facebook_name,
                        phone,
                        email,
                        event_date,
                        event_time,
                        event_type,
                        package_name,
                        package_json,
                        custom_order,
                        theme,
                        venue,
                        notes,
                        status,
                        agreed_price,
                        package_price,
                        required_down_payment,
                        amount_paid,
                        balance,
                        payment_status
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                `,
                    [
                        targetStoreId,
                        targetBranchId,
                        finalBookingReference,
                        finalBookingType,
                        name,
                        facebookName || facebook_name || null,
                        phone,
                        email || null,
                        finalDate,
                        finalEventTime,
                        finalEventType,
                        packageNameForSave,
                        packageJsonForSave,
                        finalCustomOrder,
                        theme || null,
                        venue || null,
                        notes || "",
                        normalizeBookingStatus(status) || "Pending Review",
                        null,
                        packagePrice,
                        requiredDownPayment,
                        amountPaid,
                        balance,
                        paymentStatus,
                    ]
                );

                const bookingId = result.insertId;

                const bookingItemsToSave = isCustom
                    ? normalizeBookingItemsForSave(getBookingItemsInput(body), {
                        bookingId,
                        storeId: targetStoreId,
                        branchId: targetBranchId,
                        sourceType: "custom",
                        packageId: null,
                    })
                    : normalizeBookingItemsForSave(packageSnapshot?.inclusions || [], {
                        bookingId,
                        storeId: targetStoreId,
                        branchId: targetBranchId,
                        sourceType: "package",
                        packageId: packageSnapshot?.id || packageId || null,
                    });

                await insertBookingItems(connection, bookingItemsToSave);
                let rentalQuote={amount:0,count:0};
                if(rentalSelections.length){
                    if(!finalBookingReference || String(finalBookingReference).length>100)
                        throw rentalError("Rental bookings need a booking reference of at most 100 characters.");
                    const [duplicate]=await connection.execute(`SELECT id FROM bookings
                    WHERE store_id=? AND booking_reference=? AND id<>? LIMIT 1`,
                        [targetStoreId,finalBookingReference,bookingId]);
                    if(duplicate.length)throw rentalError("Booking reference is already used. Try again.");
                    rentalQuote=await saveRentalRequestLines(connection,{
                        bookingId,storeId:targetStoreId,branchId:targetBranchId,reference:finalBookingReference,
                        startDate:rentalStartDate,endDate:rentalEndDate,lines:rentalSelections
                    });
                }
                await connection.commit();
                return response(201, {
                    success: true,
                    id: bookingId,
                    package_price: packagePrice,
                    required_down_payment: requiredDownPayment,
                    balance,
                    payment_status: paymentStatus,
                    booking_items_saved: bookingItemsToSave.length,
                    rental_items_saved: rentalQuote.count,
                    rental_quoted_subtotal: rentalQuote.amount,
                });
            } catch(error) {await connection.rollback();
                if(error.rentalValidation||rentalSelections.length)return response(409,{error:error.message});
                throw error;
            }
        }

        // ── PUBLIC: get_booking_by_reference ─────────────────────────────────
        if (action === "get_booking_by_reference") {
            const { bookingReference, booking_reference } = body;
            const ref = bookingReference || booking_reference;

            if (!ref) {
                return response(400, { error: "Missing bookingReference" });
            }

            const [rows] = await connection.execute(
                `
                    SELECT
                        ${bookingSelectFields()}
                    FROM bookings
                             LEFT JOIN branches
                                       ON bookings.branch_id = branches.id
                                           AND bookings.store_id = branches.store_id
                    WHERE bookings.booking_reference = ?
                        LIMIT 1
                `,
                [ref]
            );

            if (!rows.length) {
                return response(404, { error: "Booking not found" });
            }

            return response(200, { booking: rows[0] });
        }

        // ── PUBLIC: get_bookings_by_phone ─────────────────────────────────────
        if (action === "get_bookings_by_phone") {
            const { phone, storeId, store_id } = body;
            const targetStoreId = Number(storeId || store_id);

            if (!phone || !targetStoreId) {
                return response(400, { error: "Missing phone or storeId" });
            }

            const [rows] = await connection.execute(
                `
                    SELECT
                        ${bookingSelectFields()}
                    FROM bookings
                             LEFT JOIN branches
                                       ON bookings.branch_id = branches.id
                                           AND bookings.store_id = branches.store_id
                    WHERE bookings.phone = ?
                      AND bookings.store_id = ?
                    ORDER BY bookings.created_at DESC
                `,
                [phone, targetStoreId]
            );

            return response(200, { bookings: rows });
        }

        // ── PUBLIC: get_public_bookings ───────────────────────────────────────
        if (action === "get_public_bookings") {
            const { storeId, store_id } = body;
            const targetStoreId = Number(storeId || store_id);

            if (!targetStoreId) {
                return response(400, { error: "Missing storeId" });
            }

            const [rows] = await connection.execute(
                `
                    SELECT
                        id,
                        name,
                        event_date AS date,
                    status
                    FROM bookings
                    WHERE store_id = ?
                    ORDER BY created_at DESC
                `,
                [targetStoreId]
            );

            return response(200, { bookings: rows });
        }

        // ── PROTECTED: verify token ───────────────────────────────────────────
        let store_id;
        let tokenRole;
        let tokenBranchId;
        let decodedToken;

        try {
            const auth = verifyProtectedStore(event);
            store_id = auth.storeId;
            tokenRole = auth.tokenRole;
            tokenBranchId = auth.tokenBranchId;
            decodedToken = auth.decoded;
        } catch (err) {
            return response(401, {
                error: err.message === "No token" ? "No token" : "Invalid token",
            });
        }

        if (!store_id) {
            return response(401, { error: "Invalid token store" });
        }

        // Owner sees the store; Managers and Staff are restricted to their active
        // employee record and JWT-assigned branch regardless of client body.
        if (!["owner", "manager", "staff"].includes(tokenRole)) {
            return response(403, { error: "Business account role required." });
        }
        const bookingAccess = await getOperationalAccess(connection, decodedToken, "bookings");
        if (bookingAccess === "none") {
            return response(403, { error: "Bookings access is not permitted for this account." });
        }
        const bookingReadActions = new Set([
            "get_booking_page_bookings", "get_dashboard_bookings", "get_bookings", "get_booking_items",
        ]);
        if (bookingAccess !== "full" && !bookingReadActions.has(action)) {
            return response(403, { error: "Full Bookings access is required for this action." });
        }
        // Item cost data is an Owner financial KPI, not an operational Staff view.
        if (action === "get_booking_costs" && tokenRole !== "owner") {
            return response(403, { error: "Only the Owner can access booking cost details." });
        }
        if (tokenRole === "manager" || tokenRole === "staff") {
            if (!Number.isSafeInteger(tokenBranchId) || tokenBranchId <= 0) {
                return response(403, { error: "A valid assigned branch is required." });
            }
            const requestedBranch = body.branch_id ?? body.branchId;
            if (requestedBranch !== undefined && requestedBranch !== null && requestedBranch !== "" &&
                Number(requestedBranch) !== tokenBranchId) {
                return response(403, { error: "You cannot access a different branch." });
            }
            body.branch_id = tokenBranchId;
            body.branchId = tokenBranchId;
        }

        // ── PROTECTED: get_booking_page_bookings ────────────────────────────────
        // Use this action on the OwnerBookings, ManagerBookings, and
        // StaffBookings screens. It returns the fields needed by those pages
        // without returning the package_json snapshot for hundreds of records.
        if (action === "get_booking_page_bookings") {
            const { branch_id, branchId } = body;
            const requestedBranchId = branch_id || branchId;
            const rawDateFrom = body.date_from ?? body.dateFrom;
            const rawDateTo = body.date_to ?? body.dateTo;
            const dateFrom = normalizeDateFilter(rawDateFrom);
            const dateTo = normalizeDateFilter(rawDateTo);

            if ((rawDateFrom && !dateFrom) || (rawDateTo && !dateTo)) {
                return response(400, { error: "Invalid booking date filter. Use YYYY-MM-DD." });
            }

            if (dateFrom && dateTo && dateFrom > dateTo) {
                return response(400, { error: "date_from cannot be later than date_to." });
            }

            let query = `
                SELECT
                    ${bookingPageSelectFields()}
                FROM bookings
                         LEFT JOIN branches
                                   ON bookings.branch_id = branches.id
                                       AND bookings.store_id = branches.store_id
                WHERE bookings.store_id = ?
            `;

            const params = [store_id];

            if (requestedBranchId) {
                query += ` AND bookings.branch_id = ?`;
                params.push(Number(requestedBranchId));
            }

            if (dateFrom) {
                query += ` AND bookings.event_date >= ?`;
                params.push(dateFrom);
            }

            if (dateTo) {
                query += ` AND bookings.event_date <= ?`;
                params.push(dateTo);
            }

            query += ` ORDER BY bookings.created_at DESC`;

            const [rows] = await connection.execute(query, params);

            return response(200, {
                bookings: rows,
                total: rows.length,
            });
        }

        // ── PROTECTED: get_dashboard_bookings ─────────────────────────────────
        // This endpoint is intentionally lightweight. The previous dashboard
        // request used get_bookings, which returned large package JSON fields
        // for every booking and could time out or exceed API response limits.
        if (action === "get_dashboard_bookings") {
            const { branch_id, branchId } = body;
            const requestedBranchId = branch_id || branchId;

            let query = `
                SELECT
                    ${dashboardBookingSelectFields()}
                FROM bookings
                         LEFT JOIN branches
                                   ON bookings.branch_id = branches.id
                                       AND bookings.store_id = branches.store_id
                WHERE bookings.store_id = ?
            `;

            const params = [store_id];

            if (requestedBranchId) {
                query += ` AND bookings.branch_id = ?`;
                params.push(Number(requestedBranchId));
            }

            query += ` ORDER BY bookings.created_at DESC`;

            const [rows] = await connection.execute(query, params);

            return response(200, {
                bookings: rows,
                total: rows.length,
            });
        }

        // ── PROTECTED: get_bookings ───────────────────────────────────────────
        if (action === "get_bookings") {
            const { branch_id, branchId } = body;
            const requestedBranchId = branch_id || branchId;

            let query = `
                SELECT
                    ${bookingSelectFields()}
                FROM bookings
                         LEFT JOIN branches
                                   ON bookings.branch_id = branches.id
                                       AND bookings.store_id = branches.store_id
                WHERE bookings.store_id = ?
            `;

            const params = [store_id];

            if (requestedBranchId) {
                query += ` AND bookings.branch_id = ?`;
                params.push(Number(requestedBranchId));
            }

            query += ` ORDER BY bookings.created_at DESC`;

            const [rows] = await connection.execute(query, params);

            return response(200, { bookings: rows });
        }

        // ── PROTECTED: get_booking_costs ──────────────────────────────────────
        // Returns item-level inventory cost for owner financial KPIs. The
        // project has had two booking_items schemas over its development
        // history, so the quantity/cost columns are detected at runtime.
        // This keeps the dashboard compatible with both the seeded local
        // database and the current booking workflow.
        if (action === "get_booking_costs") {
            const { branch_id, branchId } = body;
            const requestedBranchId = branch_id || branchId;
            const rawDateFrom = body.date_from ?? body.dateFrom;
            const rawDateTo = body.date_to ?? body.dateTo;
            const dateFrom = normalizeDateFilter(rawDateFrom);
            const dateTo = normalizeDateFilter(rawDateTo);

            if ((rawDateFrom && !dateFrom) || (rawDateTo && !dateTo)) {
                return response(400, { error: "Invalid booking cost date filter. Use YYYY-MM-DD." });
            }

            if (dateFrom && dateTo && dateFrom > dateTo) {
                return response(400, { error: "date_from cannot be later than date_to." });
            }

            const { quantityColumn, hasUnitCost } =
                await getBookingItemsCostSchema(connection);

            if (!quantityColumn) {
                return response(200, { success: true, costs: {} });
            }
            const quantityExpression = `COALESCE(NULLIF(bi.${quantityColumn}, 0), 0)`;
            const unitCostExpression = hasUnitCost
                ? `COALESCE(NULLIF(bi.unit_cost, 0), CASE WHEN bi.variant_id IS NOT NULL THEN pv.original_price ELSE p.original_price END, 0)`
                : `COALESCE(CASE WHEN bi.variant_id IS NOT NULL THEN pv.original_price ELSE p.original_price END, 0)`;

            let query = `
                SELECT
                    bi.booking_id AS bookingId,
                    bi.product_id AS productId,
                    bi.variant_id AS variantId,
                    ${quantityExpression} AS quantityUsed,
                    ${unitCostExpression} AS unitCost
                FROM booking_items bi
                         INNER JOIN bookings b
                                    ON b.id = bi.booking_id
                         LEFT JOIN products p
                                   ON p.id = bi.product_id
                                       AND p.store_id = b.store_id
                         LEFT JOIN product_variants pv
                                   ON pv.id = bi.variant_id
                                       AND pv.product_id = bi.product_id
                WHERE b.store_id = ?
            `;

            const params = [store_id];

            if (requestedBranchId) {
                query += ` AND b.branch_id = ?`;
                params.push(Number(requestedBranchId));
            }

            if (dateFrom) {
                query += ` AND b.event_date >= ?`;
                params.push(dateFrom);
            }

            if (dateTo) {
                query += ` AND b.event_date <= ?`;
                params.push(dateTo);
            }

            query += ` ORDER BY bi.booking_id, bi.id`;

            const [rows] = await connection.execute(query, params);
            const totals = new Map();
            const invalidBookings = new Set();
            const rowCounts = new Map();

            for (const row of rows) {
                const bookingId = String(row.bookingId);
                const quantity = Number(row.quantityUsed || 0);
                const unitCost = Number(row.unitCost || 0);

                rowCounts.set(bookingId, (rowCounts.get(bookingId) || 0) + 1);

                if (!Number.isFinite(quantity) || quantity <= 0 || !Number.isFinite(unitCost) || unitCost < 0) {
                    invalidBookings.add(bookingId);
                    continue;
                }

                totals.set(
                    bookingId,
                    (totals.get(bookingId) || 0) + quantity * unitCost
                );
            }

            const costs = {};
            for (const [bookingId, total] of totals.entries()) {
                if (!invalidBookings.has(bookingId) && rowCounts.get(bookingId) > 0) {
                    costs[bookingId] = Number(total.toFixed(2));
                }
            }

            return response(200, {
                success: true,
                costs,
                cost_basis: hasUnitCost
                    ? "booking_item_unit_cost_with_inventory_fallback"
                    : "live_inventory_original_price",
            });
        }

        // ── PROTECTED: get_booking_items ───────────────────────────────────────
        if (action === "get_booking_items") {
            const { booking_id, branch_id, branchId } = body;
            const requestedBranchId = branch_id || branchId;

            if (!booking_id) {
                return response(400, { error: "Missing booking_id" });
            }

            let bookingQuery = `
                SELECT id, status, store_id, branch_id
                FROM bookings
                WHERE id = ?
                  AND store_id = ?
            `;

            const bookingParams = [Number(booking_id), store_id];

            if (requestedBranchId) {
                bookingQuery += ` AND branch_id = ?`;
                bookingParams.push(Number(requestedBranchId));
            }

            const [bookingRows] = await connection.execute(bookingQuery, bookingParams);

            if (!bookingRows.length) {
                return response(404, { error: "Booking not found" });
            }

            let itemQuery = `
                SELECT
                    id,
                    booking_id,
                    source_type,
                    package_id,
                    product_id,
                    variant_id,
                    product_name,
                    variant_name,
                    category,
                    booked_quantity,
                    reserved_quantity,
                    used_quantity,
                    restored_quantity,
                    unit_price,
                    estimated_subtotal,
                    used_subtotal,
                    inventory_status
                FROM booking_items
                WHERE booking_id = ?
                  AND store_id = ?
            `;

            const itemParams = [Number(booking_id), store_id];

            if (requestedBranchId) {
                itemQuery += ` AND branch_id = ?`;
                itemParams.push(Number(requestedBranchId));
            }

            itemQuery += ` ORDER BY id ASC`;

            const [items] = await connection.execute(itemQuery, itemParams);

            return response(200, {
                success: true,
                booking: bookingRows[0],
                items,
            });
        }

        // ── PROTECTED: update_status (enhanced) ────────────────────────────────
        if (action === "update_status") {
            const { booking_id, status: rawStatus, agreed_price, branch_id, branchId } = body;
            let status = rawStatus;
            const usedItems = getUsedItemsInput(body);
            const requestedBranchId = branch_id || branchId;

            if (!booking_id || !status) return response(400, { error: "Missing booking_id or status" });

            const allowedStatuses = ["Pending Review","Confirmed","Preparing","Completed","Cancelled"];
            const normalizedTargetStatus = normalizeBookingStatus(status);
            if (!normalizedTargetStatus || !allowedStatuses.includes(normalizedTargetStatus)) {
                return response(400, { error: "Invalid booking status" });
            }
            status = normalizedTargetStatus;

            let selectQuery = `
                SELECT id, status, store_id, branch_id, package_json, booking_reference, name
                FROM bookings
                WHERE id = ?
                  AND store_id = ?
            `;
            const selectParams = [Number(booking_id), store_id];
            if (requestedBranchId) { selectQuery += ` AND branch_id = ?`; selectParams.push(Number(requestedBranchId)); }

            const [rows] = await connection.execute(selectQuery, selectParams);
            if (!rows.length) return response(404, { error: "Booking not found" });

            console.log("COMPLETED BLOCK HIT");
            console.log("PACKAGE JSON:", rows[0].package_json);

            const currentStatus = normalizeBookingStatus(rows[0].status) || "Pending Review";
            const allowedTransitions = {
                "Pending Review": ["Confirmed","Cancelled"],
                "Confirmed": ["Preparing","Cancelled"],
                "Preparing": ["Completed","Cancelled"],
                "Completed": [],
                "Cancelled": [],
            };
            if (!allowedTransitions[currentStatus]?.includes(status)) {
                return response(400, { error: `Cannot move booking from ${currentStatus} to ${status}` });
            }

            let inventoryResult = {
                ok: true,
                reservedCount: 0,
                restoredCount: 0,
                restoredQuantity: 0,
                usedQuantity: 0,
            };

            const actingEmployee = await getActingEmployee(
                connection,
                decodedToken,
                tokenRole,
                store_id
            );

            await connection.beginTransaction();
            try {
                // 1️⃣ Update booking status
                let query = `UPDATE bookings SET status = ?`;
                const params = [status];
                if (agreed_price !== undefined && agreed_price !== null) { query += `, agreed_price = ?`; params.push(Number(agreed_price)); }
                query += ` WHERE id = ? AND store_id = ?`;
                params.push(Number(booking_id), store_id);
                if (requestedBranchId) { query += ` AND branch_id = ?`; params.push(Number(requestedBranchId)); }
                await connection.execute(query, params);

                // 2️⃣ Deduct stock if Completed
                // 2️⃣ Reserve/deduct inventory when booking is confirmed
                if (status === "Confirmed") {
                    inventoryResult = await reserveBookingInventory(connection, {
                        bookingId: Number(booking_id),
                        storeId: rows[0].store_id,
                        branchId: requestedBranchId || rows[0].branch_id || null,
                        actor: actingEmployee,
                    });

                    if (!inventoryResult.ok) {
                        await connection.rollback();

                        return response(400, {
                            error: inventoryResult.error,
                        });
                    }
                }

                if(status === "Confirmed") {
                    await confirmRentalAllocations(connection,{
                        bookingId:Number(booking_id),storeId:store_id,
                        branchId:requestedBranchId||rows[0].branch_id,
                        price:agreed_price??(await connection.execute(
                            "SELECT agreed_price FROM bookings WHERE id=? AND store_id=?",[Number(booking_id),store_id]))[0][0]?.agreed_price
                    });
                }
                if(status === "Completed") {
                    await requireRentalReturnBeforeCompletion(connection,{
                        bookingId:Number(booking_id),storeId:store_id,branchId:requestedBranchId||rows[0].branch_id
                    });
                }
                if (status === "Cancelled") {
                    await cancelRentalAllocations(connection,{
                        bookingId:Number(booking_id),storeId:store_id,branchId:requestedBranchId||rows[0].branch_id
                    });
                    inventoryResult = await restoreBookingInventoryOnCancel(connection, {
                        bookingId: Number(booking_id),
                        storeId: rows[0].store_id,
                        branchId: requestedBranchId || rows[0].branch_id || null,
                        usedItems,
                        actor: actingEmployee,
                    });

                    if (!inventoryResult.ok) {
                        await connection.rollback();

                        return response(400, {
                            error: inventoryResult.error,
                        });
                    }
                }

                await connection.commit();
            } catch (err) {
                await connection.rollback();
                if(err.rentalValidation)return response(409,{error:err.message});
                throw err;
            }

            const statusActionLabels = {
                Confirmed: "Confirmed booking",
                Preparing: "Started preparing booking",
                Completed: "Marked booking as completed",
                Cancelled: "Cancelled booking",
            };

            const bookingRef = buildBookingReference(rows[0], booking_id);
            const customerName = rows[0].name || "customer";

            await logEmployeeAction(connection, {
                storeId: store_id,
                branchId: requestedBranchId || rows[0].branch_id || null,
                employee: actingEmployee,
                module: "Bookings",
                referenceNumber: bookingRef,
                action: statusActionLabels[status] || `Updated booking status to ${status}`,
                referenceId: String(booking_id),
                details: `${bookingRef} (${customerName}): ${currentStatus} → ${status}`,
            });

            return response(200, {
                success: true,
                status,
                reserved_items: inventoryResult?.reservedCount || 0,
                restored_items: inventoryResult?.restoredCount || 0,
                restored_quantity: inventoryResult?.restoredQuantity || 0,
                used_quantity: inventoryResult?.usedQuantity || 0,
            });
        }

        // ── PROTECTED: update_price for custom bookings ───────────────────────
        if (action === "update_price") {
            const {
                booking_id,
                agreed_price,
                required_down_payment,
                requiredDownPayment,
                branch_id,
                branchId,
            } = body;

            const requestedBranchId = branch_id || branchId;

            if (!booking_id || agreed_price === undefined || agreed_price === null) {
                return response(400, {
                    error: "Missing booking_id or agreed_price",
                });
            }

            const total = toNumber(agreed_price);
            const requiredDp = toNumber(
                required_down_payment ?? requiredDownPayment
            );

            if (total <= 0) {
                return response(400, {
                    error: "agreed_price must be greater than 0",
                });
            }

            if (requiredDp < 0) {
                return response(400, {
                    error: "required_down_payment cannot be negative",
                });
            }

            if (requiredDp > total) {
                return response(400, {
                    error: "required_down_payment cannot exceed agreed_price",
                });
            }

            let priceSelectQuery = `
                SELECT id, branch_id, booking_reference, name, agreed_price, required_down_payment
                FROM bookings
                WHERE id = ?
                  AND store_id = ?
            `;
            const priceSelectParams = [Number(booking_id), store_id];
            if (requestedBranchId) {
                priceSelectQuery += ` AND branch_id = ?`;
                priceSelectParams.push(Number(requestedBranchId));
            }

            const [priceRows] = await connection.execute(priceSelectQuery, priceSelectParams);

            if (!priceRows.length) {
                return response(404, { error: "Booking not found" });
            }

            const previousBooking = priceRows[0];
            const rentalQuote=await rentalQuoteTotal(connection,Number(booking_id),store_id,
                requestedBranchId||previousBooking.branch_id);
            if(rentalQuote.count){
                const [state]=await connection.execute("SELECT status FROM bookings WHERE id=? AND store_id=?",
                    [Number(booking_id),store_id]);
                if(normalizeBookingStatus(state[0]?.status)!=='Pending Review')
                    return response(409,{error:"Rental booking prices cannot be changed after confirmation."});
                if(total<rentalQuote.total-0.005)
                    return response(400,{error:`Booking total cannot be below the agreed equipment charges of ₱${rentalQuote.total.toFixed(2)}.`});
            }


            let query = `
                UPDATE bookings
                SET
                    agreed_price = ?,
                    required_down_payment = ?,
                    balance = GREATEST(? - COALESCE(amount_paid, 0), 0),
                    payment_status = CASE
                                         WHEN COALESCE(amount_paid, 0) >= ? THEN 'Fully Paid'
                                         WHEN COALESCE(amount_paid, 0) >= ? AND ? > 0 THEN 'Down Payment Paid'
                                         WHEN COALESCE(amount_paid, 0) > 0 THEN 'Partial'
                                         ELSE 'Down Payment Required'
                        END
                WHERE id = ?
                  AND store_id = ?
            `;

            const params = [
                total,
                requiredDp,
                total,
                total,
                requiredDp,
                requiredDp,
                Number(booking_id),
                store_id,
            ];

            if (requestedBranchId) {
                query += ` AND branch_id = ?`;
                params.push(Number(requestedBranchId));
            }

            await connection.beginTransaction();

            try {
                await connection.execute(query, params);

                const priceBookingRef = buildBookingReference(previousBooking, booking_id);
                const customerNameForPrice = previousBooking.name || "customer";
                const prevAgreed = Number(previousBooking.agreed_price || 0);
                const prevDp = Number(previousBooking.required_down_payment || 0);

                const actingEmployeeForPrice = await getActingEmployee(
                    connection,
                    decodedToken,
                    tokenRole,
                    store_id
                );

                await logEmployeeAction(connection, {
                    storeId: store_id,
                    branchId: requestedBranchId || previousBooking.branch_id || null,
                    employee: actingEmployeeForPrice,
                    module: "Bookings",
                    referenceNumber: priceBookingRef,
                    action: "Updated custom price",
                    referenceId: String(booking_id),
                    details:
                        `${priceBookingRef} (${customerNameForPrice}): ` +
                        `price ₱${prevAgreed.toLocaleString()} → ₱${total.toLocaleString()}, ` +
                        `down payment ₱${prevDp.toLocaleString()} → ₱${requiredDp.toLocaleString()}`,
                });

                await connection.commit();
            } catch (err) {
                await connection.rollback();
                throw err;
            }

            return response(200, {
                success: true,
                agreed_price: total,
                required_down_payment: requiredDp,
            });
        }

        // ── PROTECTED: update_payment ─────────────────────────────────────────
        if (action === "update_payment") {
            const {
                booking_id,
                amount_paid,
                balance,
                payment_status,
                branch_id,
                branchId,
            } = body;

            const requestedBranchId = branch_id || branchId;

            if (
                !booking_id ||
                amount_paid === undefined ||
                amount_paid === null ||
                !payment_status
            ) {
                return response(400, {
                    error: "Missing booking_id, amount_paid, or payment_status",
                });
            }

            const paid = toNumber(amount_paid);
            const safeBalance =
                balance !== undefined && balance !== null ? toNumber(balance) : null;
            if (!Number.isFinite(Number(amount_paid)) || paid < 0 ||
                (safeBalance !== null && (!Number.isFinite(Number(balance)) || safeBalance < 0))) {
                return response(400, { error: "Payment amounts must be valid non-negative numbers." });
            }

            let selectQuery = `
                SELECT id, status, store_id, branch_id, booking_reference, name
                FROM bookings
                WHERE id = ?
                  AND store_id = ?
            `;

            const selectParams = [Number(booking_id), store_id];

            if (requestedBranchId) {
                selectQuery += ` AND branch_id = ?`;
                selectParams.push(Number(requestedBranchId));
            }

            const [bookingRows] = await connection.execute(selectQuery, selectParams);

            if (!bookingRows.length) {
                return response(404, { error: "Booking not found" });
            }

            const currentStatus = normalizeBookingStatus(bookingRows[0].status) || "Pending Review";
            const willAutoConfirm =
                ["Down Payment Paid", "Fully Paid"].includes(payment_status) &&
                ["Pending Review", "Awaiting Down Payment"].includes(currentStatus);

            let query = `
                UPDATE bookings
                SET
                    amount_paid = ?,
                    payment_status = ?,
                    balance = CASE
                                  WHEN ? IS NULL THEN GREATEST(
                                          COALESCE(NULLIF(package_price, 0), NULLIF(agreed_price, 0), 0) - ?,
                                          0
                                                      )
                                  ELSE ?
                        END,
                    status = CASE
                                 WHEN ? IN ('Down Payment Paid', 'Fully Paid')
                                     AND status IN ('Pending Review', 'Awaiting Down Payment')
                                     THEN 'Confirmed'
                                 ELSE status
                        END
                WHERE id = ?
                  AND store_id = ?
            `;

            const params = [
                paid,
                payment_status,
                safeBalance,
                paid,
                safeBalance,
                payment_status,
                Number(booking_id),
                store_id,
            ];

            if (requestedBranchId) {
                query += ` AND branch_id = ?`;
                params.push(Number(requestedBranchId));
            }

            let inventoryResult = {
                ok: true,
                reservedCount: 0,
            };

            await connection.beginTransaction();

            try {
                await connection.execute(query, params);

                if (willAutoConfirm) {
                    inventoryResult = await reserveBookingInventory(connection, {
                        bookingId: Number(booking_id),
                        storeId: bookingRows[0].store_id,
                        branchId: requestedBranchId || bookingRows[0].branch_id || null,
                    });

                    if (!inventoryResult.ok) {
                        await connection.rollback();

                        return response(400, {
                            error: inventoryResult.error,
                        });
                    }
                }

                if(willAutoConfirm){
                    const [priceRows]=await connection.execute("SELECT agreed_price,package_price FROM bookings WHERE id=? AND store_id=?",
                        [Number(booking_id),store_id]);
                    await confirmRentalAllocations(connection,{
                        bookingId:Number(booking_id),storeId:store_id,branchId:requestedBranchId||bookingRows[0].branch_id,
                        price:priceRows[0]?.agreed_price??priceRows[0]?.package_price
                    });
                }
                await connection.commit();
            } catch (err) {
                await connection.rollback();
                if(err.rentalValidation)return response(409,{error:err.message});
                throw err;
            }

            const paymentBookingRef = buildBookingReference(bookingRows[0], booking_id);
            const customerNameForPayment = bookingRows[0].name || "customer";

            const paymentActionLabels = {
                "Fully Paid": "Marked as fully paid",
                "Down Payment Paid": "Marked down payment as paid",
                "Partial": "Recorded partial payment",
            };

            const actingEmployeeForPayment = await getActingEmployee(
                connection,
                decodedToken,
                tokenRole,
                store_id
            );

            await logEmployeeAction(connection, {
                storeId: store_id,
                branchId: requestedBranchId || bookingRows[0].branch_id || null,
                employee: actingEmployeeForPayment,
                module: "Bookings",
                referenceNumber: paymentBookingRef,
                action: paymentActionLabels[payment_status] || `Updated payment status to ${payment_status}`,
                referenceId: String(booking_id),
                details: `${paymentBookingRef} (${customerNameForPayment}): paid ₱${paid.toLocaleString()}, status → ${payment_status}`,
            });

            return response(200, {
                success: true,
                amount_paid: paid,
                balance: safeBalance,
                payment_status,
                status: willAutoConfirm ? "Confirmed" : currentStatus,
                reserved_items: inventoryResult.reservedCount,
            });
        }

        return response(400, { error: "Invalid action" });
    } catch (err) {
        console.error("BOOKINGS LAMBDA ERROR:", err);

        return response(500, {
            error: err.message || "Bookings Lambda failed",
        });
    } finally {
        if (connection) {
            connection.release();
        }
    }
};