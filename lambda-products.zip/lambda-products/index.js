/* eslint-disable @typescript-eslint/no-require-imports */
const mysql = require("mysql2/promise");
const jwt = require("jsonwebtoken");
const fs = require("fs");

const JWT_SECRET = "stocknbook-secret-key";

const dbConfig = {
    host: "127.0.0.1",
    user: "root",
    password: "BTA5EYVWLfWcebF",
    database: "stocknbook",
    ssl: { rejectUnauthorized: false },
};

function jsonResponse(statusCode, headers, body) {
    return {
        statusCode,
        headers,
        body: JSON.stringify(body),
    };
}

function badRequest(headers, message) {
    return jsonResponse(400, headers, { error: message });
}

function unauthorized(headers, message) {
    return jsonResponse(401, headers, { error: message });
}

function notFound(headers, message) {
    return jsonResponse(404, headers, { error: message });
}

function serverError(headers, err) {
    const message = err instanceof Error ? err.message : "Internal server error";

    console.error("Lambda error:", err);

    return jsonResponse(500, headers, {
        error: message,
    });
}

function toSafeString(value, max = 255) {
    return String(value ?? "").trim().slice(0, max);
}

function toNumber(value) {
    const n = Number(value);
    return Number.isFinite(n) ? n : null;
}

function normalizeOptionalDate(value) {
    if (value === undefined || value === null || value === "") return null;

    if (value instanceof Date && !Number.isNaN(value.getTime())) {
        return value.toISOString().slice(0, 10);
    }

    const text = String(value).trim();

    if (!text) return null;

    const isoMatch = text.match(/^(\d{4})-(\d{2})-(\d{2})$/);

    if (!isoMatch) {
        throw new Error(`Invalid expiration date "${text}". Use YYYY-MM-DD.`);
    }

    const year = Number(isoMatch[1]);
    const month = Number(isoMatch[2]);
    const day = Number(isoMatch[3]);
    const candidate = new Date(Date.UTC(year, month - 1, day));

    if (
        candidate.getUTCFullYear() !== year ||
        candidate.getUTCMonth() !== month - 1 ||
        candidate.getUTCDate() !== day
    ) {
        throw new Error(`Invalid expiration date "${text}".`);
    }

    return text;
}

function firstDefined(...values) {
    return values.find((value) => value !== undefined && value !== null);
}

function parseBooleanFlag(value) {
    if (typeof value === "boolean") return value;
    if (typeof value === "number") return value === 1;

    if (typeof value === "string") {
        const clean = value.trim().toLowerCase();
        return clean === "1" || clean === "true" || clean === "yes";
    }

    return false;
}

function parseVariantValues(value) {
    if (!value) return {};

    if (typeof value === "string") {
        try {
            const parsed = JSON.parse(value);
            return typeof parsed === "object" && parsed !== null ? parsed : {};
        } catch {
            return {};
        }
    }

    if (typeof value === "object") return value;

    return {};
}

function cleanVariantValues(value) {
    const rawValues = parseVariantValues(value);
    const cleaned = {};

    Object.entries(rawValues).forEach(([key, val]) => {
        const cleanKey = String(key || "").trim().toLowerCase();
        const cleanValue = String(val || "").trim();

        if (cleanKey && cleanValue) {
            cleaned[cleanKey] = cleanValue;
        }
    });

    return cleaned;
}

/* Save the user's selected pricing rule in addition to the final price. */
function readPricingSelection(input, fallback) {
    const method = String(firstDefined(
        input.pricingMethod, input.pricing_method,
        fallback?.pricingMethod, fallback?.pricing_method,
        "manual"
    )).trim().toLowerCase();
    if (method !== "manual" && method !== "markup") {
        throw new Error("Pricing method must be manual or markup.");
    }
    const raw = firstDefined(
        input.markupPercentage, input.markup_percentage,
        fallback?.markupPercentage, fallback?.markup_percentage
    );
    let percentage = null;
    if (raw !== undefined && raw !== null && raw !== "") {
        percentage = Number(raw);
        if (!Number.isFinite(percentage) || percentage < 0 || percentage > 99999) {
            throw new Error("Markup must be a nonnegative percentage.");
        }
    }
    if (method === "markup" && percentage === null) {
        throw new Error("Enter a markup percentage or choose Manual Selling Price.");
    }
    return { pricingMethod: method, markupPercentage: percentage };
}

function getIncomingVariants(body) {
    const rawVariants =
        body.variants ||
        body.product_variants ||
        body.productVariants ||
        body.variant_details ||
        [];

    if (!Array.isArray(rawVariants)) return [];

    return rawVariants
        .map((variant) => {
            const variantValues = cleanVariantValues(
                firstDefined(
                    variant.variantValues,
                    variant.variant_values,
                    variant.values
                )
            );

            return {
                variantValues,
                id: toNumber(variant.id) || null,
                ...readPricingSelection(variant),
                stock: toNumber(firstDefined(variant.stock, variant.quantity, variant.qty)) ?? 0,
                alertLevel:
                    toNumber(firstDefined(variant.alertLevel, variant.alert_level, variant.alert)) ?? 0,
                originalPrice:
                    toNumber(
                        firstDefined(
                            variant.originalPrice,
                            variant.original_price,
                            variant.costPrice,
                            variant.cost_price,
                            variant.original
                        )
                    ) ?? 0,
                salesPrice:
                    toNumber(
                        firstDefined(
                            variant.salesPrice,
                            variant.sales_price,
                            variant.price,
                            variant.sales
                        )
                    ) ?? 0,
                expirationDate: normalizeOptionalDate(
                    firstDefined(
                        variant.expirationDate,
                        variant.expiration_date,
                        variant.expiryDate,
                        variant.expiry_date
                    )
                ),
            };
        })
        .filter((variant) => Object.keys(variant.variantValues).length > 0);
}

function getVariantTotalStock(variants) {
    return variants.reduce((sum, variant) => sum + Number(variant.stock || 0), 0);
}

function getVariantTotalAlert(variants) {
    return variants.reduce((sum, variant) => sum + Number(variant.alertLevel || 0), 0);
}

function getMinVariantPrice(variants, field) {
    const prices = variants
        .map((variant) => Number(variant[field] || 0))
        .filter((price) => Number.isFinite(price) && price > 0);

    return prices.length > 0 ? Math.min(...prices) : 0;
}

async function safeRollback(connection) {
    try {
        if (connection) await connection.rollback();
    } catch {
        // Ignore rollback error.
    }
}

async function ensureStoreExists(connection, storeId) {
    const parsed = Number(storeId);
    if (!Number.isInteger(parsed) || parsed <= 0) return false;

    const [rows] = await connection.execute(
        "SELECT id FROM stores WHERE id = ? LIMIT 1",
        [parsed]
    );

    return rows.length > 0;
}

async function ensureBranchBelongsToStore(connection, branchId, storeId) {
    const parsedBranchId = Number(branchId);
    const parsedStoreId = Number(storeId);

    if (!Number.isInteger(parsedBranchId) || parsedBranchId <= 0) return false;
    if (!Number.isInteger(parsedStoreId) || parsedStoreId <= 0) return false;

    const [rows] = await connection.execute(
        "SELECT id FROM branches WHERE id = ? AND store_id = ? LIMIT 1",
        [parsedBranchId, parsedStoreId]
    );

    return rows.length > 0;
}

function normalizeVariantRow(row) {
    return {
        id: Number(row.id),
        productId: Number(row.productId ?? row.product_id),
        variantValues: parseVariantValues(row.variantValues ?? row.variant_values),
        variantNumber: row.variantNumber ?? row.variant_number ?? null,
        stock: Number(row.stock ?? 0),
        alertLevel: Number(row.alertLevel ?? row.alert_level ?? 0),
        originalPrice: Number(row.originalPrice ?? row.original_price ?? 0),
        salesPrice: Number(row.salesPrice ?? row.sales_price ?? 0),
        pricingMethod: row.pricingMethod ?? row.pricing_method ?? "manual",
        markupPercentage: row.markupPercentage ?? row.markup_percentage ?? null,
        expirationDate:
            row.expirationDate ??
            row.expiration_date ??
            null,
        createdAt: row.createdAt ?? row.created_at ?? "",
    };
}

async function attachVariants(connection, products) {
    if (!Array.isArray(products) || products.length === 0) return [];

    const productIds = products.map((product) => Number(product.id)).filter(Boolean);

    if (productIds.length === 0) {
        return products.map((product) => ({
            ...product,
            hasVariants: false,
            has_variants: 0,
            variants: [],
        }));
    }

    const placeholders = productIds.map(() => "?").join(",");

    const [variantRows] = await connection.execute(
        `SELECT
             id,
             product_id AS productId,
             variant_values AS variantValues,
             variant_number AS variantNumber,
             stock,
             alert_level AS alertLevel,
             original_price AS originalPrice,
             sales_price AS salesPrice,
             pricing_method AS pricingMethod,
             markup_percentage AS markupPercentage,
             expiration_date AS expirationDate,
             created_at AS createdAt
         FROM product_variants
         WHERE product_id IN (${placeholders})
           AND deleted_at IS NULL
         ORDER BY id ASC`,
        productIds
    );

    const variantsByProductId = {};

    variantRows.forEach((row) => {
        const variant = normalizeVariantRow(row);
        const key = String(variant.productId);

        if (!variantsByProductId[key]) {
            variantsByProductId[key] = [];
        }

        variantsByProductId[key].push(variant);
    });

    return products.map((product) => {
        const variants = variantsByProductId[String(product.id)] || [];
        const hasVariants =
            Number(product.hasVariants ?? product.has_variants ?? 0) === 1 ||
            variants.length > 0;

        return {
            ...product,
            hasVariants,
            has_variants: hasVariants ? 1 : 0,
            variants,
        };
    });
}

function hideProductCostsForNonOwners(products, tokenRole) {
    if (tokenRole === "owner") return products;

    return products.map((product) => ({
        ...product,
        originalPrice: 0,
        variants: Array.isArray(product.variants)
            ? product.variants.map((variant) => ({
                ...variant,
                originalPrice: 0,
            }))
            : [],
    }));
}

async function getProducts(connection, storeId, activeBranchId, productId = null) {
    let query = `
        SELECT
            products.id,
            products.product_number AS productNumber,
            products.store_id AS storeId,
            products.branch_id AS branchId,
            branches.branch_name AS branchName,
            products.name,
            products.category,
            products.stock,
            products.alert_level AS alertLevel,
            products.original_price AS originalPrice,
            products.sales_price AS salesPrice,
            products.pricing_method AS pricingMethod,
            products.markup_percentage AS markupPercentage,
            products.expiration_date AS expirationDate,
            products.has_variants AS hasVariants,
            products.created_at AS createdAt
        FROM products
                 LEFT JOIN branches
                           ON products.branch_id = branches.id
                               AND products.store_id = branches.store_id
        WHERE products.store_id = ?
          AND products.deleted_at IS NULL
    `;

    const params = [storeId];

    if (activeBranchId) {
        query += " AND products.branch_id = ?";
        params.push(activeBranchId);
    }

    if (productId) {
        query += " AND products.id = ?";
        params.push(productId);
    }

    query += " ORDER BY products.created_at DESC";

    const [rows] = await connection.execute(query, params);

    return attachVariants(connection, rows);
}

async function getProductById(connection, storeId, activeBranchId, productId) {
    const products = await getProducts(connection, storeId, activeBranchId, productId);
    return products[0] || null;
}

// Caller holds the parent product row lock (new product creation is branch-locked).
// The never-decreasing counter prevents reuse even after a variant is archived.
function validateProductInventoryInputs(body, stock, alertLevel, originalPrice, salesPrice, variants) {
    const validQuantity=n=>Number.isSafeInteger(n)&&n>=0&&n<=2147483647;
    const validAmount=n=>Number.isFinite(n)&&n>=0&&n<=100000000;
    if (!validQuantity(stock)||!validQuantity(alertLevel)||!validAmount(originalPrice)||!validAmount(salesPrice)) {
        throw new Error("Stock and Reorder Point must be nonnegative whole numbers; prices must be nonnegative.");
    }
    for (const v of variants) {
        if (!validQuantity(v.stock)||!validQuantity(v.alertLevel)||!validAmount(v.originalPrice)||!validAmount(v.salesPrice)) {
            throw new Error("Each variant needs a valid quantity, reorder point, and price.");
        }
    }
    const isMarkupValid=(entry)=>{
        const selection=readPricingSelection(entry);
        if (selection.pricingMethod!=="markup")return true;
        return Math.abs(roundMoney(Number(entry.originalPrice)*(1+selection.markupPercentage/100))-
            Number(entry.salesPrice))<0.011;
    };
    if (!variants.length && !isMarkupValid({...body,originalPrice,salesPrice})) {
        throw new Error("Selling price must match the configured markup calculation.");
    }
    if (variants.some(v=>!isMarkupValid(v))) throw new Error("One or more variant markup prices are incorrect.");
}

async function insertProductVariants(connection, productId, variants) {
    if (!Array.isArray(variants) || variants.length === 0) return [];
    const [counterRows] = await connection.execute(
        "SELECT product_number AS productNumber, next_variant_sequence AS nextSequence FROM products WHERE id = ? FOR UPDATE",
        [productId]
    );
    if (!counterRows.length || !counterRows[0].productNumber) throw new Error("Parent Product Number is missing.");
    let sequence = Number(counterRows[0].nextSequence || 1);
    const generated = [];
    for (const variant of variants) {
        if (!variant.variantValues || !Object.keys(variant.variantValues).length) throw new Error("Variant values are required.");
        const variantNumber = `${counterRows[0].productNumber}-V${String(sequence++).padStart(3, "0")}`;
        const [result] = await connection.execute(
            `INSERT INTO product_variants
             (product_id, variant_number, variant_values, stock, alert_level, original_price,
              sales_price, pricing_method, markup_percentage, expiration_date)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [productId, variantNumber, JSON.stringify(variant.variantValues), Number(variant.stock || 0),
                Number(variant.alertLevel || 0), Number(variant.originalPrice || 0),
                Number(variant.salesPrice || 0), variant.pricingMethod || "manual",
                variant.markupPercentage ?? null, variant.expirationDate || null]
        );
        generated.push({id: Number(result.insertId), variantNumber});
    }
    await connection.execute("UPDATE products SET next_variant_sequence = ? WHERE id = ?", [sequence, productId]);
    return generated;
}

/* DUPLICATE VALIDATION HELPERS */

function normalizeDuplicateText(value) {
    return String(value ?? "")
        .trim()
        .replace(/\s+/g, " ")
        .toLowerCase();
}

function getVariantSignature(values) {
    const entries = Object.entries(values || {})
        .map(([key, value]) => [
            normalizeDuplicateText(key),
            normalizeDuplicateText(value),
        ])
        .filter(([, value]) => value.length > 0)
        .sort(([keyA, valueA], [keyB, valueB]) => {
            const keyCompare = keyA.localeCompare(keyB);
            return keyCompare !== 0 ? keyCompare : valueA.localeCompare(valueB);
        });

    if (entries.length === 0) return "";

    return entries.map(([key, value]) => `${key}:${value}`).join("|");
}

function getVariantDisplayName(values) {
    return (
        Object.values(values || {})
            .map((value) => String(value || "").trim())
            .filter(Boolean)
            .join(", ") || "Unnamed variant"
    );
}

function getDuplicateVariantLabel(variants) {
    const seen = new Map();

    for (const variant of variants || []) {
        const signature = getVariantSignature(variant.variantValues);

        if (!signature) continue;

        const displayName = getVariantDisplayName(variant.variantValues);

        if (seen.has(signature)) {
            return displayName;
        }

        seen.set(signature, displayName);
    }

    return "";
}

async function findExistingProductByName(
    connection,
    storeId,
    branchId,
    productName,
    excludeProductId = null
) {
    const [rows] = await connection.execute(
        `SELECT id, name
         FROM products
         WHERE store_id = ?
           AND branch_id = ?
           AND deleted_at IS NULL`,
        [storeId, branchId]
    );

    const cleanName = normalizeDuplicateText(productName);

    return (
        rows.find((row) => {
            const sameName = normalizeDuplicateText(row.name) === cleanName;
            const notCurrentProduct =
                !excludeProductId || Number(row.id) !== Number(excludeProductId);

            return sameName && notCurrentProduct;
        }) || null
    );
}


async function ensureRestockHistoryTable(connection) {
    await connection.execute(`
        CREATE TABLE IF NOT EXISTS restock_history (
                                                       id BIGINT NOT NULL AUTO_INCREMENT,
                                                       store_id BIGINT NOT NULL,
                                                       branch_id BIGINT NOT NULL,
                                                       product_id BIGINT NOT NULL,
                                                       product_name VARCHAR(255) NOT NULL,
            variant_name VARCHAR(255) NULL,
            stock_before INT NOT NULL DEFAULT 0,
            quantity_added INT NOT NULL DEFAULT 0,
            current_stock INT NOT NULL DEFAULT 0,
            received_by VARCHAR(255) NULL,
            notes VARCHAR(500) NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            INDEX idx_restock_store (store_id),
            INDEX idx_restock_branch (branch_id),
            INDEX idx_restock_product (product_id),
            INDEX idx_restock_created_at (created_at)
            )
    `);
}

/* -------------------------------------------------------------------------- */
/*         INITIAL PURCHASE: SUPPLIER AND CASH / CREDIT RECORD ONLY           */
/* -------------------------------------------------------------------------- */

function roundMoney(value) {
    return Math.round((Number(value || 0) + Number.EPSILON) * 100) / 100;
}

function normalizedPurchaseDate(value) {
    // Reuses the project's existing strict YYYY-MM-DD validation.
    return normalizeOptionalDate(value);
}

function getInitialPurchaseInput(body, stock, originalPrice, variants, storedTotal = null) {
    const source = body.initialPurchase ?? body.initial_purchase;
    if (source === undefined || source === null) return null; // existing clients continue working
    if (!source || typeof source !== "object" || Array.isArray(source)) {
        throw new Error("Invalid initial purchase information.");
    }
    if (storedTotal === null && Number(stock) <= 0) {
        throw new Error("Initial purchase details require stock greater than zero.");
    }
    const supplier = toSafeString(source.supplier, 150);
    const supplierInvoiceNumber = toSafeString(source.supplierInvoiceNumber ?? source.supplier_invoice_number, 80) || null;
    const purchaseDate = normalizedPurchaseDate(source.purchaseDate ?? source.purchase_date);
    const paymentMethod = String(source.paymentMethod ?? source.payment_method ?? "").trim().toLowerCase();
    if (!supplier || !purchaseDate) {
        throw new Error("Supplier and purchase date are required for initial stock.");
    }
    if (!["cash", "credit"].includes(paymentMethod)) {
        throw new Error("Payment method must be cash or credit.");
    }

    const rawCost = Array.isArray(variants) && variants.length > 0
        ? variants.reduce((sum, variant) =>
            sum + Number(variant.stock || 0) * Number(variant.originalPrice || 0), 0)
        : Number(stock) * Number(originalPrice);
    if (!Number.isFinite(rawCost) || rawCost < 0) {
        throw new Error("Invalid initial inventory purchase cost.");
    }
    // Edit never rewrites the original supplier purchase total just because
    // product stock or replacement costs changed in a later period.
    const purchaseTotal = storedTotal === null ? roundMoney(rawCost) : roundMoney(storedTotal);
    const paidCandidate = toNumber(source.amountPaid ?? source.amount_paid ?? 0);
    if (paidCandidate === null || paidCandidate < 0) {
        throw new Error("Amount paid must be a valid nonnegative number.");
    }
    if (paymentMethod === "credit" && roundMoney(paidCandidate) > purchaseTotal) {
        throw new Error("Amount paid cannot exceed the initial purchase cost.");
    }
    const amountPaid = paymentMethod === "cash" ? purchaseTotal : roundMoney(paidCandidate);
    const outstandingBalance = roundMoney(Math.max(0, purchaseTotal - amountPaid));
    const paymentDueDate = paymentMethod === "credit"
        ? normalizedPurchaseDate(source.paymentDueDate ?? source.payment_due_date)
        : null;
    if (outstandingBalance > 0 && !paymentDueDate) {
        throw new Error("Payment due date is required for an outstanding credit purchase.");
    }
    if (paymentDueDate && paymentDueDate < purchaseDate) {
        throw new Error("Payment due date cannot be before the purchase date.");
    }
    return { supplier, supplierInvoiceNumber, purchaseDate, paymentMethod, purchaseTotal,
        amountPaid, outstandingBalance, paymentDueDate };
}

async function ensureInitialPurchaseTable(connection) {
    // Initialized only when a new product has initial supplier purchase details.
    // DDL happens BEFORE beginTransaction to avoid an implicit MySQL commit.
    if (await tableExists(connection, "inventory_initial_purchases")) return;
    await connection.execute(`
        CREATE TABLE IF NOT EXISTS inventory_initial_purchases (
                                                                   id BIGINT NOT NULL AUTO_INCREMENT,
                                                                   store_id BIGINT NOT NULL,
                                                                   branch_id BIGINT NOT NULL,
                                                                   product_id BIGINT NOT NULL,
                                                                   supplier VARCHAR(150) NOT NULL,
            purchase_date DATE NOT NULL,
            supplier_invoice_number VARCHAR(80) NULL,
            payment_method VARCHAR(10) NOT NULL,
            purchase_total DECIMAL(14,2) NOT NULL,
            amount_paid DECIMAL(14,2) NOT NULL,
            outstanding_balance DECIMAL(14,2) NOT NULL,
            payment_due_date DATE NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY uq_inventory_initial_product (product_id),
            INDEX idx_initial_purchase_store_branch (store_id, branch_id),
            INDEX idx_initial_purchase_due_date (payment_due_date)
            )
    `);
}

async function recordInitialPurchase(connection, storeId, branchId, productId, purchase) {
    if (!purchase) return;
    await connection.execute(
        `INSERT INTO inventory_initial_purchases
         (store_id, branch_id, product_id, supplier, supplier_invoice_number, purchase_date, payment_method,
          purchase_total, amount_paid, outstanding_balance, payment_due_date)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [storeId, branchId, productId, purchase.supplier, purchase.supplierInvoiceNumber, purchase.purchaseDate,
            purchase.paymentMethod, purchase.purchaseTotal, purchase.amountPaid,
            purchase.outstandingBalance, purchase.paymentDueDate]
    );
}

async function findInitialPurchase(connection, storeId, branchId, productId, lock = false) {
    if (!(await tableExists(connection, "inventory_initial_purchases"))) return null;
    const [rows] = await connection.execute(
        `SELECT id, supplier, supplier_invoice_number AS supplierInvoiceNumber,
                DATE_FORMAT(purchase_date,'%Y-%m-%d') AS purchaseDate,
                payment_method AS paymentMethod, purchase_total AS purchaseTotal,
                amount_paid AS amountPaid, outstanding_balance AS outstandingBalance,
                DATE_FORMAT(payment_due_date,'%Y-%m-%d') AS paymentDueDate
         FROM inventory_initial_purchases
         WHERE store_id = ? AND branch_id = ? AND product_id = ? LIMIT 1 ${lock ? "FOR UPDATE" : ""}`,
        [storeId, branchId, productId]
    );
    return rows[0] || null;
}

async function updateInitialPurchase(connection, storeId, branchId, productId, purchase, existingRecord) {
    if (!purchase) return;
    if (!existingRecord) {
        await recordInitialPurchase(connection, storeId, branchId, productId, purchase);
        return;
    }
    await connection.execute(
        `UPDATE inventory_initial_purchases
         SET supplier = ?, supplier_invoice_number = ?, purchase_date = ?, payment_method = ?, amount_paid = ?,
             outstanding_balance = ?, payment_due_date = ?
         WHERE id = ? AND store_id = ? AND branch_id = ? AND product_id = ?`,
        [purchase.supplier, purchase.supplierInvoiceNumber, purchase.purchaseDate, purchase.paymentMethod,
            purchase.amountPaid, purchase.outstandingBalance, purchase.paymentDueDate,
            existingRecord.id, storeId, branchId, productId]
    );
}

/* STOCKNBOOK PURCHASE LEDGER: canonical financial transactions, distinct from stock. */
function exactMoney(value, label) {
    const raw = Number(value);
    if (!Number.isFinite(raw) || raw < 0 || Math.abs(raw * 100 - Math.round(raw * 100)) > 0.00001) {
        throw new Error(`${label} must be a nonnegative amount with at most 2 decimal places.`);
    }
    return Math.round(raw * 100);
}
function validatePurchaseHeader(input, lines) {
    const supplier = toSafeString(input.supplier, 150);
    const purchaseDate = normalizeOptionalDate(input.purchaseDate ?? input.receivedDate);
    const supplierInvoiceNumber = toSafeString(input.supplierInvoiceNumber ?? input.supplier_invoice_number, 80) || null;
    const paymentMethod = String(input.paymentMethod || "").toLowerCase();
    if (!supplier || !purchaseDate || !["cash", "credit"].includes(paymentMethod)) {
        throw new Error("Supplier, purchase date, and Cash/Credit are required.");
    }
    if (!lines.length || lines.some(l => !Number.isSafeInteger(l.quantity) || l.quantity <= 0 ||
        !Number.isInteger(l.productId) || l.productId <= 0 ||
        (l.variantId !== null && (!Number.isInteger(l.variantId) || l.variantId <= 0)))) {
        throw new Error("A purchase needs one or more positive product or variant lines.");
    }
    const totalCents = lines.reduce((total, line) => total + line.quantity * exactMoney(line.unitPurchaseCost, "Unit purchase cost"), 0);
    if (!Number.isSafeInteger(totalCents)) throw new Error("Purchase amount is too large.");
    const amountPaidCents = paymentMethod === "cash" ? totalCents : exactMoney(input.amountPaid ?? 0, "Amount paid");
    if (amountPaidCents > totalCents) throw new Error("Amount paid cannot exceed purchase total.");
    const dueDate = paymentMethod === "credit" ? normalizeOptionalDate(input.paymentDueDate) : null;
    if (totalCents > amountPaidCents && !dueDate) throw new Error("Due date is required for unpaid credit.");
    if (dueDate && dueDate < purchaseDate) throw new Error("Due date cannot precede purchase date.");
    return {supplier, purchaseDate, supplierInvoiceNumber, paymentMethod, dueDate,
        totalCents, amountPaidCents, outstandingCents: totalCents - amountPaidCents};
}
async function createStockReceipt(connection, {storeId, branchId, purchaseId, lines, receivedDate, receivedBy, requestKey,
    legacySupplier, legacyInvoice, legacyPaymentMethod, legacyAmountPaid,
    legacyPurchaseTotal, legacyOutstandingBalance}) {
    if (!lines.length) throw new Error("Receipt must contain received stock.");
    const [r] = await connection.execute(
        `INSERT INTO inventory_stock_receipts
         (store_id, branch_id, product_id, purchase_id, supplier, supplier_invoice_number,
          received_date, payment_method, purchase_total, amount_paid, outstanding_balance,
          payment_due_date, received_by, request_key)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NULL, ?, ?)`,
        [storeId, branchId, lines[0].productId, purchaseId, legacySupplier, legacyInvoice,
            receivedDate, legacyPaymentMethod,
            legacyPurchaseTotal ?? roundMoney(lines.reduce((sum,l)=>sum+l.quantity*l.unitPurchaseCost,0)),
            legacyAmountPaid || 0, legacyOutstandingBalance ?? 0, receivedBy || "System", requestKey || null]
    );
    const receiptId = Number(r.insertId);
    await connection.execute("UPDATE inventory_stock_receipts SET receiving_number = ? WHERE id = ?",
        [`RCV-${String(receiptId).padStart(6,"0")}`, receiptId]);
    for (const line of lines) {
        const [createdItem] = await connection.execute(
            `INSERT INTO inventory_stock_receipt_items
             (receipt_id, product_id, variant_id, variant_name, quantity_received,
              unit_purchase_cost, expiration_date, purchase_item_id)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
            [receiptId, line.productId, line.variantId ?? null, line.variantName ?? null,
                line.quantity, line.unitPurchaseCost, line.expirationDate ?? null, line.purchaseItemId ?? null]
        );
        // One canonical Stock In movement per physical receipt line, including
        // initial stock. Payment settlement does not create stock movements.
        await connection.execute(
            `INSERT INTO inventory_stock_movements
             (store_id, branch_id, product_id, variant_id, receipt_item_id,
              movement, quantity, movement_date)
             VALUES (?, ?, ?, ?, ?, 'Stock In', ?, ?)`,
            [storeId,branchId,line.productId,line.variantId ?? null,Number(createdItem.insertId),line.quantity,receivedDate]
        );
    }
    return receiptId;
}
// CREATE purchase once; record its financial payment once even if the purchase has many variants/products.
async function createPurchaseLedger(connection, {storeId, branchId, input, lines, source, purchaseRef, requestKey, receivedBy,
    receivedDate, deliveredLines}) {
    const p = validatePurchaseHeader(input, lines);
    const [result] = await connection.execute(
        `INSERT INTO inventory_purchase_transactions
         (store_id, branch_id, source, import_ref, request_key, supplier, supplier_invoice_number,
          purchase_date, payment_method, purchase_total, payment_due_date)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [storeId, branchId, source, purchaseRef || null, requestKey || null, p.supplier,
            p.supplierInvoiceNumber, p.purchaseDate, p.paymentMethod, p.totalCents/100, p.dueDate]
    );
    const purchaseId = Number(result.insertId);
    // Include the persisted store and branch codes in every new Purchase Number.
    const { storeCode, branchCode } = await getProductCodeContext(connection, storeId, branchId);
    await connection.execute("UPDATE inventory_purchase_transactions SET purchase_number = ? WHERE id = ?",
        [`${storeCode}-${branchCode}-PUR-${String(purchaseId).padStart(6, "0")}`, purchaseId]);
    const purchaseLines = [];
    for (const line of lines) {
        const [item] = await connection.execute(
            `INSERT INTO inventory_purchase_items
             (purchase_id, product_id, variant_id, quantity_ordered, unit_purchase_cost, expiration_date)
             VALUES (?, ?, ?, ?, ?, ?)`,
            [purchaseId, line.productId, line.variantId ?? null, line.quantity,
                line.unitPurchaseCost, line.expirationDate ?? null]
        );
        purchaseLines.push({...line, purchaseItemId: Number(item.insertId)});
    }
    if (p.amountPaidCents > 0) {
        await connection.execute(
            `INSERT INTO inventory_supplier_payments (purchase_id, amount, payment_date)
             VALUES (?, ?, ?)`, [purchaseId, p.amountPaidCents/100, p.purchaseDate]);
    }
    // Invoice/order quantities can be greater than the first delivery.
    // Match physical receipts to ordered lines; never treat undelivered goods as on-hand stock.
    const physicalLines = deliveredLines === undefined ? purchaseLines : deliveredLines.map(delivery => {
        const item = purchaseLines.find(line => line.productId === delivery.productId &&
            (line.variantId ?? null) === (delivery.variantId ?? null));
        if (!item || delivery.quantity > item.quantity || delivery.quantity <= 0 ||
            exactMoney(item.unitPurchaseCost,"Purchase cost") !== exactMoney(delivery.unitPurchaseCost,"Received cost")) {
            throw new Error("Delivered quantities and costs must match their purchase lines.");
        }
        return {...delivery, purchaseItemId:item.purchaseItemId};
    });
    const receiptId = await createStockReceipt(connection, {
        storeId, branchId, purchaseId, lines: physicalLines,
        receivedDate: receivedDate || p.purchaseDate, receivedBy, requestKey,
        legacySupplier: p.supplier, legacyInvoice: p.supplierInvoiceNumber,
        legacyPaymentMethod: p.paymentMethod, legacyAmountPaid: p.amountPaidCents/100,
        legacyPurchaseTotal:p.totalCents/100,legacyOutstandingBalance:p.outstandingCents/100,
    });
    return {purchaseId, receiptId, purchaseTotal:p.totalCents/100,
        amountPaid:p.amountPaidCents/100, outstandingBalance:p.outstandingCents/100};
}
async function findCanonicalInitialPurchase(connection, storeId, branchId, productId) {
    const [rows] = await connection.execute(
        `SELECT p.id AS purchaseId, p.supplier, p.supplier_invoice_number AS supplierInvoiceNumber,
                DATE_FORMAT(p.purchase_date,'%Y-%m-%d') AS purchaseDate,
                p.payment_method AS paymentMethod, p.purchase_total AS purchaseTotal,
                DATE_FORMAT(p.payment_due_date,'%Y-%m-%d') AS paymentDueDate,
                (SELECT COUNT(DISTINCT item.product_id) FROM inventory_purchase_items item WHERE item.purchase_id=p.id) AS productCount,
                COALESCE((SELECT SUM(pay.amount) FROM inventory_supplier_payments pay WHERE pay.purchase_id=p.id),0) AS amountPaid
         FROM inventory_purchase_transactions p
                  INNER JOIN inventory_purchase_items pi ON pi.purchase_id=p.id
         WHERE p.store_id=? AND p.branch_id=? AND pi.product_id=? AND p.source IN ('add','import')
         ORDER BY p.id ASC LIMIT 1`, [storeId, branchId, productId]
    );
    if (!rows.length) return null;
    const entry = rows[0];
    return {...entry, purchaseTotal: Number(entry.purchaseTotal), amountPaid: Number(entry.amountPaid),
        outstandingBalance: roundMoney(Number(entry.purchaseTotal)-Number(entry.amountPaid))};
}

async function getRestockReceivedBy(
    connection,
    decoded,
    tokenRole,
    storeId
) {
    try {
        if (tokenRole === "manager" && decoded?.manager_id) {
            const [rows] = await connection.execute(
                `SELECT manager_name
                 FROM managers
                 WHERE id = ?
                   AND store_id = ?
                     LIMIT 1`,
                [Number(decoded.manager_id), storeId]
            );

            if (rows.length > 0) {
                return (
                    toSafeString(rows[0].manager_name, 255) ||
                    toSafeString(decoded.email, 255) ||
                    "Manager"
                );
            }
        }

        if (tokenRole === "staff" && decoded?.staff_id) {
            const [rows] = await connection.execute(
                `SELECT staff_name
                 FROM staff
                 WHERE id = ?
                   AND store_id = ?
                     LIMIT 1`,
                [Number(decoded.staff_id), storeId]
            );

            if (rows.length > 0) {
                return (
                    toSafeString(rows[0].staff_name, 255) ||
                    toSafeString(decoded.email, 255) ||
                    "Staff"
                );
            }
        }

        if (tokenRole === "owner") {
            const [rows] = await connection.execute(
                `SELECT owner_name
                 FROM stores
                 WHERE id = ?
                     LIMIT 1`,
                [storeId]
            );

            if (rows.length > 0) {
                return (
                    toSafeString(rows[0].owner_name, 255) ||
                    toSafeString(decoded?.email, 255) ||
                    "Owner"
                );
            }
        }
    } catch (error) {
        console.error("Unable to resolve restock receiver:", error);
    }

    return (
        toSafeString(decoded?.email, 255) ||
        toSafeString(tokenRole, 80) ||
        "User"
    );
}

async function recordRestockHistory(
    connection,
    {
        storeId,
        branchId,
        beforeProduct,
        afterProduct,
        receivedBy,
    }
) {
    if (!beforeProduct || !afterProduct || !branchId) {
        return;
    }

    const beforeVariants = Array.isArray(beforeProduct.variants)
        ? beforeProduct.variants
        : [];

    const afterVariants = Array.isArray(afterProduct.variants)
        ? afterProduct.variants
        : [];

    const beforeHasVariants =
        Boolean(beforeProduct.hasVariants) || beforeVariants.length > 0;

    const afterHasVariants =
        Boolean(afterProduct.hasVariants) || afterVariants.length > 0;

    if (beforeHasVariants !== afterHasVariants) {
        return;
    }

    await ensureRestockHistoryTable(connection);

    if (!afterHasVariants) {
        const stockBefore = Number(beforeProduct.stock || 0);
        const currentStock = Number(afterProduct.stock || 0);
        const quantityAdded = currentStock - stockBefore;

        if (quantityAdded <= 0) {
            return;
        }

        await connection.execute(
            `INSERT INTO restock_history
             (
                 store_id,
                 branch_id,
                 product_id,
                 product_name,
                 variant_name,
                 stock_before,
                 quantity_added,
                 current_stock,
                 received_by
             )
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [
                storeId,
                branchId,
                Number(afterProduct.id),
                toSafeString(afterProduct.name || beforeProduct.name, 255),
                null,
                stockBefore,
                quantityAdded,
                currentStock,
                receivedBy,
            ]
        );

        return;
    }

    const previousVariants = new Map();

    for (const variant of beforeVariants) {
        const signature = getVariantSignature(
            variant.variantValues || {}
        );

        if (!signature) {
            continue;
        }

        previousVariants.set(signature, Number(variant.stock || 0));
    }

    for (const variant of afterVariants) {
        const signature = getVariantSignature(
            variant.variantValues || {}
        );

        if (!signature || !previousVariants.has(signature)) {
            continue;
        }

        const stockBefore = Number(previousVariants.get(signature) || 0);
        const currentStock = Number(variant.stock || 0);
        const quantityAdded = currentStock - stockBefore;

        if (quantityAdded <= 0) {
            continue;
        }

        await connection.execute(
            `INSERT INTO restock_history
             (
                 store_id,
                 branch_id,
                 product_id,
                 product_name,
                 variant_name,
                 stock_before,
                 quantity_added,
                 current_stock,
                 received_by
             )
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [
                storeId,
                branchId,
                Number(afterProduct.id),
                toSafeString(afterProduct.name || beforeProduct.name, 255),
                getVariantDisplayName(variant.variantValues),
                stockBefore,
                quantityAdded,
                currentStock,
                receivedBy,
            ]
        );
    }
}

/*
 * The JWT issued at login only carries ids (store_id / manager_id /
 * staff_id) and an email — never a display name. To log a real,
 * human-readable employee_actions row we look the acting user's name up
 * from their own table using the id that's already in the token.
 */
async function getActingEmployee(connection, decoded, tokenRole, storeId) {
    const role = String(tokenRole || "").toLowerCase();

    if (role === "manager" && decoded?.manager_id) {
        const [rows] = await connection.execute(
            `SELECT manager_name FROM managers WHERE id = ? AND store_id = ? LIMIT 1`,
            [Number(decoded.manager_id), storeId]
        );

        return {
            id: Number(decoded.manager_id),
            name: toSafeString(rows[0]?.manager_name, 255) || "Manager",
            role: "Manager",
        };
    }

    if (role === "staff" && decoded?.staff_id) {
        const [rows] = await connection.execute(
            `SELECT staff_name FROM staff WHERE id = ? AND store_id = ? LIMIT 1`,
            [Number(decoded.staff_id), storeId]
        );

        return {
            id: Number(decoded.staff_id),
            name: toSafeString(rows[0]?.staff_name, 255) || "Staff",
            role: "Staff",
        };
    }

    if (role === "owner") {
        const [rows] = await connection.execute(
            `SELECT owner_name FROM stores WHERE id = ? LIMIT 1`,
            [storeId]
        );

        return {
            id: null,
            name: toSafeString(rows[0]?.owner_name, 255) || "Owner",
            role: "Owner",
        };
    }

    return { id: null, name: "Unknown", role: "Staff" };
}

/*
 * Writes one row to employee_actions. Called from inside the same DB
 * transaction as the product action it's logging, so the log and the
 * action succeed or fail together.
 */
async function logEmployeeAction(connection, entry) {
    await connection.execute(
        `INSERT INTO employee_actions
         (store_id, branch_id, employee_id, employee_name, employee_role,
          module, reference_number, action, reference_id, details)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
            entry.storeId,
            entry.branchId ?? null,
            entry.employee.id,
            entry.employee.name,
            entry.employee.role,
            entry.module,
            entry.referenceNumber ?? null,
            entry.action,
            entry.referenceId ?? null,
            entry.details ?? null,
        ]
    );
}

const STORE_CODE_STOP_WORDS = new Set([
    "THE", "AND", "OF", "STORE", "SHOP", "ENTERPRISE", "ENTERPRISES",
    "TRADING", "COMPANY", "CO", "INC", "CORP", "CORPORATION", "CITY"
]);

const BRANCH_CODE_STOP_WORDS = new Set([
    "THE", "AND", "OF", "BRANCH", "RETAIL", "OUTLET", "LOCATION",
    "STORE", "SHOP", "MAIN", "NORTH", "SOUTH", "EAST", "WEST",
    "CENTRAL", "CITY", "MUNICIPALITY"
]);

function normalizeCodeWords(value) {
    return String(value || "")
        .normalize("NFKD")
        .replace(/[\u0300-\u036f]/g, "")
        .toUpperCase()
        .replace(/[^A-Z0-9]+/g, " ")
        .trim()
        .split(/\s+/)
        .filter(Boolean);
}

function compactAlpha(value) {
    return normalizeCodeWords(value).join("").replace(/[^A-Z]/g, "");
}

function codeFromSingleWord(word) {
    const clean = String(word || "").replace(/[^A-Z]/g, "");
    if (!clean) return "XXX";

    const first = clean.charAt(0);
    const consonants = clean.slice(1).replace(/[AEIOU]/g, "");
    let code = `${first}${consonants}`.slice(0, 3);

    if (code.length < 3) {
        code = `${code}${clean.slice(1)}`.slice(0, 3);
    }

    return code.padEnd(3, "X");
}

function buildReadableCode(value, stopWords, fallback = "XXX") {
    const rawWords = normalizeCodeWords(value);
    const words = rawWords.filter((word) => !stopWords.has(word));

    if (words.length >= 3) {
        return words.slice(0, 3).map((word) => word.charAt(0)).join("");
    }

    if (words.length === 2) {
        const second = codeFromSingleWord(words[1]);
        return `${words[0].charAt(0)}${second.slice(0, 2)}`;
    }

    if (words.length === 1) {
        return codeFromSingleWord(words[0]);
    }

    const fallbackWords = normalizeCodeWords(fallback);
    return codeFromSingleWord(fallbackWords[0] || "XXX");
}

function getBranchCodeSource(branchName, address) {
    const meaningfulBranchWords = normalizeCodeWords(branchName).filter(
        (word) => !BRANCH_CODE_STOP_WORDS.has(word) && !/^\d+$/.test(word)
    );

    // If the branch name itself contains a real location/name (for example
    // "Mandaluyong Branch"), use it. Generic labels such as
    // "Branch 4 Retail Branch" fall back to the address location.
    if (meaningfulBranchWords.length > 0) {
        return meaningfulBranchWords.join(" ");
    }

    const addressParts = String(address || "")
        .split(",")
        .map((part) => part.trim())
        .filter(Boolean);

    if (addressParts.length >= 2) {
        return addressParts[addressParts.length - 2];
    }

    return addressParts[0] || branchName || "Branch";
}

async function allocateUniqueStoreCode(connection, storeId, storeName, slug) {
    const source = storeName || slug || `Store ${storeId}`;
    const base = buildReadableCode(source, STORE_CODE_STOP_WORDS, "STR");
    const compact = compactAlpha(source);
    const candidates = [base];

    for (let length = 4; length <= 7; length += 1) {
        const extra = compact.slice(0, Math.max(0, length - 3));
        const candidate = `${base}${extra}`.slice(0, length);
        if (candidate && !candidates.includes(candidate)) candidates.push(candidate);
    }

    for (let suffix = 0; suffix < 26; suffix += 1) {
        candidates.push(`${base}${String.fromCharCode(65 + suffix)}`);
    }

    for (const candidate of candidates) {
        const [rows] = await connection.execute(
            `SELECT id FROM stores
             WHERE store_code = ?
               AND id <> ?
                 LIMIT 1`,
            [candidate, storeId]
        );

        if (rows.length === 0) return candidate;
    }

    throw new Error("Unable to allocate a unique store code.");
}

async function allocateUniqueBranchCode(
    connection,
    storeId,
    branchId,
    branchName,
    address
) {
    const source = getBranchCodeSource(branchName, address);
    const base = buildReadableCode(source, BRANCH_CODE_STOP_WORDS, "BRN");
    const compact = compactAlpha(source);
    const candidates = [base];

    for (let length = 4; length <= 7; length += 1) {
        const extra = compact.slice(0, Math.max(0, length - 3));
        const candidate = `${base}${extra}`.slice(0, length);
        if (candidate && !candidates.includes(candidate)) candidates.push(candidate);
    }

    for (let suffix = 0; suffix < 26; suffix += 1) {
        candidates.push(`${base}${String.fromCharCode(65 + suffix)}`);
    }

    for (const candidate of candidates) {
        const [rows] = await connection.execute(
            `SELECT id FROM branches
             WHERE store_id = ?
               AND branch_code = ?
               AND id <> ?
                 LIMIT 1`,
            [storeId, candidate, branchId]
        );

        if (rows.length === 0) return candidate;
    }

    throw new Error("Unable to allocate a unique branch code.");
}

function buildProductNumber(storeCode, branchCode, sequence) {
    return `${storeCode}-${branchCode}-${String(sequence).padStart(3, "0")}`;
}

async function getProductCodeContext(connection, storeId, branchId) {
    const [rows] = await connection.execute(
        `SELECT
             stores.store_code AS storeCode,
             branches.branch_code AS branchCode
         FROM stores
                  INNER JOIN branches
                             ON branches.store_id = stores.id
                                 AND branches.id = ?
         WHERE stores.id = ?
             LIMIT 1`,
        [branchId, storeId]
    );

    if (!rows.length || !rows[0].storeCode || !rows[0].branchCode) {
        throw new Error("Store/branch code is not available for product numbering.");
    }

    return {
        storeCode: String(rows[0].storeCode),
        branchCode: String(rows[0].branchCode),
    };
}

async function reserveNextProductSequence(connection, storeId, branchId) {
    // The branch row is locked by create_product before this helper runs.
    // Derive the current maximum from BOTH the sequence table and the actual
    // stored Product Nos. This makes the allocator self-healing even when
    // product_number_sequences is empty or behind existing products.
    const [sequenceRows] = await connection.execute(
        `SELECT last_sequence AS lastSequence
         FROM product_number_sequences
         WHERE store_id = ?
           AND branch_id = ?
             FOR UPDATE`,
        [storeId, branchId]
    );

    const [productRows] = await connection.execute(
        `SELECT COALESCE(
                        MAX(
                                CAST(
                                        SUBSTRING_INDEX(product_number, '-', -1)
                                    AS UNSIGNED
                                )
                        ),
                        0
                ) AS maxExistingSequence
         FROM products
         WHERE store_id = ?
           AND branch_id = ?
           AND deleted_at IS NULL
           AND product_number REGEXP
               '^[A-Za-z]{3,8}-[A-Za-z]{3,8}-[0-9]{3,}$'`,
        [storeId, branchId]
    );

    const sequenceValue = sequenceRows.length
        ? Number(sequenceRows[0].lastSequence || 0)
        : 0;

    const productValue = Number(
        productRows?.[0]?.maxExistingSequence || 0
    );

    const currentMaximum = Math.max(sequenceValue, productValue, 0);

    await connection.execute(
        `INSERT INTO product_number_sequences
             (store_id, branch_id, last_sequence)
         VALUES (?, ?, ?)
             ON DUPLICATE KEY UPDATE
                                  last_sequence = GREATEST(last_sequence, VALUES(last_sequence)),
                                  updated_at = CURRENT_TIMESTAMP`,
        [storeId, branchId, currentMaximum]
    );

    return currentMaximum + 1;
}

async function commitProductSequence(connection, storeId, branchId, sequence) {
    await connection.execute(
        `INSERT INTO product_number_sequences
             (store_id, branch_id, last_sequence)
         VALUES (?, ?, ?)
             ON DUPLICATE KEY UPDATE
                                  last_sequence = GREATEST(last_sequence, VALUES(last_sequence)),
                                  updated_at = CURRENT_TIMESTAMP`,
        [storeId, branchId, sequence]
    );
}

function getTotalStock(product) {
    if (!product) return 0;

    if (product.hasVariants && Array.isArray(product.variants)) {
        return product.variants.reduce(
            (sum, variant) => sum + Number(variant.stock || 0),
            0
        );
    }

    return Number(product.stock || 0);
}


/* -------------------------------------------------------------------------- */
/*                    SAFE PRODUCT REMOVAL / ARCHIVE LOGIC                    */
/* -------------------------------------------------------------------------- */

async function tableExists(connection, tableName) {
    const [rows] = await connection.execute(
        `SELECT 1
         FROM INFORMATION_SCHEMA.TABLES
         WHERE TABLE_SCHEMA = DATABASE()
           AND TABLE_NAME = ?
             LIMIT 1`,
        [tableName]
    );

    return rows.length > 0;
}

async function tableHasColumn(connection, tableName, columnName) {
    const [rows] = await connection.execute(
        `SELECT 1
         FROM INFORMATION_SCHEMA.COLUMNS
         WHERE TABLE_SCHEMA = DATABASE()
           AND TABLE_NAME = ?
           AND COLUMN_NAME = ?
             LIMIT 1`,
        [tableName, columnName]
    );

    return rows.length > 0;
}

async function tableHasIndex(connection, tableName, indexName) {
    const [rows] = await connection.execute(
        `SELECT 1
         FROM INFORMATION_SCHEMA.STATISTICS
         WHERE TABLE_SCHEMA = DATABASE()
           AND TABLE_NAME = ?
           AND INDEX_NAME = ?
             LIMIT 1`,
        [tableName, indexName]
    );

    return rows.length > 0;
}

async function addColumnIfMissing(connection, tableName, columnName, definitionSql) {
    if (await tableHasColumn(connection, tableName, columnName)) {
        return;
    }

    try {
        await connection.execute(
            `ALTER TABLE ${tableName} ADD COLUMN ${definitionSql}`
        );
    } catch (error) {
        // Two API requests can reach this migration at the same time. In that
        // case request A may add the column after request B's INFORMATION_SCHEMA
        // check but before request B executes ALTER TABLE. Treat that race as
        // success instead of turning a valid request into HTTP 500.
        if (error?.code === "ER_DUP_FIELDNAME") {
            return;
        }
        throw error;
    }
}

async function addIndexIfMissing(connection, tableName, indexName, indexSql) {
    if (await tableHasIndex(connection, tableName, indexName)) {
        return;
    }

    try {
        await connection.execute(
            `ALTER TABLE ${tableName} ADD ${indexSql}`
        );
    } catch (error) {
        // Same race protection as addColumnIfMissing(). If another request has
        // already created the named index, the desired schema is already true.
        if (error?.code === "ER_DUP_KEYNAME") {
            return;
        }
        throw error;
    }
}

async function isProductNumberSchemaReady(connection) {
    const requiredStructure = await Promise.all([
        tableHasColumn(connection, "stores", "store_code"),
        tableHasColumn(connection, "branches", "branch_code"),
        tableHasColumn(connection, "products", "product_number"),
        tableExists(connection, "product_number_sequences"),
        tableHasIndex(connection, "stores", "uq_stores_store_code"),
        tableHasIndex(connection, "branches", "uq_branches_store_branch_code"),
        tableHasIndex(connection, "products", "uq_products_product_number"),
    ]);

    if (requiredStructure.some((ready) => !ready)) {
        return false;
    }

    const [missingStoreCodes] = await connection.execute(
        `SELECT id
         FROM stores
         WHERE store_code IS NULL OR TRIM(store_code) = ''
             LIMIT 1`
    );

    if (missingStoreCodes.length > 0) {
        return false;
    }

    const [missingBranchCodes] = await connection.execute(
        `SELECT id
         FROM branches
         WHERE branch_code IS NULL OR TRIM(branch_code) = ''
             LIMIT 1`
    );

    if (missingBranchCodes.length > 0) {
        return false;
    }

    const [missingProductNumbers] = await connection.execute(
        `SELECT id
         FROM products
         WHERE deleted_at IS NULL
           AND (
             product_number IS NULL
                 OR TRIM(product_number) = ''
                 OR product_number NOT REGEXP
                  '^[A-Za-z]{3,8}-[A-Za-z]{3,8}-[0-9]{3,}$'
             )
             LIMIT 1`
    );

    return missingProductNumbers.length === 0;
}

async function ensureProductNumberSchema(connection) {
    if (!(await tableExists(connection, "products"))) return;

    /*
     * IMPORTANT:
     * Do not use MySQL GET_LOCK() here.
     *
     * This function runs inside a normal API request. Multiple inventory,
     * dashboard, POS, and report requests can happen at the same time, so a
     * long-lived advisory lock can make every /api/products request wait and
     * eventually return HTTP 500.
     *
     * Instead:
     * 1. Use a very cheap fast-path once the schema/data are already ready.
     * 2. Keep every DDL operation idempotent.
     * 3. Backfill only when something is actually missing.
     *
     * Product-number allocation itself is protected separately by a row lock
     * on the branch during create_product.
     */
    if (await isProductNumberSchemaReady(connection)) {
        return;
    }

    await addColumnIfMissing(
        connection,
        "stores",
        "store_code",
        "store_code VARCHAR(8) NULL AFTER id"
    );

    await addColumnIfMissing(
        connection,
        "branches",
        "branch_code",
        "branch_code VARCHAR(8) NULL AFTER id"
    );

    await addColumnIfMissing(
        connection,
        "products",
        "product_number",
        "product_number VARCHAR(40) NULL AFTER id"
    );

    await connection.execute(
        `CREATE TABLE IF NOT EXISTS product_number_sequences (
                                                                 store_id BIGINT NOT NULL,
                                                                 branch_id BIGINT NOT NULL,
                                                                 last_sequence INT NOT NULL DEFAULT 0,
                                                                 updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
                                                                 ON UPDATE CURRENT_TIMESTAMP,
                                                                 PRIMARY KEY (store_id, branch_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`
    );

    // Generate a stable store code only for stores that still need one.
    const [stores] = await connection.execute(
        `SELECT id, store_name, slug, store_code
         FROM stores
         WHERE store_code IS NULL OR TRIM(store_code) = ''
         ORDER BY id ASC`
    );

    for (const store of stores) {
        const code = await allocateUniqueStoreCode(
            connection,
            Number(store.id),
            store.store_name,
            store.slug
        );

        await connection.execute(
            `UPDATE stores
             SET store_code = ?
             WHERE id = ?
               AND (store_code IS NULL OR TRIM(store_code) = '')`,
            [code, Number(store.id)]
        );
    }

    // Generate a stable branch code only for branches that still need one.
    const [branches] = await connection.execute(
        `SELECT id, store_id, branch_name, address, branch_code
         FROM branches
         WHERE branch_code IS NULL OR TRIM(branch_code) = ''
         ORDER BY store_id ASC, id ASC`
    );

    for (const branch of branches) {
        const code = await allocateUniqueBranchCode(
            connection,
            Number(branch.store_id),
            Number(branch.id),
            branch.branch_name,
            branch.address
        );

        await connection.execute(
            `UPDATE branches
             SET branch_code = ?
             WHERE id = ?
               AND (branch_code IS NULL OR TRIM(branch_code) = '')`,
            [code, Number(branch.id)]
        );
    }

    // Backfill ONLY products that are missing the new business Product No.
    const [products] = await connection.execute(
        `SELECT
             products.id,
             products.store_id,
             products.branch_id,
             products.product_number,
             stores.store_code,
             branches.branch_code
         FROM products
                  INNER JOIN stores
                             ON stores.id = products.store_id
                  LEFT JOIN branches
                            ON branches.id = products.branch_id
                                AND branches.store_id = products.store_id
         WHERE products.deleted_at IS NULL
           AND (
             products.product_number IS NULL
                 OR TRIM(products.product_number) = ''
                 OR products.product_number NOT REGEXP
                  '^[A-Za-z]{3,8}-[A-Za-z]{3,8}-[0-9]{3,}$'
             )
         ORDER BY products.store_id ASC,
                  products.branch_id ASC,
                  products.id ASC`
    );

    const branchState = new Map();

    for (const product of products) {
        const storeId = Number(product.store_id);
        const branchId = Number(product.branch_id || 0);

        if (!storeId || !branchId || !product.store_code || !product.branch_code) {
            continue;
        }

        const key = `${storeId}:${branchId}`;

        if (!branchState.has(key)) {
            const [maxRows] = await connection.execute(
                `SELECT COALESCE(
                                MAX(
                                        CAST(
                                                SUBSTRING_INDEX(product_number, '-', -1)
                                            AS UNSIGNED
                                        )
                                ),
                                0
                        ) AS maximum
                 FROM products
                 WHERE store_id = ?
                   AND branch_id = ?
                   AND product_number REGEXP
                       '^[A-Za-z]{3,8}-[A-Za-z]{3,8}-[0-9]{3,}$'`,
                [storeId, branchId]
            );

            branchState.set(
                key,
                Number(maxRows?.[0]?.maximum || 0)
            );
        }

        const nextSequence = Number(branchState.get(key) || 0) + 1;
        branchState.set(key, nextSequence);

        const replacement = buildProductNumber(
            String(product.store_code),
            String(product.branch_code),
            nextSequence
        );

        await connection.execute(
            `UPDATE products
             SET product_number = ?
             WHERE id = ?
               AND (
                 product_number IS NULL
                     OR TRIM(product_number) = ''
                     OR product_number NOT REGEXP
                      '^[A-Za-z]{3,8}-[A-Za-z]{3,8}-[0-9]{3,}$'
                 )`,
            [replacement, Number(product.id)]
        );
    }

    // Sync the sequence table to the actual Product Nos. already stored.
    const [sequenceMaximums] = await connection.execute(
        `SELECT
             store_id,
             branch_id,
             COALESCE(
                     MAX(
                             CAST(
                                     SUBSTRING_INDEX(product_number, '-', -1)
                                 AS UNSIGNED
                             )
                     ),
                     0
             ) AS maximum
         FROM products
         WHERE branch_id IS NOT NULL
           AND product_number REGEXP
               '^[A-Za-z]{3,8}-[A-Za-z]{3,8}-[0-9]{3,}$'
         GROUP BY store_id, branch_id`
    );

    for (const row of sequenceMaximums) {
        await commitProductSequence(
            connection,
            Number(row.store_id),
            Number(row.branch_id),
            Number(row.maximum || 0)
        );
    }

    await addIndexIfMissing(
        connection,
        "stores",
        "uq_stores_store_code",
        "UNIQUE INDEX uq_stores_store_code (store_code)"
    );

    await addIndexIfMissing(
        connection,
        "branches",
        "uq_branches_store_branch_code",
        "UNIQUE INDEX uq_branches_store_branch_code (store_id, branch_code)"
    );

    await addIndexIfMissing(
        connection,
        "products",
        "uq_products_product_number",
        "UNIQUE INDEX uq_products_product_number (product_number)"
    );
}

function normalizeRemovalStatus(value) {
    return String(value || "")
        .trim()
        .toLowerCase()
        .replace(/\s+/g, " ");
}

function parsePackageInclusions(value) {
    if (Array.isArray(value)) return value;

    if (typeof value === "string") {
        try {
            const parsed = JSON.parse(value);
            return Array.isArray(parsed) ? parsed : [];
        } catch {
            return [];
        }
    }

    return [];
}

function packageIncludesProduct(inclusions, productId) {
    return (Array.isArray(inclusions) ? inclusions : []).some((item) => {
        if (!item || typeof item !== "object") return false;

        const candidateId = Number(
            item.productId ??
            item.product_id ??
            item.id ??
            0
        );

        return Number.isInteger(candidateId) && candidateId === Number(productId);
    });
}

function isExpiredInventoryDate(value) {
    if (!value) return false;

    const dateText = value instanceof Date
        ? value.toISOString().slice(0, 10)
        : String(value).slice(0, 10);

    if (!/^\d{4}-\d{2}-\d{2}$/.test(dateText)) return false;

    const today = new Date();
    const todayText = [
        today.getFullYear(),
        String(today.getMonth() + 1).padStart(2, "0"),
        String(today.getDate()).padStart(2, "0"),
    ].join("-");

    return dateText < todayText;
}

async function getProductRemovalImpact(
    connection,
    storeId,
    activeBranchId,
    product
) {
    const productId = Number(product.id);
    const blockers = [];
    const history = [];
    const counts = {
        posSales: 0,
        bookings: 0,
        activeBookings: 0,
        packages: 0,
        activePackages: 0,
        restocks: 0,
    };

    // POS history. Any order item referencing the product is historical data
    // that should survive product removal.
    if (await tableExists(connection, "order_items")) {
        const [rows] = await connection.execute(
            `SELECT COUNT(*) AS total
             FROM order_items
             WHERE product_id = ?`,
            [productId]
        );

        counts.posSales = Number(rows[0]?.total || 0);
        if (counts.posSales > 0) {
            history.push("POS sales history");
        }
    }

    // Booking history and unresolved bookings. Pending Review, Confirmed and
    // Preparing are considered active because the booking has not yet reached
    // a final Completed/Cancelled state.
    if (
        await tableExists(connection, "booking_items") &&
        await tableExists(connection, "bookings")
    ) {
        const [historyRows] = await connection.execute(
            `SELECT COUNT(*) AS total
             FROM booking_items
             WHERE product_id = ?`,
            [productId]
        );

        counts.bookings = Number(historyRows[0]?.total || 0);
        if (counts.bookings > 0) {
            history.push("booking history");
        }

        const [activeRows] = await connection.execute(
            `SELECT COUNT(*) AS total
             FROM booking_items bi
                      INNER JOIN bookings b
                                 ON b.id = bi.booking_id
             WHERE bi.product_id = ?
               AND LOWER(TRIM(COALESCE(b.status, ''))) IN
                   ('pending review', 'confirmed', 'preparing')`,
            [productId]
        );

        counts.activeBookings = Number(activeRows[0]?.total || 0);
        if (counts.activeBookings > 0) {
            blockers.push(
                "This product is used by an active booking. Complete or cancel the booking before removing the product."
            );
        }
    }

    // Packages are stored primarily in packages.inclusions as JSON in the
    // current StockNBook implementation. Read and inspect the JSON in JS so the
    // check remains compatible with MySQL/TiDB JSON/text storage.
    if (await tableExists(connection, "packages")) {
        const packageColumns = {
            branchId: await tableHasColumn(connection, "packages", "branch_id"),
            status: await tableHasColumn(connection, "packages", "status"),
            inclusions: await tableHasColumn(connection, "packages", "inclusions"),
        };

        if (packageColumns.inclusions) {
            let packageQuery = `
                SELECT id, name,
                       ${packageColumns.status ? "status" : "'Active' AS status"},
                       inclusions
                FROM packages
                WHERE store_id = ?
            `;
            const packageParams = [storeId];

            if (activeBranchId && packageColumns.branchId) {
                packageQuery += " AND branch_id = ?";
                packageParams.push(activeBranchId);
            }

            const [packageRows] = await connection.execute(
                packageQuery,
                packageParams
            );

            for (const pkg of packageRows) {
                const inclusions = parsePackageInclusions(pkg.inclusions);
                if (!packageIncludesProduct(inclusions, productId)) continue;

                counts.packages += 1;

                if (normalizeRemovalStatus(pkg.status) === "active") {
                    counts.activePackages += 1;
                    blockers.push(
                        `This product is included in the active package “${toSafeString(pkg.name, 120) || `Package #${pkg.id}`}”. Remove it from that package first.`
                    );
                }
            }

            if (counts.packages > 0) {
                history.push("package history");
            }
        }
    }

    // Backward compatibility for installations that use a normalized
    // package_items table in addition to the packages.inclusions JSON field.
    if (
        await tableExists(connection, "package_items") &&
        await tableHasColumn(connection, "package_items", "product_id")
    ) {
        const [packageItemRows] = await connection.execute(
            `SELECT COUNT(*) AS total
             FROM package_items
             WHERE product_id = ?`,
            [productId]
        );

        const normalizedPackageHistory = Number(packageItemRows[0]?.total || 0);
        if (normalizedPackageHistory > 0) {
            if (counts.packages === 0) history.push("package history");
            counts.packages = Math.max(counts.packages, normalizedPackageHistory);
        }

        if (
            await tableHasColumn(connection, "package_items", "package_id") &&
            await tableExists(connection, "packages") &&
            await tableHasColumn(connection, "packages", "status")
        ) {
            const [activePackageRows] = await connection.execute(
                `SELECT COUNT(*) AS total
                 FROM package_items pi
                          INNER JOIN packages p
                                     ON p.id = pi.package_id
                 WHERE pi.product_id = ?
                   AND LOWER(TRIM(COALESCE(p.status, ''))) = 'active'`,
                [productId]
            );

            const normalizedActivePackages = Number(activePackageRows[0]?.total || 0);
            if (normalizedActivePackages > 0 && counts.activePackages === 0) {
                blockers.push(
                    "This product is included in an active package. Remove it from the package first."
                );
            }
            counts.activePackages = Math.max(
                counts.activePackages,
                normalizedActivePackages
            );
        }
    }

    // Restock history is optional and is created by this Lambda when needed.
    if (
        await tableExists(connection, "restock_history") &&
        await tableHasColumn(connection, "restock_history", "product_id")
    ) {
        const [rows] = await connection.execute(
            `SELECT COUNT(*) AS total
             FROM restock_history
             WHERE product_id = ?`,
            [productId]
        );

        counts.restocks = Number(rows[0]?.total || 0);
        if (counts.restocks > 0) {
            history.push("restock history");
        }
    }

    if (await tableExists(connection, "inventory_purchase_items")) {
        const [rows] = await connection.execute(
            `SELECT COUNT(*) AS total FROM inventory_purchase_items WHERE product_id=?`, [productId]);
        if (Number(rows[0]?.total || 0) > 0) history.push("supplier purchase history");
    }

    // A supplier purchase is a financial record and must survive product removal.
    if (await tableExists(connection, "inventory_initial_purchases")) {
        const [purchaseRows] = await connection.execute(
            `SELECT COUNT(*) AS total FROM inventory_initial_purchases
             WHERE store_id = ? AND product_id = ?`,
            [storeId, productId]
        );
        if (Number(purchaseRows[0]?.total || 0) > 0) {
            history.push("initial supplier purchase / payable history");
        }
    }

    // Expiration by itself is not a reason for permanent deletion. Preserve the
    // record by archiving it, matching StockNBook's inventory-history policy.
    const productExpired = isExpiredInventoryDate(product.expirationDate);
    const variantExpired = Array.isArray(product.variants)
        ? product.variants.some((variant) =>
            isExpiredInventoryDate(variant.expirationDate)
        )
        : false;

    if (productExpired || variantExpired) {
        history.push("expired inventory record");
    }

    const uniqueBlockers = Array.from(new Set(blockers));
    const uniqueHistory = Array.from(new Set(history));

    let mode = "permanent";

    if (uniqueBlockers.length > 0) {
        mode = "blocked";
    } else if (uniqueHistory.length > 0) {
        mode = "archive";
    }

    return {
        mode,
        blockers: uniqueBlockers,
        history: uniqueHistory,
        counts,
    };
}

function isVariantExpiryRemovalEligible(variant) {
    const raw = variant.expiration_date ?? variant.expirationDate;
    const text = raw instanceof Date ? raw.toISOString().slice(0, 10) : String(raw || "").slice(0, 10);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(text)) return false;
    const todayParts = new Intl.DateTimeFormat("en-GB", {
        timeZone: "Asia/Manila", year: "numeric", month: "2-digit", day: "2-digit",
    }).formatToParts(new Date());
    const part = kind => todayParts.find(item => item.type === kind)?.value || "";
    const today = `${part("year")}-${part("month")}-${part("day")}`;
    const diffDays = (Date.parse(`${text}T00:00:00Z`) - Date.parse(`${today}T00:00:00Z`)) / 86400000;
    return Number.isFinite(diffDays) && diffDays <= 30;
}

/* Only the selected variant is removed. Parent-level references are handled
   conservatively when older StockNBook records do not identify a variant. */
async function getVariantRemovalImpact(connection, storeId, activeBranchId, product, variant) {
    const productId = Number(product.id);
    const variantId = Number(variant.id);
    const blockers = [];
    const history = [];
    const counts = {};

    const referenceCount = async (table, name) => {
        if (!(await tableExists(connection, table)) ||
            !(await tableHasColumn(connection, table, "product_id"))) return 0;
        const hasVariantId = await tableHasColumn(connection, table, "variant_id");
        // A NULL variant_id can be a legacy, unallocated reference to any
        // variant of this product. Never silently treat it as unrelated.
        const [rows] = await connection.execute(
            `SELECT COUNT(*) AS total FROM ${table} WHERE product_id=?` +
            (hasVariantId ? " AND (variant_id=? OR variant_id IS NULL)" : ""),
            hasVariantId ? [productId, variantId] : [productId]
        );
        const count = Number(rows[0]?.total || 0);
        counts[name] = count;
        if (count > 0) history.push(name);
        return count;
    };

    await referenceCount("order_items", "POS sales history");
    await referenceCount("inventory_purchase_items", "supplier purchase history");
    await referenceCount("inventory_stock_receipt_items", "stock receipt history");
    await referenceCount("inventory_stock_movements", "stock movement history");
    await referenceCount("inventory_stock_adjustments", "stock adjustment history");

    // This legacy table records variant_name instead of a stable variant id.
    // Treat product-level history as a reference rather than deleting its data.
    await referenceCount("restock_history", "restock history");
    await referenceCount("inventory_initial_purchases", "initial purchase history");

    if (await tableExists(connection, "booking_items") &&
        await tableExists(connection, "bookings") &&
        await tableHasColumn(connection, "booking_items", "product_id")) {
        const hasVariantId = await tableHasColumn(connection, "booking_items", "variant_id");
        const condition = hasVariantId ? " AND (bi.variant_id=? OR bi.variant_id IS NULL)" : "";
        const args = hasVariantId ? [productId, variantId] : [productId];
        const [rows] = await connection.execute(
            `SELECT COUNT(*) AS total FROM booking_items bi WHERE bi.product_id=?${condition}`, args
        );
        counts.bookings = Number(rows[0]?.total || 0);
        if (counts.bookings > 0) history.push("booking history");
        const [activeRows] = await connection.execute(
            `SELECT COUNT(*) AS total FROM booking_items bi
                                               JOIN bookings b ON b.id=bi.booking_id
             WHERE bi.product_id=?${condition}
               AND LOWER(TRIM(COALESCE(b.status,''))) IN ('pending review','confirmed','preparing')`, args
        );
        if (Number(activeRows[0]?.total || 0) > 0) {
            blockers.push("This variant may be needed for an active booking. Complete or cancel the booking first.");
        }
    }

    // JSON package inclusions can be product-level or variant-specific.
    // Product-level inclusions are ambiguous, so protect all child variants.
    if (await tableExists(connection, "packages") &&
        await tableHasColumn(connection, "packages", "inclusions")) {
        const hasBranch = await tableHasColumn(connection, "packages", "branch_id");
        const hasStatus = await tableHasColumn(connection, "packages", "status");
        const [rows] = await connection.execute(
            `SELECT id, name, ${hasStatus ? "status" : "'Active' AS status"}, inclusions
             FROM packages WHERE store_id=?` +
            (activeBranchId && hasBranch ? " AND branch_id=?" : ""),
            activeBranchId && hasBranch ? [storeId, activeBranchId] : [storeId]
        );
        for (const pkg of rows) {
            const matched = parsePackageInclusions(pkg.inclusions).some(item => {
                if (!item || typeof item !== "object") return false;
                const itemProductId = Number(item.productId ?? item.product_id ?? item.id ?? 0);
                const itemVariantId = item.variantId ?? item.variant_id;
                return itemProductId === productId &&
                    (itemVariantId == null || itemVariantId === "" || Number(itemVariantId) === variantId);
            });
            if (!matched) continue;
            history.push("package history");
            if (normalizeRemovalStatus(pkg.status) === "active") {
                blockers.push(`This variant may be used in active package "${toSafeString(pkg.name, 120) || pkg.id}". Remove it from the package first.`);
            }
        }
    }
    if (await tableExists(connection, "package_items") &&
        await tableHasColumn(connection, "package_items", "product_id")) {
        const hasVariantId = await tableHasColumn(connection, "package_items", "variant_id");
        const condition = hasVariantId ? " AND (pi.variant_id=? OR pi.variant_id IS NULL)" : "";
        const args = hasVariantId ? [productId, variantId] : [productId];
        const [rows] = await connection.execute(
            `SELECT COUNT(*) AS total FROM package_items pi WHERE pi.product_id=?${condition}`, args
        );
        if (Number(rows[0]?.total || 0) > 0) history.push("package history");
        if (await tableExists(connection, "packages") &&
            await tableHasColumn(connection, "packages", "status") &&
            await tableHasColumn(connection, "package_items", "package_id")) {
            const [active] = await connection.execute(
                `SELECT COUNT(*) AS total FROM package_items pi
                                                   JOIN packages p ON p.id=pi.package_id
                 WHERE pi.product_id=?${condition}
                   AND LOWER(TRIM(COALESCE(p.status,'')))='active'`, args
            );
            if (Number(active[0]?.total || 0) > 0) {
                blockers.push("This variant may be used in an active package. Remove that package inclusion first.");
            }
        }
    }
    // Expiration records are retained under StockNBook's established archive policy.
    if (isExpiredInventoryDate(variant.expiration_date ?? variant.expirationDate)) {
        history.push("expired inventory record");
    }
    return {
        mode: blockers.length ? "blocked" : history.length ? "archive" : "permanent",
        blockers: [...new Set(blockers)],
        history: [...new Set(history)],
        counts,
    };
}

// Must run inside a transaction after locking the parent to serialize against
// stock receipts, stock adjustments, and edits to that same product.
async function applyVariantRemoval(connection, storeId, activeBranchId, productId, variantId, employee, forceArchive = false) {
    let sql = `SELECT id, name, product_number AS productNumber, has_variants AS hasVariants,
                      branch_id AS branchId FROM products
               WHERE id=? AND store_id=? AND deleted_at IS NULL`;
    const params = [productId, storeId];
    if (activeBranchId) { sql += " AND branch_id=?"; params.push(activeBranchId); }
    sql += " FOR UPDATE";
    const [products] = await connection.execute(sql, params);
    if (!products.length || !Number(products[0].hasVariants)) {
        const err = new Error("Active variant product not found.");
        err.removalStatus = 404;
        throw err;
    }
    const product = products[0];
    const [variants] = await connection.execute(
        `SELECT id, variant_number AS variantNumber, variant_values AS variantValues,
                expiration_date, stock
         FROM product_variants
         WHERE id=? AND product_id=? AND deleted_at IS NULL FOR UPDATE`,
        [variantId, productId]
    );
    if (!variants.length) {
        const err = new Error("The selected variant is no longer active. Refresh inventory.");
        err.removalStatus = 404;
        throw err;
    }
    const variant = variants[0];
    if (!isVariantExpiryRemovalEligible(variant)) {
        const err = new Error("Only expired or expiring-soon variants can be removed from this review action.");
        err.removalStatus = 409;
        throw err;
    }
    const impact = await getVariantRemovalImpact(connection, storeId, activeBranchId, product, variant);
    if (impact.mode === "blocked") {
        const err = new Error(impact.blockers[0] || "Active commitments prevent variant removal.");
        err.removalStatus = 409;
        err.impact = impact;
        throw err;
    }
    const mode = forceArchive ? "archive" : impact.mode;
    if (mode === "archive") {
        const [result] = await connection.execute(
            `UPDATE product_variants SET deleted_at=NOW()
             WHERE id=? AND product_id=? AND deleted_at IS NULL`, [variantId, productId]
        );
        if (!Number(result.affectedRows)) throw new Error("Variant was not archived.");
    } else {
        const [result] = await connection.execute(
            `DELETE FROM product_variants WHERE id=? AND product_id=? AND deleted_at IS NULL`,
            [variantId, productId]
        );
        if (!Number(result.affectedRows)) throw new Error("Variant was not deleted.");
    }

    // Never remove or change sibling variants. Update only the parent summary,
    // using remaining ACTIVE variants. Archive an empty parent but keep its
    // identifiers and transaction references intact.
    const [remaining] = await connection.execute(
        `SELECT stock, alert_level AS alertLevel, original_price AS originalPrice,
                sales_price AS salesPrice
         FROM product_variants WHERE product_id=? AND deleted_at IS NULL`, [productId]
    );
    if (remaining.length) {
        const stock = getVariantTotalStock(remaining);
        const alert = getVariantTotalAlert(remaining);
        const cost = getMinVariantPrice(remaining, "originalPrice");
        const price = getMinVariantPrice(remaining, "salesPrice");
        await connection.execute(
            `UPDATE products SET stock=?, alert_level=?, original_price=?, sales_price=?
             WHERE id=? AND store_id=? AND deleted_at IS NULL`,
            [stock, alert, cost, price, productId, storeId]
        );
    } else {
        await connection.execute(
            `UPDATE products SET stock=0, alert_level=0, deleted_at=NOW()
             WHERE id=? AND store_id=? AND deleted_at IS NULL`,
            [productId, storeId]
        );
    }
    await logEmployeeAction(connection, {
        storeId, branchId: Number(product.branchId), employee,
        module: "Inventory", referenceNumber: variant.variantNumber || product.productNumber || String(variantId),
        action: mode === "archive" ? "Archived variant" : "Permanently deleted variant",
        referenceId: String(productId),
        details: `${mode === "archive" ? "Archived" : "Deleted"} variant ${getVariantDisplayName(parseVariantValues(variant.variantValues))} (${variant.variantNumber || variantId}) of ${product.name}; sibling variants unchanged`,
    });
    return { mode, impact: { ...impact, mode } };
}

async function archiveProduct(connection, storeId, activeBranchId, productId) {
    await connection.execute(
        `UPDATE product_variants
         SET deleted_at = COALESCE(deleted_at, NOW())
         WHERE product_id = ?`,
        [productId]
    );

    let query = `
        UPDATE products
        SET deleted_at = NOW()
        WHERE id = ?
          AND store_id = ?
          AND deleted_at IS NULL
    `;
    const params = [productId, storeId];

    if (activeBranchId) {
        query += " AND branch_id = ?";
        params.push(activeBranchId);
    }

    const [result] = await connection.execute(query, params);
    return Number(result.affectedRows || 0);
}

async function permanentlyDeleteProduct(
    connection,
    storeId,
    activeBranchId,
    productId
) {
    // Variants are safe to physically remove only after the impact check proves
    // that no transaction/package/booking/restock history depends on the product.
    await connection.execute(
        "DELETE FROM product_variants WHERE product_id = ?",
        [productId]
    );

    let query = `
        DELETE FROM products
        WHERE id = ?
          AND store_id = ?
          AND deleted_at IS NULL
    `;
    const params = [productId, storeId];

    if (activeBranchId) {
        query += " AND branch_id = ?";
        params.push(activeBranchId);
    }

    const [result] = await connection.execute(query, params);
    return Number(result.affectedRows || 0);
}

exports.handler = async (event) => {
    const headers = {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type, Authorization",
        "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
        "Content-Type": "application/json",
    };

    const method =
        event?.requestContext?.http?.method ||
        event?.httpMethod;

    if (method === "OPTIONS") {
        return { statusCode: 204, headers, body: "" };
    }

    let body = {};

    try {
        body = JSON.parse(event?.body || "{}");
    } catch {
        return badRequest(headers, "Invalid JSON body");
    }

    const action = body.action;
    let connection;

    try {
        connection = await mysql.createConnection(dbConfig);

        const authHeader =
            event?.headers?.authorization ||
            event?.headers?.Authorization ||
            "";

        if (!authHeader) {
            return unauthorized(headers, "No token provided");
        }

        let decoded;
        let storeId;
        let tokenBranchId;
        let tokenRole;

        try {
            const token = authHeader.replace("Bearer ", "");
            decoded = jwt.verify(token, JWT_SECRET);

            storeId = Number(decoded.store_id);
            tokenBranchId = decoded.branch_id ? Number(decoded.branch_id) : null;
            tokenRole = String(decoded.role || "").toLowerCase();
        } catch {
            return unauthorized(headers, "Invalid token");
        }

        if (!Number.isInteger(storeId) || storeId <= 0) {
            return unauthorized(headers, "Invalid store in token");
        }

        const storeExists = await ensureStoreExists(connection, storeId);

        if (!storeExists) {
            return badRequest(headers, "Store account not found");
        }

        const isBranchUser = tokenRole === "manager" || tokenRole === "staff";

        const rawRequestedBranchId = firstDefined(body.branch_id, body.branchId);

        const requestedBranchId =
            rawRequestedBranchId !== undefined &&
            rawRequestedBranchId !== null &&
            rawRequestedBranchId !== ""
                ? Number(rawRequestedBranchId)
                : null;

        const activeBranchId = isBranchUser
            ? tokenBranchId
            : requestedBranchId || null;

        if (isBranchUser && !activeBranchId) {
            return badRequest(headers, "Missing branch_id for branch user");
        }

        if (activeBranchId) {
            const branchOk = await ensureBranchBelongsToStore(
                connection,
                activeBranchId,
                storeId
            );

            if (!branchOk) {
                return badRequest(headers, "Invalid branch for this store");
            }
        }

        // Keep Product No. as a real, unique database field. This also
        // backfills products created before the product_number column existed.
        await ensureProductNumberSchema(connection);

        if (action === "get_products") {
            const products = await getProducts(connection, storeId, activeBranchId);
            const visibleProducts = hideProductCostsForNonOwners(products, tokenRole);
            return jsonResponse(200, headers, { products: visibleProducts });
        }

        // Read-only purchase references for the existing Recent Stock Activity rows.
        // The manager's branch is derived from the token; IDs are never fabricated.
        if (action === "get_recent_purchased_stock_in") {
            if (!["owner", "manager"].includes(tokenRole)) {
                return unauthorized(headers, "Only owners and managers may view purchase references.");
            }
            if (!activeBranchId) return badRequest(headers, "A branch is required.");
            if (!(await tableExists(connection, "inventory_stock_receipts")) ||
                !(await tableExists(connection, "inventory_stock_receipt_items")) ||
                !(await tableExists(connection, "inventory_purchase_transactions"))) {
                return jsonResponse(200, headers, { success: true, stockInMovements: [] });
            }
            const hasCreatedAt = await tableHasColumn(connection, "inventory_stock_receipts", "created_at");
            const dateExpression = hasCreatedAt ? "r.created_at" : "r.received_date";
            const displayDate = hasCreatedAt ? "r.created_at" : "DATE_FORMAT(r.received_date, '%Y-%m-%d')";
            const [rows] = await connection.execute(
                `SELECT ri.product_id AS productId,
                        COALESCE(p.name, 'Archived Product') AS productName,
                        ri.variant_name AS variantName,
                        ri.quantity_received AS quantity,
                        ${displayDate} AS recordedAt,
                        pt.purchase_number AS purchaseNumber,
                        pt.source AS purchaseSource
                 FROM inventory_stock_receipt_items ri
                          INNER JOIN inventory_stock_receipts r ON r.id = ri.receipt_id
                          LEFT JOIN inventory_purchase_transactions pt
                                    ON pt.id = r.purchase_id AND pt.store_id = r.store_id
                                        AND pt.branch_id = r.branch_id
                          LEFT JOIN products p ON p.id = ri.product_id AND p.store_id = r.store_id
                     AND p.branch_id = r.branch_id
                 WHERE r.store_id = ? AND r.branch_id = ?
                   AND ri.quantity_received > 0
                   AND ${dateExpression} >= DATE_SUB(NOW(), INTERVAL 30 DAY)
                 ORDER BY ${dateExpression} DESC, ri.id DESC
                     LIMIT 500`,
                [storeId, activeBranchId]
            );
            return jsonResponse(200, headers, { success: true, stockInMovements: rows });
        }

        // Read-only, branch-scoped date lookup for Manager Inventory's
        // "Last Stock In" column. Only positive stock increases qualify.
        if (action === "get_last_stock_in") {
            if (!activeBranchId) return badRequest(headers, "A branch is required.");
            if (!(await tableExists(connection, "restock_history")) ||
                !(await tableExists(connection,"inventory_stock_receipts"))) {
                return jsonResponse(200, headers, { success: true, stockInRecords: [] });
            }
            const [rows] = await connection.execute(
                `SELECT events.productId, events.variantId, events.variantName,
                        DATE_FORMAT(MAX(events.stockInDate),'%Y-%m-%d') AS stockInDate
                 FROM (
                          SELECT rh.product_id AS productId, CAST(NULL AS SIGNED) AS variantId,
                                 rh.variant_name AS variantName,
                                 COALESCE(rh.received_date,DATE(rh.created_at)) AS stockInDate,
                                 rh.store_id AS storeId,rh.branch_id AS branchId
                          FROM restock_history rh WHERE rh.quantity_added>0
                          UNION ALL
                          SELECT ri.product_id AS productId,ri.variant_id AS variantId,
                                 ri.variant_name AS variantName,r.received_date AS stockInDate,
                                 r.store_id AS storeId,r.branch_id AS branchId
                          FROM inventory_stock_receipt_items ri
                                   JOIN inventory_stock_receipts r ON r.id=ri.receipt_id
                          WHERE ri.quantity_received>0
                      ) AS events
                          JOIN products p ON p.id=events.productId AND p.store_id=events.storeId
                     AND p.branch_id=events.branchId AND p.deleted_at IS NULL
                 WHERE events.storeId=? AND events.branchId=?
                   AND events.stockInDate <= CURRENT_DATE()
                 GROUP BY events.productId,events.variantId,events.variantName`,
                [storeId,activeBranchId]
            );
            // An Added movement must show the quantity actually received when
            // the product was created, never the current stock after POS sales.
            // Each Add Product / Import purchase stores its original item units.
            let initialStockQuantities = [];
            if (await tableExists(connection, "inventory_purchase_transactions") &&
                await tableExists(connection, "inventory_purchase_items")) {
                const [initialRows] = await connection.execute(
                    `SELECT pi.product_id AS productId,
                            SUM(pi.quantity_ordered) AS initialQuantity
                     FROM inventory_purchase_items pi
                              JOIN inventory_purchase_transactions pt ON pt.id = pi.purchase_id
                              JOIN products p ON p.id = pi.product_id
                     WHERE pt.store_id = ? AND pt.branch_id = ?
                       AND pt.source IN ('add', 'import')
                       AND p.store_id = ? AND p.branch_id = ?
                       AND p.deleted_at IS NULL
                     GROUP BY pi.product_id`,
                    [storeId, activeBranchId, storeId, activeBranchId]
                );
                initialStockQuantities = initialRows;
            }
            return jsonResponse(200, headers, { success: true, stockInRecords: rows, initialStockQuantities });
        }


        if (action === "get_stock_suppliers") {
            if (tokenRole !== "owner" && tokenRole !== "manager") {
                return unauthorized(headers, "Only owners and managers may view suppliers.");
            }
            if (!activeBranchId) return badRequest(headers, "A branch is required.");
            const suppliers = new Set();
            for (const table of ["inventory_initial_purchases", "inventory_stock_receipts"]) {
                if (!(await tableExists(connection, table))) continue;
                const [rows] = await connection.execute(
                    `SELECT DISTINCT supplier FROM ${table}
                     WHERE store_id = ? AND branch_id = ? AND supplier IS NOT NULL`,
                    [storeId, activeBranchId]);
                for (const row of rows) {
                    if (String(row.supplier || "").trim()) suppliers.add(String(row.supplier).trim());
                }
            }
            return jsonResponse(200, headers, { success: true, suppliers: [...suppliers].sort() });
        }

        /* Dedicated stock receipt: updates quantities and moving-average unit costs,
           applying the manager's chosen selling price within the same transaction.
           Earlier supplier purchase amounts and variant definitions are untouched. */
        if (action === "receive_stock") {
            if (tokenRole !== "owner" && tokenRole !== "manager") {
                return unauthorized(headers, "Only owners and managers may receive supplier stock.");
            }
            const productId = Number(body.product_id ?? body.productId);
            if (!activeBranchId || !Number.isInteger(productId) || productId <= 0) {
                return badRequest(headers, "A valid product and branch are required.");
            }
            const supplier = toSafeString(body.supplier, 150);
            const invoiceNumber = toSafeString(body.supplierInvoiceNumber ?? body.supplier_invoice_number, 80) || null;
            let receivedDate;
            let dueDate;
            try {
                receivedDate = normalizeOptionalDate(body.receivedDate);
                dueDate = normalizeOptionalDate(body.paymentDueDate);
            } catch (error) { return badRequest(headers, error.message); }
            const paymentMethod = String(body.paymentMethod || "").trim().toLowerCase();
            const todayParts = new Intl.DateTimeFormat("en-GB", {
                timeZone: "Asia/Manila", year: "numeric", month: "2-digit", day: "2-digit",
            }).formatToParts(new Date());
            const datePart = (kind) => todayParts.find(p => p.type === kind)?.value || "";
            const todayInPhilippines = `${datePart("year")}-${datePart("month")}-${datePart("day")}`;
            if (receivedDate && receivedDate > todayInPhilippines) {
                return badRequest(headers, "Date Received cannot be in the future.");
            }
            if (!supplier || !receivedDate || !["cash", "credit"].includes(paymentMethod)) {
                return badRequest(headers, "Supplier, Date Received and Cash/Credit are required.");
            }
            const rawLines = body.lines;
            if (!Array.isArray(rawLines) || rawLines.length === 0 || rawLines.length > 200) {
                return badRequest(headers, "Select between 1 and 200 receiving lines.");
            }
            const cleanLines = [];
            const seen = new Set();
            for (const raw of rawLines) {
                const variantId = raw.variantId == null ? null : Number(raw.variantId);
                const quantity = Number(raw.quantity);
                const unitPurchaseCost = Number(raw.unitPurchaseCost);
                let expirationDate;
                try { expirationDate = normalizeOptionalDate(raw.expirationDate); }
                catch (error) { return badRequest(headers, error.message); }
                if ((variantId !== null && (!Number.isInteger(variantId) || variantId <= 0)) ||
                    !Number.isSafeInteger(quantity) || quantity <= 0 || quantity > 1000000 ||
                    !Number.isFinite(unitPurchaseCost) || unitPurchaseCost < 0 || unitPurchaseCost > 100000000 ||
                    Math.round(unitPurchaseCost * 100) !== unitPurchaseCost * 100 &&
                    Math.abs(Math.round(unitPurchaseCost * 100) - unitPurchaseCost * 100) > 0.00001) {
                    return badRequest(headers, "Each line requires a positive whole quantity and a valid unit purchase cost (2 decimal places max).");
                }
                if (expirationDate && expirationDate < receivedDate) {
                    return badRequest(headers, "An incoming batch cannot be expired before Date Received.");
                }
                const key = String(variantId ?? "regular");
                if (seen.has(key)) return badRequest(headers, "Duplicate receiving variant line.");
                seen.add(key);
                if (raw.orderedQuantity !== undefined && Number(raw.orderedQuantity) !== quantity) {
                    return badRequest(headers, "Receive Stock accepts only quantities received now. Create another purchase for a separate delivery.");
                }
                // Pricing choice is optional for older clients; default to keeping
                // the existing retail price. The server always calculates average cost.
                const pricingDecision = String(raw.pricingDecision || "keep").trim().toLowerCase();
                if (!["keep", "suggested", "manual"].includes(pricingDecision)) {
                    return badRequest(headers, "Selling price decision must be Keep, Suggested, or Manual.");
                }
                let manualSellingPrice = null;
                if (pricingDecision === "manual") {
                    try {
                        manualSellingPrice = exactMoney(raw.manualSellingPrice, "Manual Selling Price") / 100;
                    } catch (error) { return badRequest(headers, error.message); }
                    if (manualSellingPrice > 100000000) {
                        return badRequest(headers, "Manual Selling Price is too large.");
                    }
                }
                // An explicit markup is used for newly priced zero-stock items
                // and for applying the weighted-average suggestion to remaining stock.
                let pricingMarkupPercentage = null;
                if (pricingDecision === "suggested" && raw.pricingMarkupPercentage !== undefined) {
                    const markupInput = raw.pricingMarkupPercentage;
                    if (markupInput === null || markupInput === "" ||
                        !Number.isFinite(Number(markupInput)) || Number(markupInput) < 0 ||
                        Number(markupInput) > 99999 ||
                        Math.abs(Number(markupInput) * 10000 - Math.round(Number(markupInput) * 10000)) > 0.00001) {
                        return badRequest(headers, "Markup Percentage must be between 0 and 99999 (up to four decimal places).");
                    }
                    pricingMarkupPercentage = Number(markupInput);
                }
                cleanLines.push({ variantId, quantity, unitPurchaseCost, expirationDate,
                    pricingDecision, manualSellingPrice, pricingMarkupPercentage,
                    expectedPricing:raw.expectedPricing ?? null });
            }
            const costCents = cleanLines.reduce((sum, line) =>
                sum + line.quantity * Math.round(line.unitPurchaseCost * 100), 0);
            if (!Number.isSafeInteger(costCents)) return badRequest(headers, "Purchase cost is too large.");
            const purchaseTotal = costCents / 100;
            const inputPaid = Number(body.amountPaid ?? 0);
            if (!Number.isFinite(inputPaid) || inputPaid < 0 || inputPaid > purchaseTotal ||
                Math.abs(Math.round(inputPaid * 100) - inputPaid * 100) > 0.00001) {
                return badRequest(headers, "Amount Paid must be between zero and the total purchase cost.");
            }
            const amountPaid = paymentMethod === "cash" ? purchaseTotal : Math.round(inputPaid * 100) / 100;
            const outstandingBalance = (costCents - Math.round(amountPaid * 100)) / 100;
            if (body.purchaseId != null && String(body.purchaseId).trim() !== "") {
                return badRequest(headers, "Each Receive Stock submission creates one new supplier purchase. Existing-purchase deliveries are not supported.");
            }
            if (outstandingBalance > 0 && (!dueDate || dueDate < receivedDate)) {
                return badRequest(headers, "A valid Payment Due Date is required for unpaid credit.");
            }
            if (!(await tableExists(connection, "inventory_purchase_transactions")) ||
                !(await tableExists(connection, "inventory_stock_receipts")) ||
                !(await tableExists(connection, "inventory_stock_receipt_items"))) {
                return badRequest(headers, "Run the Receive Stock SQL migration before receiving stock.");
            }
            const requestKey = toSafeString(body.requestKey, 80);
            if (!requestKey) return badRequest(headers, "Receiving request key is required to prevent duplicate stock receipts.");
            await connection.beginTransaction();
            // Lock the parent product to serialize concurrent receives for it.
            const [lockedProducts] = await connection.execute(
                `SELECT id, name, has_variants, product_number, stock,
                        original_price, sales_price, pricing_method, markup_percentage FROM products
                 WHERE id = ? AND store_id = ? AND branch_id = ? AND deleted_at IS NULL
                     FOR UPDATE`, [productId, storeId, activeBranchId]);
            if (!lockedProducts.length) { await safeRollback(connection); return notFound(headers, "Product not found."); }
            const [previous] = await connection.execute(
                `SELECT id, purchase_id AS purchaseId FROM inventory_stock_receipts
                 WHERE store_id=? AND branch_id=? AND request_key=? LIMIT 1`,
                [storeId, activeBranchId, requestKey]);
            if (previous.length) {
                await connection.commit();
                return jsonResponse(200, headers, {success:true, alreadyProcessed:true,
                    receiptId:previous[0].id, purchaseId:previous[0].purchaseId});
            }
            const current = lockedProducts[0];
            const isVariantProduct = Number(current.has_variants) === 1;
            const variants = new Map();
            if (isVariantProduct) {
                const [rows] = await connection.execute(
                    `SELECT id, stock, variant_values, original_price, sales_price,
                            pricing_method, markup_percentage FROM product_variants
                     WHERE product_id = ? AND deleted_at IS NULL FOR UPDATE`, [productId]);
                for (const variant of rows) variants.set(Number(variant.id), variant);
            }
            const receiptLines = [];
            for (const line of cleanLines) {
                if (isVariantProduct && (line.variantId === null || !variants.has(line.variantId))) {
                    await safeRollback(connection);
                    return badRequest(headers, "One receiving variant no longer belongs to this product.");
                }
                if (!isVariantProduct && line.variantId !== null) {
                    await safeRollback(connection);
                    return badRequest(headers, "Regular products cannot receive variant lines.");
                }
                const variant = isVariantProduct ? variants.get(line.variantId) : null;
                const variantName = variant ? getVariantDisplayName(parseVariantValues(variant.variant_values)) : null;
                const pricingRow = variant || current;
                const currentStock = Number(pricingRow.stock);
                const oldAverageCost = Number(pricingRow.original_price);
                const oldSellingPrice = Number(pricingRow.sales_price);
                const oldPricingMethod = String(pricingRow.pricing_method || "manual").toLowerCase();
                const oldMarkupRaw = pricingRow.markup_percentage;
                const oldMarkup = oldMarkupRaw === null || oldMarkupRaw === undefined ? null : Number(oldMarkupRaw);
                if (!Number.isSafeInteger(currentStock) || currentStock < 0 ||
                    !Number.isFinite(oldAverageCost) || oldAverageCost < 0 ||
                    !Number.isFinite(oldSellingPrice) || oldSellingPrice < 0 ||
                    (oldMarkup !== null && (!Number.isFinite(oldMarkup) || oldMarkup < 0))) {
                    await safeRollback(connection);
                    return badRequest(headers, "The saved inventory cost, price, or quantity is invalid.");
                }
                // Prevent overwriting changes made by another manager after the dialog loaded.
                const expected = line.expectedPricing;
                if (expected && typeof expected === "object") {
                    const matches = Number(expected.stock) === currentStock &&
                        Math.abs(Number(expected.averageCost) - oldAverageCost) < 0.011 &&
                        Math.abs(Number(expected.sellingPrice) - oldSellingPrice) < 0.011 &&
                        String(expected.pricingMethod || "manual").toLowerCase() === oldPricingMethod &&
                        (expected.markupPercentage == null && oldMarkup === null ||
                            expected.markupPercentage != null && oldMarkup !== null &&
                            Math.abs(Number(expected.markupPercentage) - oldMarkup) < 0.0001);
                    if (!matches) {
                        await safeRollback(connection);
                        return jsonResponse(409, headers, {error:
                                "Stock, cost, or pricing changed since Receive Stock was opened. Close and reopen the dialog before confirming."});
                    }
                }
                // Moving weighted average uses units still on hand, NOT the
                // entire history of purchases. Original receipt unit costs are
                // preserved in inventory_stock_receipt_items for auditing.
                const averageCost = roundMoney((currentStock * oldAverageCost +
                    line.quantity * line.unitPurchaseCost) / (currentStock + line.quantity));
                const impliedMarkup = oldAverageCost > 0
                    ? Math.max(0, (oldSellingPrice / oldAverageCost - 1) * 100) : 0;
                const targetMarkup = line.pricingMarkupPercentage !== null
                    ? line.pricingMarkupPercentage
                    : oldPricingMethod === "markup" && oldMarkup !== null
                        ? oldMarkup : Math.round(impliedMarkup * 10000) / 10000;
                const suggestedPrice = roundMoney(averageCost * (1 + targetMarkup / 100));
                // Validate only a price which the user actually chose. An extreme
                // implied markup must not prevent Keep/Manual stock receiving.
                if (line.pricingDecision === "suggested" &&
                    (!Number.isFinite(suggestedPrice) || suggestedPrice > 100000000 ||
                        !Number.isFinite(targetMarkup) || targetMarkup < 0 || targetMarkup > 99999)) {
                    await safeRollback(connection);
                    return badRequest(headers, "The suggested selling price exceeds the allowed pricing range.");
                }
                // Every receiving line, including stock that had reached zero,
                // can now choose Manual or Percentage Markup explicitly.
                // Legacy requests without a choice retain their current retail price.
                const selectedPrice = line.pricingDecision === "suggested"
                    ? suggestedPrice
                    : line.pricingDecision === "manual"
                        ? line.manualSellingPrice : oldSellingPrice;
                const selectedMethod = line.pricingDecision === "suggested"
                    ? "markup"
                    : oldPricingMethod === "markup" && oldMarkup !== null &&
                    line.pricingDecision === "keep" &&
                    Math.abs(selectedPrice - roundMoney(averageCost * (1 + oldMarkup / 100))) < 0.011
                        ? "markup" : "manual";
                // Retain saved markup for manual pricing so Edit Product can
                // still display the previous target if the manager needs it.
                const selectedMarkup = selectedMethod === "markup"
                    ? (line.pricingDecision === "suggested" ? targetMarkup : oldMarkup)
                    : oldMarkup;
                if (!Number.isFinite(selectedPrice) || selectedPrice < 0 || selectedPrice > 100000000) {
                    await safeRollback(connection);
                    return badRequest(headers, "The selected selling price is invalid.");
                }
                receiptLines.push({ ...line, variantName, stockBefore: currentStock,
                    averageCost, selectedPrice, selectedMethod, selectedMarkup });
            }
            const receivedBy = await getRestockReceivedBy(connection, decoded, tokenRole, storeId);
            // Every Receive Stock submission is a single fully received supplier purchase.
            const ledger = await createPurchaseLedger(connection, {
                storeId, branchId:activeBranchId, input:{supplier, supplierInvoiceNumber:invoiceNumber,
                    purchaseDate:receivedDate, paymentMethod, amountPaid, paymentDueDate:dueDate},
                lines:receiptLines.map(line=>({...line, productId})),
                source:"receive", requestKey, receivedBy, receivedDate});
            const receiptId = ledger.receiptId;
            const purchaseId = ledger.purchaseId;
            const totalQuantity = cleanLines.reduce((sum, line) => sum + line.quantity, 0);
            for (const line of receiptLines) {
                if (line.variantId !== null) {
                    await connection.execute(
                        `UPDATE product_variants
                         SET stock = stock + ?, original_price = ?, sales_price = ?,
                             pricing_method = ?, markup_percentage = ?
                         WHERE id = ? AND product_id = ? AND deleted_at IS NULL`,
                        [line.quantity, line.averageCost, line.selectedPrice,
                            line.selectedMethod, line.selectedMarkup, line.variantId, productId]);
                }
                await connection.execute(
                    `INSERT INTO restock_history
                     (store_id, branch_id, product_id, product_name, variant_name,
                      stock_before, quantity_added, current_stock, received_by, received_date)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                    [storeId, activeBranchId, productId, toSafeString(current.name), line.variantName,
                        line.stockBefore, line.quantity, line.stockBefore + line.quantity,
                        receivedBy, receivedDate]);
            }
            if (isVariantProduct) {
                // Parent product's display prices follow the updated variant rows.
                // Preserve its existing pricing method: variant pricing is individual.
                const [updatedVariants] = await connection.execute(
                    `SELECT original_price, sales_price FROM product_variants
                     WHERE product_id = ? AND deleted_at IS NULL`, [productId]);
                const minimumPositive = (field) => {
                    const prices = updatedVariants.map(row => Number(row[field]))
                        .filter(price => Number.isFinite(price) && price > 0);
                    return prices.length ? Math.min(...prices) : 0;
                };
                await connection.execute(
                    `UPDATE products SET stock = stock + ?, original_price = ?, sales_price = ?
                     WHERE id = ? AND store_id = ? AND branch_id = ?`,
                    [totalQuantity, minimumPositive("original_price"), minimumPositive("sales_price"),
                        productId, storeId, activeBranchId]);
            } else {
                const line = receiptLines[0];
                await connection.execute(
                    `UPDATE products SET stock = stock + ?, original_price = ?, sales_price = ?,
                                         pricing_method = ?, markup_percentage = ?
                     WHERE id = ? AND store_id = ? AND branch_id = ?`,
                    [totalQuantity, line.averageCost, line.selectedPrice, line.selectedMethod,
                        line.selectedMarkup, productId, storeId, activeBranchId]);
            }
            const actingEmployee = await getActingEmployee(connection, decoded, tokenRole, storeId);
            await logEmployeeAction(connection, {
                storeId, branchId: activeBranchId, employee: actingEmployee,
                module: "Inventory", referenceNumber: current.product_number || String(productId),
                action: "Restocked inventory", referenceId: String(productId),
                details: `Received ${totalQuantity} unit(s) of ${current.name} from ${supplier} (Receipt #${receiptId})`,
            });
            await connection.commit();
            return jsonResponse(200, headers, {
                success: true, receiptId, purchaseId, receivingNumber:`RCV-${String(receiptId).padStart(6,"0")}`,
                totalQuantity, purchaseTotal: ledger.purchaseTotal,
                amountPaid: ledger.amountPaid,
                outstandingBalance: ledger.outstandingBalance,
            });
        }

        if (action === "get_supplier_payables") {
            // Owners can view all of their store's branches. Managers stay
            // restricted to the assigned branch from their verified token.
            if (!["owner", "manager"].includes(tokenRole)) return unauthorized(headers, "Not permitted.");
            const branchSql = activeBranchId ? " AND p.branch_id=?" : "";
            const branchParams = activeBranchId ? [activeBranchId] : [];
            const [rows] = await connection.execute(
                `SELECT p.id AS purchaseId, p.branch_id AS branchId,
                        b.branch_name AS branchName, p.purchase_number AS purchaseNumber,
                        p.supplier, p.supplier_invoice_number AS supplierInvoiceNumber,
                        p.purchase_total AS purchaseTotal, p.payment_method AS paymentMethod,
                        DATE_FORMAT(p.purchase_date,'%Y-%m-%d') AS purchaseDate,
                        DATE_FORMAT(p.payment_due_date,'%Y-%m-%d') AS paymentDueDate,
                        COALESCE((SELECT SUM(pay.amount) FROM inventory_supplier_payments pay
                                  WHERE pay.purchase_id=p.id),0) AS amountPaid
                 FROM inventory_purchase_transactions p
                          LEFT JOIN branches b ON b.id=p.branch_id AND b.store_id=p.store_id
                 WHERE p.store_id=?${branchSql}
                 ORDER BY p.id DESC`, [storeId, ...branchParams]);
            const payables=rows.map(row=>({...row, purchaseTotal:Number(row.purchaseTotal),amountPaid:Number(row.amountPaid),
                outstandingBalance:Math.max(0,roundMoney(Number(row.purchaseTotal)-Number(row.amountPaid))),
                paymentStatus:Number(row.amountPaid)>=Number(row.purchaseTotal)?"Paid":Number(row.amountPaid)>0?"Partially Paid":"Unpaid"}));
            return jsonResponse(200,headers,{success:true,payables});
        }
        if (action === "get_supplier_purchase_items") {
            if (!["owner", "manager"].includes(tokenRole)) return unauthorized(headers,"Not permitted.");
            const purchaseId=Number(body.purchaseId);
            if(!Number.isInteger(purchaseId)||purchaseId<=0)return badRequest(headers,"Valid purchase ID required.");
            const branchSql=activeBranchId?" AND branch_id=?":"";
            const branchParams=activeBranchId?[activeBranchId]:[];
            const [headersFound]=await connection.execute(
                `SELECT id,purchase_number AS purchaseNumber,supplier,purchase_total AS purchaseTotal
                 FROM inventory_purchase_transactions
                 WHERE id=? AND store_id=?${branchSql} LIMIT 1`,
                [purchaseId,storeId,...branchParams]);
            if(!headersFound.length)return notFound(headers,"Purchase not found in this store/branch.");
            const [rows]=await connection.execute(
                `SELECT pi.product_id AS productId,p.product_number AS productNumber,
                        COALESCE(p.name,'Archived product') AS productName,
                        pi.variant_id AS variantId, v.variant_number AS variantNumber,v.variant_values AS variantValues,
                        pi.quantity_ordered AS quantity,pi.unit_purchase_cost AS unitCost,
                        (pi.quantity_ordered*pi.unit_purchase_cost) AS lineTotal
                 FROM inventory_purchase_items pi
                          LEFT JOIN products p ON p.id=pi.product_id AND p.store_id=?
                          LEFT JOIN product_variants v ON v.id=pi.variant_id AND v.product_id=pi.product_id
                 WHERE pi.purchase_id=? ORDER BY pi.id`,[storeId,purchaseId]);
            return jsonResponse(200,headers,{success:true,purchase:headersFound[0],items:rows.map(row=>({
                    ...row,quantity:Number(row.quantity),unitCost:Number(row.unitCost),lineTotal:roundMoney(Number(row.lineTotal)),
                    variantValues:parseVariantValues(row.variantValues)
                }))});
        }
        if (action === "pay_supplier_purchase") {
            if (!["owner", "manager"].includes(tokenRole)) return unauthorized(headers,"Not permitted.");
            const purchaseId=Number(body.purchaseId), requestKey=toSafeString(body.requestKey,80);
            if (!Number.isInteger(purchaseId) || purchaseId<=0 || !requestKey) return badRequest(headers,"Purchase and payment reference required.");
            let amountCents,date;
            try {amountCents=exactMoney(body.amount,"Amount paid");date=normalizeOptionalDate(body.paymentDate);}
            catch(error) {return badRequest(headers,error.message);}
            if (amountCents<=0 || !date) return badRequest(headers,"Positive payment and payment date are required.");
            if (date > new Date().toLocaleDateString("sv-SE",{timeZone:"Asia/Manila"})) {
                return badRequest(headers,"Payment Date cannot be in the future.");
            }
            const branchSql=activeBranchId?" AND branch_id=?":"";
            const branchParams=activeBranchId?[activeBranchId]:[];
            await connection.beginTransaction();
            const [rows]=await connection.execute(
                `SELECT id,purchase_total AS purchaseTotal FROM inventory_purchase_transactions
                 WHERE id=? AND store_id=?${branchSql} FOR UPDATE`,[purchaseId,storeId,...branchParams]);
            if (!rows.length){await safeRollback(connection);return notFound(headers,"Purchase not found.");}
            const [existingPayment]=await connection.execute(
                `SELECT id FROM inventory_supplier_payments WHERE purchase_id=? AND request_key=? LIMIT 1`,[purchaseId,requestKey]);
            if (existingPayment.length){await connection.commit();return jsonResponse(200,headers,{success:true,alreadyProcessed:true});}
            const [paidRows]=await connection.execute(
                `SELECT COALESCE(SUM(amount),0) AS amountPaid FROM inventory_supplier_payments WHERE purchase_id=?`,[purchaseId]);
            const balanceCents=exactMoney(rows[0].purchaseTotal,"Purchase total")-exactMoney(paidRows[0].amountPaid,"Amount paid");
            if (amountCents>balanceCents){await safeRollback(connection);return badRequest(headers,"Payment exceeds remaining balance.");}
            await connection.execute(`INSERT INTO inventory_supplier_payments (purchase_id,amount,payment_date,request_key)
                                      VALUES (?,?,?,?)`,[purchaseId,amountCents/100,date,requestKey]);
            await connection.commit();
            return jsonResponse(200,headers,{success:true,outstandingBalance:(balanceCents-amountCents)/100});
        }

        if (action === "adjust_stock") {
            if (!["owner","manager"].includes(tokenRole) || !activeBranchId) return unauthorized(headers,"Not permitted.");
            const productId=Number(body.productId), variantId=body.variantId==null?null:Number(body.variantId);
            const expected=Number(body.expectedStock), target=Number(body.newStock);
            const reason=toSafeString(body.reason,500),requestKey=toSafeString(body.requestKey,80);
            if(!Number.isInteger(productId)||productId<=0 || (variantId!==null && (!Number.isInteger(variantId)||variantId<=0)) ||
                !Number.isInteger(expected)||expected<0||!Number.isInteger(target)||target<0 || target>2147483647 ||
                reason.length<8 || !requestKey) return badRequest(headers,"Provide valid current/corrected stock, a reason of at least 8 characters, and a request reference.");
            // Use the existing structured adjustment ledger when available;
            // otherwise log the correction in the existing employee_actions
            // audit history. No additional table is required for this change.
            const hasAdjustmentLedger = await tableExists(connection, "inventory_stock_adjustments");
            await connection.beginTransaction();
            const [products]=await connection.execute(
                `SELECT id,name,product_number AS productNumber,stock,has_variants AS hasVariants FROM products
                 WHERE id=? AND store_id=? AND branch_id=? AND deleted_at IS NULL FOR UPDATE`,
                [productId,storeId,activeBranchId]);
            if(!products.length){await safeRollback(connection);return notFound(headers,"Product not found in this branch.");}
            const p=products[0];
            if (hasAdjustmentLedger) {
                const [duplicates] = await connection.execute(
                    "SELECT id,stock_after AS newStock FROM inventory_stock_adjustments WHERE store_id=? AND branch_id=? AND request_key=? LIMIT 1",
                    [storeId,activeBranchId,requestKey]);
                if (duplicates.length) {await connection.commit();return jsonResponse(200,headers,{success:true,alreadyProcessed:true,newStock:Number(duplicates[0].newStock)});}
            }
            let current, aggregateStock=target;
            if(Boolean(p.hasVariants)) {
                if(variantId===null){await safeRollback(connection);return badRequest(headers,"Select a specific variant to adjust.");}
                const [variants]=await connection.execute(
                    `SELECT id,stock FROM product_variants WHERE product_id=? AND deleted_at IS NULL ORDER BY id FOR UPDATE`,[productId]);
                const selected=variants.find(row=>Number(row.id)===variantId);
                if(!selected){await safeRollback(connection);return badRequest(headers,"Variant not found.");}
                current=Number(selected.stock);
                aggregateStock=variants.reduce((sum,row)=>sum+Number(row.id===variantId?target:row.stock),0);
            }else{
                if(variantId!==null){await safeRollback(connection);return badRequest(headers,"This product has no variants.");}
                current=Number(p.stock);
            }
            if(current!==expected){await safeRollback(connection);return badRequest(headers,`Stock changed since opening this dialog (now ${current}). Reopen and retry.`);}
            if(target===current){await safeRollback(connection);return badRequest(headers,"Corrected quantity must differ from current stock.");}
            if(aggregateStock>2147483647){await safeRollback(connection);return badRequest(headers,"Total stock would exceed the supported limit.");}
            // A correction is never a purchase receipt or POS sale.
            if(variantId!==null) await connection.execute("UPDATE product_variants SET stock=? WHERE id=? AND product_id=?",[target,variantId,productId]);
            await connection.execute("UPDATE products SET stock=? WHERE id=? AND store_id=? AND branch_id=?",[aggregateStock,productId,storeId,activeBranchId]);
            const employee=await getActingEmployee(connection,decoded,tokenRole,storeId);
            if (hasAdjustmentLedger) {
                await connection.execute(
                    `INSERT INTO inventory_stock_adjustments
                     (store_id,branch_id,product_id,variant_id,stock_before,stock_after,quantity_change,reason,employee_name,employee_role,request_key)
                     VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
                    [storeId,activeBranchId,productId,variantId,current,target,target-current,reason,employee.name,employee.role,requestKey]);
            }
            await logEmployeeAction(connection,{storeId,branchId:activeBranchId,employee,
                module:"Inventory",referenceNumber:p.productNumber||String(productId),action:"Corrected stock level",referenceId:String(productId),
                details:`Corrected ${variantId?`variant ${variantId}`:"regular product"} stock ${current} -> ${target} (${target-current>=0?"+":""}${target-current}); reason: ${reason}`});
            await connection.commit();
            return jsonResponse(200,headers,{success:true,productId,variantId,previousStock:current,newStock:target,totalStock:aggregateStock});
        }
        if (action === "get_product_editor_details") {
            // Managers may enter cost and supplier information in Edit Product,
            // but those confidential fields remain hidden in overview lists.
            if (tokenRole !== "owner" && tokenRole !== "manager") {
                return unauthorized(headers, "Only owners and managers may edit supplier purchase details.");
            }
            const productId = Number(body.id);
            if (!Number.isInteger(productId) || productId <= 0) {
                return badRequest(headers, "Invalid product id");
            }
            const product = await getProductById(connection, storeId, activeBranchId, productId);
            if (!product) return notFound(headers, "Product not found");
            const canonical = await findCanonicalInitialPurchase(connection, storeId, Number(product.branchId), productId);
            const raw = canonical || await findInitialPurchase(connection, storeId, Number(product.branchId), productId);
            const purchase = raw ? {
                supplier: raw.supplier,
                supplierInvoiceNumber: raw.supplierInvoiceNumber || null,
                purchaseDate: raw.purchaseDate,
                paymentMethod: raw.paymentMethod,
                purchaseTotal: Number(raw.purchaseTotal),
                amountPaid: Number(raw.amountPaid),
                outstandingBalance: Number(raw.outstandingBalance),
                paymentDueDate: raw.paymentDueDate,
                productCount: Number(raw.productCount || 1),
            } : null;
            return jsonResponse(200, headers, { product, purchase });
        }

        if (action === "get_product_initial_purchase") {
            if (tokenRole !== "owner" && tokenRole !== "manager") {
                return unauthorized(headers, "Insufficient permission to view supplier purchases.");
            }
            const productId = Number(body.id);
            if (!Number.isInteger(productId) || productId <= 0) {
                return badRequest(headers, "Invalid product id");
            }
            const product = await getProductById(connection, storeId, activeBranchId, productId);
            if (!product) return notFound(headers, "Product not found");
            const canonical = await findCanonicalInitialPurchase(connection, storeId, Number(product.branchId), productId);
            if (canonical) {
                return jsonResponse(200,headers,{purchase:tokenRole==="owner"?canonical:{
                        supplier:canonical.supplier,purchaseDate:canonical.purchaseDate,paymentMethod:canonical.paymentMethod}});
            }
            if (!(await tableExists(connection, "inventory_initial_purchases"))) {
                return jsonResponse(200, headers, { purchase: null });
            }
            const [rows] = await connection.execute(
                `SELECT supplier,
                        DATE_FORMAT(purchase_date, '%Y-%m-%d') AS purchaseDate,
                        payment_method AS paymentMethod,
                        purchase_total AS purchaseTotal,
                        amount_paid AS amountPaid,
                        outstanding_balance AS outstandingBalance,
                        DATE_FORMAT(payment_due_date, '%Y-%m-%d') AS paymentDueDate
                 FROM inventory_initial_purchases
                 WHERE store_id = ? AND branch_id = ? AND product_id = ? LIMIT 1`,
                [storeId, Number(product.branchId), productId]
            );
            const row = rows[0];
            if (!row) return jsonResponse(200, headers, { purchase: null });
            const purchase = tokenRole === "owner" ? {
                supplier: row.supplier, purchaseDate: row.purchaseDate,
                paymentMethod: row.paymentMethod,
                purchaseTotal: Number(row.purchaseTotal),
                amountPaid: Number(row.amountPaid),
                outstandingBalance: Number(row.outstandingBalance),
                paymentDueDate: row.paymentDueDate,
            } : {
                supplier: row.supplier, purchaseDate: row.purchaseDate,
                paymentMethod: row.paymentMethod,
            };
            return jsonResponse(200, headers, { purchase });
        }

        /* ATOMIC IMPORT FOR THE THREE-SHEET STOCKNBOOK TEMPLATE.
         * Existing create/update/delete actions and their handlers stay unchanged.
         * A shared Purchase Ref is allocated across its products without
         * duplicating an invoice payment across every variant/product.
         */
        if (action === "import_products_bulk") {
            if (tokenRole !== "owner" && tokenRole !== "manager") {
                return unauthorized(headers, "Only owners and managers can import supplier purchase records.");
            }
            if (!activeBranchId) return badRequest(headers, "branch_id is required");
            const incoming = body.products;
            const singlePurchaseMode = body.importMode === "single_purchase";
            // New Excel flow: one server-controlled purchase grouping for all
            // products. Older API clients still use the existing purchases array.
            const rawPurchases = singlePurchaseMode ? [body.purchase] : (body.purchases || []);
            if (!Array.isArray(incoming) || !incoming.length || incoming.length > 500 ||
                !Array.isArray(rawPurchases) || (singlePurchaseMode &&
                    (!body.purchase || typeof body.purchase !== "object" || Array.isArray(body.purchase)))) {
                return badRequest(headers, "Provide 1–500 import products and a purchase list.");
            }
            try {
                // Validate data BEFORE writing any rows, then repeat duplicate
                // checks under the branch lock in the transaction below.
                const clean = [];
                const names = new Set();
                for (const raw of incoming) {
                    const name = toSafeString(raw.name, 120);
                    const category = toSafeString(raw.category, 120);
                    if (!name || !category) throw new Error("Every imported product needs a name and category.");
                    const key = name.trim().toLowerCase().replace(/\s+/g, " ");
                    if (names.has(key)) throw new Error(`Duplicate product "${name}" in import.`);
                    names.add(key);
                    const variants = getIncomingVariants(raw);
                    const hasVariants = parseBooleanFlag(raw.hasVariants ?? raw.has_variants) || variants.length > 0;
                    if (hasVariants && !variants.length) throw new Error(`Product "${name}" needs variants.`);
                    if (hasVariants && getDuplicateVariantLabel(variants)) throw new Error(`Duplicate variant in product "${name}".`);
                    const stock = hasVariants ? getVariantTotalStock(variants) : Number(raw.stock);
                    const alertLevel = hasVariants ? getVariantTotalAlert(variants) : Number(raw.alertLevel);
                    const cost = hasVariants ? getMinVariantPrice(variants, "originalPrice") : Number(raw.originalPrice);
                    const price = hasVariants ? getMinVariantPrice(variants, "salesPrice") : Number(raw.salesPrice);
                    if (![stock, alertLevel, cost, price].every(n => Number.isFinite(n) && n >= 0) ||
                        !Number.isInteger(stock) || !Number.isInteger(alertLevel) ||
                        variants.some(v => !Number.isInteger(v.stock) || !Number.isInteger(v.alertLevel) ||
                            v.stock < 0 || v.alertLevel < 0 || v.originalPrice < 0 || v.salesPrice < 0)) {
                        throw new Error(`Invalid stock/reorder/pricing numbers in "${name}".`);
                    }
                    const pricing = readPricingSelection(raw);
                    const isPriceConsistent = (record, recordPricing) =>
                        recordPricing.pricingMethod !== "markup" ||
                        Math.abs(roundMoney(record.originalPrice * (1 + recordPricing.markupPercentage / 100)) - Number(record.salesPrice)) < 0.011;
                    if (!hasVariants && !isPriceConsistent({originalPrice: cost, salesPrice: price}, pricing)) {
                        throw new Error(`Markup selling price is incorrect for "${name}".`);
                    }
                    if (variants.some(variant => !isPriceConsistent(variant, readPricingSelection(variant)))) {
                        throw new Error(`A variant has an incorrect markup price in "${name}".`);
                    }
                    const purchaseRef = singlePurchaseMode ? "SINGLE_FILE_PURCHASE" : toSafeString(raw.purchaseRef ?? raw.purchase_ref, 80);
                    const itemCost = roundMoney(hasVariants
                        ? variants.reduce((sum, v) => sum + v.stock * v.originalPrice, 0)
                        : stock * cost);
                    clean.push({ name, category, variants, hasVariants, stock, alertLevel,
                        cost, price, pricing, itemCost, purchaseRef,
                        expirationDate: hasVariants ? null : normalizeOptionalDate(raw.expirationDate ?? raw.expiration_date) });
                }
                if (singlePurchaseMode && rawPurchases.length !== 1) {
                    throw new Error("One Excel file must contain exactly one supplier purchase.");
                }
                const purchases = new Map();
                for (const raw of rawPurchases) {
                    const ref = singlePurchaseMode ? "SINGLE_FILE_PURCHASE" : toSafeString(raw.purchaseRef ?? raw.purchase_ref, 80);
                    const refKey = ref.toLowerCase();
                    if (!ref || purchases.has(refKey)) throw new Error(`Duplicate or empty purchase reference: ${ref}.`);
                    const supplier = toSafeString(raw.supplier, 150);
                    const purchaseDate = normalizeOptionalDate(raw.purchaseDate);
                    const method = String(raw.paymentMethod || "").trim().toLowerCase();
                    const due = normalizeOptionalDate(raw.paymentDueDate);
                    const amountPaid = Number(raw.amountPaid);
                    const supplierInvoiceNumber = toSafeString(raw.supplierInvoiceNumber ?? raw.supplier_invoice_number,80) || null;
                    if (!supplier || !purchaseDate || !["cash", "credit"].includes(method) ||
                        !Number.isFinite(amountPaid) || amountPaid < 0) throw new Error(`Invalid supplier/payment data for ${ref}.`);
                    const lines = clean.filter(product => product.purchaseRef.toLowerCase() === refKey);
                    if (!lines.length) throw new Error(`Unused purchase reference ${ref}.`);
                    const total = roundMoney(lines.reduce((sum, item) => sum + item.itemCost, 0));
                    if (lines.some(item => item.stock <= 0)) throw new Error(`Purchase ${ref} contains a product with no initial stock.`);
                    const paid = method === "cash" ? total : roundMoney(amountPaid);
                    if (method === "credit" && paid > total) throw new Error(`Amount Paid exceeds invoice total for ${ref}.`);
                    if (method === "cash" && amountPaid !== 0 && roundMoney(amountPaid) !== total) throw new Error(`Cash payment must equal invoice total for ${ref}.`);
                    if (method === "credit" && paid < total && !due) throw new Error(`Due date required for unpaid purchase ${ref}.`);
                    if (due && due < purchaseDate) throw new Error(`Due date cannot precede purchase date for ${ref}.`);
                    purchases.set(refKey, {ref, supplier, supplierInvoiceNumber, purchaseDate, method,
                        due: method === "credit" ? due : null, paid, total,
                        lineCosts: lines.map(item => item.itemCost) });
                }
                for (const item of clean) {
                    if (item.purchaseRef && !purchases.has(item.purchaseRef.toLowerCase())) {
                        throw new Error(`No PURCHASE DETAILS entry for ${item.purchaseRef}.`);
                    }
                }
                if (!(await tableExists(connection,"inventory_purchase_transactions"))) {
                    throw new Error("Run the transaction-based inventory SQL migration before importing.");
                }
                await connection.beginTransaction();
                await connection.execute("SELECT id FROM branches WHERE id = ? AND store_id = ? FOR UPDATE", [activeBranchId, storeId]);
                const {storeCode, branchCode} = await getProductCodeContext(connection, storeId, activeBranchId);
                const actingEmployee = await getActingEmployee(connection, decoded, tokenRole, storeId);
                // Only older multi-purchase imports carry user-entered refs.
                // New one-purchase imports have no manual import reference.
                for (const invoice of purchases.values()) {
                    if (singlePurchaseMode) continue;
                    const [existingRefs] = await connection.execute(
                        `SELECT id FROM inventory_purchase_transactions
                         WHERE store_id = ? AND branch_id = ? AND source='import' AND LOWER(import_ref) = ? LIMIT 1`,
                        [storeId, activeBranchId, invoice.ref.toLowerCase()]
                    );
                    if (existingRefs.length) throw new Error(`Purchase Ref ${invoice.ref} already exists in this branch.`);
                }
                const created = [];
                const pendingInvoices = new Map();
                for (const item of clean) {
                    if (await findExistingProductByName(connection, storeId, activeBranchId, item.name)) {
                        throw new Error(`Product "${item.name}" already exists in this branch.`);
                    }
                    const sequence = await reserveNextProductSequence(connection, storeId, activeBranchId);
                    const productNumber = buildProductNumber(storeCode, branchCode, sequence);
                    const [insert] = await connection.execute(
                        `INSERT INTO products (product_number, store_id, branch_id, package_id, package_name,
                                               name, category, stock, alert_level, original_price, sales_price,
                                               pricing_method, markup_percentage, expiration_date, has_variants)
                         VALUES (?, ?, ?, NULL, NULL, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                        [productNumber, storeId, activeBranchId, item.name, item.category, item.stock,
                            item.alertLevel, item.cost, item.price, item.pricing.pricingMethod,
                            item.pricing.markupPercentage, item.expirationDate, item.hasVariants ? 1 : 0]
                    );
                    const productId = insert.insertId;
                    await commitProductSequence(connection, storeId, activeBranchId, sequence);
                    const variantKeys = item.hasVariants ? await insertProductVariants(connection, productId, item.variants) : [];
                    if (item.purchaseRef) {
                        const refKey=item.purchaseRef.toLowerCase();
                        const purchaseLines=pendingInvoices.get(refKey) || [];
                        if (item.hasVariants) item.variants.forEach((variant,i)=>{
                            if (variant.stock>0) purchaseLines.push({productId,variantId:variantKeys[i].id,quantity:variant.stock,
                                unitPurchaseCost:variant.originalPrice,expirationDate:variant.expirationDate});
                        });
                        else if (item.stock>0) purchaseLines.push({productId,variantId:null,quantity:item.stock,
                            unitPurchaseCost:item.cost,expirationDate:item.expirationDate});
                        pendingInvoices.set(refKey,purchaseLines);
                    }
                    await logEmployeeAction(connection, {storeId, branchId: activeBranchId,
                        employee: actingEmployee, module:"Inventory", referenceNumber:productNumber,
                        action:"Added product", referenceId:String(productId),
                        details:`Added ${item.name}${item.hasVariants?` with ${item.variants.length} variant(s)`:""} to inventory`});
                    created.push({id:productId, productNumber, name:item.name});
                }
                for (const [refKey, invoice] of purchases) {
                    const purchaseLines=pendingInvoices.get(refKey) || [];
                    if (!purchaseLines.length) throw new Error(`Purchase ${invoice.ref} has no received units.`);
                    const ledger=await createPurchaseLedger(connection,{
                        storeId,branchId:activeBranchId, source:"import",
                        purchaseRef:singlePurchaseMode ? null : invoice.ref,
                        input:{supplier:invoice.supplier,supplierInvoiceNumber:invoice.supplierInvoiceNumber,
                            purchaseDate:invoice.purchaseDate,paymentMethod:invoice.method,
                            amountPaid:invoice.paid,paymentDueDate:invoice.due},
                        lines:purchaseLines,receivedBy:actingEmployee.name,
                    });
                }
                await connection.commit();
                return jsonResponse(201, headers, {success:true, products:created});
            } catch (error) {
                await safeRollback(connection);
                return badRequest(headers, error instanceof Error ? error.message : "Unable to import products.");
            }
        }

        if (action === "create_product") {
            const name = toSafeString(body.name, 120);
            const category = toSafeString(body.category, 120);
            const packageId = toNumber(firstDefined(body.packageId, body.package_id));
            const packageName = toSafeString(firstDefined(body.packageName, body.package_name), 255);

            const incomingVariants = getIncomingVariants(body);
            const hasVariants =
                parseBooleanFlag(firstDefined(body.hasVariants, body.has_variants)) ||
                incomingVariants.length > 0;

            if (!name || !category) {
                return badRequest(headers, "name and category are required");
            }

            if (!activeBranchId) {
                return badRequest(headers, "branch_id is required");
            }

            if (hasVariants && incomingVariants.length === 0) {
                return badRequest(headers, "Please add at least one valid variant");
            }

            const existingProduct = await findExistingProductByName(
                connection,
                storeId,
                activeBranchId,
                name
            );

            if (existingProduct) {
                return badRequest(
                    headers,
                    `Product "${name}" already exists in this branch.`
                );
            }

            const duplicateVariantLabel = hasVariants
                ? getDuplicateVariantLabel(incomingVariants)
                : "";

            if (duplicateVariantLabel) {
                return badRequest(
                    headers,
                    `Variant "${duplicateVariantLabel}" already exists in this product.`
                );
            }

            const stock = hasVariants
                ? getVariantTotalStock(incomingVariants)
                : toNumber(firstDefined(body.stock, body.quantity, body.qty)) ?? 0;

            const alertLevel = hasVariants
                ? getVariantTotalAlert(incomingVariants)
                : toNumber(firstDefined(body.alertLevel, body.alert_level, body.alert)) ?? 0;

            const originalPrice = hasVariants
                ? getMinVariantPrice(incomingVariants, "originalPrice")
                : toNumber(firstDefined(body.originalPrice, body.original_price, body.cost_price)) ?? 0;

            const salesPrice = hasVariants
                ? getMinVariantPrice(incomingVariants, "salesPrice")
                : toNumber(firstDefined(body.salesPrice, body.sales_price, body.price)) ?? 0;
            const pricing = readPricingSelection(body);
            try {validateProductInventoryInputs(body,stock,alertLevel,originalPrice,salesPrice,incomingVariants);}
            catch(error){return badRequest(headers,error.message);}

            let initialPurchase;
            try {
                initialPurchase = getInitialPurchaseInput(body, stock, originalPrice, incomingVariants);
            } catch (purchaseError) {
                return badRequest(headers, purchaseError.message);
            }
            if (stock>0 && !initialPurchase && !parseBooleanFlag(body.openingStock ?? body.opening_stock)) {
                return badRequest(headers,"Initial stock requires supplier purchase details or explicit Opening Stock.");
            }
            if (initialPurchase && tokenRole !== "owner" && tokenRole !== "manager") {
                return unauthorized(headers, "Only owners and managers may record supplier purchases.");
            }
            if (initialPurchase && !(await tableExists(connection,"inventory_purchase_transactions"))) {
                return badRequest(headers,"Run the transaction-based inventory migration before saving supplier stock.");
            }

            const expirationDate = hasVariants
                ? null
                : normalizeOptionalDate(
                    firstDefined(
                        body.expirationDate,
                        body.expiration_date,
                        body.expiryDate,
                        body.expiry_date
                    )
                );

            await connection.beginTransaction();

            // Lock the branch row while allocating the next branch-local product
            // sequence so two simultaneous product creations cannot receive the
            // same STORE-BRANCH-NUMBEROFPRODUCT value.
            await connection.execute(
                `SELECT id
                 FROM branches
                 WHERE id = ?
                   AND store_id = ?
                     FOR UPDATE`,
                [activeBranchId, storeId]
            );

            // Re-check under the branch lock: concurrent saves cannot create duplicate products.
            if (await findExistingProductByName(connection,storeId,activeBranchId,name)) {
                await safeRollback(connection);
                return badRequest(headers,`Product "${name}" already exists in this branch.`);
            }

            const { storeCode, branchCode } = await getProductCodeContext(
                connection,
                storeId,
                activeBranchId
            );
            const nextProductSequence = await reserveNextProductSequence(
                connection,
                storeId,
                activeBranchId
            );
            const productNumber = buildProductNumber(
                storeCode,
                branchCode,
                nextProductSequence
            );

            const [result] = await connection.execute(
                `INSERT INTO products
                 (product_number, store_id, branch_id, package_id, package_name, name, category, stock, alert_level, original_price, sales_price, pricing_method, markup_percentage, expiration_date, has_variants)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                [
                    productNumber,
                    storeId,
                    activeBranchId,
                    packageId,
                    packageName || null,
                    name,
                    category,
                    stock,
                    alertLevel,
                    originalPrice,
                    salesPrice,
                    pricing.pricingMethod,
                    pricing.markupPercentage,
                    expirationDate,
                    hasVariants ? 1 : 0,
                ]
            );

            const productId = result.insertId;

            await commitProductSequence(
                connection,
                storeId,
                activeBranchId,
                nextProductSequence
            );

            if (hasVariants) {
                await insertProductVariants(connection, productId, incomingVariants);
            }

            // One normalized supplier transaction for every initial supplier purchase;
            // zero-stock/opening balances never create a payable.
            if (initialPurchase) {
                const savedVariants=hasVariants ? (await getProductById(connection,storeId,activeBranchId,productId)).variants : [];
                const lines=hasVariants ? incomingVariants.map((variant,i)=>({
                    productId,variantId:savedVariants[i].id,quantity:variant.stock,
                    unitPurchaseCost:variant.originalPrice, expirationDate:variant.expirationDate,
                })).filter(line=>line.quantity>0) : [{productId,variantId:null,quantity:stock,
                    unitPurchaseCost:originalPrice,expirationDate}];
                await createPurchaseLedger(connection,{storeId,branchId:activeBranchId,source:"add",
                    input:initialPurchase,lines,receivedBy:decoded?.email || "System"});
            }

            const actingEmployee = await getActingEmployee(
                connection,
                decoded,
                tokenRole,
                storeId
            );

            await logEmployeeAction(connection, {
                storeId,
                branchId: activeBranchId,
                employee: actingEmployee,
                module: "Inventory",
                referenceNumber: productNumber,
                action: "Added product",
                referenceId: String(productId),
                details: `Added ${name}${hasVariants ? ` with ${incomingVariants.length} variant(s)` : ""} to inventory`,
            });

            await connection.commit();

            const product = await getProductById(
                connection,
                storeId,
                activeBranchId,
                productId
            );

            return jsonResponse(201, headers, {
                success: true,
                product,
            });
        }

        if (action === "update_product") {
            const id = Number(body.id);

            if (!Number.isInteger(id) || id <= 0) {
                return badRequest(headers, "Invalid product id");
            }

            const existing = await getProductById(
                connection,
                storeId,
                activeBranchId,
                id
            );

            if (!existing) {
                return notFound(headers, "Product not found");
            }

            const name = toSafeString(body.name, 120);
            const category = toSafeString(body.category, 120);
            const packageId = toNumber(firstDefined(body.packageId, body.package_id));
            const packageName = toSafeString(firstDefined(body.packageName, body.package_name), 255);

            const incomingVariants = getIncomingVariants(body);
            const hasVariants =
                parseBooleanFlag(firstDefined(body.hasVariants, body.has_variants)) ||
                incomingVariants.length > 0;

            if (!name || !category) {
                return badRequest(headers, "name and category are required");
            }

            if (hasVariants && incomingVariants.length === 0) {
                return badRequest(headers, "Please add at least one valid variant");
            }

            const duplicateProduct = await findExistingProductByName(
                connection,
                storeId,
                activeBranchId,
                name,
                id
            );

            if (duplicateProduct) {
                return badRequest(
                    headers,
                    `Product "${name}" already exists in this branch.`
                );
            }

            const duplicateVariantLabel = hasVariants
                ? getDuplicateVariantLabel(incomingVariants)
                : "";

            if (duplicateVariantLabel) {
                return badRequest(
                    headers,
                    `Variant "${duplicateVariantLabel}" already exists in this product.`
                );
            }

            const stock = hasVariants
                ? getVariantTotalStock(incomingVariants)
                : toNumber(firstDefined(body.stock, body.quantity, body.qty)) ?? 0;

            const alertLevel = hasVariants
                ? getVariantTotalAlert(incomingVariants)
                : toNumber(firstDefined(body.alertLevel, body.alert_level, body.alert)) ?? 0;

            const originalPrice = hasVariants
                ? getMinVariantPrice(incomingVariants, "originalPrice")
                : toNumber(firstDefined(body.originalPrice, body.original_price, body.cost_price)) ?? 0;

            const salesPrice = hasVariants
                ? getMinVariantPrice(incomingVariants, "salesPrice")
                : toNumber(firstDefined(body.salesPrice, body.sales_price, body.price)) ?? 0;
            const pricing = readPricingSelection(body);
            try {validateProductInventoryInputs(body,stock,alertLevel,originalPrice,salesPrice,incomingVariants);}
            catch(error){return badRequest(headers,error.message);}

            const expirationDate = hasVariants
                ? null
                : normalizeOptionalDate(
                    firstDefined(
                        body.expirationDate,
                        body.expiration_date,
                        body.expiryDate,
                        body.expiry_date
                    )
                );

            // Changes to an existing supplier purchase are validated and audited below.
            const editPurchaseDetails = body.initialPurchase ?? body.initial_purchase;
            if (editPurchaseDetails != null && !["owner","manager"].includes(tokenRole)) {
                return unauthorized(headers,"Only owners and managers may correct purchase details.");
            }
            const existingVariants=Array.isArray(existing.variants)?existing.variants:[];
            if (Boolean(existing.hasVariants) !== hasVariants) {
                return badRequest(headers,"Changing a product between regular and variant types requires a separate migration.");
            }
            const existingById=new Map(existingVariants.map(v=>[Number(v.id),v]));
            if (hasVariants) {
                const submittedIds=incomingVariants.filter(v=>v.id).map(v=>Number(v.id));
                if (new Set(submittedIds).size!==submittedIds.length || submittedIds.some(id=>!existingById.has(id)) ||
                    existingVariants.some(v=>!submittedIds.includes(Number(v.id)))) {
                    return badRequest(headers,"Editing must preserve existing Variant IDs; archiving variants requires a separate action.");
                }
                for (const v of incomingVariants) {
                    if (v.id && Number(v.stock)!==Number(existingById.get(Number(v.id)).stock)) {
                        return badRequest(headers,"Use Receive Stock or Stock Adjustment to change variant quantity.");
                    }
                    if (!v.id && Number(v.stock)!==0) return badRequest(headers,"New variants must start at 0 stock.");
                }
            } else if (stock !== Number(existing.stock)) {
                return badRequest(headers,"Use Receive Stock or Stock Adjustment to change quantity.");
            }
            const stableStock=Number(existing.stock);
            await connection.beginTransaction();
            // Serialize edits and receives to avoid overwriting changes to inventory quantities.
            await connection.execute("SELECT id FROM products WHERE id=? AND store_id=? AND branch_id=? FOR UPDATE",
                [id,storeId,Number(existing.branchId)]);
            if (hasVariants) {
                const [lockedVariants]=await connection.execute(
                    "SELECT id,stock FROM product_variants WHERE product_id=? AND deleted_at IS NULL FOR UPDATE",[id]);
                const lockedMap=new Map(lockedVariants.map(v=>[Number(v.id),Number(v.stock)]));
                if (existingVariants.some(v=>lockedMap.get(Number(v.id))!==Number(v.stock))) {
                    await safeRollback(connection);
                    return badRequest(headers,"Stock changed while you were editing. Reload and try again.");
                }
            } else {
                const [lockedProducts]=await connection.execute("SELECT stock FROM products WHERE id=? FOR UPDATE",[id]);
                if (!lockedProducts.length || Number(lockedProducts[0].stock)!==stableStock) {
                    await safeRollback(connection);
                    return badRequest(headers,"Stock changed while you were editing. Reload and try again.");
                }
            }

            let purchaseChangeLog = "";
            if (editPurchaseDetails != null) {
                const branchForEdit = Number(existing.branchId);
                const canonical = await findCanonicalInitialPurchase(connection, storeId, branchForEdit, id);
                if (canonical) {
                    // Lock one shared purchase header. Editing a shared import updates the
                    // purchase ONCE, never one balance per product.
                    const [lockedPurchases] = await connection.execute(
                        `SELECT id,purchase_number AS purchaseNumber,purchase_total AS purchaseTotal,
                                supplier,supplier_invoice_number AS invoiceNumber,
                                DATE_FORMAT(purchase_date,'%Y-%m-%d') AS purchaseDate,
                                payment_method AS paymentMethod,
                                DATE_FORMAT(payment_due_date,'%Y-%m-%d') AS dueDate
                         FROM inventory_purchase_transactions
                         WHERE id=? AND store_id=? AND branch_id=? FOR UPDATE`,
                        [canonical.purchaseId,storeId,branchForEdit]);
                    if (!lockedPurchases.length) {
                        await safeRollback(connection);
                        return badRequest(headers,"The original purchase was changed. Reopen Edit Product.");
                    }
                    const original = lockedPurchases[0];
                    let revised;
                    try {
                        revised = getInitialPurchaseInput({initialPurchase:editPurchaseDetails},
                            stableStock,originalPrice,incomingVariants,Number(original.purchaseTotal));
                    } catch (error) {
                        await safeRollback(connection);
                        return badRequest(headers,error.message);
                    }
                    const [paymentRows] = await connection.execute(
                        `SELECT id,amount,request_key FROM inventory_supplier_payments
                         WHERE purchase_id=? ORDER BY id FOR UPDATE`,[original.id]);
                    const currentPaidCents = paymentRows.reduce((sum,row)=>sum+Math.round(Number(row.amount)*100),0);
                    const targetPaidCents = exactMoney(revised.amountPaid,"Amount Paid");
                    if (editPurchaseDetails.expectedAmountPaid !== undefined &&
                        exactMoney(editPurchaseDetails.expectedAmountPaid,"Previously Recorded Amount Paid") !== currentPaidCents) {
                        await safeRollback(connection);
                        return badRequest(headers,"Supplier payments have changed since you opened Edit Product. Reopen the dialog before saving.");
                    }
                    const totalCents = exactMoney(original.purchaseTotal,"Original Purchase Total");
                    if (targetPaidCents > totalCents || targetPaidCents < 0) {
                        await safeRollback(connection);
                        return badRequest(headers,"Amount Paid must be between zero and the original purchase total.");
                    }
                    // Existing supplier payments remain intact. A signed correction entry
                    // changes the payable total without deleting a historical payment row.
                    const delta = targetPaidCents-currentPaidCents;
                    if (delta !== 0) {
                        await connection.execute(
                            `INSERT INTO inventory_supplier_payments(purchase_id,amount,payment_date,request_key)
                             VALUES(?,?,?,?)`,
                            [original.id,delta/100,revised.purchaseDate,
                                `EDIT-CORRECTION-${id}-${Date.now()}-${Math.random().toString(36).slice(2,8)}`]);
                    }
                    await connection.execute(
                        `UPDATE inventory_purchase_transactions
                         SET supplier=?,supplier_invoice_number=?,purchase_date=?,
                             payment_method=?,payment_due_date=?
                         WHERE id=? AND store_id=? AND branch_id=?`,
                        [revised.supplier,revised.supplierInvoiceNumber,revised.purchaseDate,
                            revised.paymentMethod,revised.paymentDueDate,original.id,storeId,branchForEdit]);
                    purchaseChangeLog = `Corrected ${original.purchaseNumber || original.id} supplier/payment details (paid: ${currentPaidCents/100} -> ${targetPaidCents/100}); original total preserved`;
                } else {
                    // Older StockNBook records may have only the legacy initial purchase.
                    const legacy = await findInitialPurchase(connection,storeId,branchForEdit,id,true);
                    if (!legacy) {
                        await safeRollback(connection);
                        return badRequest(headers,"No original supplier purchase exists for this product. Do not create a new purchase through Edit Product.");
                    }
                    let revised;
                    try {
                        revised = getInitialPurchaseInput({initialPurchase:editPurchaseDetails},
                            stableStock,originalPrice,incomingVariants,Number(legacy.purchaseTotal));
                    } catch(error) {
                        await safeRollback(connection);
                        return badRequest(headers,error.message);
                    }
                    await updateInitialPurchase(connection,storeId,branchForEdit,id,revised,legacy);
                    purchaseChangeLog = `Corrected legacy initial purchase ${legacy.id}; original total preserved`;
                }
            }

            let query = `
                UPDATE products
                SET
                    package_id = ?,
                    package_name = ?,
                    name = ?,
                    category = ?,
                    stock = ?,
                    alert_level = ?,
                    original_price = ?,
                    sales_price = ?,
                    pricing_method = ?,
                    markup_percentage = ?,
                    expiration_date = ?,
                    has_variants = ?
                WHERE id = ?
                  AND store_id = ?
            `;

            const params = [
                packageId,
                packageName || null,
                name,
                category,
                stableStock,
                alertLevel,
                originalPrice,
                salesPrice,
                pricing.pricingMethod,
                pricing.markupPercentage,
                expirationDate,
                hasVariants ? 1 : 0,
                id,
                storeId,
            ];

            if (activeBranchId) {
                query += " AND branch_id = ?";
                params.push(activeBranchId);
            }

            const [result] = await connection.execute(query, params);

            if (result.affectedRows === 0) {
                await safeRollback(connection);
                return notFound(headers, "Product not found");
            }

            // Never DELETE+INSERT existing variants. Their IDs/variant numbers anchor POS,
            // purchases, receipts, bookings, and audit references.
            if (hasVariants) {
                for (const v of incomingVariants) {
                    if (v.id) {
                        await connection.execute(
                            `UPDATE product_variants SET variant_values=?, alert_level=?, original_price=?,
                                                         sales_price=?, pricing_method=?, markup_percentage=?, expiration_date=?
                             WHERE id=? AND product_id=? AND deleted_at IS NULL`,
                            [JSON.stringify(v.variantValues),v.alertLevel,v.originalPrice,v.salesPrice,
                                v.pricingMethod,v.markupPercentage,v.expirationDate,v.id,id]);
                    }
                }
                const added=incomingVariants.filter(v=>!v.id);
                if (added.length) await insertProductVariants(connection,id,added);
            }
            const product = await getProductById(
                connection,
                storeId,
                activeBranchId,
                id
            );

            const actingEmployee = await getActingEmployee(
                connection,
                decoded,
                tokenRole,
                storeId
            );

            await logEmployeeAction(connection, {
                storeId,
                branchId: activeBranchId,
                employee: actingEmployee,
                module: "Inventory",
                referenceNumber: existing.productNumber || existing.product_number || String(id),
                action: "Updated product",
                referenceId: String(id),
                details: `Updated details for ${name}${purchaseChangeLog ? "; "+purchaseChangeLog : ""}`,
            });

            await connection.commit();

            return jsonResponse(200, headers, {
                success: true,
                product,
            });
        }

        // Manager Stock Action Center: review and remove only the selected variant.
        // Do not delegate these actions to delete_product (which is parent-wide).
        if (action === "get_variant_removal_impact" || action === "delete_variant") {
            if (!["owner", "manager"].includes(tokenRole)) {
                return unauthorized(headers, "Only owners and managers may remove inventory variants.");
            }
            const productId = Number(body.id ?? body.productId);
            const variantId = Number(body.variantId ?? body.variant_id);
            if (!Number.isInteger(productId) || productId <= 0 ||
                !Number.isInteger(variantId) || variantId <= 0) {
                return badRequest(headers, "Valid Product ID and Variant ID are required.");
            }
            const existing = await getProductById(connection, storeId, activeBranchId, productId);
            if (!existing || !existing.hasVariants) return notFound(headers, "Variant product not found.");
            const variant = (existing.variants || []).find(item => Number(item.id) === variantId);
            if (!variant) return notFound(headers, "Selected variant not found in this branch.");
            if (!isVariantExpiryRemovalEligible(variant)) {
                return jsonResponse(409, headers, {
                    success: false, error: "Only expired or expiring-soon variants can be removed from this review action.",
                });
            }

            if (action === "get_variant_removal_impact") {
                const impact = await getVariantRemovalImpact(connection, storeId, activeBranchId, existing, variant);
                return jsonResponse(200, headers, { success: true, impact });
            }

            const employee = await getActingEmployee(connection, decoded, tokenRole, storeId);
            const attempt = async (forceArchive) => {
                await connection.beginTransaction();
                try {
                    const result = await applyVariantRemoval(
                        connection, storeId, activeBranchId, productId, variantId, employee, forceArchive
                    );
                    await connection.commit();
                    return result;
                } catch (error) {
                    await safeRollback(connection);
                    throw error;
                }
            };
            let result;
            try {
                result = await attempt(false);
            } catch (error) {
                if (error.removalStatus) {
                    return jsonResponse(error.removalStatus, headers, {
                        success: false, error: error.message, impact: error.impact || null,
                    });
                }
                // An unforeseen FK reference may prevent physical deletion;
                // retry safely as an archive, never delete history.
                if (!["ER_ROW_IS_REFERENCED", "ER_ROW_IS_REFERENCED_2"].includes(error.code)) {
                    throw error;
                }
                try {
                    result = await attempt(true);
                } catch (retryError) {
                    if (retryError.removalStatus) {
                        return jsonResponse(retryError.removalStatus, headers, {
                            success: false, error: retryError.message, impact: retryError.impact || null,
                        });
                    }
                    throw retryError;
                }
            }
            return jsonResponse(200, headers, {
                success: true,
                mode: result.mode,
                impact: result.impact,
                message: result.mode === "archive"
                    ? "Selected variant archived. Other variants remain active."
                    : "Selected unused variant deleted. Other variants remain active.",
            });
        }

        if (action === "get_product_removal_impact") {
            const id = Number(body.id);

            if (!Number.isInteger(id) || id <= 0) {
                return badRequest(headers, "Invalid product id");
            }

            const existing = await getProductById(
                connection,
                storeId,
                activeBranchId,
                id
            );

            if (!existing) {
                return notFound(headers, "Product not found");
            }

            const impact = await getProductRemovalImpact(
                connection,
                storeId,
                activeBranchId,
                existing
            );

            return jsonResponse(200, headers, {
                success: true,
                impact,
            });
        }

        if (action === "delete_product") {
            const id = Number(body.id);

            if (!Number.isInteger(id) || id <= 0) {
                return badRequest(headers, "Invalid product id");
            }

            const existing = await getProductById(
                connection,
                storeId,
                activeBranchId,
                id
            );

            if (!existing) {
                return notFound(headers, "Product not found");
            }

            // Re-check on the server when the user confirms. The UI preview is
            // informative only; the backend remains the source of truth.
            const impact = await getProductRemovalImpact(
                connection,
                storeId,
                activeBranchId,
                existing
            );

            if (impact.mode === "blocked") {
                return jsonResponse(409, headers, {
                    success: false,
                    mode: "blocked",
                    error: impact.blockers[0] || "This product cannot be removed yet.",
                    impact,
                });
            }

            const actingEmployee = await getActingEmployee(
                connection,
                decoded,
                tokenRole,
                storeId
            );

            await connection.beginTransaction();

            let finalMode = impact.mode;

            try {
                if (impact.mode === "archive") {
                    const affectedRows = await archiveProduct(
                        connection,
                        storeId,
                        activeBranchId,
                        id
                    );

                    if (affectedRows === 0) {
                        throw new Error("Product could not be archived because it is no longer active.");
                    }

                    await logEmployeeAction(connection, {
                        storeId,
                        branchId: activeBranchId,
                        employee: actingEmployee,
                        module: "Inventory",
                        referenceNumber: existing.productNumber || existing.product_number || String(id),
                        action: "Archived product",
                        referenceId: String(id),
                        details: `Archived ${existing.name} to preserve historical business records`,
                    });
                } else {
                    const affectedRows = await permanentlyDeleteProduct(
                        connection,
                        storeId,
                        activeBranchId,
                        id
                    );

                    if (affectedRows === 0) {
                        throw new Error("Product could not be permanently deleted.");
                    }

                    await logEmployeeAction(connection, {
                        storeId,
                        branchId: activeBranchId,
                        employee: actingEmployee,
                        module: "Inventory",
                        referenceNumber: existing.productNumber || existing.product_number || String(id),
                        action: "Permanently deleted product",
                        referenceId: String(id),
                        details: `Permanently deleted unused product ${existing.name}`,
                    });
                }

                await connection.commit();
            } catch (removalError) {
                await safeRollback(connection);

                // A foreign-key relationship unknown to this Lambda may still
                // prevent a physical delete. In that situation, never destroy
                // history: safely archive instead.
                if (impact.mode !== "permanent") {
                    throw removalError;
                }

                await connection.beginTransaction();

                const archivedRows = await archiveProduct(
                    connection,
                    storeId,
                    activeBranchId,
                    id
                );

                if (archivedRows === 0) {
                    throw removalError;
                }

                finalMode = "archive";

                await logEmployeeAction(connection, {
                    storeId,
                    branchId: activeBranchId,
                    employee: actingEmployee,
                    module: "Inventory",
                    referenceNumber: existing.productNumber || existing.product_number || String(id),
                    action: "Archived product",
                    referenceId: String(id),
                    details: `Archived ${existing.name} because a related system record prevented permanent deletion`,
                });

                await connection.commit();
            }

            return jsonResponse(200, headers, {
                success: true,
                mode: finalMode,
                impact: {
                    ...impact,
                    mode: finalMode,
                },
                message:
                    finalMode === "archive"
                        ? "Product archived successfully. Historical records were preserved."
                        : "Unused product permanently deleted successfully.",
            });
        }

        return badRequest(headers, "Invalid action");
    } catch (err) {
        await safeRollback(connection);
        return serverError(headers, err);
    } finally {
        if (connection) {
            await connection.end();
        }
    }
};
